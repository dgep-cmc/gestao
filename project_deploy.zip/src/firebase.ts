import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDocFromServer,
  initializeFirestore
} from 'firebase/firestore';
// Fallback to environment variables since the config file is optional/removed
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
  firestoreDatabaseId: import.meta.env.VITE_FIREBASE_DATABASE_ID || '(default)',
};

let app, db: ReturnType<typeof getFirestore>, auth: ReturnType<typeof getAuth>;

try {
  app = initializeApp(firebaseConfig);
  db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');
  auth = getAuth(app);
} catch (error) {
  console.error("Firebase Initialization Error. Verifique as variáveis de ambiente:", error);
  // Default mocks if it fails completely (so the UI doesn't crash on boot)
  app = {} as any;
  db = {} as any;
  auth = {} as any;
}

export { db, auth, app };
export const isFirebaseConfigured = !!firebaseConfig.apiKey;
export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('https://www.googleapis.com/auth/drive');

let cachedAccessToken: string | null = null;
let currentLoginPromise: Promise<any> | null = null;

export const loginWithGoogle = async () => {
  if (currentLoginPromise) {
    return currentLoginPromise;
  }

  currentLoginPromise = (async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        cachedAccessToken = credential.accessToken;
      }
      return result;
    } finally {
      currentLoginPromise = null;
    }
  })();

  return currentLoginPromise;
};

export const logout = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

export const getAccessToken = () => cachedAccessToken;
