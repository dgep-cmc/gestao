import React from 'react';
import { motion } from 'motion/react';
import { FileText, UserPlus, ArrowRight, Lock, Users } from 'lucide-react';
import { UserProfile } from '../types';
import { LOGO_BASE64 } from '../lib/logo';
import pkg from '../../package.json';

interface ModuleSelectorProps {
  onSelect: (module: 'frequency' | 'frequency_comissionados' | 'hiring' | 'hiring_comissionados') => void;
  profile: UserProfile | null;
  onOpenUserManagement?: () => void;
}

export default function ModuleSelector({ onSelect, profile, onOpenUserManagement }: ModuleSelectorProps) {
  const isModuleAllowed = (module: 'frequency' | 'frequency_comissionados' | 'hiring' | 'hiring_comissionados') => {
    if (!profile) return false;
    if (profile.role === 'master') return true;
    return profile.allowedModules?.includes(module);
  };

  const frequencyAllowed = isModuleAllowed('frequency');
  const frequencyComissionadosAllowed = isModuleAllowed('frequency_comissionados');
  const hiringAllowed = isModuleAllowed('hiring');
  const hiringComissionadosAllowed = isModuleAllowed('hiring_comissionados');

  const bothFrequenciesLocked = !frequencyAllowed && !frequencyComissionadosAllowed;
  const bothHiringsLocked = !hiringAllowed && !hiringComissionadosAllowed;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-10">
          <div className="mx-auto mb-6">
            <img src={LOGO_BASE64} alt="CMC Logo" className="h-20 w-auto mx-auto object-contain mix-blend-multiply" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Portal de Gerenciamento de Pessoas</h1>
          <p className="text-sm font-bold text-blue-600 uppercase tracking-tighter opacity-80">Diretoria de Gestão de Pessoas</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div 
            className={`group relative bg-white p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200 text-left transition-all ${
              !bothFrequenciesLocked 
                ? 'hover:border-blue-300' 
                : 'opacity-50 cursor-not-allowed grayscale'
            }`}
          >
            <div className={`w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 border border-slate-100 ${
              !bothFrequenciesLocked ? 'bg-blue-50 text-blue-600' : 'text-slate-400'
            }`}>
              <FileText className="w-8 h-8" />
            </div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-2xl font-bold text-slate-900">Módulo de Frequência</h2>
              {bothFrequenciesLocked && <Lock className="w-4 h-4 text-slate-400" />}
            </div>
            <p className="text-sm text-slate-500 mb-8 leading-relaxed font-medium">
              Gestão de frequências mensais, validações de atestados e relatórios de efetividade.
            </p>
            
            <div className="flex flex-col gap-3">
              <button
                id="btn-frequencia-estagiarios"
                disabled={!frequencyAllowed}
                onClick={() => frequencyAllowed && onSelect('frequency')}
                className={`w-full flex items-center justify-between px-5 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                  frequencyAllowed 
                    ? 'cursor-pointer bg-sky-500 hover:bg-sky-600 text-white shadow-md shadow-sky-200/30 active:scale-[0.98]' 
                    : 'bg-slate-150 text-slate-400 cursor-not-allowed opacity-60 border border-slate-150'
                }`}
              >
                <span>Frequência de Estagiários</span>
                {frequencyAllowed ? <ArrowRight className="w-4 h-4" /> : <Lock className="w-4 h-4 text-slate-450" />}
              </button>
              <button
                id="btn-frequencia-comissionados"
                disabled={!frequencyComissionadosAllowed}
                onClick={() => frequencyComissionadosAllowed && onSelect('frequency_comissionados')}
                className={`w-full flex items-center justify-between px-5 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                  frequencyComissionadosAllowed 
                    ? 'cursor-pointer bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-200/30 active:scale-[0.98]' 
                    : 'bg-slate-150 text-slate-400 cursor-not-allowed opacity-60 border border-slate-155'
                }`}
              >
                <span>Frequência de Comissionados</span>
                {frequencyComissionadosAllowed ? <ArrowRight className="w-4 h-4" /> : <Lock className="w-4 h-4 text-slate-455" />}
              </button>
            </div>
          </div>

          <div 
            className={`group relative bg-white p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200 text-left transition-all ${
              !bothHiringsLocked 
                ? 'hover:border-emerald-300' 
                : 'opacity-50 cursor-not-allowed grayscale'
            }`}
          >
            <div className={`w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 border border-slate-100 ${
              !bothHiringsLocked ? 'bg-emerald-50 text-emerald-600' : 'text-slate-400'
            }`}>
              <UserPlus className="w-8 h-8" />
            </div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-2xl font-bold text-slate-900">Módulo de Contratação</h2>
              {bothHiringsLocked && <Lock className="w-4 h-4 text-slate-400" />}
            </div>
            <p className="text-sm text-slate-500 mb-8 leading-relaxed font-medium">
              Solicitações de contratação, abertura de vagas, nomeações e assinaturas digitais.
            </p>
            
            <div className="flex flex-col gap-3">
              <button
                id="btn-contratacao-estagiarios"
                disabled={!hiringAllowed}
                onClick={() => hiringAllowed && onSelect('hiring')}
                className={`w-full flex items-center justify-between px-5 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                  hiringAllowed 
                    ? 'cursor-pointer bg-emerald-500 hover:bg-emerald-600 text-white shadow-md shadow-emerald-200/30 active:scale-[0.98]' 
                    : 'bg-slate-150 text-slate-400 cursor-not-allowed opacity-60 border border-slate-150'
                }`}
              >
                <span>Contratação de Estagiários</span>
                {hiringAllowed ? <ArrowRight className="w-4 h-4" /> : <Lock className="w-4 h-4 text-slate-450" />}
              </button>
              <button
                id="btn-contratacao-comissionados"
                disabled={!hiringComissionadosAllowed}
                onClick={() => hiringComissionadosAllowed && onSelect('hiring_comissionados')}
                className={`w-full flex items-center justify-between px-5 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                  hiringComissionadosAllowed 
                    ? 'cursor-pointer bg-emerald-700 hover:bg-emerald-800 text-white shadow-md shadow-emerald-250/30 active:scale-[0.98]' 
                    : 'bg-slate-150 text-slate-400 cursor-not-allowed opacity-60 border border-slate-155'
                }`}
              >
                <span>Contratação de Comissionados</span>
                {hiringComissionadosAllowed ? <ArrowRight className="w-4 h-4" /> : <Lock className="w-4 h-4 text-slate-455" />}
              </button>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          {profile?.role === 'master' && onOpenUserManagement && (
            <button
              id="btn-gestao-usuarios"
              onClick={onOpenUserManagement}
              className="mb-6 mx-auto flex items-center justify-center gap-2 px-6 py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-xs font-black uppercase tracking-widest shadow-sm hover:shadow-md transition-all active:scale-[0.98]"
            >
              <Users className="w-4 h-4" />
              Gestão de Usuários e Acessos
            </button>
          )}
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
            Elaborado pela Diretoria de Gestão de Pessoas. Versão {pkg.version}
          </p>
        </div>
      </div>
    </div>
  );
}
