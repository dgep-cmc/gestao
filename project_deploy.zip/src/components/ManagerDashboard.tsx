import { useState, useEffect, ReactNode } from 'react';
import { 
  Building2, 
  Search, 
  FileCheck, 
  AlertCircle, 
  CheckCircle2, 
  Printer,
  Calendar,
  Save,
  Plus,
  Paperclip,
  X,
  File as FileIcon,
  LayoutDashboard,
  Users,
  FileText,
  ChevronRight,
  Download
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { frequencyService } from '../services/frequencyService';
import { auth, db } from '../firebase';
import { query, collection, where, getDocs } from 'firebase/firestore';
import { UserProfile, FrequencyRecord, FrequencyDetails } from '../types';
import { format } from 'date-fns';
import { generateFrequencyPDF, generateComissionadosFrequencyPDF } from '../lib/pdfGenerator';
import { ptBR } from 'date-fns/locale';

const formatInputDate = (val: string | null | undefined): string => {
  if (!val) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(val)) return val;
  if (val.includes('T') || val.includes(' ')) {
    const parts = val.split(/[T ]/);
    if (parts[0] && /^\d{4}-\d{2}-\d{2}$/.test(parts[0])) {
      return parts[0];
    }
  }
  try {
    const d = new Date(val);
    if (!isNaN(d.getTime())) {
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }
  } catch (e) {
    // ignore
  }
  return '';
};

export default function ManagerDashboard({ 
  profile, 
  selectedSector, 
  setSelectedSector,
  month,
  setMonth,
  year,
  setYear,
  isComissionados = false
}: { 
  profile: UserProfile | null,
  selectedSector: string,
  setSelectedSector: (s: string) => void,
  month: number,
  setMonth: (m: number) => void,
  year: number,
  setYear: (y: number) => void,
  isComissionados?: boolean
}) {
  const now = new Date();
  const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);

  const [records, setRecords] = useState<FrequencyRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState<'dashboard' | 'frequency'>(selectedSector ? 'frequency' : 'dashboard');

  // Confirmation state for period change
  const [pendingPeriod, setPendingPeriod] = useState<{ month: number, year: number } | null>(null);

  useEffect(() => {
    if (selectedSector) {
      setView('frequency');
    } else {
      setView('dashboard');
    }
  }, [selectedSector]);

  const [stats, setStats] = useState<{
    totalInterns: number,
    totalSectors: number,
    submittedFrequencies: number,
    validatedFrequencies: number
  } | null>(null);

  // Edited values state
  const [editedRecords, setEditedRecords] = useState<Record<string, FrequencyDetails>>({});
  const [activeCalendarPicker, setActiveCalendarPicker] = useState<{
    recordId: string;
    type: 'falta' | 'atestados' | 'recesso';
  } | null>(null);
  const [calendarSelectedDays, setCalendarSelectedDays] = useState<number[]>([]);
  const [systemErrorModal, setSystemErrorModal] = useState<{ title: string; message: string } | null>(null);
  const [selectedInterns, setSelectedInterns] = useState<Record<string, boolean>>({});

  const triggerSystemAlert = (title: string, message: string) => {
    setSystemErrorModal({ title, message });
  };

  const parseDaysStr = (str: string): number[] => {
    if (!str) return [];
    return str
      .split(',')
      .map(s => {
        const parts = s.trim().split('/');
        if (parts.length > 0) {
          const d = parseInt(parts[0], 10);
          return isNaN(d) ? null : d;
        }
        return null;
      })
      .filter((d): d is number => d !== null);
  };

  const toggleDaySelection = (day: number) => {
    setCalendarSelectedDays(prev => {
      if (prev.includes(day)) {
        return prev.filter(d => d !== day);
      } else {
        return [...prev, day];
      }
    });
  };

  useEffect(() => {
    if (activeCalendarPicker) {
      const details = editedRecords[activeCalendarPicker.recordId];
      if (details) {
        let dateStr = '';
        if (activeCalendarPicker.type === 'falta') dateStr = details.datasFalta || '';
        else if (activeCalendarPicker.type === 'atestados') dateStr = details.datasAtestados || '';
        else if (activeCalendarPicker.type === 'recesso') dateStr = details.datasRecesso || '';
        
        setCalendarSelectedDays(parseDaysStr(dateStr));
      }
    } else {
      setCalendarSelectedDays([]);
    }
  }, [activeCalendarPicker]);

  const confirmCalendarSelection = async () => {
    if (!activeCalendarPicker) return;
    const { recordId, type } = activeCalendarPicker;
    
    const sorted = [...calendarSelectedDays].sort((a, b) => a - b);
    const formattedStr = sorted
      .map(day => `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}`)
      .join(', ');
      
    const daysCount = sorted.length > 0 ? sorted.length.toString() : '';

    setEditedRecords(prev => {
      const details = prev[recordId];
      if (!details) return prev;

      const nextDetails = {
        ...details,
        ...(type === 'falta' ? { falta: daysCount, datasFalta: formattedStr } : {}),
        ...(type === 'atestados' ? { atestados: daysCount, datasAtestados: formattedStr } : {}),
        ...(type === 'recesso' ? { recesso: daysCount, datasRecesso: formattedStr } : {})
      };

      const summaries: string[] = [];
      if (nextDetails.datasFalta) summaries.push(`Faltas: ${nextDetails.datasFalta}`);
      if (nextDetails.datasAtestados) summaries.push(`Atestados: ${nextDetails.datasAtestados}`);
      if (nextDetails.datasRecesso) summaries.push(`Recesso: ${nextDetails.datasRecesso}`);
      nextDetails.datasJustificadas = summaries.join(' | ');

      try {
        if (isComissionados) {
          frequencyService.saveComissionadosDraft(recordId, nextDetails);
        } else {
          frequencyService.saveDraft(recordId, nextDetails);
        }
      } catch (err) {
        console.error("Save draft failed", err);
      }

      return {
        ...prev,
        [recordId]: nextDetails
      };
    });

    setActiveCalendarPicker(null);
    toast.success("Ocorrências atualizadas!");
  };

  const formatToDDMM = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length < 3) return '';
    return `${parts[2]}/${parts[1]}`;
  };

  const getDefaultDatesForPeriod = (m: number, y: number) => {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth() + 1; // 1-12

    const firstDayStr = `${y}-${String(m).padStart(2, '0')}-01`;
    const lastDay = new Date(y, m, 0).getDate();
    const lastDayStr = `${y}-${String(m).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;

    const selectedDate = new Date(y, m - 1, 1);
    const currentDate = new Date(currentYear, currentMonth - 1, 1);

    if (selectedDate.getTime() > currentDate.getTime()) {
      // Competência futura
      return {
        startDate: firstDayStr,
        endDate: lastDayStr,
        isFuture: true
      };
    } else if (y === currentYear && m === currentMonth) {
      // Competência atual
      const yesterday = new Date(today);
      yesterday.setDate(today.getDate() - 1);
      
      if (yesterday.getMonth() + 1 === currentMonth) {
        const yesterdayStr = `${y}-${String(m).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
        return {
          startDate: firstDayStr,
          endDate: yesterdayStr,
          isFuture: false
        };
      }
      return {
        startDate: firstDayStr,
        endDate: firstDayStr,
        isFuture: false
      };
    } else {
      // Competência passada
      return {
        startDate: firstDayStr,
        endDate: lastDayStr,
        isFuture: false
      };
    }
  };

  useEffect(() => {
    if (view === 'dashboard') {
      loadStats();
    } else if (selectedSector) {
      loadRecords();
    }
  }, [view, month, year, selectedSector]);

  const handlePeriodChange = (newMonth: number, newYear: number) => {
    if (newMonth === month && newYear === year) return;
    setPendingPeriod({ month: newMonth, year: newYear });
  };

  const confirmPeriodChange = () => {
    if (pendingPeriod) {
      setMonth(pendingPeriod.month);
      setYear(pendingPeriod.year);
      setPendingPeriod(null);
    }
  };

  const loadStats = async () => {
    if (!profile?.sectors) return;
    setLoading(true);
    try {
      const s = isComissionados
        ? await frequencyService.getComissionadosManagerDashboardStats(month, year, profile.sectors)
        : await frequencyService.getManagerDashboardStats(month, year, profile.sectors);
      setStats(s);
    } catch (e) {
      console.error(e);
      toast.error("Erro ao carregar estatísticas");
    } finally {
      setLoading(false);
    }
  };

  const loadRecords = async () => {
    setLoading(true);
    let r: FrequencyRecord[] = [];
    if (isComissionados) {
      const activeSectors = selectedSector === '__gabinete__'
        ? (profile?.sectors || []).filter(s => s.trim().toUpperCase() !== 'GABINETE DA PRESIDÊNCIA')
        : [selectedSector];
      r = await frequencyService.getComissionadosFrequenciesByPeriod(month, year, activeSectors);
    } else {
      r = await frequencyService.getFrequenciesByPeriod(month, year, selectedSector);
    }
    setRecords(r);
    
    // Initialize editedRecords with existing details or originals
    const initial: Record<string, FrequencyDetails> = {};
    const initialSelected: Record<string, boolean> = {};

    r.forEach(rec => {
      let stDate = rec.details?.startDate;
      let enDate = rec.details?.endDate;

      if (!stDate || !enDate) {
        const defaultDates = getDefaultDatesForPeriod(month, year);
        stDate = stDate || defaultDates.startDate;
        enDate = enDate || defaultDates.endDate;

        // Decrypt from periodoOriginal if format is DD/MM a DD/MM
        if (rec.periodoOriginal && rec.periodoOriginal.includes(' a ')) {
          const parts = rec.periodoOriginal.split(' a ');
          if (parts.length === 2) {
            const startParts = parts[0].split('/');
            const endParts = parts[1].split('/');
            if (startParts.length === 2 && endParts.length === 2) {
              const startDay = startParts[0].padStart(2, '0');
              const endDay = endParts[0].padStart(2, '0');
              stDate = `${year}-${String(month).padStart(2, '0')}-${startDay}`;
              enDate = `${year}-${String(month).padStart(2, '0')}-${endDay}`;
            }
          }
        }
      }

      initial[rec.id] = rec.details ? {
        ...rec.details,
        startDate: stDate,
        endDate: enDate,
        atestadoFiles: rec.details.atestadoFiles || [],
        atestadoFilesNames: rec.details.atestadoFilesNames || [],
        datasJustificadas: rec.details.datasJustificadas || '',
        datasFalta: rec.details.datasFalta || '',
        datasAtestados: rec.details.datasAtestados || '',
        datasRecesso: rec.details.datasRecesso || ''
      } : {
        periodo: `${formatToDDMM(stDate)} a ${formatToDDMM(enDate)}`,
        startDate: stDate,
        endDate: enDate,
        presenca: 'integral',
        falta: '',
        atestados: '',
        recesso: rec.recessoOriginal,
        atestadoFiles: [],
        atestadoFilesNames: [],
        datasJustificadas: '',
        datasFalta: '',
        datasAtestados: '',
        datasRecesso: ''
      };

      initialSelected[rec.id] = true;
    });

    setEditedRecords(initial);
    setSelectedInterns(prev => {
      const next = { ...prev };
      r.forEach(rec => {
        if (next[rec.id] === undefined) {
          next[rec.id] = true;
        }
      });
      return next;
    });

    try {
      setLoadingArchives(true);
      const allArchives = isComissionados
        ? await frequencyService.getComissionadosArchiveByPeriod(month, year)
        : await frequencyService.getArchiveByPeriod(month, year);
      const rawSectorArchives = selectedSector === '__gabinete__'
        ? allArchives.filter(a => a.lotacao === '__gabinete__' || (profile?.sectors?.includes(a.lotacao) && a.lotacao.trim().toUpperCase() !== 'GABINETE DA PRESIDÊNCIA'))
        : allArchives.filter(a => a.lotacao === selectedSector);
      
      const sortedRawArchives = [...rawSectorArchives].sort((a, b) => {
        const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return timeB - timeA;
      });

      const seenRecordIds = new Set<string>();
      const filtered: any[] = [];

      for (const arch of sortedRawArchives) {
        const archRecs = arch.recordIds 
          ? r.filter(record => arch.recordIds!.includes(record.id))
          : r.filter(record => !sortedRawArchives.some(other => other.id !== arch.id && other.recordIds?.includes(record.id)));
        
        if (archRecs.length === 0 && !arch.pdfUrl) continue;

        const hasUnseen = archRecs.some(record => !seenRecordIds.has(record.id));
        if (hasUnseen || archRecs.length === 0) {
          archRecs.forEach(record => seenRecordIds.add(record.id));
          filtered.push({
            ...arch,
            resolvedRecords: archRecs
          });
        }
      }
      setSectorArchives(filtered);
    } catch (e) {
      console.error("Erro ao carregar arquivos enviados:", e);
    } finally {
      setLoadingArchives(false);
      setLoading(false);
    }
  };

  const handleInputChange = (id: string, field: keyof FrequencyDetails, value: string) => {
    setEditedRecords(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: value
      }
    }));
  };

  const handleDateChange = (id: string, field: 'startDate' | 'endDate', value: string) => {
    setEditedRecords(prev => {
      const current = prev[id];
      if (!current) return prev;
      const nextStart = field === 'startDate' ? value : current.startDate || '';
      const nextEnd = field === 'endDate' ? value : current.endDate || '';
      const formattedPeriod = `${formatToDDMM(nextStart)} a ${formatToDDMM(nextEnd)}`;
      return {
        ...prev,
        [id]: {
          ...current,
          [field]: value,
          periodo: formattedPeriod
        }
      };
    });
  };

  const handleNumericInputChange = (id: string, field: 'falta' | 'atestados' | 'recesso', value: string) => {
    if (value === '') {
      handleInputChange(id, field, '');
      return;
    }
    const normalized = value.replace(',', '.');
    if (!/^\d*\.?\d*$/.test(normalized)) {
      return;
    }
    const num = parseFloat(normalized);
    if (!isNaN(num) && num > 31) {
      toast.error("O valor máximo para cada ocorrência é 31 dias.");
      return;
    }
    handleInputChange(id, field, normalized);
  };

  const handlePresencaChange = (id: string, value: 'integral' | 'parcial') => {
    setEditedRecords(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        presenca: value,
        // Clear justificativas if integral
        ...(value === 'integral' ? { 
          falta: '', 
          atestados: '', 
          recesso: '', 
          atestadoFiles: [], 
          atestadoFilesNames: [], 
          datasJustificadas: '',
          datasFalta: '',
          datasAtestados: '',
          datasRecesso: ''
        } : {})
      }
    }));
  };

  const handleFileChange = async (id: string, files: FileList | null) => {
    if (!files || files.length === 0) return;
    
    setLoading(true);
    const newFilesIds: string[] = [];
    const newFilesNames: string[] = [];

    const record = records.find(r => r.id === id);
    const internName = record ? record.internName : 'Candidato';

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.size > 8 * 1024 * 1024) { // 8MB limit for chunked storage
        toast.error(`Arquivo ${file.name} excede o limite de 8MB.`);
        continue;
      }

      try {
        const monthStr = record ? record.month.toString().padStart(2, '0') : month.toString().padStart(2, '0');
        const yearStr = record ? record.year.toString() : year.toString();
        const lotacaoVal = record ? record.lotacao : selectedSector || 'Arquivos Gerais';
        
        // Novo padrão: Nome_do_Estagiario_ nome do arquivo enviado.pdf
        const cleanInternName = internName.trim().replace(/\s+/g, '_');
        const finalName = `${cleanInternName}_ ${file.name}`;

        // Create renamed file
        const renamedFile = new File([file], finalName, { type: file.type });

        let uploadUserName: string | undefined = undefined;
        if (isComissionados) {
          uploadUserName = (profile?.name || auth.currentUser?.displayName || 'USUÁRIO');
          if (uploadUserName && !uploadUserName.toUpperCase().startsWith("VER ")) {
            uploadUserName = "VER " + uploadUserName;
          }
        }

        const fileId = await frequencyService.uploadFile(renamedFile, `atestado_${id}`, {
          module: isComissionados ? 'frequency_comissionados' : 'frequency',
          monthYear: `${yearStr}-${monthStr}`,
          lotacao: lotacaoVal,
          userName: uploadUserName
        });
        newFilesIds.push(fileId);
        newFilesNames.push(finalName);
      } catch (err) {
        toast.error(`Erro ao enviar ${file.name}`);
      }
    }

    const updatedDetails = {
      ...editedRecords[id],
      atestadoFiles: [...(editedRecords[id]?.atestadoFiles || []), ...newFilesIds],
      atestadoFilesNames: [...(editedRecords[id]?.atestadoFilesNames || []), ...newFilesNames],
    };

    setEditedRecords(prev => ({
      ...prev,
      [id]: updatedDetails
    }));

    // Save draft immediately to Firestore so files stay linked!
    try {
      if (isComissionados) {
        await frequencyService.saveComissionadosDraft(id, updatedDetails);
      } else {
        await frequencyService.saveDraft(id, updatedDetails);
      }
      toast.success("Atestado anexado e salvo com sucesso!");
    } catch {
      toast.error("Erro ao registrar anexo no banco.");
    }

    setLoading(false);
  };

  const handleDownload = async (fileId: string, fileName: string) => {
    if (fileId && (fileId.startsWith('http://') || fileId.startsWith('https://'))) {
      window.open(fileId, '_blank');
      return;
    }
    try {
      const loadingToast = toast.loading(`Baixando ${fileName}...`);
      const { data } = await frequencyService.downloadFile(fileId);
      const url = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 100);
      toast.success("Download concluído", { id: loadingToast });
    } catch (err) {
      toast.error("Erro ao baixar arquivo");
    }
  };

  const removeFile = async (id: string, index: number) => {
    const fileId = editedRecords[id]?.atestadoFiles?.[index];
    if (fileId) {
      const deleteToast = toast.loading("Excluindo arquivo físico do Drive...");
      try {
        await frequencyService.deleteFile(fileId);
        toast.success("Arquivo excluído do Google Drive.", { id: deleteToast });
      } catch (err) {
        console.error("Erro ao apagar arquivo:", err);
        toast.error("Falha ao remover arquivo do drive.", { id: deleteToast });
      }
    }

    const newFiles = [...(editedRecords[id]?.atestadoFiles || [])];
    const newNames = [...(editedRecords[id]?.atestadoFilesNames || [])];
    newFiles.splice(index, 1);
    newNames.splice(index, 1);

    const updatedDetails = {
      ...editedRecords[id],
      atestadoFiles: newFiles,
      atestadoFilesNames: newNames
    };

    setEditedRecords(prev => ({
      ...prev,
      [id]: updatedDetails
    }));

    try {
      if (isComissionados) {
        await frequencyService.saveComissionadosDraft(id, updatedDetails);
      } else {
        await frequencyService.saveDraft(id, updatedDetails);
      }
      toast.success("Rascunho atualizado.");
    } catch {
      toast.error("Erro ao remover referência do banco de dados.");
    }
  };

  const handleSaveDraft = async () => {
    const pendingRecords = records.filter(r => r.status === 'pending' || r.status === 'devolvida');
    if (pendingRecords.length === 0) {
      toast.success("Todos os registros já estão salvos ou enviados.");
      return;
    }

    setLoading(true);
    try {
      for (const rec of pendingRecords) {
        if (isComissionados) {
          await frequencyService.saveComissionadosDraft(rec.id, editedRecords[rec.id]);
        } else {
          await frequencyService.saveDraft(rec.id, editedRecords[rec.id]);
        }
      }
      toast.success("Alterações salvas como rascunho!");
      loadRecords();
    } catch (error) {
      toast.error("Erro ao salvar rascunho");
    } finally {
      setLoading(false);
    }
  };

  const [showConfirm, setShowConfirm] = useState(false);
  const [showReason, setShowReason] = useState<string | null>(null);
  const [showPdfOptions, setShowPdfOptions] = useState(false);
  const [sectorArchives, setSectorArchives] = useState<any[]>([]);
  const [loadingArchives, setLoadingArchives] = useState(false);
  
  const handleSaveAndSubmit = async () => {
    toast.dismiss();
    const pendingRecords = records.filter(r => (r.status === 'pending' || r.status === 'devolvida') && selectedInterns[r.id]);
    
    if (pendingRecords.length === 0) {
      triggerSystemAlert(
        isComissionados ? "Nenhum Servidor Selecionado" : "Nenhum Estagiário Selecionado",
        isComissionados 
          ? "Por favor, marque pelo menos um servidor pendente ou em rascunho para enviar à DGEP." 
          : "Por favor, marque pelo menos um estagiário pendente ou em rascunho para enviar à DGEP."
      );
      return;
    }
    
    const todayStr = new Date().toISOString().substring(0, 10); // YYYY-MM-DD
    
    // Validation
    for (const r of pendingRecords) {
      const details = editedRecords[r.id];
      if (!details) {
        triggerSystemAlert(
          "Dados Incompletos",
          isComissionados
            ? `Dados não encontrados para o servidor ${r.internName}.`
            : `Dados não encontrados para o estagiário ${r.internName}.`
        );
        return;
      }

      // Proibir enviar se o período final for para hoje ou posterior
      if (details.endDate && details.endDate >= todayStr) {
        triggerSystemAlert(
          "Bloqueio de Envio",
          "Você está tentando enviar uma frequência com data posterior a hoje. Por favor, aguarde o final do período para emissão do Formulário de Frequência."
        );
        return;
      }

      if (!details.periodo || !details.periodo.trim()) {
        triggerSystemAlert(
          "Falta Período de Referência",
          isComissionados
            ? `O período de referência é obrigatório para o servidor ${r.internName}.`
            : `O período de referência é obrigatório para o estagiário ${r.internName}.`
        );
        return;
      }
      
      if (details.presenca === 'parcial') {
        const valFalta = parseFloat(details.falta || '0') || 0;
        const valAtestados = parseFloat(details.atestados || '0') || 0;
        const valRecesso = parseFloat(details.recesso || '0') || 0;
        
        if (valFalta === 0 && valAtestados === 0 && valRecesso === 0) {
          triggerSystemAlert(
            "Ausência de Ocorrências",
            isComissionados
              ? `Para a presença do tipo parcial de ${r.internName}, preencha pelo menos uma ocorrência (Faltas, Atestados ou Férias) com valor maior que zero.`
              : `Para a presença do tipo parcial de ${r.internName}, preencha pelo menos uma ocorrência (Faltas, Atestados ou Recesso) com valor maior que zero.`
          );
          return;
        }

        if (valFalta > 0) {
          if (!details.datasFalta || !details.datasFalta.trim()) {
            triggerSystemAlert(
              "Datas da Falta Não Informadas",
              isComissionados
                ? `Por favor, preencha as datas das faltas para o servidor ${r.internName}. Clique sobre a quantidade de dias para selecionar no calendário.`
                : `Por favor, preencha as datas das faltas para o estagiário ${r.internName}. Clique sobre a quantidade de dias para selecionar no calendário.`
            );
            return;
          }
        }

        if (valAtestados > 0) {
          if (!details.datasAtestados || !details.datasAtestados.trim()) {
            triggerSystemAlert(
              "Datas do Atestado Não Informadas",
              isComissionados
                ? `Por favor, preencha as datas dos atestados para o servidor ${r.internName}. Clique sobre a quantidade de dias para selecionar no calendário.`
                : `Por favor, preencha as datas dos atestados para o estagiário ${r.internName}. Clique sobre a quantidade de dias para selecionar no calendário.`
            );
            return;
          }
          if (!details.atestadoFiles || details.atestadoFiles.length === 0) {
            triggerSystemAlert(
              "Atestado Médico Obrigatório",
              isComissionados
                ? `Para o servidor ${r.internName}, como há atestado médico informado, é de envio obrigatório anexar o documento digitalizado correspondente.`
                : `Para o estagiário ${r.internName}, como há atestado médico informado, é de envio obrigatório anexar o documento digitalizado correspondente.`
            );
            return;
          }
        }

        if (valRecesso > 0) {
          if (!details.datasRecesso || !details.datasRecesso.trim()) {
            triggerSystemAlert(
              isComissionados ? "Datas de Férias Não Informadas" : "Datas de Recesso Não Informadas",
              isComissionados
                ? `Por favor, preencha as datas das férias para o servidor ${r.internName}. Clique sobre a quantidade de dias para selecionar no calendário.`
                : `Por favor, preencha as datas do recesso para o estagiário ${r.internName}. Clique sobre a quantidade de dias para selecionar no calendário.`
            );
            return;
          }
        }
      }
    }

    setShowConfirm(true);
  };

  const confirmSubmission = async () => {
    setShowConfirm(false);
    const pendingRecords = records.filter(r => (r.status === 'pending' || r.status === 'devolvida') && selectedInterns[r.id]);
    
    setLoading(true);
    const mainToastId = toast.loading("Enviando frequências...");
    
    const nowIso = new Date().toISOString();
    try {
      const payloads = pendingRecords.map(rec => ({
        id: rec.id,
        details: editedRecords[rec.id]
      }));

      if (isComissionados) {
        await frequencyService.submitComissionadosMultipleFrequencies(payloads, nowIso);
      } else {
        await frequencyService.submitMultipleFrequencies(payloads, nowIso);
      }
      
      toast.success("Frequências enviadas com sucesso!", { id: mainToastId });
      
      try {
        let formattedName = '';
        if (isComissionados) {
          let nameToUse = (profile?.name || auth.currentUser?.displayName || 'Vereador').trim();
          nameToUse = nameToUse.replace(/^(VER\.|VER|VEREADOR\.|VEREADOR)\s+/i, '');
          formattedName = `Ver_${nameToUse.replace(/\s+/g, '_')}`;
        } else {
          formattedName = selectedSector.replace(/\s+/g, '_');
        }
        const monthStr = month.toString().padStart(2, '0');
        const baseName = `Frequencia_${formattedName}_${monthStr}_${year}`;
        const archiveCollection = isComissionados ? 'archive_comissionados' : 'archive';

        // Obter número de PDFs já arquivados para esta lotação/competência
        const qArch = query(
          collection(db, archiveCollection),
          where('lotacao', '==', selectedSector),
          where('month', '==', month),
          where('year', '==', year)
        );
        const snapArch = await getDocs(qArch);
        
        let nextIndex = 0;
        const existingNumbers: number[] = [];
        snapArch.docs.forEach(docSnap => {
          const data = docSnap.data();
          const fName = data.fileName || '';
          if (fName.startsWith(baseName)) {
            let remaining = fName.substring(baseName.length);
            if (remaining.endsWith('.pdf')) {
              remaining = remaining.substring(0, remaining.length - 4);
            }
            if (remaining.startsWith('_')) {
              const numStr = remaining.substring(1);
              if (/^\d+$/.test(numStr)) {
                existingNumbers.push(parseInt(numStr, 10));
              }
            } else if (remaining === '') {
              existingNumbers.push(0);
            }
          }
        });

        if (existingNumbers.length > 0) {
          nextIndex = Math.max(...existingNumbers) + 1;
        }

        const suffix = nextIndex > 0 ? `_${nextIndex}` : '';

        // Generate PDF specifically for records submitted in this batch, with original submission timestamp attached
        const doc = isComissionados
          ? generateComissionadosFrequencyPDF(
              pendingRecords.map(r => ({ 
                ...r, 
                details: editedRecords[r.id],
                submittedAt: nowIso,
                submittedBy: auth.currentUser?.email || profile?.email || ''
              })), 
              month, 
              year,
              selectedSector,
              auth.currentUser?.displayName || profile?.name || profile?.email.split('@')[0] || 'USUÁRIO',
              auth.currentUser?.email || profile?.email || ''
            )
          : generateFrequencyPDF(
              pendingRecords.map(r => ({ 
                ...r, 
                details: editedRecords[r.id],
                submittedAt: nowIso,
                submittedBy: auth.currentUser?.email || profile?.email || ''
              })), 
              month, 
              year,
              selectedSector,
              auth.currentUser?.displayName || profile?.name || profile?.email.split('@')[0] || 'USUÁRIO',
              auth.currentUser?.email || profile?.email || ''
            );

        // Save to archive
        const fileName = `${baseName}${suffix}.pdf`;
        const pdfBlob = doc.output('blob');
        
        const monthYear = `${year}-${monthStr}`;

        let signatureName = profile?.name || auth.currentUser?.displayName || 'USUÁRIO';
        if (signatureName && !signatureName.toUpperCase().startsWith("VER ") && isComissionados) {
          signatureName = "VER " + signatureName;
        }

        const pdfUrl = await frequencyService.uploadFile(pdfBlob, `${baseName}${suffix}`, {
          module: isComissionados ? 'frequency_comissionados' : 'frequency',
          monthYear,
          lotacao: selectedSector,
          userName: signatureName
        });
        
        const docRecord = {
          fileName,
          lotacao: selectedSector,
          month,
          year,
          generatedBy: profile?.email || 'unknown',
          timestamp: new Date().toISOString(),
          pdfUrl,
          recordIds: pendingRecords.map(r => r.id)
        };

        if (isComissionados) {
          await frequencyService.saveComissionadosGeneratedDocument(docRecord);
        } else {
          await frequencyService.saveGeneratedDocument(docRecord);
        }

        // Save locally
        doc.save(fileName);
      } catch (err) {
        console.error("Erro no PDF ou Arquivamento", err);
        toast.error("Frequência enviada, mas houve falha ao arquivar PDF.", { duration: 5000 });
      }
      
      await loadRecords();
    } catch (error: any) {
      console.error("Submission error:", error);
      toast.error("Erro ao enviar frequências. Verifique sua conexão ou permissões.", { id: mainToastId });
    } finally {
      setLoading(false);
    }
  };

  if (!profile) return null;

  if (!profile.sectors || profile.sectors.length === 0) {
    return (
      <div className="bg-white p-12 rounded-3xl shadow-sm text-center border border-gray-200">
        <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Sem Setor Vinculado</h2>
        <p className="text-gray-500 max-w-md mx-auto">
          Sua conta ainda não está vinculada a uma lotação específica. 
          Entre em contato com a DGEP para configurar seu acesso.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between px-4 sm:px-8 py-4 md:py-0 md:h-[84px] gap-4 shrink-0 z-10 shadow-sm sticky top-0">
        <div className="min-w-0 w-full md:w-auto">
          <h2 className="text-base sm:text-xl font-bold text-slate-800 truncate" title={view === 'dashboard' ? 'Resumo de Indicadores' : (selectedSector === '__gabinete__' ? 'Gabinete Parlamentar' : (selectedSector || 'Selecione uma Lotação'))}>
            {view === 'dashboard' ? 'Resumo de Indicadores' : (selectedSector === '__gabinete__' ? 'Gabinete Parlamentar' : (selectedSector || 'Selecione uma Lotação'))}
          </h2>
          <p className="text-xs sm:text-sm font-bold text-blue-600 uppercase tracking-tighter opacity-80 mt-0.5 sm:mt-1">
            {view === 'dashboard' ? 'Painel do Gestor' : 'Confirmação de Frequência Mensal'}
          </p>
        </div>
        
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="flex flex-1 md:flex-none items-center bg-slate-50 p-2 rounded-xl border-2 border-slate-200 shadow-inner overflow-hidden select-none">
            <div className="hidden sm:flex items-center gap-2 px-3 border-r border-slate-200">
              <Calendar className="w-5 h-5 text-blue-600" />
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest whitespace-nowrap">Selecione o Período:</span>
            </div>
            <div className="flex sm:hidden items-center gap-1.5 px-2 border-r border-slate-200 shrink-0">
              <Calendar className="w-4 h-4 text-blue-600" />
            </div>
            <select 
              value={month} 
              onChange={(e) => handlePeriodChange(Number(e.target.value), year)}
              className="flex-1 sm:flex-none bg-transparent border-none text-sm font-black px-2 sm:px-4 py-2 focus:ring-0 cursor-pointer text-slate-700 hover:text-blue-600 transition-colors truncate"
            >
              {Array.from({ length: 12 }, (_, i) => (
                <option key={i + 1} value={i + 1}>
                  {format(new Date(2024, i, 1), 'MMMM', { locale: ptBR }).toUpperCase()}
                </option>
              ))}
            </select>
            <div className="w-[1px] h-6 bg-slate-200 my-auto"></div>
            <select 
              value={year} 
              onChange={(e) => handlePeriodChange(month, Number(e.target.value))}
              className="bg-transparent border-none text-sm font-black px-4 py-2 focus:ring-0 cursor-pointer text-slate-700 hover:text-blue-600 transition-colors"
            >
              {[2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        </div>
      </header>

      {pendingPeriod && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center text-blue-600 mb-6">
              <Calendar className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-3">Alterar Período?</h3>
            <p className="text-slate-600 mb-8 leading-relaxed">
              Você deseja acessar o período de frequência do mês <span className="font-bold text-blue-600 uppercase italic">
                {format(new Date(2024, pendingPeriod.month - 1, 1), 'MMMM', { locale: ptBR })}
              </span> de <span className="font-bold text-blue-600">{pendingPeriod.year}</span>?
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <button 
                onClick={() => setPendingPeriod(null)}
                className="flex-1 px-6 py-4 text-sm font-bold text-slate-500 hover:bg-slate-50 rounded-2xl transition-all border border-slate-200"
              >
                Permanecer no período atual
              </button>
              <button 
                onClick={confirmPeriodChange}
                className="flex-1 px-6 py-4 text-sm font-bold bg-blue-600 text-white hover:bg-blue-700 rounded-2xl shadow-xl shadow-blue-100 transition-all"
              >
                Sim, Alterar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="p-4 sm:p-8 space-y-6 max-w-7xl mx-auto w-full pb-12">
        {view === 'dashboard' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard 
                label={isComissionados ? "Servidores no Período" : "Estagiários no Período"} 
                value={stats?.totalInterns || 0} 
                icon={<Users className="w-4 h-4 text-purple-600" />}
                color="bg-purple-500"
              />
              <StatCard 
                label="Lotações Vinculadas" 
                value={stats?.totalSectors || 0} 
                icon={<Building2 className="w-4 h-4 text-blue-600" />}
                color="bg-blue-500"
              />
              <StatCard 
                label="Frequências Enviadas" 
                value={stats?.submittedFrequencies || 0} 
                icon={<FileText className="w-4 h-4 text-emerald-600" />}
                color="bg-emerald-500"
              />
              <StatCard 
                label="Frequências Validadas" 
                value={stats?.validatedFrequencies || 0} 
                icon={<CheckCircle2 className="w-4 h-4 text-indigo-600" />}
                color="bg-indigo-500"
              />
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Building2 className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Minhas Lotações</h3>
                  <p className="text-[10px] text-slate-400 font-medium uppercase tracking-widest">Selecione para gerenciar frequências</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                {profile.sectors?.map(sector => (
                  <button
                    key={sector}
                    onClick={() => {
                      setSelectedSector(sector);
                      setView('frequency');
                    }}
                    className="flex items-center justify-between p-3 sm:p-4 bg-white border border-slate-200 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-all group text-left shadow-sm hover:shadow-md"
                  >
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:bg-blue-600 transition-colors shrink-0">
                        <Building2 className="w-4 h-4 sm:w-5 sm:h-5 text-slate-400 group-hover:text-white" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs sm:text-sm font-bold text-slate-700 group-hover:text-blue-700 truncate">{sector}</p>
                        <p className="text-[9px] sm:text-[10px] text-slate-400 font-medium uppercase tracking-wider">Acessar Setor</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {view === 'frequency' && (
          <>
            {records.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-20 text-center shadow-sm">
                <FileCheck className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <p className="text-sm font-bold text-slate-800">{isComissionados ? "Nenhum servidor encontrado" : "Nenhum estagiário encontrado"}</p>
                <p className="text-xs text-slate-400 mt-1">Nenhum registro para o período {month}/{year} neste setor.</p>
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
                <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                  <h3 className="text-sm font-bold text-slate-700">Controle de Frequência</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left min-w-[700px] xl:min-w-full">
                    <thead>
                      <tr className="text-[10px] uppercase text-slate-400 font-bold bg-white">
                        <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap w-10">
                          <input 
                            type="checkbox"
                            checked={records.filter(r => r.status === 'pending' || r.status === 'devolvida').every(r => selectedInterns[r.id]) && records.filter(r => r.status === 'pending' || r.status === 'devolvida').length > 0}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              setSelectedInterns(prev => {
                                const next = { ...prev };
                                records.forEach(r => {
                                  if (r.status === 'pending' || r.status === 'devolvida') {
                                    next[r.id] = checked;
                                  }
                                });
                                return next;
                              });
                            }}
                            className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                        </th>
                        {isComissionados && (
                          <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap">Matrícula</th>
                        )}
                        <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap">
                          {isComissionados ? 'Servidor' : 'Estagiário'}
                        </th>
                        {isComissionados && (
                          <>
                            <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap">Lotação</th>
                            <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap">Cargo</th>
                          </>
                        )}
                        <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap w-[165px] min-w-[165px]">Período</th>
                        <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap">Presença</th>
                        <th className="px-2 py-3 border-b border-slate-100 text-center whitespace-nowrap">Faltas</th>
                        <th className="px-2 py-3 border-b border-slate-100 text-center whitespace-nowrap">Atestados</th>
                        <th className="px-2 py-3 border-b border-slate-100 text-center whitespace-nowrap">
                          {isComissionados ? 'Férias' : 'Recesso'}
                        </th>
                        <th className="px-3 py-3 border-b border-slate-100 text-center whitespace-nowrap">Datas</th>
                        <th className="px-3 py-3 border-b border-slate-100 whitespace-nowrap">Status</th>
                      </tr>
                    </thead>
                    <tbody className="text-xs text-slate-600 divide-y divide-slate-50">
                      {records.map((r, i) => {
                        const details = editedRecords[r.id];
                        if (!details) return null;
                        const isSubmitted = r.status === 'submitted' || r.status === 'validada';
                        const isPending = r.status === 'pending' || r.status === 'devolvida';
                        const { isFuture } = getDefaultDatesForPeriod(month, year);

                        return (
                          <tr key={r.id} className={`${!isPending ? 'bg-slate-50/50' : 'hover:bg-blue-50/30'} transition-colors`}>
                            <td className="px-3 py-2 w-10">
                              <input 
                                type="checkbox"
                                disabled={!isPending}
                                checked={!!selectedInterns[r.id]}
                                onChange={(e) => {
                                  setSelectedInterns(prev => ({
                                    ...prev,
                                    [r.id]: e.target.checked
                                  }));
                                }}
                                className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                              />
                            </td>
                            {isComissionados && (
                              <td className="px-3 py-2 text-xs text-slate-500 font-mono">
                                {r.matricula || '-'}
                              </td>
                            )}
                            <td className="px-3 py-2">
                              <p className="text-xs font-bold text-slate-800 whitespace-normal break-words leading-tight block min-w-[140px] max-w-[240px]" title={r.internName}>
                                {r.internName}
                              </p>
                              {(details.datasFalta || details.datasAtestados || details.datasRecesso) && (
                                <div className="text-[10px] text-slate-400 font-normal italic tracking-tight whitespace-normal max-w-xs leading-tight mt-0.5 space-y-0.5">
                                  {details.datasFalta && <div>Faltas: {details.datasFalta}</div>}
                                  {details.datasAtestados && <div>Atestados: {details.datasAtestados}</div>}
                                  {details.datasRecesso && <div>{isComissionados ? 'Férias' : 'Recesso'}: {details.datasRecesso}</div>}
                                </div>
                              )}
                            </td>
                            {isComissionados && (
                              <>
                                <td className="px-3 py-2 text-xs text-slate-600 font-medium">
                                  {r.lotacao || '-'}
                                </td>
                                <td className="px-3 py-2 text-xs text-slate-600 font-medium">
                                  {r.cargo || (r as any).cargo || '-'}
                                </td>
                              </>
                            )}
                            <td className="px-3 py-2 w-[165px] min-w-[165px]">
                              <div className={`flex flex-col gap-1.5 w-full ${isFuture ? 'opacity-60' : ''}`}>
                                <div className="flex items-center gap-2 justify-between w-full">
                                  <span className="text-[10px] text-slate-450 font-bold uppercase shrink-0 w-6">De:</span>
                                  <input 
                                    type="date" 
                                    disabled={!isPending || isFuture}
                                    value={formatInputDate(details.startDate)}
                                    onChange={(e) => handleDateChange(r.id, 'startDate', e.target.value)}
                                    className="bg-white border border-slate-200 rounded-md px-1.5 py-1 text-[11px] w-full max-w-[125px] focus:ring-1 focus:ring-blue-500 disabled:bg-transparent disabled:border-transparent cursor-pointer shrink-0"
                                  />
                                </div>
                                <div className="flex items-center gap-2 justify-between w-full">
                                  <span className="text-[10px] text-slate-450 font-bold uppercase shrink-0 w-6">Até:</span>
                                  <input 
                                    type="date" 
                                    disabled={!isPending || isFuture}
                                    value={formatInputDate(details.endDate)}
                                    onChange={(e) => handleDateChange(r.id, 'endDate', e.target.value)}
                                    className="bg-white border border-slate-200 rounded-md px-1.5 py-1 text-[11px] w-full max-w-[125px] focus:ring-1 focus:ring-blue-500 disabled:bg-transparent disabled:border-transparent cursor-pointer shrink-0"
                                  />
                                </div>
                              </div>
                            </td>
                            <td className="px-3 py-2">
                              <select 
                                disabled={!isPending}
                                value={details.presenca}
                                onChange={(e) => handlePresencaChange(r.id, e.target.value as any)}
                                className="bg-white border border-slate-200 rounded-md p-1 text-[11px] focus:ring-1 focus:ring-blue-500 disabled:bg-transparent disabled:border-transparent shrink-0 cursor-pointer"
                              >
                                <option value="integral">Integral</option>
                                <option value="parcial">Parcial</option>
                              </select>
                            </td>
                            <td className="px-2 py-2 text-center">
                              <button
                                type="button"
                                disabled={!isPending || details.presenca === 'integral'}
                                onClick={() => setActiveCalendarPicker({ recordId: r.id, type: 'falta' })}
                                className="bg-white hover:bg-slate-50 border border-slate-200 rounded-md p-1 text-[11px] w-12 text-center focus:ring-1 focus:ring-blue-500 disabled:opacity-30 disabled:bg-slate-50 disabled:cursor-not-allowed mx-auto font-bold text-slate-800 transition-colors flex items-center justify-center h-[28px]"
                                title={!isPending ? 'Visualizar datas no calendário' : 'Preencher faltas pelo calendário'}
                              >
                                {details.falta || '0'}
                              </button>
                            </td>
                            <td className="px-2 py-2">
                              <div className="flex flex-col items-center gap-1">
                                <div className="flex items-center gap-1 justify-center">
                                  <button
                                    type="button"
                                    disabled={!isPending || details.presenca === 'integral'}
                                    onClick={() => setActiveCalendarPicker({ recordId: r.id, type: 'atestados' })}
                                    className="bg-white hover:bg-slate-50 border border-slate-200 rounded-md p-1 text-[11px] w-12 text-center focus:ring-1 focus:ring-blue-500 disabled:opacity-30 disabled:bg-slate-50 disabled:cursor-not-allowed font-bold text-slate-800 transition-colors flex items-center justify-center h-[28px]"
                                    title={!isPending ? 'Visualizar datas no calendário' : 'Preencher atestados pelo calendário'}
                                  >
                                    {details.atestados || '0'}
                                  </button>
                                  
                                  {details.presenca === 'parcial' && isPending && parseFloat(details.atestados || '0') > 0 && (
                                    <label 
                                      id={`attach-doc-btn-${r.id}`}
                                      className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-600 p-1 rounded-md transition-colors border border-slate-200 flex items-center justify-center shrink-0" 
                                      title="Adicionar atestado digitalizado"
                                    >
                                      <Paperclip className="w-3 h-3" />
                                      <input 
                                        id={`attach-doc-file-${r.id}`}
                                        type="file" 
                                        multiple 
                                        accept="image/*,application/pdf"
                                        className="hidden" 
                                        onChange={(e) => handleFileChange(r.id, e.target.files)}
                                      />
                                    </label>
                                  )}
                                </div>
                                
                                {details.presenca === 'parcial' && isPending && (details.atestadoFiles || []).length > 0 && (
                                  <div className="flex flex-col gap-0.5 w-full min-w-[100px]">
                                    <div className="flex flex-wrap gap-1 items-center justify-center">
                                      {details.atestadoFiles?.map((fname, idx) => (
                                        <div key={idx} className="flex items-center gap-1 bg-blue-50 text-blue-700 text-[9px] px-1 py-0.5 rounded border border-blue-100 group">
                                          <span className="truncate max-w-[50px]" title={details.atestadoFilesNames?.[idx]}>
                                            {details.atestadoFilesNames?.[idx]}
                                          </span>
                                          <button 
                                            id={`remove-doc-btn-${r.id}-${idx}`}
                                            onClick={() => removeFile(r.id, idx)}
                                            className="hover:text-red-600 focus:outline-none"
                                          >
                                            <X className="w-2 h-2" />
                                          </button>
                                        </div>
                                      ))}
                                    </div>
                                    <p className="text-[8px] text-slate-400 text-center uppercase font-bold tracking-tighter">
                                      {(details.atestadoFiles || []).length} arquivo(s)
                                    </p>
                                  </div>
                                )}

                                {details.presenca === 'parcial' && !isPending && (details.atestadoFiles || []).length > 0 && (
                                  <div className="flex flex-wrap gap-1 justify-center">
                                    {details.atestadoFiles?.map((fileId, idx) => (
                                      <button 
                                        key={idx}
                                        id={`download-doc-btn-${r.id}-${idx}`}
                                        onClick={() => handleDownload(fileId, details.atestadoFilesNames?.[idx] || 'download')}
                                        className="p-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md transition-colors border border-slate-200 cursor-pointer"
                                        title={details.atestadoFilesNames?.[idx]}
                                      >
                                        <FileIcon className="w-3 h-3" />
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </td>
                            <td className="px-2 py-2 text-center">
                              <button
                                type="button"
                                disabled={!isPending || details.presenca === 'integral'}
                                onClick={() => setActiveCalendarPicker({ recordId: r.id, type: 'recesso' })}
                                className="bg-white hover:bg-slate-50 border border-slate-200 rounded-md p-1 text-[11px] w-12 text-center focus:ring-1 focus:ring-blue-500 disabled:opacity-30 disabled:bg-slate-50 disabled:cursor-not-allowed mx-auto font-bold text-slate-800 transition-colors flex items-center justify-center h-[28px]"
                                title={!isPending ? 'Visualizar datas no calendário' : 'Preencher recesso pelo calendário'}
                              >
                                {details.recesso || '0'}
                              </button>
                            </td>
                            <td className="px-3 py-2 text-center">
                              {(() => {
                                const numFalta = parseFloat(details.falta || '0') || 0;
                                const numAtestados = parseFloat(details.atestados || '0') || 0;
                                const numRecesso = parseFloat(details.recesso || '0') || 0;
                                const hasOccurrences = numFalta > 0 || numAtestados > 0 || numRecesso > 0;

                                return (
                                  <div className="flex flex-wrap items-center justify-center gap-1 max-w-[80px] mx-auto">
                                    {numFalta > 0 && (
                                      <button
                                        type="button"
                                        onClick={() => setActiveCalendarPicker({ recordId: r.id, type: 'falta' })}
                                        className="text-[9px] font-bold bg-red-50 text-red-700 hover:bg-red-100 px-1 rounded border border-red-200"
                                        title="Ver datas de falta"
                                      >
                                        Falta
                                      </button>
                                    )}
                                    {numAtestados > 0 && (
                                      <button
                                        type="button"
                                        onClick={() => setActiveCalendarPicker({ recordId: r.id, type: 'atestados' })}
                                        className="text-[9px] font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 px-1 rounded border border-emerald-200"
                                        title="Ver datas de atestado"
                                      >
                                        At.
                                      </button>
                                    )}
                                    {numRecesso > 0 && (
                                      <button
                                        type="button"
                                        onClick={() => setActiveCalendarPicker({ recordId: r.id, type: 'recesso' })}
                                        className="text-[9px] font-bold bg-amber-50 text-amber-700 hover:bg-amber-100 px-1 rounded border border-amber-200"
                                        title="Ver datas de recesso"
                                      >
                                        Rec.
                                      </button>
                                    )}
                                    {!hasOccurrences && (
                                      <span className="text-[9px] font-semibold text-slate-300 italic uppercase">-</span>
                                    )}
                                  </div>
                                );
                              })()}
                            </td>
                            <td className="px-3 py-2">
                              {r.status === 'validada' ? (
                                <div className="flex items-center gap-1 text-blue-600 font-bold text-[9px] whitespace-nowrap">
                                  <CheckCircle2 className="w-3 h-3 shrink-0" />
                                  VALIDADA
                                </div>
                              ) : r.status === 'submitted' ? (
                                <div className="flex items-center gap-1 text-green-600 font-bold text-[9px] whitespace-nowrap">
                                  <CheckCircle2 className="w-3 h-3 shrink-0" />
                                  ENVIADA
                                </div>
                              ) : r.status === 'devolvida' ? (
                                <div className="flex flex-col gap-1">
                                  <div className="flex items-center gap-1 text-red-500 font-bold text-[9px] whitespace-nowrap">
                                    <AlertCircle className="w-3 h-3 shrink-0" />
                                    DEVOLVIDA
                                  </div>
                                  {r.returnReason && (
                                    <button
                                      onClick={() => setShowReason(r.returnReason!)}
                                      className="text-[9px] font-bold text-red-600 bg-red-50 hover:bg-red-100 px-1.5 py-0.5 rounded transition-colors whitespace-nowrap"
                                    >
                                      Ler Motivo
                                    </button>
                                  )}
                                </div>
                              ) : (
                                <div className="flex items-center gap-1 text-amber-500 font-bold text-[9px] whitespace-nowrap">
                                  <AlertCircle className="w-3 h-3 shrink-0" />
                                  PENDENTE
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {records.length > 0 && (
              <div className="sticky bottom-6 z-20 mt-8">
                <div className="bg-slate-900 p-4 sm:px-6 rounded-2xl shadow-2xl flex flex-col sm:flex-row items-center justify-between sm:gap-8 border border-slate-800 gap-4 max-w-4xl mx-auto">
              <div className="flex lg:flex items-center gap-3 w-full sm:w-auto overflow-hidden">
                <div className="p-2 bg-blue-600 rounded-lg shrink-0">
                  <Save className="w-4 h-4 text-white" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-white text-[11px] font-bold truncate">Enviar Frequência</p>
                  <p className="text-slate-400 text-[9px] font-medium tracking-tight truncate">Os dados serão salvos no portal DGEP</p>
                </div>
              </div>
              
              <div className="flex gap-2 w-full sm:w-auto">
                <button 
                  onClick={handleSaveDraft}
                  disabled={loading}
                  className="px-3.5 py-2.5 text-xs font-bold bg-slate-850 hover:bg-slate-800 text-slate-200 rounded-lg transition-colors text-center flex items-center justify-center gap-2 shrink-0 sm:w-auto w-1/2 border border-slate-800"
                  title="Salvar alterações sem enviar"
                >
                  <Save className="w-4 h-4" />
                  <span>SALVAR</span>
                </button>

                <button 
                  onClick={handleSaveAndSubmit}
                  disabled={loading}
                  className="px-4.5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-lg shadow-blue-900/40 flex items-center justify-center gap-2 transition-all shrink-0 sm:w-auto w-1/2"
                  title="Enviar frequências para a DGEP"
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <FileCheck className="w-4 h-4 shrink-0" />
                      <span className="truncate whitespace-nowrap">ENVIAR</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Frequências Já Enviadas e Arquivadas */}
        <div className="bg-white border-2 border-slate-200 rounded-3xl p-6 sm:p-8 mt-12 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-50 rounded-lg">
              <FileCheck className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Frequências Enviadas e Arquivadas</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Histórico de visualização e download dos arquivos gerados para {selectedSector === '__gabinete__' ? 'Gabinete Parlamentar' : selectedSector}</p>
            </div>
          </div>

          {sectorArchives.length > 0 ? (
            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              {sectorArchives.map((arch, index) => (
                <div key={arch.id || index} className="border border-slate-200 bg-slate-50/45 rounded-2xl p-3 sm:p-4 hover:border-slate-350 hover:bg-white transition-all flex flex-col justify-between gap-2.5 sm:gap-3 shadow-sm hover:shadow">
                  <div className="flex flex-col xl:flex-row xl:items-start justify-between gap-2.5 sm:gap-3">
                    <div className="flex items-start gap-2 flex-1 min-w-0">
                      <FileText className="w-4 h-4 sm:w-5 sm:h-5 text-rose-600 shrink-0 mt-0.5" />
                      <div className="flex flex-col min-w-0">
                        <span className="font-semibold text-[11px] sm:text-xs text-slate-800 truncate font-mono tracking-tight" title={arch.fileName}>
                          {arch.fileName}
                        </span>
                        <span className="text-[8px] sm:text-[9px] text-slate-400 mt-0.5 font-medium leading-none truncate">
                          Por: <span className="font-bold">{arch.generatedBy?.split('@')[0] || '-'}</span>
                        </span>
                      </div>
                    </div>
                    
                    <button 
                      onClick={async () => {
                        const loadingToast = toast.loading("Baixando PDF...");
                        try {
                          if (arch.pdfUrl.startsWith('http://') || arch.pdfUrl.startsWith('https://')) {
                            window.open(arch.pdfUrl, '_blank');
                          } else {
                            const { data } = await frequencyService.downloadFile(arch.pdfUrl);
                            const url = URL.createObjectURL(data);
                            const link = document.createElement('a');
                            link.href = url;
                            link.download = arch.fileName;
                            link.click();
                            setTimeout(() => URL.revokeObjectURL(url), 100);
                          }
                          toast.success("Download iniciado", { id: loadingToast });
                        } catch (err) {
                          console.error(err);
                          toast.error("Erro ao baixar arquivo", { id: loadingToast });
                        }
                      }}
                      className="px-2 py-1 text-[9px] sm:text-[10px] font-bold bg-white text-rose-600 hover:bg-rose-50 border border-rose-105 rounded-lg transition-colors flex items-center justify-center gap-1 shrink-0 shadow-sm"
                    >
                      <Download className="w-3 h-3" /> Baixar
                    </button>
                  </div>

                  {/* Intern List of PDF */}
                  {arch.resolvedRecords && arch.resolvedRecords.length > 0 && (
                    <div className="mt-1">
                      <span className="text-[8px] font-semibold text-slate-400 uppercase tracking-widest">Estagiários: </span>
                      <span className="text-[10px] text-slate-600 font-medium">
                        {arch.resolvedRecords.map((item: any) => item.internName).join(', ')}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-slate-400 bg-slate-50/50 border border-dashed border-slate-200 rounded-2xl text-[11px] font-medium">
              Nenhuma via eletrônica enviada ou arquivada nesta competência ainda.
            </div>
          )}
        </div>
      </>
    )}
  </div>
      
      {/* Confirmation Modal */}
      {showConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center gap-3 text-amber-600 mb-4">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-lg font-bold">Confirmar Envio?</h3>
            </div>
            
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              Ao enviar à DGEP, os registros serão <span className="font-bold text-slate-900">travados para edição</span>. 
              O documento PDF será gerado e arquivado automaticamente no sistema.
            </p>
            
            <div className="flex gap-3">
              <button 
                onClick={() => setShowConfirm(false)}
                className="flex-1 px-4 py-2 text-sm font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition-all"
              >
                CANCELAR
              </button>
              <button 
                onClick={confirmSubmission}
                className="flex-1 px-4 py-2 text-sm font-bold bg-blue-600 text-white hover:bg-blue-700 rounded-xl shadow-lg shadow-blue-200 transition-all"
              >
                CONFIRMAR
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reason for Return Modal */}
      {showReason && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center gap-3 text-red-600 mb-4">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-lg font-bold">Motivo da Devolução</h3>
            </div>
            
            <div className="bg-red-50 p-4 rounded-xl border border-red-100 mb-6">
              <p className="text-sm text-red-800 leading-relaxed font-medium whitespace-pre-wrap">
                {showReason}
              </p>
            </div>
            
            <button 
              onClick={() => setShowReason(null)}
              className="w-full px-4 py-2 text-sm font-bold bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-xl transition-all"
            >
              FECHAR
            </button>
          </div>
        </div>
      )}

      {/* Multi-Select Calendar Picker Modal */}
      {activeCalendarPicker && (() => {
        const { recordId, type } = activeCalendarPicker;
        const record = records.find(r => r.id === recordId);
        const details = editedRecords[recordId];
        if (!record || !details) return null;

        const isPending = record.status === 'pending' || record.status === 'devolvida';

        // Calculate days in the selected month
        const daysInMonth = new Date(year, month, 0).getDate();
        
        let typeLabel = 'Faltas';
        let alertColorHex = 'bg-red-50 text-red-700';
        if (type === 'atestados') {
          typeLabel = 'Atestados Médicos';
          alertColorHex = 'bg-emerald-50 text-emerald-700';
        } else if (type === 'recesso') {
          typeLabel = 'Recesso';
          alertColorHex = 'bg-amber-50 text-amber-700';
        }

        // Generate day options list 1..daysInMonth
        const daysArray = Array.from({ length: daysInMonth }, (_, index) => index + 1);

        return (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full p-6 border border-slate-200 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-tight">Datas: {typeLabel}</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{record.internName}</p>
                </div>
                <button 
                  onClick={() => setActiveCalendarPicker(null)}
                  className="p-1 hover:bg-slate-100 rounded-full transition-colors focus:outline-none"
                >
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <div className="py-2">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Mês: {month.toString().padStart(2, '0')}/{year}</span>
                  <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase ${alertColorHex}`}>
                    {calendarSelectedDays.length} Dia(s) Selecionado(s)
                  </span>
                </div>

                <div className="grid grid-cols-7 gap-1.5 text-center">
                  {/* Calendar Headers */}
                  {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((h, i) => (
                    <span key={i} className="text-[9px] font-black text-slate-350">{h}</span>
                  ))}

                  {/* Offset empty days for alignment if needed */}
                  {(() => {
                    const firstDayIdx = new Date(year, month - 1, 1).getDay();
                    return Array.from({ length: firstDayIdx }).map((_, i) => (
                      <div key={`empty-${i}`} className="h-8"></div>
                    ));
                  })()}

                  {daysArray.map(dayNum => {
                    const isSelected = calendarSelectedDays.includes(dayNum);
                    let activeColor = 'bg-blue-600 text-white';
                    if (type === 'falta') activeColor = 'bg-red-600 text-white';
                    else if (type === 'atestados') activeColor = 'bg-emerald-600 text-white';
                    else if (type === 'recesso') activeColor = 'bg-amber-500 text-white';

                    return (
                      <button
                        key={dayNum}
                        type="button"
                        disabled={!isPending}
                        onClick={() => toggleDaySelection(dayNum)}
                        className={`h-8 w-8 rounded-lg text-xs font-bold transition-all flex items-center justify-center border ${
                          isSelected
                            ? `${activeColor} border-transparent shadow-sm scale-105`
                            : isPending 
                              ? 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-150 cursor-pointer hover:scale-105' 
                              : 'bg-slate-100 text-slate-400 border-transparent cursor-not-allowed'
                        }`}
                      >
                        {dayNum}
                      </button>
                    );
                  })}
                </div>

                {isPending && (
                  <p className="text-[9px] text-slate-400 text-center mt-4 uppercase font-bold tracking-wider leading-relaxed">
                    Clique sobre os dias no calendário para marcar/desmarcar
                  </p>
                )}
              </div>

              {isPending ? (
                <div className="flex gap-2">
                  <button 
                    type="button"
                    onClick={() => setActiveCalendarPicker(null)}
                    className="w-1/2 py-2 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-all"
                  >
                    CANCELAR
                  </button>
                  <button 
                    type="button"
                    onClick={confirmCalendarSelection}
                    className="w-1/2 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-md transition-all uppercase tracking-wider"
                  >
                    CONCLUÍDO
                  </button>
                </div>
              ) : (
                <button 
                  type="button"
                  onClick={() => setActiveCalendarPicker(null)}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-md transition-all"
                >
                  CONCLUÍDO
                </button>
              )}
            </div>
          </div>
        );
      })()}

      {/* Custom System Centered Alert Box */}
      {systemErrorModal && (
        <div className="fixed inset-0 z-[115] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full p-6 border border-slate-200 flex flex-col gap-4 text-center max-h-[90vh] overflow-y-auto">
            <div className="mx-auto p-3 bg-red-50 text-red-650 rounded-full w-fit">
              <AlertCircle className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-tight">{systemErrorModal.title}</h3>
              <p className="text-[11px] text-slate-500 font-semibold leading-relaxed mt-2 p-2 bg-slate-50 border border-slate-100 rounded-2xl">
                {systemErrorModal.message}
              </p>
            </div>
            <button 
              onClick={() => setSystemErrorModal(null)}
              className="w-full mt-2 py-2.5 bg-slate-950 hover:bg-slate-900 text-white rounded-xl text-xs font-black shadow-md transition-all uppercase tracking-widest cursor-pointer"
            >
              OK
            </button>
          </div>
        </div>
      )}


    </div>
  );
}

function StatCard({ label, value, icon, color }: { label: string, value: string | number, icon: ReactNode, color: string }) {
  return (
    <div className="bg-white p-5 rounded-xl border-2 border-slate-200 shadow-sm text-left hover:shadow-md transition-all group">
      <div className="flex items-center justify-between mb-2">
        <p className="text-slate-500 text-[10px] uppercase tracking-wider font-bold">{label}</p>
        <div className="p-1.5 bg-slate-50 rounded-lg group-hover:scale-110 transition-transform">
          {icon}
        </div>
      </div>
      <h3 className="text-3xl font-bold text-slate-900 mt-1 tabular-nums">{value}</h3>
      <div className="w-full bg-slate-100 h-1.5 mt-3 rounded-full overflow-hidden">
        <div className={`${color} h-full w-full opacity-60`}></div>
      </div>
    </div>
  );
}
