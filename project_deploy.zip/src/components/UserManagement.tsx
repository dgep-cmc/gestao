import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Users as UsersIcon, 
  ChevronUp, 
  ChevronDown, 
  Power, 
  Trash2,
  FileText
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { frequencyService } from '../services/frequencyService';
import { UserProfile } from '../types';
import Button from './common/Button';
import Modal from './common/Modal';
import { validateCPF, formatCPF, formatPhone } from '../lib/validation';

export default function UserManagement({ allSectors }: { allSectors: string[] }) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [confirmAction, setConfirmAction] = useState<{ 
    uid: string, 
    email: string, 
    type: 'inactivate' | 'reactivate' | 'delete' | 'roleChange',
    targetRole?: string,
    targetSectors?: string[],
    targetModules?: ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[]
  } | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedUid, setExpandedUid] = useState<string | null>(null);
  
  // New user state
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState('manager');
  const [newSectors, setNewSectors] = useState<string[]>([]);
  const [newModules, setNewModules] = useState<('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[]>(['frequency']);
  const [newCpf, setNewCpf] = useState('');
  const [newPhone, setNewPhone] = useState('');

  // Editing state for expanded user
  const [editCpf, setEditCpf] = useState('');
  const [editPhone, setEditPhone] = useState('');

  useEffect(() => {
    if (expandedUid) {
      const u = users.find(x => x.uid === expandedUid);
      if (u) {
        setEditCpf(u.cpf ? formatCPF(u.cpf) : '');
        setEditPhone(u.phone ? formatPhone(u.phone) : '');
      }
    } else {
      setEditCpf('');
      setEditPhone('');
    }
  }, [expandedUid, users]);

  useEffect(() => { loadUsers(); }, []);
  const loadUsers = async () => {
    try {
      const u = await frequencyService.getAllUsers();
      setUsers(u);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (uid: string, role: string, sectors: string[], modules: ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[], force: boolean = false, cpf?: string, phone?: string) => {
    const user = users.find(u => u.uid === uid);
    if (!user) return;

    // Only ask for confirmation if the role or modules are actually changing significantly
    if (!force && (user.role !== role)) {
      setConfirmAction({
        uid,
        email: user.email,
        type: 'roleChange',
        targetRole: role,
        targetSectors: sectors,
        targetModules: modules
      });
      return;
    }

    try {
      const finalCpf = cpf !== undefined ? cpf : user.cpf;
      const finalPhone = phone !== undefined ? phone : user.phone;
      await frequencyService.updateUserRole(uid, role, sectors, modules, finalCpf, finalPhone);
      toast.success("Perfil atualizado");
      loadUsers();
    } catch (e: any) { 
      console.error(e);
      toast.error("Falha na atualização"); 
    }
  };

  const handleAddUser = async () => {
    if (!newEmail.trim()) {
      toast.error("Preencha o email institucional");
      return;
    }
    if (!newCpf.trim()) {
      toast.error("Preencha o CPF do usuário");
      return;
    }
    if (!validateCPF(newCpf)) {
      toast.error("CPF inválido");
      return;
    }
    if (newModules.length === 0) {
      toast.error("Selecione pelo menos um módulo de acesso");
      return;
    }
    const cleanEmail = newEmail.trim().toLowerCase();
    
    if (users.find(u => u.email.toLowerCase() === cleanEmail)) {
      toast.error("Este email já possui um perfil cadastrado.");
      return;
    }

    try {
      setActionLoading(true);
      await frequencyService.addUserByEmail(cleanEmail, newRole, newSectors, newModules, newCpf, newPhone);
      toast.success("Usuário adicionado com sucesso!");
      setNewEmail('');
      setNewCpf('');
      setNewPhone('');
      setNewSectors([]);
      setNewModules(['frequency']);
      loadUsers();
    } catch (e: any) {
      console.error(e);
      toast.error("Falha ao adicionar usuário");
    } finally {
      setActionLoading(false);
    }
  };

  const executeGroupAction = async () => {
    if (!confirmAction) return;
    const { uid, type, targetRole, targetSectors, targetModules } = confirmAction;
    setConfirmAction(null);
    setActionLoading(true);

    try {
      if (type === 'delete') {
        await frequencyService.deleteUser(uid);
        toast.success("Usuário excluído com sucesso");
      } else if (type === 'roleChange' && targetRole) {
        await handleUpdate(uid, targetRole, targetSectors || [], targetModules || ['frequency'], true);
      } else {
        await frequencyService.toggleUserActive(uid, type === 'reactivate');
        toast.success(`Usuário ${type === 'inactivate' ? 'inativado' : 'reativado'} com sucesso`);
      }
      loadUsers();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao processar ação de usuário");
    } finally {
      setActionLoading(false);
    }
  };

  const toggleModule = (module: 'frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados', current: ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[], setter: (val: ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[]) => void) => {
    if (current.includes(module)) {
      setter(current.filter(m => m !== module));
    } else {
      setter([...current, module]);
    }
  };

  const filteredUsers = users.filter(u => {
    const search = searchTerm.toLowerCase();
    return (
      u.email.toLowerCase().includes(search) ||
      (u.sectors || []).some(s => s.toLowerCase().includes(search))
    );
  });

  if (loading) {
    return (
      <div className="bg-white p-20 text-center border border-slate-200 rounded-xl">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="text-xs text-slate-400 mt-4 font-medium uppercase tracking-widest">Carregando Usuários...</p>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
      <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <h3 className="text-sm font-bold text-slate-700">Gestão de Acessos</h3>
      </div>
      
      {/* Add New User & Search */}
      <div className="p-4 sm:px-6 bg-slate-50 border-b border-slate-200">
        <div className="flex flex-col lg:flex-row gap-6 mb-6">
          <div className="lg:w-3/5 flex flex-col gap-4 p-4 bg-white border border-slate-200 rounded-xl shadow-sm">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Cadastrar Novo Usuário</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Email Institucional</label>
                <input 
                  type="email" 
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="usuario@cmc.pr.gov.br"
                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 transition-all"
                />
              </div>
              <div>
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Nível de Acesso</label>
                <select 
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-2 text-sm focus:ring-blue-500"
                >
                  <option value="manager">Gestor</option>
                  <option value="master">Admin (DGEP)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">CPF (obrigatório)</label>
                <input 
                  type="text" 
                  value={newCpf}
                  onChange={(e) => setNewCpf(formatCPF(e.target.value))}
                  placeholder="000.000.000-00"
                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 transition-all"
                />
              </div>
              <div>
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Telefone (opcional)</label>
                <input 
                  type="text" 
                  value={newPhone}
                  onChange={(e) => setNewPhone(formatPhone(e.target.value))}
                  placeholder="(00) 00000-0000"
                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500 transition-all"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Módulos Permitidos</label>
              <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={newModules.includes('frequency')} 
                    onChange={() => toggleModule('frequency', newModules, setNewModules)}
                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-semibold text-slate-700">Frequência Estagiários</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={newModules.includes('frequency_comissionados')} 
                    onChange={() => toggleModule('frequency_comissionados', newModules, setNewModules)}
                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-semibold text-slate-700">Frequência Comissionados</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={newModules.includes('hiring')} 
                    onChange={() => toggleModule('hiring', newModules, setNewModules)}
                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-semibold text-slate-700">Contratação Estagiários</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={newModules.includes('hiring_comissionados')} 
                    onChange={() => toggleModule('hiring_comissionados', newModules, setNewModules)}
                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-semibold text-slate-700">Contratação Comissionados</span>
                </label>
              </div>
            </div>

            <div className="relative">
              <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Lotações Designadas (opcional)</label>
              <SectorEditor 
                sectors={newSectors} 
                availableSectors={allSectors} 
                onChange={setNewSectors} 
              />
            </div>
            
            <Button
              onClick={handleAddUser}
              isLoading={actionLoading}
              className="mt-2"
            >
              CADASTRAR USUÁRIO
            </Button>
          </div>

          <div className="lg:w-2/5 flex flex-col gap-4 p-4 bg-white border border-slate-200 rounded-xl shadow-sm justify-center">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Localizar Usuário</h4>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Busca por email ou lotação..."
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none"
              />
            </div>
            <p className="text-[10px] text-slate-400">Total de {users.length} usuários cadastrados</p>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50">
            <tr className="text-[10px] uppercase text-slate-400 font-bold">
              <th className="px-6 py-4 border-b border-slate-100">Usuário / Nível</th>
              <th className="px-6 py-4 border-b border-slate-100 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="text-sm divide-y divide-slate-100">
            {filteredUsers.length === 0 ? (
              <tr>
                <td colSpan={2} className="px-6 py-20 text-center text-slate-400">
                  <Search className="w-10 h-10 mx-auto mb-2 opacity-10" />
                  Nenhum usuário encontrado com os termos: "{searchTerm}"
                </td>
              </tr>
            ) : (
              filteredUsers.map((u, index) => (
                <React.Fragment key={u.uid}>
                  <tr 
                    onClick={() => setExpandedUid(expandedUid === u.uid ? null : u.uid)}
                    className={`cursor-pointer transition-colors ${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'} hover:bg-blue-50/50 ${u.active === false ? 'opacity-60' : ''}`}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                          u.role === 'master' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {u.email[0].toUpperCase()}
                        </div>
                        <div className="flex flex-col">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900">{u.email}</span>
                            {u.active === false && (
                              <span className="text-[9px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded font-bold uppercase">Inativo</span>
                            )}
                            <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                              u.role === 'master' ? 'bg-indigo-50 text-indigo-600 border border-indigo-100' : 'bg-slate-100 text-slate-500 border border-slate-200'
                            }`}>
                              {u.role === 'master' ? 'ADMIN' : 'GESTOR'}
                            </span>
                          </div>
                          <div className="flex gap-2 items-center mt-0.5">
                            {(u.allowedModules || ['frequency']).map(m => {
                              let bgClass = "bg-slate-50 text-slate-600 border-slate-100";
                              let text: string = m;
                              if (m === 'frequency') {
                                bgClass = "bg-blue-50 text-blue-600 border-blue-100";
                                text = "Freq. Estag.";
                              } else if (m === 'frequency_comissionados') {
                                bgClass = "bg-purple-50 text-purple-600 border-purple-100";
                                text = "Freq. Com.";
                              } else if (m === 'hiring') {
                                bgClass = "bg-emerald-50 text-emerald-600 border-emerald-100";
                                text = "Contrat. Estag.";
                              } else if (m === 'hiring_comissionados') {
                                bgClass = "bg-indigo-50 text-indigo-600 border-indigo-100";
                                text = "Contrat. Com.";
                              }
                              return (
                                <span key={m} className={`text-[8px] font-black px-1.5 py-0.5 rounded-sm border ${bgClass}`}>
                                  {text}
                                </span>
                              );
                            })}
                          </div>
                          {(u.sectors || []).length > 0 && (
                            <span className="text-[10px] text-slate-500 mt-1">
                              {(u.sectors || []).join(', ').slice(0, 80)}
                              {(u.sectors || []).join(', ').length > 80 && '...'}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {expandedUid === u.uid ? <ChevronUp className="w-4 h-4 text-blue-500" /> : <ChevronDown className="w-4 h-4 text-slate-300" />}
                      </div>
                    </td>
                  </tr>
                  
                  {expandedUid === u.uid && (
                    <tr className={index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                      <td colSpan={2} className="px-6 pb-6 pt-2 border-t border-blue-100/50 bg-blue-50/20">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                          <div className="space-y-4">
                            <div className="flex flex-col gap-1.5">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Alterar Nível de Acesso</label>
                              <div className="flex bg-white border border-slate-200 rounded-lg p-1.5 gap-2 max-w-sm">
                                <button 
                                  onClick={() => handleUpdate(u.uid, 'manager', u.sectors || [], (u.allowedModules as any) || ['frequency'])}
                                  className={`flex-1 py-1.5 text-[10px] font-bold rounded-md transition-all ${u.role === 'manager' ? 'bg-slate-900 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
                                >
                                  GESTOR
                                </button>
                                <button 
                                  onClick={() => handleUpdate(u.uid, 'master', u.sectors || [], (u.allowedModules as any) || ['frequency'])}
                                  className={`flex-1 py-1.5 text-[10px] font-bold rounded-md transition-all ${u.role === 'master' ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
                                >
                                  ADMIN (DGEP)
                                </button>
                              </div>
                            </div>

                            <div className="flex flex-col gap-1.5">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Módulos Permitidos</label>
                              <div className="flex flex-col gap-2 p-3 bg-white border border-slate-200 rounded-lg">
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input 
                                    type="checkbox" 
                                    checked={(u.allowedModules || ['frequency']).includes('frequency')} 
                                    onChange={() => {
                                      const current = u.allowedModules || ['frequency'];
                                      const next = (current.includes('frequency') ? current.filter(m => m !== 'frequency') : [...current, 'frequency']) as ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[];
                                      if (next.length === 0) return toast.error("Selecione pelo menos um módulo");
                                      handleUpdate(u.uid, u.role, u.sectors || [], next);
                                    }}
                                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                  />
                                  <span className="text-xs font-semibold text-slate-700">Frequência Estagiários</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input 
                                    type="checkbox" 
                                    checked={(u.allowedModules || ['frequency']).includes('frequency_comissionados')} 
                                    onChange={() => {
                                      const current = u.allowedModules || ['frequency'];
                                      const next = (current.includes('frequency_comissionados') ? current.filter(m => m !== 'frequency_comissionados') : [...current, 'frequency_comissionados']) as ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[];
                                      if (next.length === 0) return toast.error("Selecione pelo menos um módulo");
                                      handleUpdate(u.uid, u.role, u.sectors || [], next);
                                    }}
                                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                  />
                                  <span className="text-xs font-semibold text-slate-700">Frequência Comissionados</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input 
                                    type="checkbox" 
                                    checked={(u.allowedModules || ['frequency']).includes('hiring')} 
                                    onChange={() => {
                                      const current = u.allowedModules || ['frequency'];
                                      const next = (current.includes('hiring') ? current.filter(m => m !== 'hiring') : [...current, 'hiring']) as ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[];
                                      if (next.length === 0) return toast.error("Selecione pelo menos um módulo");
                                      handleUpdate(u.uid, u.role, u.sectors || [], next);
                                    }}
                                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                  />
                                  <span className="text-xs font-semibold text-slate-700">Contratação Estagiários</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input 
                                    type="checkbox" 
                                    checked={(u.allowedModules || ['frequency']).includes('hiring_comissionados')} 
                                    onChange={() => {
                                      const current = u.allowedModules || ['frequency'];
                                      const next = (current.includes('hiring_comissionados') ? current.filter(m => m !== 'hiring_comissionados') : [...current, 'hiring_comissionados']) as ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[];
                                      if (next.length === 0) return toast.error("Selecione pelo menos um módulo");
                                      handleUpdate(u.uid, u.role, u.sectors || [], next);
                                    }}
                                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                  />
                                  <span className="text-xs font-semibold text-slate-700">Contratação Comissionados</span>
                                </label>
                              </div>
                            </div>

                            <div className="flex flex-col gap-1.5">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Lotações Designadas</label>
                              <SectorEditor 
                                sectors={u.sectors || []} 
                                availableSectors={allSectors} 
                                onChange={(newSectors) => handleUpdate(u.uid, u.role, newSectors, (u.allowedModules as any) || ['frequency'])} 
                              />
                            </div>
                          </div>

                          <div className="space-y-4">
                            <div className="flex flex-col gap-1.5">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Controles de Conta</label>
                              <div className="flex flex-wrap gap-3">
                                <button
                                  onClick={() => setConfirmAction({ 
                                    uid: u.uid, 
                                    email: u.email, 
                                    type: u.active === false ? 'reactivate' : 'inactivate' 
                                  })}
                                  className={`flex items-center gap-2 px-4 py-2 text-[10px] font-bold rounded-lg border transition-all ${
                                    u.active === false 
                                      ? 'bg-green-50 border-green-200 text-green-700 hover:bg-green-100' 
                                      : 'bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100'
                                  }`}
                                >
                                  <Power className="w-3.5 h-3.5" />
                                  {u.active !== false ? "INATIVAR ACESSO" : "REATIVAR ACESSO"}
                                </button>

                                <button
                                  onClick={() => setConfirmAction({ uid: u.uid, email: u.email, type: 'delete' })}
                                  className="flex items-center gap-2 px-4 py-2 text-[10px] font-bold rounded-lg border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition-all"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  EXCLUIR PERFIL
                                </button>
                              </div>
                            </div>
                            
                            <div className="flex flex-col gap-1.5 bg-white border border-slate-200 rounded-lg p-3 space-y-3">
                              <p className="text-[10px] text-slate-400 uppercase font-bold border-b border-slate-100 pb-1">Dados Cadastrais</p>
                              <div>
                                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">CPF (obrigatório)</label>
                                <input 
                                  type="text" 
                                  value={editCpf}
                                  onChange={(e) => setEditCpf(formatCPF(e.target.value))}
                                  placeholder="000.000.000-00"
                                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-1.5 text-xs focus:ring-blue-500"
                                />
                              </div>
                              <div>
                                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">Telefone (opcional)</label>
                                <input 
                                  type="text" 
                                  value={editPhone}
                                  onChange={(e) => setEditPhone(formatPhone(e.target.value))}
                                  placeholder="(00) 00000-0000"
                                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-3 py-1.5 text-xs focus:ring-blue-500"
                                />
                              </div>
                              <button
                                onClick={async () => {
                                  if (!editCpf.trim()) {
                                    toast.error("O CPF é obrigatório");
                                    return;
                                  }
                                  if (!validateCPF(editCpf)) {
                                    toast.error("CPF inválido");
                                    return;
                                  }
                                  try {
                                    setActionLoading(true);
                                    await frequencyService.updateUserRole(u.uid, u.role, u.sectors || [], u.allowedModules || ['frequency'], editCpf, editPhone);
                                    toast.success("Dados cadastrais salvos");
                                    loadUsers();
                                  } catch (err) {
                                    toast.error("Erro ao salvar dados");
                                  } finally {
                                    setActionLoading(false);
                                  }
                                }}
                                className="w-full py-1.5 text-[9px] font-bold uppercase tracking-wider rounded bg-blue-600 hover:bg-blue-700 text-white transition-all active:scale-[0.98]"
                              >
                                Salvar Dados Cadastrais
                              </button>
                            </div>
                            
                            <div className="p-3 bg-white border border-slate-200 rounded-lg">
                               <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Informações Técnicas</p>
                               <p className="text-[9px] text-slate-500 font-mono break-all">ID: {u.uid}</p>
                               <p className="text-[9px] text-slate-500 mt-1 uppercase">Última atualização: {new Date().toLocaleDateString()}</p>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal
        isOpen={!!confirmAction}
        onClose={() => setConfirmAction(null)}
        title={
          confirmAction?.type === 'delete' ? 'Excluir Usuário?' : 
          confirmAction?.type === 'inactivate' ? 'Inativar Usuário?' : 
          confirmAction?.type === 'roleChange' ? 'Alterar Nível de Acesso?' : 'Reativar Usuário?'
        }
        confirmLabel={actionLoading ? 'PROCESSANDO...' : 'CONFIRMAR'}
        onConfirm={executeGroupAction}
        confirmVariant={
          confirmAction?.type === 'delete' ? 'danger' : 
          confirmAction?.type === 'inactivate' ? 'danger' : 
          confirmAction?.type === 'roleChange' ? 'primary' : 'success'
        }
        isLoading={actionLoading}
      >
        <p className="text-sm text-slate-600 leading-relaxed font-medium">
          Deseja realmente {
            confirmAction?.type === 'delete' ? 'excluir DEFINITIVAMENTE' : 
            confirmAction?.type === 'inactivate' ? 'inativar' : 
            confirmAction?.type === 'roleChange' ? `alterar para ${confirmAction.targetRole === 'master' ? 'ADMIN (DGEP)' : 'GESTOR'}` : 'reativar'
          } o acesso de <span className="font-bold text-slate-900">{confirmAction?.email}</span>?
          {confirmAction?.type === 'delete' && <span className="block mt-2 text-red-500 font-bold">Esta ação não pode ser desfeita.</span>}
        </p>
      </Modal>
    </div>
  );
}

function SectorEditor({ sectors, availableSectors = [], onChange }: { sectors: string[], availableSectors?: string[], onChange: (s: string[]) => void }) {
  const [val, setVal] = useState('');
  const sortedAvailableSectors = [...(availableSectors || [])].sort((a, b) =>
    a.localeCompare(b, 'pt-BR', { sensitivity: 'base' })
  );

  return (
    <div className="flex flex-col gap-2 w-full">
      <div className="flex gap-2 items-center flex-wrap">
        {sectors.map(s => (
          <div key={s} className="bg-slate-200 text-slate-700 text-xs font-bold px-2 py-1 rounded-md flex items-center gap-1.5">
            {s}
            <button 
              onClick={() => onChange(sectors.filter(x => x !== s))}
              className="hover:text-red-600 focus:outline-none"
            >
              ×
            </button>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input 
          list="sector-options"
          type="text"
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              if (val.trim() && !sectors.includes(val.trim())) {
                onChange([...sectors, val.trim()]);
                setVal('');
              }
            }
          }}
          className="min-w-0 flex-1 bg-white border border-slate-200 rounded-md text-xs px-2 py-1.5 focus:ring-blue-500"
          placeholder="Adicionar lotação..."
        />
        <datalist id="sector-options">
          {sortedAvailableSectors.map(s => (
            <option key={s} value={s} />
          ))}
        </datalist>
        <button 
          onClick={() => {
            if (val.trim() && !sectors.includes(val.trim())) {
              onChange([...sectors, val.trim()]);
              setVal('');
            }
          }}
          className="bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-600 px-2.5 py-1.5 rounded-md text-sm font-bold transition-colors"
        >
          +
        </button>
      </div>
    </div>
  );
}
