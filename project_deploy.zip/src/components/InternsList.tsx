import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  ArrowUpDown, 
  Printer, 
  Download,
  Building2,
  FileText,
  CheckCircle2,
  AlertCircle,
  Clock
} from 'lucide-react';
import { frequencyService } from '../services/frequencyService';
import { FrequencyRecord, UserProfile } from '../types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'react-hot-toast';
import { generateInternsListPDF } from '../lib/pdfGenerator';
import Button from './common/Button';

type SortKey = 'matricula' | 'internName' | 'lotacao' | 'periodo' | 'falta' | 'atestados' | 'recesso' | 'status';

export default function InternsList({ month, year, profile, isComissionados = false }: { month: number, year: number, profile?: UserProfile | null, isComissionados?: boolean }) {
  const [records, setRecords] = useState<FrequencyRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'asc' | 'desc' } | null>({ key: 'internName', direction: 'asc' });
  
  // Filters
  const [filters, setFilters] = useState({
    status: [] as string[],
    hasFaltas: false,
    hasAtestados: false,
    hasRecesso: false,
  });

  useEffect(() => {
    loadRecords();
  }, [month, year]);

  const loadRecords = async () => {
    setLoading(true);
    try {
      const data = isComissionados
        ? await frequencyService.getComissionadosFrequenciesByPeriod(month, year)
        : await frequencyService.getFrequenciesByPeriod(month, year);
      setRecords(data);
    } catch (error) {
      toast.error(`Erro ao carregar ${isComissionados ? 'servidores' : 'estagiários'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (key: SortKey) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'validada': return 'Validada';
      case 'submitted': return 'Enviada';
      case 'devolvida': return 'Devolvida';
      default: return 'Pendente';
    }
  };

  const filteredRecords = records.filter(r => {
    const matchesSearch = r.internName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          r.lotacao.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filters.status.length === 0 || filters.status.includes(r.status);
    
    // Combined logic filters
    const hasFaltaValue = (r.details?.falta && r.details.falta !== '0');
    const hasAtestadoValue = (r.details?.atestados && r.details.atestados !== '0');
    const hasRecessoValue = (r.details?.recesso && r.details.recesso !== '0');

    const hasAnyOccurrenceFilter = filters.hasFaltas || filters.hasAtestados || filters.hasRecesso;
    const matchesOccurrences = !hasAnyOccurrenceFilter || (
      (filters.hasFaltas && hasFaltaValue) ||
      (filters.hasAtestados && hasAtestadoValue) ||
      (filters.hasRecesso && hasRecessoValue)
    );

    return matchesSearch && matchesStatus && matchesOccurrences;
  });

  const sortedRecords = [...filteredRecords].sort((a, b) => {
    if (!sortConfig) return 0;
    
    const { key, direction } = sortConfig;
    let aValue: any = a[key as keyof FrequencyRecord] || '';
    let bValue: any = b[key as keyof FrequencyRecord] || '';

    // Handle details fields
    if (key === 'falta') aValue = Number(a.details?.falta) || 0;
    if (key === 'falta') bValue = Number(b.details?.falta) || 0;
    if (key === 'atestados') aValue = Number(a.details?.atestados) || 0;
    if (key === 'atestados') bValue = Number(b.details?.atestados) || 0;
    if (key === 'recesso') aValue = Number(a.details?.recesso) || 0;
    if (key === 'recesso') bValue = Number(b.details?.recesso) || 0;
    if (key === 'periodo') aValue = a.details?.periodo || a.periodoOriginal || '';
    if (key === 'periodo') bValue = b.details?.periodo || b.periodoOriginal || '';

    if (aValue < bValue) return direction === 'asc' ? -1 : 1;
    if (aValue > bValue) return direction === 'asc' ? 1 : -1;
    return 0;
  });

  const toggleStatusFilter = (status: string) => {
    setFilters(prev => ({
      ...prev,
      status: prev.status.includes(status) 
        ? prev.status.filter(s => s !== status)
        : [...prev.status, status]
    }));
  };

  const handleExportPDF = () => {
    try {
      const userName = profile?.name || 'Administrador';
      const userEmail = profile?.email || 'dgep@cmc.pr.gov.br';
      generateInternsListPDF(sortedRecords, month, year, userName, userEmail, isComissionados);
      toast.success("PDF gerado com sucesso!");
    } catch (error) {
      console.error(error);
      toast.error("Erro ao gerar PDF");
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-20">
      {/* Filters Bar */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-3">
              <Search className="w-5 h-5 text-slate-400" />
              <h3 className="text-sm font-bold text-slate-700 uppercase">Busca e Filtros</h3>
            </div>
            <input 
              type="text" 
              placeholder="Buscar por nome ou lotação..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 transition-all outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="lg:w-1/2 border-l border-slate-100 lg:pl-6 space-y-4">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Opções de Filtro Combinado</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="space-y-2">
                <p className="text-[10px] text-slate-500 font-bold">Status</p>
                <div className="space-y-1.5">
                  <FilterCheckbox label="Pendentes" checked={filters.status.includes('pending')} onChange={() => toggleStatusFilter('pending')} />
                  <FilterCheckbox label="Enviadas" checked={filters.status.includes('submitted')} onChange={() => toggleStatusFilter('submitted')} />
                  <FilterCheckbox label="Validadas" checked={filters.status.includes('validada')} onChange={() => toggleStatusFilter('validada')} />
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-[10px] text-slate-500 font-bold">Ocorrências</p>
                <div className="space-y-1.5">
                  <FilterCheckbox label="Com Faltas" checked={filters.hasFaltas} onChange={() => setFilters(f => ({...f, hasFaltas: !f.hasFaltas}))} />
                  <FilterCheckbox label="Com Atestados" checked={filters.hasAtestados} onChange={() => setFilters(f => ({...f, hasAtestados: !f.hasAtestados}))} />
                  <FilterCheckbox label={isComissionados ? "Com Férias" : "Com Recesso"} checked={filters.hasRecesso} onChange={() => setFilters(f => ({...f, hasRecesso: !f.hasRecesso}))} />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-end">
            <Button 
              onClick={handleExportPDF}
              icon={FileText}
            >
              GERAR RELATÓRIO PDF
            </Button>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <h3 className="text-sm font-bold text-slate-700">Listagem Geral de {isComissionados ? 'Servidores' : 'Estagiários'}</h3>
          <span className="text-[10px] font-bold text-slate-400 bg-white px-2 py-1 rounded border border-slate-200">
            {sortedRecords.length} REGISTROS ENCONTRADOS
          </span>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] uppercase text-slate-400 font-bold bg-white">
                <TableHeader label="Matrícula" sortKey="matricula" currentSort={sortConfig} onSort={handleSort} />
                <TableHeader label="Nome" sortKey="internName" currentSort={sortConfig} onSort={handleSort} />
                <TableHeader label="Lotação" sortKey="lotacao" currentSort={sortConfig} onSort={handleSort} />
                <TableHeader label="Período" sortKey="periodo" currentSort={sortConfig} onSort={handleSort} />
                <TableHeader label="Faltas" sortKey="falta" currentSort={sortConfig} onSort={handleSort} className="text-center" />
                <TableHeader label="Atestados" sortKey="atestados" currentSort={sortConfig} onSort={handleSort} className="text-center" />
                <TableHeader label="Recesso" sortKey={isComissionados ? "recesso" : "recesso"} labelOverride={isComissionados ? "Férias" : undefined} currentSort={sortConfig} onSort={handleSort} className="text-center" />
                <TableHeader label="Status" sortKey="status" currentSort={sortConfig} onSort={handleSort} />
              </tr>
            </thead>
            <tbody className="text-[12px] divide-y divide-slate-100">
              {loading ? (
                <tr>
                   <td colSpan={8} className="px-6 py-20 text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  </td>
                </tr>
              ) : sortedRecords.length === 0 ? (
                <tr>
                   <td colSpan={8} className="px-6 py-20 text-center text-slate-400 font-medium">Nenhum registro encontrado com os filtros selecionados.</td>
                </tr>
              ) : (
                sortedRecords.map(r => (
                  <tr key={r.id} className="hover:bg-slate-50/50 transition-colors">
                     <td className="px-4 py-3 font-semibold text-slate-600 whitespace-nowrap">
                      {r.matricula || '-'}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900 whitespace-normal break-words max-w-[240px]">
                      <div>{r.internName}</div>
                      {r.details?.datasJustificadas && (
                        <div className="text-[9px] text-slate-400 font-normal italic tracking-tight whitespace-normal max-w-xs leading-tight mt-0.5">
                          Datas: {r.details.datasJustificadas}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[11px] font-medium text-slate-500 whitespace-normal break-words max-w-[200px]">{r.lotacao}</td>
                    <td className="px-4 py-3 text-[11px] text-slate-500 font-medium whitespace-nowrap">{r.details?.periodo || r.periodoOriginal}</td>
                    <td className="px-3 py-3 text-center text-slate-500 font-medium">{r.details?.falta || '0'}</td>
                    <td className="px-3 py-3 text-center text-slate-500 font-medium">{r.details?.atestados || '0'}</td>
                    <td className="px-3 py-3 text-center text-slate-500 font-medium">{r.details?.recesso || '0'}</td>
                    <td className="px-4 py-3">
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border whitespace-nowrap ${
                        r.status === 'validada' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                        r.status === 'submitted' ? 'bg-green-50 text-green-700 border-green-200' :
                        r.status === 'devolvida' ? 'bg-red-50 text-red-700 border-red-200' :
                        'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        {getStatusLabel(r.status).toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function TableHeader({ label, sortKey, currentSort, onSort, className = "", labelOverride }: { 
  label: string; 
  sortKey: SortKey; 
  currentSort: { key: SortKey; direction: 'asc' | 'desc' } | null;
  onSort: (key: SortKey) => void;
  className?: string;
  labelOverride?: string;
}) {
  const active = currentSort?.key === sortKey;
  
  return (
    <th className={`px-6 py-4 border-b border-slate-100 group cursor-pointer hover:bg-slate-50 transition-colors ${className}`} onClick={() => onSort(sortKey)}>
      <div className={`flex items-center gap-2 ${className.includes('text-center') ? 'justify-center' : ''}`}>
        {labelOverride || label}
        <ArrowUpDown className={`w-3 h-3 transition-colors ${active ? 'text-blue-500' : 'text-slate-300 group-hover:text-slate-400'}`} />
      </div>
    </th>
  );
}

function FilterCheckbox({ label, checked, onChange }: { label: string, checked: boolean, onChange: () => void }) {
  return (
    <label className="flex items-center gap-2 cursor-pointer group">
      <div className={`w-3.5 h-3.5 rounded border transition-all flex items-center justify-center ${
        checked ? 'bg-blue-600 border-blue-600' : 'bg-white border-slate-300 group-hover:border-slate-400'
      }`}>
        {checked && <CheckCircle2 className="w-2.5 h-2.5 text-white" strokeWidth={3} />}
      </div>
      <span className={`text-[11px] font-medium transition-colors ${checked ? 'text-slate-900 font-bold' : 'text-slate-500'}`}>{label}</span>
      <input type="checkbox" className="sr-only" checked={checked} onChange={onChange} />
    </label>
  );
}
