import React, { useState, useEffect } from 'react';
import { 
  Users, 
  MapPin, 
  ArrowLeft, 
  Plus, 
  Trash2, 
  FolderSync, 
  HelpCircle,
  ShieldCheck
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { frequencyService } from '../services/frequencyService';
import DriveDiagnostics from './DriveDiagnostics';
import Button from './common/Button';
import Modal from './common/Modal';

interface AdminPanelProps {
  onBack: () => void;
}

export default function AdminPanel({ onBack }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'sectors' | 'drive_diag'>('sectors');
  const [sectors, setSectors] = useState<{ id: string; name: string }[]>([]);
  const [mappings, setMappings] = useState<{ id: string; alias: string; targetSectorId: string }[]>([]);
  
  // New sector inputs
  const [newSectorName, setNewSectorName] = useState('');
  
  // Loading states
  const [loading, setLoading] = useState(true);
  const [btnLoading, setBtnLoading] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string; type: 'sector' | 'mapping' } | null>(null);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    try {
      setLoading(true);
      const [secList, mapList] = await Promise.all([
        frequencyService.getAllSectorsList(),
        frequencyService.getSectorMappings()
      ]);
      setSectors(secList);
      setMappings(mapList);
    } catch (err) {
      console.error(err);
      toast.error("Erro ao carregar dados administrativos.");
    } finally {
      setLoading(false);
    }
  };

  const handleAddSector = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSectorName.trim()) {
      toast.error("Insira o nome da lotação");
      return;
    }
    
    // Check if sector already exists
    const duplicate = sectors.find(s => s.name.toUpperCase() === newSectorName.trim().toUpperCase());
    if (duplicate) {
      toast.error("Esta lotação já está cadastrada.");
      return;
    }

    try {
      setBtnLoading(true);
      await frequencyService.createSector(newSectorName.trim());
      toast.success("Lotação oficial cadastrada com sucesso!");
      setNewSectorName('');
      loadAdminData();
    } catch (err) {
      console.error(err);
      toast.error("Falha ao criar lotação.");
    } finally {
      setBtnLoading(false);
    }
  };

  const handleDeleteSector = async () => {
    if (!deleteTarget) return;
    try {
      setBtnLoading(true);
      if (deleteTarget.type === 'sector') {
        await frequencyService.deleteSector(deleteTarget.id);
        toast.success("Lotação excluída com sucesso.");
      } else {
        await frequencyService.deleteSectorMapping(deleteTarget.id);
        toast.success("Mapeamento excluído com sucesso.");
      }
      setDeleteTarget(null);
      loadAdminData();
    } catch (err) {
      console.error(err);
      toast.error("Falha ao efetuar exclusão.");
    } finally {
      setBtnLoading(false);
    }
  };

  const getSectorNameById = (id: string) => {
    return sectors.find(s => s.id === id)?.name || "Lotação Desconhecida";
  };

  const sectorNamesArray = sectors.map(s => s.name);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-500 hover:text-slate-700"
              title="Voltar ao Portal"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-lg font-bold text-gray-900 leading-none">Painel Administrativo do Portal</h1>
              <p className="text-[10px] font-bold text-blue-600 uppercase tracking-wider mt-1">DGEP - Controle Centralizado</p>
            </div>
          </div>
          
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('sectors')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                activeTab === 'sectors' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <MapPin className="w-4 h-4" />
              Lotações (Setores)
            </button>
            <button
              onClick={() => setActiveTab('drive_diag')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                activeTab === 'drive_diag' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              Google Drive
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 bg-white border border-gray-200 rounded-2xl shadow-sm">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
            <p className="text-xs text-slate-400 mt-4 font-bold uppercase tracking-widest">Carregando painel...</p>
          </div>
        ) : activeTab === 'drive_diag' ? (
          <div className="bg-white border border-slate-250 rounded-2xl p-6 shadow-sm">
            <DriveDiagnostics />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Register Sector */}
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 pb-2 border-b border-slate-100">
                  Cadastrar Nova Lotação
                </h3>
                <form onSubmit={handleAddSector} className="space-y-4">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 block">
                      Nome Oficial da Lotação
                    </label>
                    <input 
                      type="text" 
                      value={newSectorName}
                      onChange={(e) => setNewSectorName(e.target.value)}
                      placeholder="EX: GABINETE DA PRESIDÊNCIA"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm uppercase placeholder:normal-case font-semibold focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <Button
                    type="submit"
                    isLoading={btnLoading}
                    className="w-full py-2.5 flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    CADASTRAR LOTAÇÃO
                  </Button>
                </form>
              </div>

              <div className="bg-slate-100 rounded-2xl p-6 border border-slate-200 text-slate-600">
                <h4 className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-2">
                  <FolderSync className="w-4 h-4 text-blue-600" />
                  Mapeamentos Inteligentes
                </h4>
                <p className="text-xs leading-relaxed">
                  Os apelidos de mapeamento (Aliases) são associados no momento da importação do CSV. Eles servem para traduzir grafias variantes ou abreviadas usadas na folha para os nomes de lotação oficiais cadastrados no sistema.
                </p>
              </div>
            </div>

            {/* Right Column: List of Sectors & Mappings */}
            <div className="lg:col-span-2 space-y-6">
              {/* Lotações Oficiais */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                  <h3 className="text-xs font-black text-slate-700 uppercase tracking-widest">
                    Lotações Cadastradas ({sectors.length})
                  </h3>
                </div>
                
                {sectors.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs font-medium">
                    Nenhuma lotação cadastrada no momento. Adicione uma nova lotação ao lado.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 max-h-[400px] overflow-y-auto">
                    {sectors.map((sector) => (
                      <div key={sector.id} className="px-6 py-3 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                        <div>
                          <p className="text-sm font-bold text-slate-900">{sector.name}</p>
                          <p className="text-[9px] font-mono text-slate-400">ID: {sector.id}</p>
                        </div>
                        <button
                          onClick={() => setDeleteTarget({ id: sector.id, name: sector.name, type: 'sector' })}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          title="Excluir Lotação"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Mapeamento de Apelidos */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                  <h3 className="text-xs font-black text-slate-700 uppercase tracking-widest">
                    Regras de Mapeamento Ativas ({mappings.length})
                  </h3>
                </div>
                
                {mappings.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs font-medium">
                    Nenhuma regra de mapeamento criada ainda. Elas serão salvas durante a validação de importação de CSVs.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 max-h-[300px] overflow-y-auto">
                    {mappings.map((mapRule) => (
                      <div key={mapRule.id} className="px-6 py-3 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-650 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-md font-mono">
                              "{mapRule.alias}"
                            </span>
                            <span className="text-[10px] text-slate-400">traduz para ➔</span>
                            <span className="text-xs font-bold text-blue-700">
                              {getSectorNameById(mapRule.targetSectorId)}
                            </span>
                          </div>
                        </div>
                        <button
                          onClick={() => setDeleteTarget({ id: mapRule.id, name: `Regra para "${mapRule.alias}"`, type: 'mapping' })}
                          className="p-1.5 text-slate-400 hover:text-red-650 hover:bg-red-50 rounded-lg transition-all"
                          title="Excluir Regra de Mapeamento"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <Modal
          isOpen={!!deleteTarget}
          title="Confirmar Exclusão"
          onClose={() => setDeleteTarget(null)}
          onConfirm={handleDeleteSector}
          confirmLabel="Excluir"
          confirmVariant="danger"
          isLoading={btnLoading}
        >
          <p className="text-sm text-slate-500 leading-relaxed">
            Tem certeza de que deseja excluir {deleteTarget.type === 'sector' ? 'a lotação oficial' : 'o mapeamento'} <strong className="text-slate-800">"{deleteTarget.name}"</strong>?
          </p>
          {deleteTarget.type === 'sector' && (
            <p className="text-[11px] text-amber-600 mt-2 bg-amber-50 border border-amber-250 p-2.5 rounded-lg leading-snug">
              ⚠️ <strong>Atenção:</strong> Excluir um setor oficial pode fazer com que servidores/estagiários já importados fiquem sem designação ou gerem incompatibilidade nos acessos dos gestores até que nova associação seja feita.
            </p>
          )}
        </Modal>
      )}
    </div>
  );
}
