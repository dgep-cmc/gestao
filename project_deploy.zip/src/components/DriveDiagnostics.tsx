import React, { useState, useEffect } from 'react';
import { ShieldCheck, RefreshCw, AlertTriangle, CheckCircle, XCircle, FileText, FolderPlus, Key, Mail } from 'lucide-react';
import { getBackendUrl } from '../lib/api';

interface DiagnosticStep {
  success: boolean;
  message?: string;
  error?: string;
  folderName?: string;
  mimeType?: string;
  capabilities?: {
    canAddChildren?: boolean;
    canEdit?: boolean;
    canModifyContent?: boolean;
    canDelete?: boolean;
    canDeleteChildren?: boolean;
    [key: string]: any;
  };
}

interface DiagnosticResponse {
  credentials?: {
    privateKeyPresent: boolean;
    privateKeyLength: number;
    serviceAccountEmail: string;
    rootFolderId: string;
  };
  steps?: {
    auth?: DiagnosticStep;
    rootFolder?: DiagnosticStep;
    writeTest?: DiagnosticStep;
  };
}

export default function DriveDiagnostics() {
  const [data, setData] = useState<DiagnosticResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    runDiagnostics();
  }, []);

  const runDiagnostics = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(getBackendUrl('/api/drive/diagnostics'));
      if (!response.ok) {
        throw new Error(`Erro na API de diagnósticos: Cod ${response.status}`);
      }
      const json = await response.json();
      setData(json);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Erro inesperado ao conectar com o serviço de diagnóstico.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-250 p-6 sm:p-8 shadow-xl shadow-slate-100/50 flex flex-col gap-6 animate-fade-in" id="gdrive-diagnose-card">
      {/* Header Panel */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-600" />
            Integridade da Conexão com Google Drive
          </h3>
          <p className="text-xs text-slate-400 mt-0.5 leading-normal">
            Verifique o estado das credenciais de Conta de Serviço Google, tokens OAuth2, ID de pastas e capacidades de arquivos.
          </p>
        </div>
        
        <button
          onClick={runDiagnostics}
          disabled={loading}
          className="px-4 py-2 text-xs font-black bg-blue-600 text-white hover:bg-blue-700 disabled:bg-blue-300 rounded-xl transition-all shadow-md shadow-blue-100 flex items-center justify-center gap-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'ANALISANDO...' : 'TESTAR NOVA CONEXÃO'}
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Estabelecendo handshake com Google APIs...</p>
        </div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-5 flex items-start gap-3.5">
          <AlertTriangle className="w-6 h-6 text-red-500 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-bold text-red-800">Falha Critica na Inicialização</h4>
            <p className="text-xs text-red-600 mt-1 leading-relaxed">{error}</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Column 1: Credentials Setup */}
          <div className="border border-slate-100 bg-slate-50/50 rounded-2xl p-5 flex flex-col gap-4">
            <div className="flex items-center gap-2 text-slate-700">
              <Key className="w-4 h-4 text-slate-500" />
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-800">1. Credenciais no .env</h4>
            </div>

            <div className="flex flex-col gap-3 text-xs">
              <div className="bg-white border border-slate-100 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">E-mail de Serviço</span>
                <p className="font-mono text-[10px] text-slate-700 mt-1 select-all break-all leading-normal">
                  {data?.credentials?.serviceAccountEmail || 'NÃO CONFIGURADO'}
                </p>
              </div>

              <div className="bg-white border border-slate-100 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Chave Privada</span>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    {data?.credentials?.privateKeyPresent 
                      ? `${data?.credentials?.privateKeyLength} bytes de chave PEM` 
                      : 'Não localizada'}
                  </p>
                </div>
                {data?.credentials?.privateKeyPresent ? (
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
              </div>

              <div className="bg-white border border-slate-100 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Pasta Raiz (ROOT_ID)</span>
                <p className="font-mono text-[10px] text-slate-700 mt-1 select-all break-all">
                  {data?.credentials?.rootFolderId || 'NÃO CONFIGURADO'}
                </p>
              </div>
            </div>
          </div>

          {/* Column 2: Authentication Outcome */}
          <div className="border border-slate-100 bg-slate-50/50 rounded-2xl p-5 flex flex-col gap-4">
            <div className="flex items-center gap-2 text-slate-700">
              <Mail className="w-4 h-4 text-slate-500" />
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-800">2. OAuth2 Handshake</h4>
            </div>

            {data?.steps?.auth?.success ? (
              <div className="flex-1 flex flex-col justify-between gap-4">
                <div className="bg-white border border-emerald-100/80 p-4 rounded-xl flex items-start gap-2.5">
                  <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-[11px] font-black uppercase text-emerald-600 tracking-tight">Sucesso</h5>
                    <p className="text-[10px] text-slate-500 mt-1 leading-normal">
                      A chave privada PEM foi decodificada corretamente e o servidor obteve o token de acesso do Google OAuth2.
                    </p>
                  </div>
                </div>
                <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 text-[10px] font-bold p-3 rounded-xl text-center">
                  SISTEMA AUTENTICADO
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col justify-between gap-4">
                <div className="bg-white border border-red-100 p-4 rounded-xl flex items-start gap-2.5">
                  <XCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-[11px] font-black uppercase text-red-600 tracking-tight">Assinatura Falhou</h5>
                    <p className="text-[10px] text-slate-500 mt-1 leading-normal">
                      {data?.steps?.auth?.error}
                    </p>
                  </div>
                </div>
                <div className="bg-red-500/10 border border-red-500/20 text-red-700 text-[10px] font-bold p-3 rounded-xl text-center">
                  ERRO DE CHAVE PRIVADA
                </div>
              </div>
            )}
          </div>

          {/* Column 3: Folder Access & Capabilities */}
          <div className="border border-slate-100 bg-slate-50/50 rounded-2xl p-5 flex flex-col gap-4">
            <div className="flex items-center gap-2 text-slate-700">
              <FolderPlus className="w-4 h-4 text-slate-500" />
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-800">3. Acesso à Pasta Raiz</h4>
            </div>

            {data?.steps?.rootFolder?.success ? (
              <div className="flex-1 flex flex-col gap-3 text-xs justify-between">
                <div className="bg-white border border-slate-100 p-3.5 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Identificação do Drive</span>
                  <p className="text-xs font-black text-slate-800 mt-1 leading-normal">
                    {data.steps.rootFolder.folderName}
                  </p>
                  <p className="text-[9px] text-slate-400 mt-0.5 font-bold uppercase tracking-wider">
                    MimeType: {data.steps.rootFolder.mimeType?.split('.').pop()}
                  </p>
                </div>

                <div className="bg-white border border-slate-100 p-3.5 rounded-xl flex flex-col gap-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Permissões Efetivas:</span>
                  <div className="flex flex-col gap-1.5 text-[10px] font-bold text-slate-600">
                    <div className="flex items-center justify-between">
                      <span>Criar Subpastas:</span>
                      {data.steps.rootFolder.capabilities?.canAddChildren ? (
                        <span className="text-emerald-600">ATIVO ✓</span>
                      ) : (
                        <span className="text-red-500">NEGADO ✗</span>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Modificar Conteúdo:</span>
                      {data.steps.rootFolder.capabilities?.canModifyContent ? (
                        <span className="text-emerald-600">ATIVO ✓</span>
                      ) : (
                        <span className="text-red-500">NEGADO ✗</span>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Deletar Arquivos (Lixeira):</span>
                      {data.steps.rootFolder.capabilities?.canDelete ? (
                        <span className="text-emerald-600">ATIVO ✓</span>
                      ) : (
                        <span className="text-amber-500" title="Expected constraint on joint folders to block unwanted removals">RESTRITO ⚠</span>
                      )}
                    </div>
                  </div>
                </div>

                {data?.steps?.writeTest?.success ? (
                  <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 text-[10px] font-bold p-2.5 rounded-xl text-center uppercase tracking-wider">
                    Gravação e Escrita 100% OK
                  </div>
                ) : (
                  <div className="bg-amber-500/10 border border-amber-500/20 text-amber-700 text-[10px] font-bold p-2.5 rounded-xl flex flex-col gap-1">
                    <span className="text-center uppercase tracking-wider text-[9px]">AEROBIC / GRAVAÇÃO LIMITADA</span>
                    <span className="text-[8px] font-medium text-slate-500 leading-tight text-center">
                      {data?.steps?.writeTest?.error || 'Não foi possível gravar na pasta selecionada.'}
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-white border border-red-100 p-4 rounded-xl flex flex-col gap-2 flex-1 justify-center">
                <div className="flex items-start gap-2.5">
                  <XCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-[11px] font-black uppercase text-red-600 tracking-tight">Acesso Negado</h5>
                    <p className="text-[10px] text-slate-500 mt-1 leading-normal">
                      O Google Drive retornou erro 404/403.
                    </p>
                  </div>
                </div>
                <div className="bg-amber-50/50 border border-amber-200 text-amber-800 text-[10px] p-3 rounded-xl leading-relaxed mt-2 font-medium">
                  <strong>IMPORTANTE:</strong> Para habilitar o upload, copie o e-mail da Conta de Serviço: <br />
                  <span className="font-mono text-[9px] text-blue-600 select-all block break-all font-bold my-1 bg-white p-1 rounded border border-slate-100">{data?.credentials?.serviceAccountEmail}</span>
                  e vá em seu Google Drive, clique na pasta <strong>SISTEMA DE GESTÃO DE ESTÁGIOS</strong>, clique em <strong>Compartilhar</strong> e adicione este e-mail como <strong>"Editor"</strong> ou <strong>"Colaborador"</strong>.
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Warning Alert */}
      {!loading && !error && data?.steps?.rootFolder?.success && (
        <div className="bg-blue-50/50 border border-blue-100 rounded-2xl p-4.5 flex gap-3 text-xs leading-relaxed text-slate-600 font-medium">
          <FileText className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-slate-800 block">Dicas de Acesso & Configurações da Organização:</span>
            Se você estiver usando um Shared Drive comercial ou do Google Workspace, certifique-se de que a Conta de Serviço foi adicionada especificamente na pasta ou compartilhado com o cargo de <strong>"Editor"</strong> (Writer / Contributor).
            O erro do decoder de chave provém de formatações em chaves coladas incorretamente, o qual foi normalizado e resolvido pelo nosso sistema.
          </div>
        </div>
      )}
    </div>
  );
}
