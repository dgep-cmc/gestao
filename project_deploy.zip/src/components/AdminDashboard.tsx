import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Upload, 
  Users as UsersIcon, 
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Search,
  Filter,
  Building2,
  FileText,
  LayoutDashboard,
  ChevronUp,
  ChevronDown,
  Trash2,
  Power,
  Undo2,
  Download,
  Archive,
  FileArchive,
  File as FileIcon,
  Settings,
  ShieldCheck
} from 'lucide-react';
import Papa from 'papaparse';
import { toast } from 'react-hot-toast';
import JSZip from 'jszip';
import { auth } from '../firebase';
import { frequencyService } from '../services/frequencyService';
import { UserProfile, FrequencyRecord, GeneratedDocument } from '../types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { generateFrequencyPDF, generateComissionadosFrequencyPDF } from '../lib/pdfGenerator';

import InternsList from './InternsList';

export default function AdminDashboard({ 
  profile, 
  initialTab, 
  onTabChange,
  month,
  setMonth,
  year,
  setYear,
  isComissionados = false
}: { 
  profile: UserProfile | null, 
  initialTab: 'stats' | 'upload' | 'users' | 'records_pending' | 'records_received' | 'records_validated' | 'archive' | 'records_list' | 'settings', 
  onTabChange: (tab: any) => void,
  month: number,
  setMonth: (m: number) => void,
  year: number,
  setYear: (y: number) => void,
  isComissionados?: boolean
}) {
  const now = new Date();
  const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  
  // Custom sub-tab state for Settings
  const [activeSettingsTab, setActiveSettingsTab] = useState<'archive' | 'upload'>(() => {
    const saved = sessionStorage.getItem('activeSettingsTab');
    if (saved === 'archive' || saved === 'upload') return saved;
    return 'archive';
  });

  const handleSettingsTabChange = (tab: 'archive' | 'upload') => {
    setActiveSettingsTab(tab);
    sessionStorage.setItem('activeSettingsTab', tab);
  };

  const [activeTab, setActiveTabState] = useState<'stats' | 'upload' | 'users' | 'records_pending' | 'records_received' | 'records_validated' | 'archive' | 'records_list' | 'settings'>(() => {
    if (initialTab === 'archive' || initialTab === 'upload') {
      return 'settings';
    }
    return initialTab;
  });

  const [stats, setStats] = useState<any>(null);
  
  // Confirmation state for period change
  const [pendingPeriod, setPendingPeriod] = useState<{ month: number, year: number } | null>(null);

  useEffect(() => {
    if (initialTab === 'archive' || initialTab === 'upload') {
      setActiveTabState('settings');
      setActiveSettingsTab(initialTab);
    } else {
      setActiveTabState(initialTab);
    }
  }, [initialTab]);

  const setActiveTab = (tab: any) => {
    setActiveTabState(tab);
    onTabChange(tab);
  };

  useEffect(() => {
    loadStats();
  }, [month, year]);

  const loadStats = async () => {
    const s = isComissionados
      ? await frequencyService.getComissionadosDashboardStats(month, year)
      : await frequencyService.getDashboardStats(month, year);
    setStats(s);
  };

  const handlePeriodChange = (newMonth: number, newYear: number) => {
    if (newMonth === month && newYear === year) return;
    setPendingPeriod({ month: newMonth, year: newYear });
  };

  const confirmPeriodChange = () => {
    if (pendingPeriod) {
      setMonth(pendingPeriod.month);
      setYear(pendingPeriod.year);
      setPendingPeriod(null);
    }
  };

  if (!profile) return null;

  return (
    <div className="flex-1 flex flex-col min-w-0 overflow-y-auto bg-slate-50 animate-fade-in">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between px-4 sm:px-8 py-4 md:py-0 md:h-[84px] gap-4 shrink-0 z-10 shadow-sm">
          <div>
             <h2 className="text-xl font-bold text-slate-800">
              {activeTab === 'stats' && "Estatísticas do Período"}
              {activeTab === 'records_pending' && "Frequências Pendentes"}
              {activeTab === 'records_received' && "Frequências Recebidas"}
              {activeTab === 'records_validated' && "Frequências Validadas"}
              {activeTab === 'archive' && "Arquivo Digital"}
              {activeTab === 'users' && "Gestão de Usuários"}
              {activeTab === 'upload' && "Importação de Dados"}
              {activeTab === 'records_list' && "Listagem Geral"}
              {activeTab === 'settings' && "Configurações"}
            </h2>
            <p className="text-sm font-bold text-blue-600 uppercase tracking-tighter opacity-80">
              {format(new Date(year, month - 1, 1), 'MMMM yyyy', { locale: ptBR })}
            </p>
          </div>
          
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="flex flex-1 md:flex-none items-center bg-slate-50 p-2 rounded-xl border-2 border-slate-200 shadow-inner overflow-hidden">
              <div className="hidden sm:flex items-center gap-2 px-3 border-r border-slate-200">
                <Calendar className="w-5 h-5 text-blue-600" />
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest whitespace-nowrap">Selecione o Período:</span>
              </div>
              <select 
                value={month} 
                onChange={(e) => handlePeriodChange(Number(e.target.value), year)}
                className="flex-1 sm:flex-none bg-transparent border-none text-sm font-black px-2 sm:px-4 py-2 focus:ring-0 cursor-pointer text-slate-700 hover:text-blue-600 transition-colors truncate"
              >
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {format(new Date(2024, i, 1), 'MMMM', { locale: ptBR }).toUpperCase()}
                  </option>
                ))}
              </select>
              <div className="w-[1px] h-6 bg-slate-200 my-auto"></div>
              <select 
                value={year} 
                onChange={(e) => handlePeriodChange(month, Number(e.target.value))}
                className="bg-transparent border-none text-sm font-black px-4 py-2 focus:ring-0 cursor-pointer text-slate-700 hover:text-blue-600 transition-colors"
              >
                {[2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
          </div>
        </header>

        {pendingPeriod && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 border border-slate-200 animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
              <div className="bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center text-blue-600 mb-6">
                <Calendar className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">Alterar Período?</h3>
              <p className="text-slate-600 mb-8 leading-relaxed">
                Você deseja acessar o período de frequência do mês <span className="font-bold text-blue-600 uppercase italic">
                  {format(new Date(2024, pendingPeriod.month - 1, 1), 'MMMM', { locale: ptBR })}
                </span> de <span className="font-bold text-blue-600">{pendingPeriod.year}</span>?
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <button 
                  onClick={() => setPendingPeriod(null)}
                  className="flex-1 px-6 py-4 text-sm font-bold text-slate-500 hover:bg-slate-50 rounded-2xl transition-all border border-slate-200"
                >
                  Permanecer no período atual
                </button>
                <button 
                  onClick={confirmPeriodChange}
                  className="flex-1 px-6 py-4 text-sm font-bold bg-blue-600 text-white hover:bg-blue-700 rounded-2xl shadow-xl shadow-blue-100 transition-all"
                >
                  Sim, Alterar
                </button>
              </div>
            </div>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-8">
          <div className="max-w-7xl mx-auto w-full space-y-6 sm:space-y-8">
            {activeTab === 'stats' && <StatsOverview stats={stats} month={month} year={year} setActiveTab={setActiveTab} isComissionados={isComissionados} />}
            {activeTab === 'records_pending' && <RecordsViewer profile={profile} month={month} year={year} filterStatus={['pending', 'devolvida']} isComissionados={isComissionados} />}
            {activeTab === 'records_received' && <RecordsViewer profile={profile} month={month} year={year} filterStatus={['submitted']} isComissionados={isComissionados} />}
            {activeTab === 'records_validated' && <RecordsViewer profile={profile} month={month} year={year} filterStatus={['validada']} isComissionados={isComissionados} />}
            {activeTab === 'records_list' && <InternsList month={month} year={year} profile={profile} isComissionados={isComissionados} />}
            
            {activeTab === 'settings' && (
              <div className="space-y-6">
                {/* Visual sub-navigation tabs for Configurações */}
                <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-4">
                  <button
                    onClick={() => handleSettingsTabChange('archive')}
                    className={`flex items-center gap-2 px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                      activeSettingsTab === 'archive'
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-100'
                        : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Archive className="w-4 h-4" />
                    Arquivo Digital
                  </button>
                  <button
                    onClick={() => handleSettingsTabChange('upload')}
                    className={`flex items-center gap-2 px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                      activeSettingsTab === 'upload'
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-100'
                        : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Upload className="w-4 h-4" />
                    Importar Planilha
                  </button>
                </div>

                <div className="mt-6">
                  {activeSettingsTab === 'archive' && <ArchiveViewer month={month} year={year} isComissionados={isComissionados} />}
                  {activeSettingsTab === 'upload' && <CSVImporter month={month} year={year} isComissionados={isComissionados} onComplete={loadStats} onCancel={() => handleSettingsTabChange('archive')} />}
                </div>
              </div>
            )}
          </div>
        </main>
    </div>
  );
}

function StatsOverview({ stats, month, year, setActiveTab, isComissionados = false }: { stats: any, month: number, year: number, setActiveTab: (tab: any) => void, isComissionados?: boolean }) {
  if (!stats) return null;

  const total = stats.totalInterns || 0;
  const pendingInterns = stats.pendingInterns !== undefined ? stats.pendingInterns : 0;
  const submittedInterns = stats.submittedInterns !== undefined ? stats.submittedInterns : 0;
  const validatedInterns = stats.validatedInterns !== undefined ? stats.validatedInterns : 0;

  const pendingPercent = total > 0 ? (pendingInterns / total) * 100 : 0;
  const submittedPercent = total > 0 ? (submittedInterns / total) * 100 : 0;
  const validatedPercent = total > 0 ? (validatedInterns / total) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <StatCard 
          label={isComissionados ? "Servidores no Período" : "Estagiários no Período"} 
          value={total} 
          icon={<UsersIcon className="w-5 h-5 text-blue-900/40" />} 
          color="bg-purple-500" 
        />

        <StatCard 
          label="Frequências Pendentes" 
          value={pendingInterns} 
          percent={pendingPercent} 
          icon={<Clock className="w-5 h-5 text-blue-900/40" />} 
          color="bg-amber-400" 
          onClick={() => setActiveTab('records_pending')}
        />
        
        <StatCard 
          label="Frequências Recebidas" 
          value={submittedInterns} 
          percent={submittedPercent} 
          icon={<Send className="w-5 h-5 text-blue-900/40" />} 
          color="bg-green-500" 
          onClick={() => setActiveTab('records_received')}
        />

        <StatCard 
          label="Frequências Validadas" 
          value={validatedInterns} 
          percent={validatedPercent} 
          icon={<CheckCircle2 className="w-5 h-5 text-blue-900/40" />} 
          color="bg-blue-400" 
          onClick={() => setActiveTab('records_validated')}
        />
      </div>
    </div>
  );
}

import { Clock, Send } from 'lucide-react';

function StatCard({ label, value, icon, color, percent, onClick, active }: { label: string, value: any, icon: React.ReactNode, color: string, percent?: number, onClick?: () => void, active?: boolean }) {
  const CardWrapper = onClick ? 'button' : 'div';
  return (
    <CardWrapper 
      onClick={onClick}
      className={`bg-white p-3.5 sm:p-5 rounded-xl border-2 transition-all group w-full text-left ${active ? 'border-blue-600 shadow-md ring-1 ring-blue-600/20' : 'border-slate-200 shadow-sm hover:shadow-md'}`}
    >
      <div className="flex items-center justify-between mb-2">
        <p className={`text-[10px] uppercase tracking-wider font-bold ${active ? 'text-blue-600' : 'text-slate-500'}`}>{label}</p>
        <div className={`p-1.5 rounded-lg group-hover:scale-110 transition-transform ${active ? 'bg-blue-50 text-blue-600' : 'bg-slate-50'}`}>
          {icon}
        </div>
      </div>
      <div className="flex items-baseline gap-2">
        <h3 className="text-3xl font-bold text-slate-900 mt-1 tabular-nums">{value}</h3>
        {percent !== undefined && (
          <p className="text-xs font-semibold text-slate-500">
            ({percent.toFixed(0)}%)
          </p>
        )}
      </div>
      <div className="w-full bg-slate-100 h-1.5 mt-3 rounded-full overflow-hidden">
        <div className={`${color} h-full transition-all duration-1000 opacity-60`} style={{ width: percent !== undefined ? `${percent}%` : '100%' }}></div>
      </div>
    </CardWrapper>
  );
}

function CSVImporter({ month, year, onComplete, onCancel, isComissionados = false }: { month: number, year: number, onComplete: () => void, onCancel: () => void, isComissionados?: boolean }) {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [existingCount, setExistingCount] = useState<number | null>(null);
  const [existingRecords, setExistingRecords] = useState<FrequencyRecord[]>([]);
  const [resetConfirm, setResetConfirm] = useState(false);
  const [resetInput, setResetInput] = useState('');
  
  // Search and Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState('all');

  const MONTH_NAMES = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ];

  useEffect(() => {
    checkExisting();
  }, [month, year]);

  const checkExisting = async () => {
    try {
      const existing = isComissionados
        ? await frequencyService.getComissionadosFrequenciesByPeriod(month, year)
        : await frequencyService.getFrequenciesByPeriod(month, year);
      setExistingRecords(existing);
      setExistingCount(existing.length);
    } catch (e) {
      console.error("Failed to fetch existing data", e);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) setFile(e.target.files[0]);
  };

  const handleDeleteExisting = async () => {
    if (!window.confirm("ATENÇÃO: Todos os dados importados para este mês serão apagados. Deseja continuar?")) return;
    setLoading(true);
    try {
      if (isComissionados) {
        await frequencyService.deleteComissionadosMonthData(month, year);
      } else {
        await frequencyService.deleteMonthData(month, year);
      }
      toast.success("Dados do mês excluídos com sucesso!");
      setExistingRecords([]);
      setExistingCount(0);
      onComplete(); // update stats 
    } catch (e) {
      console.error(e);
      toast.error("Erro ao excluir dados.");
    } finally {
      setLoading(false);
    }
  };

  const processFile = () => {
    if (!file) return;
    setLoading(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        setParsedData(results.data);
        try {
          if (isComissionados) {
            await frequencyService.uploadComissionadosCSVData(results.data, month, year, false);
          } else {
            await frequencyService.uploadCSVData(results.data, month, year, false);
          }
          toast.success("Importação concluída!");
          checkExisting();
          onComplete();
          setFile(null); // Clear file input
        } catch (error: any) {
          if (error.message === 'DATA_EXISTS') setShowConfirm(true);
          else toast.error("Erro no processamento do arquivo.");
        } finally {
          setLoading(false);
        }
      }
    });
  };

  const executeReset = async () => {
    if (resetInput !== 'RESET') return;
    setLoading(true);
    try {
      await frequencyService.resetDatabase(isComissionados);
      toast.success("Banco de dados resetado com sucesso!");
      setResetConfirm(false);
      setResetInput('');
      setExistingRecords([]);
      setExistingCount(0);
      setFile(null);
      onComplete();
    } catch (e) {
      console.error(e);
      toast.error("Erro ao resetar o banco de dados.");
    } finally {
      setLoading(false);
    }
  };

  // Get distinct list of sectors for filter dropdown
  const uniqueSectors = [...new Set(existingRecords.map(r => r.lotacao).filter(Boolean))].sort();

  // Filter records based on search and sector dropdown
  const filteredRecords = existingRecords.filter(r => {
    const nameToSearch = r.internName || '';
    const matriculaToSearch = r.matricula || '';
    const matchesSearch = nameToSearch.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          matriculaToSearch.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = selectedSector === 'all' || r.lotacao === selectedSector;
    return matchesSearch && matchesSector;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* HEADER SECTION WITH ACTIVE MONTH */}
      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white rounded-2xl p-6 md:p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-blue-200 uppercase tracking-widest bg-blue-900/50 px-3 py-1 rounded-full">Referência de Importação</span>
            <h2 className="text-2xl md:text-3xl font-extrabold mt-2 text-white">
              Planilha de Frequência de {MONTH_NAMES[month - 1]} de {year}
            </h2>
            <p className="text-xs text-blue-100 mt-2 max-w-2xl leading-relaxed">
              Você está na seção de importação para o período de frequência de <strong className="text-white bg-blue-950/40 px-1.5 py-0.5 rounded">{MONTH_NAMES[month - 1]} de {year}</strong>. 
              Novos arquivos CSV enviados nesta tela vão atualizar ou criar registros referentes exclusivamente a este mês.
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/10 shrink-0 text-center md:text-left">
            <p className="text-[9px] text-blue-200 uppercase font-bold tracking-wider">Registros Ativos este Mês</p>
            <p className="text-3xl font-black mt-1 text-white">{existingCount !== null ? existingCount : "..."}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT COLUMN: UPLOADER */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Enviar Atualizações</h3>
            </div>
            <div className="p-6 space-y-6">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <h4 className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">Arquivos Cumulativos / Mudanças:</h4>
                <p className="text-[11px] text-slate-600 mt-2 leading-relaxed">
                  O cadastro inicial do estagiário fica como padrão no sistema. Envie novas planilhas a cada mês para registrar contratações e desligamentos. 
                  O sistema reconhece pela <strong>matrícula</strong> e atualiza automaticamente os dados de início e fim dos períodos de frequência.
                </p>
                <div className="mt-3 text-[10px] bg-blue-50 text-blue-800 border border-blue-100 rounded p-2.5 italic">
                  <strong>Exemplo:</strong> Se ANA SILVA for rescindida em 25/05, envie o CSV dela com a data de rescisão e ela será reajustada neste período sob a matrícula correspondente.
                </div>
              </div>

              <div className="border-2 border-dashed border-slate-200 hover:border-blue-500 rounded-xl p-8 text-center hover:bg-slate-50/50 transition-all cursor-pointer relative group">
                <input type="file" accept=".csv" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" />
                <Upload className="w-8 h-8 text-slate-300 mx-auto mb-3 group-hover:text-blue-500 transition-colors" />
                <p className="text-xs font-bold text-slate-800">{file ? file.name : "Clique para selecionar o arquivo CSV"}</p>
                <p className="text-[10px] text-slate-400 mt-1">Clique ou arraste o arquivo CSV</p>
              </div>

              {showConfirm && (
                <div className="bg-amber-50 border border-amber-200 p-4 rounded-lg">
                   <div className="flex gap-3">
                     <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                     <div>
                        <p className="text-xs font-bold text-amber-900 uppercase">Confirmar Importação de Ajuste</p>
                        <p className="text-xs text-amber-700 mt-1">Deseja consolidar esses registros de {isComissionados ? 'servidor' : 'estagiário'} e sincronizar os períodos correspondentes?</p>
                     </div>
                   </div>
                   <div className="mt-4 flex gap-2 justify-end">
                      <button onClick={() => setShowConfirm(false)} className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-700">Cancelar</button>
                      <button 
                        onClick={async () => {
                          setLoading(true);
                          if (isComissionados) {
                            await frequencyService.uploadComissionadosCSVData(parsedData, month, year, true);
                          } else {
                            await frequencyService.uploadCSVData(parsedData, month, year, true);
                          }
                          checkExisting();
                          onComplete();
                          setShowConfirm(false);
                          setFile(null);
                        }}
                        className="bg-amber-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm"
                      >
                        Confirmar
                      </button>
                   </div>
                </div>
              )}

              <div className="flex gap-3">
                <button onClick={onCancel} className="flex-1 px-4 py-2 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors">Voltar</button>
                <button 
                  disabled={!file || loading}
                  onClick={processFile}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold disabled:opacity-50 transition-colors shadow-sm"
                >
                  {loading ? "Importando..." : "Importar Planilha"}
                </button>
              </div>
            </div>
          </div>

          {/* Database Reset Safeguard Card */}
          <div className="bg-red-50/40 border border-red-200 rounded-2xl p-5 space-y-3">
            <div className="flex gap-3 items-start">
              <div className="p-1.5 bg-red-100 text-red-600 rounded-lg shrink-0">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-red-900">Área de Perigo</h4>
                <p className="text-[10px] text-red-700 mt-1 leading-relaxed">
                  Resetar apagará todos os {isComissionados ? "servidores comissionados" : "estagiários"}, históricos de faltas e documentos desse módulo. Use somente para recomeçar o sistema com uma nova base limpa.
                </p>
              </div>
            </div>
            {resetConfirm ? (
              <div className="space-y-2 bg-white p-3 border border-red-100 rounded-xl">
                <p className="text-[10px] font-semibold text-slate-700">Digite <span className="font-mono bg-red-100 text-red-600 px-1 py-0.5 rounded font-bold">RESET</span> para confirmar:</p>
                <input 
                  type="text" 
                  value={resetInput}
                  onChange={(e) => setResetInput(e.target.value)}
                  placeholder="RESET"
                  className="w-full text-xs font-bold text-slate-800 border border-slate-200 rounded px-2 py-1.5 focus:border-red-500 focus:outline-none"
                />
                <div className="flex gap-2 justify-end">
                  <button 
                    onClick={() => { setResetConfirm(false); setResetInput(''); }}
                    className="px-2 py-1 text-[10px] font-bold text-slate-500"
                  >
                    Cancelar
                  </button>
                  <button 
                    disabled={resetInput !== 'RESET' || loading}
                    onClick={executeReset}
                    className="bg-red-600 text-white px-3 py-1 rounded text-[10px] font-bold hover:bg-red-700 disabled:opacity-50"
                  >
                    Resetar Agora
                  </button>
                </div>
              </div>
            ) : (
              <button 
                onClick={() => setResetConfirm(true)} 
                className="w-full text-center text-red-600 hover:text-red-700 bg-white border border-red-200 hover:bg-red-50 py-2 rounded-xl text-xs font-bold transition-all"
              >
                Resetar Todos os Dados
              </button>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: SCREEN WITH CSV DATA / CURRENT MONTH UPLOADS */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-50/50">
              <div>
                <h3 className="text-sm font-bold text-slate-700">Dados já Importados no Período</h3>
                <p className="text-[11px] text-slate-400">Padrões de frequências gerados para este mês de referência.</p>
              </div>
              {existingCount !== null && existingCount > 0 && (
                <button
                  onClick={handleDeleteExisting}
                  disabled={loading}
                  className="bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors disabled:opacity-50 flex items-center gap-1.5 self-start sm:self-auto"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Excluir Todos do Mês
                </button>
              )}
            </div>

            {/* SEARCH AND FILTERING BAR */}
            <div className="p-4 border-b border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50/20">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                <input 
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar por nome ou matrícula..."
                  className="w-full bg-white border border-slate-200 rounded-lg pl-9 pr-4 py-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div className="flex gap-2">
                <Filter className="w-3.5 h-3.5 text-slate-400 mt-2.5 shrink-0" />
                <select
                  value={selectedSector}
                  onChange={(e) => setSelectedSector(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  <option value="all">Todas as Lotações ({uniqueSectors.length})</option>
                  {uniqueSectors.map(sec => (
                    <option key={sec} value={sec}>{sec}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* DADOS JÁ ENVIADOS TABLE */}
            <div className="overflow-x-auto">
              {filteredRecords.length > 0 ? (
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-slate-50 text-[10px] uppercase font-bold text-slate-400 border-b border-slate-100">
                      <th className="px-6 py-3">Matrícula</th>
                      <th className="px-6 py-3">Nome do Estagiário</th>
                      <th className="px-6 py-3">Lotação (Setor)</th>
                      <th className="px-6 py-3">Nível</th>
                      <th className="px-6 py-3">Período de Frequência</th>
                      <th className="px-6 py-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-[11px] text-slate-600">
                    {filteredRecords.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-3 font-mono text-slate-500 font-medium">
                          {r.matricula || "Não Informada"}
                        </td>
                        <td className="px-6 py-3 font-semibold text-slate-800 whitespace-normal break-words max-w-[240px]">
                          {r.internName}
                        </td>
                        <td className="px-6 py-3 text-slate-500 truncate max-w-[150px]" title={r.lotacao}>
                          {r.lotacao}
                        </td>
                        <td className="px-6 py-3">
                          <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-slate-100 text-slate-600 uppercase">
                            {r.categoria || "Ensino Superior"}
                          </span>
                        </td>
                        <td className="px-6 py-3 font-bold text-blue-600">
                          {r.periodoOriginal}
                        </td>
                        <td className="px-6 py-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[8px] font-extrabold uppercase tracking-widest inline-block ${
                            r.status === 'validada' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                            r.status === 'submitted' ? 'bg-green-50 text-green-700 border border-green-100' :
                            r.status === 'devolvida' ? 'bg-red-50 text-red-700 border border-red-100' :
                            'bg-amber-50 text-amber-700 border border-amber-100'
                          }`}>
                            {r.status === 'validada' ? 'VALIDADA' :
                             r.status === 'submitted' ? 'ENVIADA' :
                             r.status === 'devolvida' ? 'DEVOLVIDA' :
                             'PENDENTE'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="py-12 px-6 text-center text-slate-400">
                  <Calendar className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                  <p className="text-sm font-bold">Nenhum registro encontrado</p>
                  <p className="text-xs text-slate-300 mt-1">
                    {existingRecords.length === 0 
                      ? "Nenhum arquivo CSV correspondente a este mês foi enviado ainda." 
                      : "Sua busca não retornou nenhum registro neste mês."}
                  </p>
                </div>
              )}
            </div>
            
            {filteredRecords.length > 0 && (
              <div className="p-4 border-t border-slate-100 bg-slate-50/50 text-[10px] text-slate-400 flex justify-between items-center">
                <span>Mostrando {filteredRecords.length} de {existingRecords.length} estagiários</span>
                <span>Referência de Envio: {MONTH_NAMES[month - 1]}/{year}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function RecordsViewer({ profile, month, year, filterStatus, isComissionados = false }: { profile: UserProfile, month: number, year: number, filterStatus?: string[], isComissionados?: boolean }) {
  const [records, setRecords] = useState<FrequencyRecord[]>([]);
  const [archives, setArchives] = useState<GeneratedDocument[]>([]);
  const [filter, setFilter] = useState('');
  const [statusFilters, setStatusFilters] = useState<string[]>(filterStatus || ['pending', 'submitted', 'validada', 'devolvida']);
  const [loading, setLoading] = useState(false);
  const [actionConfirm, setActionConfirm] = useState<{ sector: string, type: 'validate' | 'return' | 'reopen', archiveId?: string, recordIds?: string[] } | null>(null);
  const [returnReason, setReturnReason] = useState('');

  useEffect(() => {
    if (filterStatus) {
      setStatusFilters(filterStatus);
    }
  }, [filterStatus]);

  useEffect(() => { loadRecords(); }, [month, year]);
  const loadRecords = async () => {
    const [recs, archs] = await Promise.all([
      isComissionados
        ? frequencyService.getComissionadosFrequenciesByPeriod(month, year)
        : frequencyService.getFrequenciesByPeriod(month, year),
      isComissionados
        ? frequencyService.getComissionadosArchiveByPeriod(month, year)
        : frequencyService.getArchiveByPeriod(month, year)
    ]);
    setRecords(recs);
    setArchives(archs);
  };

  const handleDownload = async (fileId: string, fileName: string) => {
    if (fileId && (fileId.startsWith('http://') || fileId.startsWith('https://'))) {
      window.open(fileId, '_blank');
      return;
    }
    const loadingToast = toast.loading(`Baixando ${fileName}...`);
    try {
      if (!fileId) {
        throw new Error("Missing fileId");
      }
      const { data } = await frequencyService.downloadFile(fileId);
      const url = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 100);
      toast.success("Download concluído", { id: loadingToast });
    } catch (err) {
      console.warn(`Error downloading ${fileName}, trying on-the-fly regeneration...`, err);
      try {
        const docInfo = archives.find(a => a.pdfUrl === fileId || a.fileName === fileName);
        const sectorName = docInfo?.lotacao || fileName.replace(/^Frequencia_/, '').replace(/_\d+_\d+\.pdf$/, '').replace(/_/g, ' ');
        const sectorRecords = records.filter(r => r.lotacao.toLowerCase() === sectorName.toLowerCase() || sectorName.toLowerCase().includes(r.lotacao.toLowerCase()));
        
        const doc = isComissionados
          ? generateComissionadosFrequencyPDF(
              sectorRecords,
              month,
              year,
              sectorName,
              docInfo?.generatedBy?.split('@')[0].toUpperCase() || auth.currentUser?.displayName || profile?.name || 'USUÁRIO',
              docInfo?.generatedBy || auth.currentUser?.email || profile?.email || ''
            )
          : generateFrequencyPDF(
              sectorRecords,
              month,
              year,
              sectorName,
              docInfo?.generatedBy?.split('@')[0].toUpperCase() || auth.currentUser?.displayName || profile?.name || 'USUÁRIO',
              docInfo?.generatedBy || auth.currentUser?.email || profile?.email || ''
            );
        doc.save(fileName);
        toast.success("Download concluído (PDF regenerado)", { id: loadingToast });
      } catch (fallbackErr) {
        console.error("Fallback PDF generation failed:", fallbackErr);
        toast.error("Erro ao baixar arquivo", { id: loadingToast });
      }
    }
  };

  const handleDGEPAction = async () => {
    if (!actionConfirm) return;
    if (actionConfirm.type === 'return' && !returnReason.trim()) {
      toast.error('Informe o motivo da devolução.');
      return;
    }
    const { sector, type, archiveId, recordIds } = actionConfirm;
    const currentReason = returnReason;
    setActionConfirm(null);
    setReturnReason('');
    setLoading(true);
    
    try {
      if (type === 'validate') {
        if (isComissionados) {
          await frequencyService.validateComissionadosSectorFrequency(sector, month, year, recordIds);
        } else {
          await frequencyService.validateSectorFrequency(sector, month, year, recordIds);
        }
        toast.success(`Frequência de ${sector} validada com sucesso!`);

        // Regenerate PDF with validation footer and update on Google Drive
        try {
          const updatedRecs = isComissionados
            ? await frequencyService.getComissionadosFrequenciesByPeriod(month, year, [sector])
            : await frequencyService.getFrequenciesByPeriod(month, year, sector);
          const archives = isComissionados
            ? await frequencyService.getComissionadosArchiveByPeriod(month, year)
            : await frequencyService.getArchiveByPeriod(month, year);
          const targetArchives = archiveId 
            ? archives.filter(a => a.id === archiveId) 
            : archives.filter(a => a.lotacao === sector);
          
          for (const arch of targetArchives) {
            if (arch.pdfUrl) {
              const archRecIds = arch.recordIds;
              const recordsForPDF = archRecIds && archRecIds.length > 0
                ? updatedRecs.filter(r => archRecIds.includes(r.id))
                : updatedRecs; // fallback

              const validatedRecordsForPDF = recordsForPDF.map(r => ({
                ...r,
                status: 'validada' as const,
                validatedAt: r.validatedAt || new Date().toISOString(),
                validatedBy: r.validatedBy || auth.currentUser?.email || profile?.email || 'dgep@cmc.pr.gov.br'
              }));

              const doc = isComissionados
                ? generateComissionadosFrequencyPDF(
                    validatedRecordsForPDF,
                    month,
                    year,
                    sector,
                    arch.generatedBy.split('@')[0].toUpperCase() || auth.currentUser?.displayName || profile?.name || 'USUÁRIO',
                    arch.generatedBy || auth.currentUser?.email || profile?.email || ''
                  )
                : generateFrequencyPDF(
                    validatedRecordsForPDF,
                    month,
                    year,
                    sector,
                    arch.generatedBy.split('@')[0].toUpperCase() || auth.currentUser?.displayName || profile?.name || 'USUÁRIO',
                    arch.generatedBy || auth.currentUser?.email || profile?.email || ''
                  );
              const pdfBlob = doc.output('blob');
              await frequencyService.updateFile(arch.pdfUrl, pdfBlob);
            }
          }
        } catch (pdfErr) {
          console.warn("Could not dynamically stamp PDF on Drive:", pdfErr);
        }
      } else if (type === 'return') {
        if (isComissionados) {
          await frequencyService.returnComissionadosSectorToDraft(sector, month, year, currentReason, archiveId, recordIds);
        } else {
          await frequencyService.returnSectorToDraft(sector, month, year, currentReason, archiveId, recordIds);
        }
        toast.success(`Frequência devolvida para correção.`);
      } else if (type === 'reopen') {
        if (isComissionados) {
          await frequencyService.reopenComissionadosSectorFrequency(sector, month, year, recordIds);
        } else {
          await frequencyService.reopenSectorFrequency(sector, month, year, recordIds);
        }
        toast.success(`Frequência reaberta.`);

        // Regenerate PDF WITHOUT validation footer and update on Google Drive
        try {
          const updatedRecs = isComissionados
            ? await frequencyService.getComissionadosFrequenciesByPeriod(month, year, [sector])
            : await frequencyService.getFrequenciesByPeriod(month, year, sector);
          const archives = isComissionados
            ? await frequencyService.getComissionadosArchiveByPeriod(month, year)
            : await frequencyService.getArchiveByPeriod(month, year);
          const targetArchives = archiveId 
            ? archives.filter(a => a.id === archiveId) 
            : archives.filter(a => a.lotacao === sector);
          
          for (const arch of targetArchives) {
            if (arch.pdfUrl) {
              const archRecIds = arch.recordIds;
              const recordsForPDF = archRecIds && archRecIds.length > 0
                ? updatedRecs.filter(r => archRecIds.includes(r.id))
                : updatedRecs; // fallback

              const unvalidatedRecordsForPDF = recordsForPDF.map(r => ({
                ...r,
                status: 'submitted' as const, // clear validation status back to standard submitted reference
                validatedAt: null,
                validatedBy: null
              }));

              const doc = isComissionados
                ? generateComissionadosFrequencyPDF(
                    unvalidatedRecordsForPDF,
                    month,
                    year,
                    sector,
                    arch.generatedBy.split('@')[0].toUpperCase() || auth.currentUser?.displayName || profile?.name || 'USUÁRIO',
                    arch.generatedBy || auth.currentUser?.email || profile?.email || ''
                  )
                : generateFrequencyPDF(
                    unvalidatedRecordsForPDF,
                    month,
                    year,
                    sector,
                    arch.generatedBy.split('@')[0].toUpperCase() || auth.currentUser?.displayName || profile?.name || 'USUÁRIO',
                    arch.generatedBy || auth.currentUser?.email || profile?.email || ''
                  );
              const pdfBlob = doc.output('blob');
              await frequencyService.updateFile(arch.pdfUrl, pdfBlob);
            }
          }
        } catch (pdfErr) {
          console.warn("Could not dynamically un-stamp PDF on Drive:", pdfErr);
        }
      }
      loadRecords();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao processar ação.");
    } finally {
      setLoading(false);
    }
  };

  const getSectorStatus = (sectorRecords: FrequencyRecord[]) => {
    const allValidated = sectorRecords.every(r => r.status === 'validada');
    if (allValidated) return 'validada';
    
    const allSubmitted = sectorRecords.every(r => r.status === 'submitted' || r.status === 'validada');
    if (allSubmitted) return 'submitted';
    
    const anyDevolvida = sectorRecords.some(r => r.status === 'devolvida');
    if (anyDevolvida) return 'devolvida';
    
    return 'pending';
  };

  // Group records by sector
  const sectors = ([...new Set(records.map(r => r.lotacao).filter(Boolean))] as string[]).sort();
  
  const filteredSectors = sectors.filter(sectorName => {
    const sectorRecords = records.filter(r => r.lotacao === sectorName);
    
    const matchesSearch = sectorName.toLowerCase().includes(filter.toLowerCase());
    const matchesStatus = sectorRecords.some(r => statusFilters.includes(r.status));
    
    return matchesSearch && matchesStatus;
  });

  const toggleStatusFilter = (status: string) => {
    setStatusFilters(prev => 
      prev.includes(status) 
        ? prev.filter(s => s !== status) 
        : [...prev, status]
    );
  };

  const statusOptions = [
    { id: 'pending', label: 'Pendente', color: 'bg-amber-500' },
    { id: 'submitted', label: 'Enviada', color: 'bg-green-600' },
    { id: 'validada', label: 'Validada', color: 'bg-blue-600' },
    { id: 'devolvida', label: 'Devolvida', color: 'bg-red-500' },
  ];

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-4 flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <Filter className="w-5 h-5 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-tight">Status de Envio por Lotação ({month}/{year})</h3>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Filtrar lotação..." 
              className="text-[11px] border border-slate-300 rounded-md pl-9 pr-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 w-full"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </div>
        </div>

        {!filterStatus && (
          <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-slate-50">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Filtrar Status:</span>
            <div className="flex flex-wrap gap-3">
              {statusOptions.map(opt => (
                <label key={opt.id} className="flex items-center gap-2 cursor-pointer group">
                  <div className="relative flex items-center">
                    <input 
                      type="checkbox" 
                      checked={statusFilters.includes(opt.id)}
                      onChange={() => toggleStatusFilter(opt.id)}
                      className="sr-only"
                    />
                    <div className={`w-4 h-4 rounded border transition-all flex items-center justify-center ${
                      statusFilters.includes(opt.id) 
                        ? `${opt.color} border-transparent` 
                        : 'border-slate-300 bg-white group-hover:border-slate-400'
                    }`}>
                      {statusFilters.includes(opt.id) && <CheckCircle2 className="w-3 h-3 text-white" />}
                    </div>
                  </div>
                  <span className={`text-[11px] font-bold transition-colors ${
                    statusFilters.includes(opt.id) ? 'text-slate-900' : 'text-slate-400'
                  }`}>
                    {opt.label}
                  </span>
                </label>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="grid gap-6">
        {isComissionados ? (() => {
          const formatFallbackName = (email: string) => {
            if (!email) return 'GESTOR';
            const namePart = email.split('@')[0];
            return namePart
              .split('.')
              .map(word => word.charAt(0).toUpperCase() + word.slice(1))
              .join(' ');
          };

          // Filter and resolve comissionados archives matching status and search filter
          const renderableArchives = archives.filter(arch => {
            const archRecs = records.filter(r => arch.recordIds?.includes(r.id));
            const matchesSearch = !filter || archRecs.some(r => r.lotacao.toLowerCase().includes(filter.toLowerCase()));
            const matchesStatus = archRecs.some(r => statusFilters.includes(r.status));
            return (archRecs.length > 0) && matchesSearch && matchesStatus;
          }).sort((a, b) => {
            const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
            const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
            return timeB - timeA;
          });

          // Compute comissionados records that are NOT part of any archive yet (pending or devolvida)
          const archivedRecordIds = new Set(archives.flatMap(a => a.recordIds || []));
          const pendingCompRecs = records.filter(r => 
            (r.status === 'pending' || r.status === 'devolvida') && 
            !archivedRecordIds.has(r.id) &&
            (!filter || r.lotacao.toLowerCase().includes(filter.toLowerCase())) &&
            statusFilters.includes(r.status)
          );

          // Group pending by sector name
          const pendingCompSectors = [...new Set(pendingCompRecs.map(r => r.lotacao))].sort();

          if (renderableArchives.length === 0 && pendingCompSectors.length === 0) {
            return (
              <div className="bg-white border border-slate-100 rounded-xl p-20 text-center">
                <Search className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <p className="text-sm font-bold text-slate-800">Nenhum registro de comissionados encontrado</p>
              </div>
            );
          }

          return (
            <div className="space-y-6">
              {/* 1. Submitted or Validated Archives */}
              {renderableArchives.map((arch) => {
                const archRecs = records.filter(r => arch.recordIds?.includes(r.id));
                const uniqueLotacoes = [...new Set(archRecs.map(r => r.lotacao))].sort();
                const lotacoesListDetail = uniqueLotacoes.join(', ');

                const isArchiveValidated = archRecs.length > 0 && archRecs.every(r => r.status === 'validada');
                const isArchiveSubmitted = archRecs.length > 0 && archRecs.some(r => r.status === 'submitted') && !isArchiveValidated;
                const isArchiveDevolvida = archRecs.length > 0 && archRecs.every(r => r.status === 'devolvida');

                let gestorName = formatFallbackName(arch.generatedBy);
                if (gestorName && !gestorName.toUpperCase().startsWith("VER ")) {
                  gestorName = "VER " + gestorName;
                }
                gestorName = gestorName.toUpperCase();

                return (
                  <div key={arch.id} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden border-l-4 border-l-slate-800">
                    <div className="bg-slate-50/80 px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100">
                      <div className="flex flex-col gap-1 w-full max-w-2xl">
                        <h4 className="text-sm font-bold text-slate-900 uppercase tracking-tight flex items-center gap-2">
                          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                          Frequência Coletiva: {gestorName}
                        </h4>
                        
                        <div className="bg-slate-100/50 p-2.5 rounded-lg border border-slate-200/50 mt-1">
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block mb-0.5">Lotações Contidas na Frequência:</span>
                          <span className="text-xs font-semibold text-slate-700 leading-normal">{lotacoesListDetail}</span>
                        </div>

                        <div className="flex flex-wrap items-center gap-3 mt-1.5 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                          <span>{archRecs.length} Servidores no período</span>
                          <span>|</span>
                          <span>Enviado em {arch.timestamp ? format(new Date(arch.timestamp), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR }) : '-'}</span>
                          <span>|</span>
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            isArchiveValidated ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                            isArchiveSubmitted ? 'bg-green-50 text-green-700 border border-green-200' :
                            'bg-red-50 text-red-700 border border-red-200'
                          }`}>
                            {isArchiveValidated ? 'VALIDADA' : isArchiveSubmitted ? 'RECEBIDA' : 'DEV. CORREÇÃO'}
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2 w-full md:w-auto shrink-0 justify-end">
                        <button 
                          onClick={() => handleDownload(arch.pdfUrl, arch.fileName)}
                          className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-lg transition-colors shadow-sm cursor-pointer"
                          title="Baixar PDF Gerado"
                        >
                          <FileText className="w-4 h-4 text-rose-600" /> Baixar PDF
                        </button>
                        
                        {isArchiveSubmitted && (
                          <>
                            <button 
                              onClick={() => setActionConfirm({ 
                                sector: arch.lotacao, 
                                type: 'validate', 
                                archiveId: arch.id, 
                                recordIds: archRecs.map(r => r.id) 
                              })}
                              className="flex items-center justify-center gap-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-bold px-3 py-2 rounded-lg transition-colors shadow-sm cursor-pointer font-sans"
                            >
                              <CheckCircle2 className="w-4 h-4" /> Validar Tudo
                            </button>
                            <button 
                              onClick={() => setActionConfirm({ 
                                sector: arch.lotacao, 
                                type: 'return', 
                                archiveId: arch.id, 
                                recordIds: archRecs.map(r => r.id) 
                              })}
                              className="flex items-center justify-center gap-1.5 border border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100 text-xs font-bold px-3 py-2 rounded-lg transition-colors cursor-pointer"
                            >
                              <Undo2 className="w-4 h-4" /> Devolver
                            </button>
                          </>
                        )}

                        {isArchiveValidated && (
                          <button 
                            onClick={() => setActionConfirm({ 
                              sector: arch.lotacao, 
                              type: 'reopen', 
                              archiveId: arch.id, 
                              recordIds: archRecs.map(r => r.id) 
                            })}
                            className="flex items-center justify-center gap-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 text-xs font-bold px-3 py-2 rounded-lg transition-colors shadow-sm cursor-pointer"
                          >
                            <Undo2 className="w-4 h-4" /> Desfazer Validação
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Table of commissionados */}
                    <div className="p-6">
                      <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-sm">
                        <table className="w-full text-left font-sans text-xs">
                          <thead>
                            <tr className="text-[10px] uppercase text-slate-400 font-bold bg-slate-50 border-b border-slate-200">
                              <th className="px-6 py-3">Matrícula</th>
                              <th className="px-6 py-3">Servidor</th>
                              <th className="px-6 py-3">Lotação</th>
                              <th className="px-6 py-3">Presença</th>
                              <th className="px-6 py-3">Período</th>
                              <th className="px-4 py-3 text-center">Faltas</th>
                              <th className="px-4 py-3 text-center">Atestados</th>
                              <th className="px-4 py-3 text-center">Recesso</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-150 bg-white">
                            {archRecs.map(r => (
                              <tr key={r.id} className="hover:bg-slate-50/40 transition-colors">
                                <td className="px-6 py-3.5 font-mono text-[11px] text-slate-500">{r.matricula || r.id}</td>
                                <td className="px-6 py-3.5 font-bold text-slate-900">{r.internName}</td>
                                <td className="px-6 py-3.5 font-semibold text-slate-700 text-[11px]">{r.lotacao}</td>
                                <td className="px-6 py-3.5">
                                  {r.details?.presenca === 'integral' ? (
                                    <span className="text-green-600 font-bold bg-green-50 px-2 py-0.5 rounded text-[10px] border border-green-150">INTEGRAL</span>
                                  ) : (
                                    <span className="text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded text-[10px] border border-amber-150">PARCIAL</span>
                                  )}
                                </td>
                                <td className="px-6 py-3.5 font-mono text-[10px] text-slate-500">{r.details?.periodo || '-'}</td>
                                <td className="px-4 py-3.5 text-center font-bold text-slate-700">{r.details?.falta || '0'}</td>
                                <td className="px-4 py-3.5 text-center">
                                  <div className="flex flex-col items-center gap-1">
                                    <span className="font-bold text-slate-700">{r.details?.atestados || '0'}</span>
                                    {(r.details?.atestadoFiles || []).length > 0 && (
                                      <div className="flex flex-wrap gap-1 justify-center">
                                        {r.details?.atestadoFiles?.map((fileId, idx) => (
                                          <button 
                                            key={idx}
                                            onClick={() => handleDownload(fileId, r.details?.atestadoFilesNames?.[idx] || 'atestado')}
                                            className="p-1 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded border border-blue-200 transition-colors cursor-pointer"
                                            title={r.details?.atestadoFilesNames?.[idx]}
                                          >
                                            <FileIcon className="w-3 h-3" />
                                          </button>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                </td>
                                <td className="px-4 py-3.5 text-center font-bold text-slate-700">{r.details?.recesso || '—'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* 2. Pending / Devolvida records (grouped by actual lotação) */}
              {pendingCompSectors.map((secName) => {
                const secRecs = pendingCompRecs.filter(r => r.lotacao === secName);
                return (
                  <div key={secName} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden border-l-4 border-l-red-400">
                    <div className="bg-slate-50 px-6 py-4 border-b border-slate-100">
                      <h4 className="text-sm font-bold text-slate-700 uppercase tracking-tight">{secName}</h4>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Aguardando Envio de Frequência ou em Revisão ({secRecs.length} servidores)</p>
                    </div>
                    <div className="p-6">
                      <div className="overflow-x-auto border border-slate-250 rounded-lg">
                        <table className="w-full text-left font-sans text-xs">
                          <thead>
                            <tr className="text-[10px] uppercase text-slate-400 font-bold bg-slate-50 border-b border-slate-100">
                              <th className="px-6 py-2.5">Matrícula</th>
                              <th className="px-6 py-2.5">Servidor</th>
                              <th className="px-6 py-2.5">Status</th>
                              <th className="px-6 py-2.5">Evolução / Motivo Devolução</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {secRecs.map(r => (
                              <tr key={r.id} className="hover:bg-slate-50/20">
                                <td className="px-6 py-2.5 text-slate-500 font-mono">{r.matricula || r.id}</td>
                                <td className="px-6 py-2.5 font-semibold text-slate-800">{r.internName}</td>
                                <td className="px-6 py-2.5">
                                  <span className={`px-2 py-0.5 text-[9px] font-bold rounded-lg border ${
                                    r.status === 'devolvida' 
                                      ? 'bg-red-50 text-red-700 border-red-200' 
                                      : 'bg-amber-50 text-amber-700 border-amber-200'
                                  }`}>
                                    {r.status === 'devolvida' ? 'DEVOLVIDA CORREÇÃO' : 'PENDENTE GESTOR'}
                                  </span>
                                </td>
                                <td className="px-6 py-2.5 italic text-slate-500">
                                  {r.status === 'devolvida' ? (
                                    <span className="text-red-700 font-medium not-italic bg-red-50/50 px-3 py-1.5 rounded-lg border border-red-100 block max-w-lg text-[10px]">
                                      <strong>Ref feedback:</strong> {r.returnReason || 'Ajustes requeridos.'}
                                    </span>
                                  ) : (
                                    'Em rascunho / aguardando preenchimento do formulário pelo gestor.'
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })() : (
          filteredSectors.length === 0 ? (
            <div className="bg-white border border-slate-100 rounded-xl p-20 text-center">
              <Search className="w-12 h-12 text-slate-100 mx-auto mb-4" />
              <p className="text-sm font-bold text-slate-800">Nenhum registro encontrado</p>
            </div>
          ) : (
            filteredSectors.map(sectorName => {
              const sectorRecords = records.filter(r => r.lotacao === sectorName);
              const rawSectorArchives = archives.filter(a => a.lotacao === sectorName);
            
            // Sort archives by timestamp descending to process newest first
            const sortedRawArchives = [...rawSectorArchives].sort((a, b) => {
              const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
              const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
              return timeB - timeA;
            });

            const seenRecordIds = new Set<string>();
            const sectorArchives: GeneratedDocument[] = [];

            for (const arch of sortedRawArchives) {
              const archRecs = arch.recordIds 
                ? sectorRecords.filter(r => arch.recordIds!.includes(r.id))
                : sectorRecords.filter(r => !sortedRawArchives.some(other => other.id !== arch.id && other.recordIds?.includes(r.id)));
              
              if (archRecs.length === 0) continue;

              const hasUnseen = archRecs.some(r => !seenRecordIds.has(r.id));
              if (hasUnseen) {
                archRecs.forEach(r => seenRecordIds.add(r.id));
                sectorArchives.push(arch);
              }
            }
            
            const renderableSectorArchives = sectorArchives.filter(arch => {
              const archRecs = arch.recordIds 
                ? sectorRecords.filter(r => arch.recordIds!.includes(r.id))
                : sectorRecords.filter(r => !sectorArchives.some(other => other.id !== arch.id && other.recordIds?.includes(r.id)));
              return archRecs.some(r => statusFilters.includes(r.status));
            });
            
            const pendingRecs = sectorRecords.filter(r => 
              (r.status === 'pending' || r.status === 'devolvida') &&
              !sectorArchives.some(arch => arch.recordIds?.includes(r.id))
            );

            const validatedCount = sectorRecords.filter(r => r.status === 'validada').length;
            const submittedCount = sectorRecords.filter(r => r.status === 'submitted').length;
            const draftOrReturnedCount = sectorRecords.filter(r => r.status === 'pending' || r.status === 'devolvida').length;

            return (
              <div key={sectorName} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden border-l-4 border-l-slate-800">
                {/* Sector Header */}
                <div className="bg-slate-50/80 px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100">
                  <div className="flex flex-col gap-1 w-full">
                    <h4 className="text-sm font-bold text-slate-900 uppercase tracking-tight">{sectorName}</h4>
                    <div className="flex flex-wrap items-center gap-3 mt-1">
                      <span className="text-[10px] font-bold text-slate-500 tracking-wider">
                        {sectorRecords.length} ESTAGIÁRIOS NO TOTAL
                      </span>
                      <span className="text-slate-200">|</span>
                      <span className="text-[10px] font-semibold text-slate-500">
                        ({validatedCount} VALIDADOS, {submittedCount} ENVIADOS, {draftOrReturnedCount} PENDENTES/CORREÇÃO)
                      </span>
                    </div>
                  </div>
                </div>

                {/* Inside the Sector Card */}
                <div className="p-6 flex flex-col gap-6">
                  {/* Part 1: List all active complementary archives */}
                  {renderableSectorArchives.length > 0 ? (
                    <div className="flex flex-col gap-6">
                      <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Documentos Recebidos / Complementares</h5>
                      
                      {renderableSectorArchives.map((arch) => {
                        // Find interns belonging to this specific archive
                        const archRecs = arch.recordIds 
                          ? sectorRecords.filter(r => arch.recordIds!.includes(r.id))
                          : sectorRecords.filter(r => !sectorArchives.some(other => other.id !== arch.id && other.recordIds?.includes(r.id)));

                        const isArchiveValidated = archRecs.length > 0 && archRecs.every(r => r.status === 'validada');
                        const isArchiveSubmitted = archRecs.length > 0 && archRecs.some(r => r.status === 'submitted') && !isArchiveValidated;
                        const isArchiveDevolvida = archRecs.length > 0 && archRecs.every(r => r.status === 'devolvida');

                        return (
                          <div key={arch.id} className="border border-slate-250 rounded-xl overflow-hidden shadow-sm bg-slate-50/10">
                            {/* Archive details and actions header bar */}
                            <div className="bg-slate-50/50 border-b border-slate-100 px-5 py-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                              <div className="flex flex-col gap-0.5">
                                <div className="flex items-center gap-2 flex-wrap bg-f">
                                  <FileText className="w-4 h-4 text-rose-600" />
                                  <span className="font-semibold text-xs text-slate-700 font-mono tracking-tight">{arch.fileName}</span>
                                  <span className={`px-2 py-0.5 text-[8px] font-bold rounded-md ${
                                    isArchiveValidated ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                                    isArchiveSubmitted ? 'bg-green-50 text-green-700 border border-green-100' :
                                    isArchiveDevolvida ? 'bg-red-50 text-red-700 border border-red-100' :
                                    'bg-amber-50 text-amber-700 border border-amber-100'
                                  }`}>
                                    {isArchiveValidated ? 'VALIDADA' : isArchiveSubmitted ? 'RECEBIDA / COMPLEMENTAR' : isArchiveDevolvida ? 'DEV. CORREÇÃO' : 'PENDENTE'}
                                  </span>
                                </div>
                                <span className="text-[9px] text-slate-400">
                                  Enviado por <span className="font-semibold">{arch.generatedBy.split('@')[0]}</span> em {arch.timestamp ? format(new Date(arch.timestamp), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR }) : '-'}
                                </span>
                              </div>

                              <div className="flex gap-2 w-full sm:w-auto shrink-0">
                                <button 
                                  onClick={() => handleDownload(arch.pdfUrl, arch.fileName)}
                                  className="flex-1 sm:flex-initial flex items-center justify-center gap-1 px-2.5 py-1 text-[10px] font-bold bg-white text-rose-600 border border-rose-100 hover:bg-rose-50 rounded-lg transition-colors shadow-sm"
                                  title="Baixar PDF Original"
                                >
                                  <FileText className="w-3.5 h-3.5" /> Baixar PDF
                                </button>
                                
                                {isArchiveSubmitted && (
                                  <>
                                    <button 
                                      onClick={() => setActionConfirm({ 
                                        sector: sectorName, 
                                        type: 'validate', 
                                        archiveId: arch.id, 
                                        recordIds: archRecs.map(r => r.id) 
                                      })}
                                      className="flex-1 sm:flex-initial flex items-center justify-center gap-1 bg-green-600 hover:bg-green-700 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors shadow-sm"
                                    >
                                      <CheckCircle2 className="w-3.5 h-3.5" /> Validar
                                    </button>
                                    <button 
                                      onClick={() => setActionConfirm({ 
                                        sector: sectorName, 
                                        type: 'return', 
                                        archiveId: arch.id, 
                                        recordIds: archRecs.map(r => r.id) 
                                      })}
                                      className="flex-1 sm:flex-initial flex items-center justify-center gap-1 border border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100 text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors"
                                    >
                                      <Undo2 className="w-3.5 h-3.5" /> Devolver
                                    </button>
                                  </>
                                )}

                                {isArchiveValidated && (
                                  <button 
                                    onClick={() => setActionConfirm({ 
                                      sector: sectorName, 
                                      type: 'reopen', 
                                      archiveId: arch.id, 
                                      recordIds: archRecs.map(r => r.id) 
                                    })}
                                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors shadow-sm"
                                  >
                                    <Undo2 className="w-3.5 h-3.5" /> Desfazer Validação
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* Intern table for this specific archive */}
                            <div className="overflow-x-auto">
                              <table className="w-full text-left">
                                <thead>
                                  <tr className="text-[9px] uppercase text-slate-400 font-bold bg-white/70">
                                    <th className="px-6 py-2.5 border-b border-slate-100">Estagiário</th>
                                    <th className="px-6 py-2.5 border-b border-slate-100 animate-pulse">Status</th>
                                    <th className="px-6 py-2.5 border-b border-slate-100">Presença</th>
                                    <th className="px-6 py-2.5 border-b border-slate-100">Período</th>
                                    <th className="px-4 py-2.5 border-b border-slate-100 text-center">Faltas</th>
                                    <th className="px-4 py-2.5 border-b border-slate-100 text-center">Atestados</th>
                                    <th className="px-4 py-2.5 border-b border-slate-100 text-center">Recesso</th>
                                  </tr>
                                </thead>
                                <tbody className="text-xs text-slate-600 divide-y divide-slate-100 bg-white">
                                  {archRecs.map(r => (
                                    <tr key={r.id} className="hover:bg-slate-50/50 transition-colors">
                                      <td className="px-6 py-2.5 font-medium text-slate-800">
                                        <div>{r.internName}</div>
                                        {r.details?.datasJustificadas && (
                                          <div className="text-[10px] text-slate-400 font-normal italic tracking-tight whitespace-normal max-w-xs leading-tight mt-0.5">
                                            Datas: {r.details.datasJustificadas}
                                          </div>
                                        )}
                                      </td>
                                      <td className="px-6 py-2.5">
                                        <span className={`text-[10px] font-bold ${
                                          r.status === 'validada' ? 'text-blue-600' :
                                          r.status === 'submitted' ? 'text-green-600' :
                                          r.status === 'devolvida' ? 'text-red-500' :
                                          'text-amber-500'
                                        }`}>
                                          {r.status === 'pending' ? 'PENDENTE' : 
                                           r.status === 'submitted' ? 'ENVIADA' : 
                                           r.status === 'validada' ? 'VALIDADA' : 'DEVOLVIDA'}
                                        </span>
                                      </td>
                                      <td className="px-6 py-2.5">
                                        {r.details?.presenca === 'integral' ? (
                                          <span className="text-green-600 font-bold bg-green-50 px-1.5 py-0.5 rounded text-[10px]">100% (INTEGRAL)</span>
                                        ) : (
                                          <span className="text-amber-600 font-bold bg-amber-50 px-1.5 py-0.5 rounded text-[10px]">PARCIAL</span>
                                        )}
                                      </td>
                                      <td className="px-6 py-2.5 text-slate-500 font-mono text-[10px]">{r.details?.periodo || '-'}</td>
                                      <td className="px-4 py-2.5 text-center text-slate-500 font-semibold">{r.details?.falta || '0'}</td>
                                      <td className="px-4 py-2.5 text-center">
                                        <div className="flex flex-col items-center gap-1">
                                          <span className="text-slate-500 font-semibold">{r.details?.atestados || '0'}</span>
                                          {(r.details?.atestadoFiles || []).length > 0 && (
                                            <div className="flex flex-wrap gap-1 justify-center">
                                              {r.details?.atestadoFiles?.map((fileId, idx) => (
                                                <button 
                                                  key={idx}
                                                  onClick={() => handleDownload(fileId, r.details?.atestadoFilesNames?.[idx] || 'atestado')}
                                                  className="p-1 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded border border-blue-150 transition-colors cursor-pointer"
                                                  title={r.details?.atestadoFilesNames?.[idx]}
                                                >
                                                  <FileIcon className="w-2.5 h-2.5" />
                                                </button>
                                              ))}
                                            </div>
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-4 py-2.5 text-center text-slate-500 font-semibold">{r.details?.recesso || '0'}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-6 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-slate-400 font-medium text-xs">
                      Nenhum documento de frequência foi enviado ainda pelo gestor para competência selecionada.
                    </div>
                  )}

                  {/* Part 2: List outstanding / pending interns who have not been submitted yet */}
                  {pendingRecs.length > 0 && (statusFilters.includes('pending') || statusFilters.includes('devolvida')) && (
                    <div className="flex flex-col gap-3 pt-2">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                        <h5 className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Estagiários Aguardando Envio do Gestor ou Em Correção</h5>
                      </div>
                      
                      <div className="overflow-x-auto border border-slate-200 rounded-xl">
                        <table className="w-full text-left">
                          <thead>
                            <tr className="text-[9px] uppercase text-slate-400 font-bold bg-slate-50/50">
                              <th className="px-6 py-2.5 border-b border-slate-200">Estagiário</th>
                              <th className="px-6 py-2.5 border-b border-slate-200">Status</th>
                              <th className="px-6 py-2.5 border-b border-slate-200">Última edição / feedback</th>
                            </tr>
                          </thead>
                          <tbody className="text-xs text-slate-600 divide-y divide-slate-100 bg-white">
                            {pendingRecs.map(r => (
                              <tr key={r.id} className="hover:bg-slate-50/20 transition-colors">
                                <td className="px-6 py-2.5 font-medium text-slate-700">{r.internName}</td>
                                <td className="px-6 py-2.5">
                                  <span className={`px-2 py-0.5 text-[9px] font-bold rounded-full ${
                                    r.status === 'devolvida' ? 'bg-red-50 text-red-700 border border-red-100' : 'bg-amber-50 text-amber-700 border border-amber-100'
                                  }`}>
                                    {r.status === 'devolvida' ? 'DEV. PARA CORREÇÃO' : 'PENDENTE (PARCIAL)'}
                                  </span>
                                </td>
                                <td className="px-6 py-2.5 text-slate-400 italic font-medium leading-relaxed">
                                  {r.status === 'devolvida' ? (
                                    <span className="text-red-600 font-normal not-italic bg-red-50/50 px-2.5 py-1 rounded border border-red-100/30 block max-w-sm text-[10px] leading-relaxed">
                                      <strong>Motivo:</strong> {r.returnReason || 'Verifique com o gestor.'}
                                    </span>
                                  ) : (
                                    'Aguardando o gestor preencher e entregar o formulário complementar.'
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        ))}
      </div>

      {actionConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className={`flex items-center gap-3 mb-4 ${
              actionConfirm.type === 'validate' ? 'text-green-600' : 
              actionConfirm.type === 'return' ? 'text-amber-600' : 'text-blue-600'
            }`}>
              {actionConfirm.type === 'validate' ? <CheckCircle2 className="w-6 h-6" /> : <Undo2 className="w-6 h-6" />}
              <h3 className="text-lg font-bold">
                {actionConfirm.type === 'validate' ? 'Validar Frequência?' : 
                 actionConfirm.type === 'return' ? 'Devolver Frequência' : 'Reabrir Frequência?'}
              </h3>
            </div>
            
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              Deseja realmente {
                actionConfirm.type === 'validate' ? 'validar a frequência' : 
                actionConfirm.type === 'return' ? 'devolver para correção' : 'reabrir a edição'
              } {actionConfirm.recordIds ? 'destes estagiários selecionados (parcial)' : 'de todos os estagiários'} da lotação <span className="font-bold text-slate-900 uppercase">{actionConfirm.sector}</span>?
            </p>
            
            {actionConfirm.type === 'return' && (
              <div className="mb-6">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 block">Motivo da devolução:</label>
                <textarea
                  className="w-full text-sm border-slate-200 rounded-lg focus:ring-amber-500 focus:border-amber-500 p-3 min-h-[80px]"
                  placeholder="Explique o que precisa ser corrigido..."
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                />
              </div>
            )}
            
            <div className="flex gap-3">
              <button 
                onClick={() => { setActionConfirm(null); setReturnReason(''); }}
                className="flex-1 px-4 py-2 text-sm font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition-all"
                disabled={loading}
              >
                CANCELAR
              </button>
              <button 
                onClick={handleDGEPAction}
                disabled={loading}
                className={`flex-1 px-4 py-2 text-sm font-bold text-white rounded-xl shadow-lg transition-all disabled:opacity-50 ${
                  actionConfirm.type === 'validate' ? 'bg-green-600 hover:bg-green-700 shadow-green-100' : 
                  actionConfirm.type === 'return' ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-100' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-100'
                }`}
              >
                {loading ? 'PROCESSANDO...' : 'CONFIRMAR'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ArchiveViewer({ month, year, isComissionados = false }: { month: number, year: number, isComissionados?: boolean }) {
  const [documents, setDocuments] = useState<GeneratedDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [zipping, setZipping] = useState(false);
  const [filter, setFilter] = useState('');

  useEffect(() => { loadArchive(); }, [month, year]);

  const loadArchive = async () => {
    setLoading(true);
    const docs = isComissionados
      ? await frequencyService.getComissionadosArchiveByPeriod(month, year)
      : await frequencyService.getArchiveByPeriod(month, year);
    setDocuments(docs);
    setLoading(false);
  };

  const getFileBlobWithFallback = async (doc: GeneratedDocument): Promise<Blob> => {
    if (doc.pdfUrl) {
      try {
        const { data } = await frequencyService.downloadFile(doc.pdfUrl);
        return data;
      } catch (err) {
        console.warn(`Failed to download ${doc.pdfUrl}, standard fallback trigger`, err);
      }
    }
    
    // Fallback: fetch records and generate PDF on-the-fly
    const sectorRecords = isComissionados
      ? await frequencyService.getComissionadosFrequenciesByPeriod(month, year, [doc.lotacao])
      : await frequencyService.getFrequenciesByPeriod(month, year, doc.lotacao);
    
    const generatedDoc = isComissionados
      ? generateComissionadosFrequencyPDF(
          sectorRecords,
          month,
          year,
          doc.lotacao,
          doc.generatedBy.split('@')[0].toUpperCase(),
          doc.generatedBy
        )
      : generateFrequencyPDF(
          sectorRecords,
          month,
          year,
          doc.lotacao,
          doc.generatedBy.split('@')[0].toUpperCase(),
          doc.generatedBy
        );
    
    return generatedDoc.output('blob');
  };

  const downloadAllAsZip = async () => {
    if (documents.length === 0) return;
    setZipping(true);
    try {
      const zip = new JSZip();
      const folderName = `Frequencias_${month}_${year}`;
      const folder = zip.folder(folderName);
      
      if (!folder) throw new Error("Could not create folder");

      const downloadPromises = documents.map(async (doc) => {
        try {
          const blobData = await getFileBlobWithFallback(doc);
          folder.file(doc.fileName, blobData);
        } catch (err) {
          console.error(`Error downloading ${doc.fileName}:`, err);
        }
      });

      await Promise.all(downloadPromises);

      const content = await zip.generateAsync({ type: "blob" });
      const url = window.URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${folderName}.zip`;
      link.click();
      window.URL.revokeObjectURL(url);
      toast.success("Download ZIP iniciado!");
    } catch (error) {
      console.error(error);
      toast.error("Erro ao gerar ZIP");
    } finally {
      setZipping(false);
    }
  };

  const handleDownload = async (doc: GeneratedDocument) => {
    const loadingToast = toast.loading(`Baixando ${doc.fileName}...`);
    try {
      const blobData = await getFileBlobWithFallback(doc);
      const url = URL.createObjectURL(blobData);
      const link = document.createElement('a');
      link.href = url;
      link.download = doc.fileName;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 100);
      toast.success("Download concluído", { id: loadingToast });
    } catch (err) {
      console.error(err);
      toast.error("Erro ao baixar arquivo", { id: loadingToast });
    }
  };

  const downloadSingle = (doc: GeneratedDocument) => {
    handleDownload(doc);
  };

  const filtered = documents.filter(d => 
    d.lotacao.toLowerCase().includes(filter.toLowerCase()) || 
    d.fileName.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
      <div className="px-4 sm:px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center bg-slate-50/50 gap-3">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <FileArchive className="w-5 h-5 text-blue-600" />
          <h3 className="text-sm font-bold text-slate-700">Arquivo Digital de PDFs</h3>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-48">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Filtrar por lotação..." 
              className="text-[11px] border border-slate-300 rounded-md pl-9 pr-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 w-full"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </div>
          
          <button 
            disabled={documents.length === 0 || zipping}
            onClick={downloadAllAsZip}
            className="w-full sm:w-auto bg-slate-800 hover:bg-slate-900 text-white text-[11px] font-bold px-4 py-2 rounded-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            {zipping ? (
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
            BAIXAR LOTE (ZIP)
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        {loading ? (
          <div className="p-20 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-xs text-slate-400 mt-4 font-medium uppercase tracking-widest">Carregando Arquivo...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-20 text-center">
            <Archive className="w-12 h-12 text-slate-100 mx-auto mb-4" />
            <p className="text-sm font-bold text-slate-800">Nenhum documento arquivado</p>
            <p className="text-xs text-slate-400 mt-1">Os PDFs gerados pelos gestores aparecerão aqui.</p>
          </div>
        ) : (
          <table className="w-full text-left min-w-[700px]">
            <thead>
              <tr className="text-[10px] uppercase text-slate-400 font-bold bg-white">
                <th className="px-6 py-3 border-b border-slate-100">Lotação</th>
                <th className="px-6 py-3 border-b border-slate-100">Nome do Arquivo</th>
                <th className="px-6 py-3 border-b border-slate-100">Gerado Por</th>
                <th className="px-6 py-3 border-b border-slate-100">Data/Hora</th>
                <th className="px-6 py-3 border-b border-slate-100 text-right">Baixar</th>
              </tr>
            </thead>
            <tbody className="text-sm text-slate-600 divide-y divide-slate-50">
              {filtered.map(doc => (
                <tr key={doc.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 font-medium text-slate-900">{doc.lotacao}</td>
                  <td className="px-6 py-4 text-xs font-mono text-slate-500 overflow-hidden text-ellipsis max-w-xs">{doc.fileName}</td>
                  <td className="px-6 py-4 text-xs font-medium text-slate-400">{doc.generatedBy}</td>
                  <td className="px-6 py-4 text-xs font-medium text-slate-400">
                    {format(new Date(doc.timestamp), "dd/MM/yy HH:mm", { locale: ptBR })}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => downloadSingle(doc)}
                      className="p-1 px-3 text-blue-600 hover:bg-blue-50 rounded-lg transition-all text-xs font-bold border border-blue-100"
                    >
                      PDF
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
