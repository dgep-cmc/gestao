import React, { useState, useEffect } from 'react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { hiringService } from '../../services/hiringService';
import { HiringRequest } from '../../types';
import SignaturePad from './SignaturePad';
import { LOGO_BASE64 } from '../../lib/logo';
import { 
  ShieldCheck, 
  User, 
  Building2, 
  CheckCircle2, 
  FileText,
  Lock,
  Signature,
  ArrowLeft,
  ArrowRight,
  Plus,
  Trash2,
  Save,
  Info,
  Briefcase
} from 'lucide-react';
import { validateCPF, formatCPF, formatPhone } from '../../lib/validation';
import { toast } from 'react-hot-toast';

export default function ComissionadosOnboarding({ requestId }: { requestId: string }) {
  const [request, setRequest] = useState<HiringRequest | null>(null);
  const [loading, setLoading] = useState(true);
  const [cpf, setCpf] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [step, setStep] = useState(1);
  const [showPad, setShowPad] = useState(false);

  // Form 2 states (Dados Cadastrais)
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [estadoCivil, setEstadoCivil] = useState('Solteiro(a)');
  const [rg, setRg] = useState('');
  const [rgEmissor, setRgEmissor] = useState('');
  const [rgData, setRgData] = useState('');
  const [naturalidade, setNaturalidade] = useState('');
  const [nacionalidade, setNacionalidade] = useState('Brasileira');
  const [endereco, setEndereco] = useState('');
  const [numero, setNumero] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('Curitiba');
  const [uf, setUf] = useState('PR');
  const [cep, setCep] = useState('');
  const [escolaridade, setEscolaridade] = useState('Superior Completo');
  const [formacao, setFormacao] = useState('');

  // Form 3: Parentesco
  const [declarouParentesco, setDeclarouParentesco] = useState(false);
  const [parentes, setParentes] = useState<{ nome: string; cargo: string; parentesco: string }[]>([]);
  const [newParente, setNewParente] = useState({ nome: '', cargo: '', parentesco: '' });

  // Form 4: Outra Atividade (Two Questions)
  const [acumulaCargoPublico, setAcumulaCargoPublico] = useState(false);
  const [exerceAtividadePrivada, setExerceAtividadePrivada] = useState(false);
  const [empresa, setEmpresa] = useState('');
  const [enderecoEmpresa, setEnderecoEmpresa] = useState('');
  const [telefoneEmpresa, setTelefoneEmpresa] = useState('');
  const [cargoEmpresa, setCargoEmpresa] = useState('');
  const [horarioOutroCargo, setHorarioOutroCargo] = useState('');

  // Form 5: Dependentes
  const [possuiDependentes, setPossuiDependentes] = useState(false);
  const [dependentesList, setDependentesList] = useState<{ codigo: string; nome: string; cpf: string; dataNascimento: string }[]>(
    [{ codigo: '01', nome: '', cpf: '', dataNascimento: '' }]
  );

  // Form 6: Impedimento
  const [declarouImpedimento, setDeclarouImpedimento] = useState(false);
  const [detalhesImpedimento, setDetalhesImpedimento] = useState('');

  // Load request and populate states
  useEffect(() => {
    hiringService.getRequest(requestId).then(req => {
      setRequest(req);
      if (req && req.student) {
        setNome(req.student.name || '');
        setEmail(req.student.email || '');
        setPhone(req.student.phone || '');
        setBirthDate(req.student.birthDate || '');
      }
      if (req && req.comissionadoDetails) {
        const details = req.comissionadoDetails;
        if (details.estadoCivil) setEstadoCivil(details.estadoCivil);
        if (details.rg) setRg(details.rg);
        if (details.rgEmissor) setRgEmissor(details.rgEmissor);
        if (details.rgData) setRgData(details.rgData);
        if (details.naturalidade) setNaturalidade(details.naturalidade);
        if (details.nacionalidade) setNacionalidade(details.nacionalidade);
        if (details.endereco) setEndereco(details.endereco);
        if (details.numero) setNumero(details.numero);
        if (details.bairro) setBairro(details.bairro);
        if (details.cidade) setCidade(details.cidade);
        if (details.uf) setUf(details.uf);
        if (details.cep) setCep(details.cep);
        if (details.escolaridade) setEscolaridade(details.escolaridade);
        if (details.formacao) setFormacao(details.formacao);

        if (details.declarouParentesco !== undefined) setDeclarouParentesco(details.declarouParentesco);
        if (details.parentesCMC) setParentes(details.parentesCMC);

        if (details.possuiOutroCargo !== undefined) {
          setAcumulaCargoPublico(details.possuiOutroCargo);
          setExerceAtividadePrivada(details.possuiOutroCargo);
        }
        if (details.empresa) setEmpresa(details.empresa);
        if (details.enderecoEmpresa) setEnderecoEmpresa(details.enderecoEmpresa);
        if (details.telefoneEmpresa) setTelefoneEmpresa(details.telefoneEmpresa);
        if (details.cargoEmpresa) setCargoEmpresa(details.cargoEmpresa);
        if (details.horarioOutroCargo) setHorarioOutroCargo(details.horarioOutroCargo);

        if (details.possuiDependentes !== undefined) setPossuiDependentes(details.possuiDependentes);
        if (details.dependentes && details.dependentes.length > 0) {
          setDependentesList(details.dependentes);
        }

        if (details.declarouImpedimento !== undefined) setDeclarouImpedimento(details.declarouImpedimento);
        if (details.detalhesImpedimento) setDetalhesImpedimento(details.detalhesImpedimento);
      }
      setLoading(false);
    }).catch(err => {
      console.error(err);
      setError('Erro ao carregar os dados cadastrais.');
      setLoading(false);
    });
  }, [requestId]);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!request) return;
    if (request.category !== 'comissionado' || !request.student) {
      setError('Operação inválida para esta indicação.');
      return;
    }
    const cleanInput = cpf.replace(/\D/g, '');
    const cleanTarget = (request.student.cpf || '').replace(/\D/g, '');
    if (cleanInput === cleanTarget && cleanInput.length === 11) {
      setAuthenticated(true);
      setError('');
    } else {
      setError('CPF incorreto ou inválido.');
    }
  };

  const handleAddParente = () => {
    if (!newParente.nome.trim() || !newParente.cargo.trim() || !newParente.parentesco.trim()) {
      toast.error("Preencha todos os campos do parente.");
      return;
    }
    setParentes([...parentes, newParente]);
    setNewParente({ nome: '', cargo: '', parentesco: '' });
  };

  const handleRemoveParente = (idx: number) => {
    setParentes(parentes.filter((_, i) => i !== idx));
  };

  // Dependente Row management
  const handleUpdateDependenteRow = (idx: number, field: string, val: string) => {
    const nextList = [...dependentesList];
    nextList[idx] = { ...nextList[idx], [field]: val };
    setDependentesList(nextList);
  };

  const handleAddDependenteRow = () => {
    setDependentesList([...dependentesList, { codigo: '01', nome: '', cpf: '', dataNascimento: '' }]);
  };

  const handleRemoveDependenteRow = (idx: number) => {
    if (idx === 0) return;
    if (window.confirm("Tem certeza que deseja excluir esta linha de dependente?")) {
      setDependentesList(dependentesList.filter((_, i) => i !== idx));
    }
  };

  const getOnboardingData = () => {
    const hasOutraAtividade = acumulaCargoPublico || exerceAtividadePrivada;
    return {
      estadoCivil,
      rg,
      rgEmissor,
      rgData,
      naturalidade,
      nacionalidade,
      endereco,
      numero,
      bairro,
      cidade,
      uf,
      cep,
      escolaridade,
      formacao,
      declarouParentesco,
      parentesCMC: declarouParentesco ? parentes : [],
      possuiOutroCargo: hasOutraAtividade,
      empresa: hasOutraAtividade ? empresa : '',
      enderecoEmpresa: hasOutraAtividade ? enderecoEmpresa : '',
      telefoneEmpresa: hasOutraAtividade ? telefoneEmpresa : '',
      cargoEmpresa: hasOutraAtividade ? cargoEmpresa : '',
      horarioOutroCargo: hasOutraAtividade ? horarioOutroCargo : '',
      possuiDependentes,
      dependentes: possuiDependentes ? dependentesList.filter(d => d.nome.trim() !== '') : [],
      declarouImpedimento,
      detalhesImpedimento: declarouImpedimento ? detalhesImpedimento : ''
    };
  };

  const handleSaveDraft = async () => {
    try {
      setLoading(true);
      const onboardingData = getOnboardingData();

      const updatedStudent = {
        ...(request?.student || {}),
        name: nome,
        email: email,
        phone: phone,
        birthDate: birthDate,
        cpf: request?.student?.cpf || ''
      };

      await hiringService.updateRequest(requestId, {
        student: updatedStudent,
        comissionadoDetails: onboardingData
      });

      if (request) {
        setRequest({
          ...request,
          student: updatedStudent,
          comissionadoDetails: {
            ...(request.comissionadoDetails || {}),
            ...onboardingData
          } as any
        });
      }

      toast.success("Rascunho salvo com sucesso! Você pode fechar o navegador e continuar mais tarde.");
      setLoading(false);
    } catch (err) {
      console.error(err);
      toast.error("Erro ao salvar rascunho.");
      setLoading(false);
    }
  };

  const validateStep1 = () => {
    if (!nome.trim() || !email.trim() || !phone.trim() || !birthDate.trim() || !rg.trim() || !rgEmissor.trim() || !rgData.trim() || !naturalidade.trim() || !nacionalidade.trim() || !endereco.trim() || !numero.trim() || !bairro.trim() || !cidade.trim() || !uf.trim() || !cep.trim() || !escolaridade.trim()) {
      toast.error("Por favor, preencha todos os dados cadastrais obrigatórios.");
      return false;
    }
    return true;
  };

  const handleNextStep = () => {
    if (step === 1 && !validateStep1()) return;
    setStep(prev => prev + 1);
  };

  const handlePrevStep = () => {
    setStep(prev => prev - 1);
  };

  const handleSaveSignature = async (signature: string) => {
    try {
      setLoading(true);
      const onboardingData = getOnboardingData();
      
      const docRef = doc(db, 'hiring_requests', requestId);
      await updateDoc(docRef, {
        'student.name': nome,
        'student.email': email,
        'student.phone': phone,
        'student.birthDate': birthDate
      });

      await hiringService.saveComissionadoOnboarding(requestId, onboardingData, signature);
      setShowPad(false);
      setSuccess(true);
      setLoading(false);
    } catch (err) {
      console.error(err);
      toast.error('Erro ao salvar preenchimento e assinar.');
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-4">
        <div className="w-12 h-12 border-4 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest">Carregando formulários...</p>
      </div>
    );
  }

  if (!request) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-[32px] shadow-xl max-w-md w-full text-center border border-slate-100">
           <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Lock className="w-8 h-8" />
           </div>
           <h1 className="text-xl font-black text-slate-900 uppercase mb-2">Acesso Negado</h1>
           <p className="text-sm text-slate-500 font-medium leading-relaxed">
             Indicação não encontrada ou você não possui permissão para acessá-la.
           </p>
        </div>
      </div>
    );
  }

  if (request.student?.signature) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full text-center border border-slate-100">
          <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-[32px] flex items-center justify-center mx-auto mb-6 border border-emerald-100 shadow-sm shadow-emerald-100/50">
             <CheckCircle2 className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 uppercase mb-3">Pré-cadastro Concluído</h1>
          <p className="text-slate-500 font-medium leading-relaxed">Seus dados cadastrais e declarações já foram preenchidos e assinados de forma segura.</p>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full text-center border border-slate-100">
          <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-[32px] flex items-center justify-center mx-auto mb-6 border border-emerald-100 shadow-sm">
             <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-black text-slate-900 uppercase mb-3">Pré-cadastro Enviado!</h2>
          <p className="text-slate-650 font-medium leading-relaxed mb-8">
            Seus dados e assinaturas digitais foram consolidados nos formulários de 2 a 6. O processo de nomeação agora aguarda a assinatura do Vereador e análise final na DGEP.
          </p>
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Código do Processo</p>
             <p className="text-[10px] font-mono text-slate-600 mt-1">{requestId}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-[#f8f9fc] flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full border border-slate-100 relative overflow-hidden">
          <div className="text-center mb-10">
             <div className="w-20 h-20 bg-slate-100 border border-slate-200 rounded-[32px] flex items-center justify-center mx-auto mb-6">
                <ShieldCheck className="w-10 h-10 text-slate-950" />
             </div>
             <h1 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Pré-Cadastro do Servidor</h1>
             <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mt-2">Validação de Identidade por CPF</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Informe seu CPF</label>
              <input 
                type="text" 
                value={cpf}
                onChange={(e) => setCpf(formatCPF(e.target.value))}
                placeholder="000.000.000-00"
                className="w-full bg-slate-50 border-slate-100 border-2 rounded-2xl px-6 py-5 text-xl text-center font-bold text-slate-900 focus:bg-white focus:ring-4 focus:ring-slate-950/5 focus:border-slate-900 outline-none transition-all placeholder:text-slate-250 font-mono"
                required
              />
            </div>
            
            {error && (
              <div className="bg-red-50 text-red-500 p-4 rounded-2xl border border-red-100 flex items-center gap-3">
                <Lock className="w-4 h-4 flex-shrink-0" />
                <p className="text-[10px] font-black uppercase tracking-widest">{error}</p>
              </div>
            )}

            <button 
              type="submit" 
              className="w-full bg-slate-950 text-white font-black py-5 rounded-2xl hover:bg-slate-900 transition-all shadow-xl shadow-slate-200 uppercase text-xs tracking-widest flex items-center justify-center gap-3"
            >
              Acessar Pré-Cadastro 
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </button>
          </form>
        </div>
      </div>
    );
  }

  const hasOutraAtividade = acumulaCargoPublico || exerceAtividadePrivada;

  return (
    <div className="min-h-screen bg-[#f8f9fc] py-12 px-4 flex flex-col items-center">
      <div className="w-full max-w-3xl mb-8 flex justify-center font-sans">
         <div className="bg-white p-4 rounded-[28px] shadow-sm border border-slate-100 flex items-center gap-3">
           <img src={LOGO_BASE64} alt="CMC Logo" className="h-10 w-auto" />
           <div className="h-8 w-[1px] bg-slate-200"></div>
           <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Portal de Gerenciamento de Pessoas</span>
         </div>
      </div>

      {/* Cargo and Sector Header Cards */}
      <div className="w-full max-w-3xl grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
         <div className="bg-white border rounded-2xl p-5 flex flex-col gap-1 shadow-sm">
           <span className="text-[8px] font-black text-slate-400 uppercase tracking-wider">Candidato</span>
           <span className="text-xs font-black text-slate-700 uppercase">{request.student?.name}</span>
         </div>
         <div className="bg-white border rounded-2xl p-5 flex flex-col gap-1 shadow-sm">
           <span className="text-[8px] font-black text-slate-400 uppercase tracking-wider">Lotação Designada</span>
           <span className="text-xs font-black text-slate-700 uppercase">{request.sector}</span>
         </div>
         <div className="bg-white border rounded-2xl p-5 flex flex-col gap-1 shadow-sm">
           <span className="text-[8px] font-black text-slate-400 uppercase tracking-wider">Cargo / CC</span>
           <span className="text-xs font-black text-slate-750 uppercase">{request.comissionadoDetails?.cargo || '---'} ({request.comissionadoDetails?.simbolo ? (request.comissionadoDetails.simbolo.startsWith('CC') ? request.comissionadoDetails.simbolo : 'CC-' + request.comissionadoDetails.simbolo) : '---'})</span>
         </div>
      </div>

      <div className="w-full max-w-3xl text-center mb-10 space-y-2">
         <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Pré-Cadastro do Servidor</h1>
         <p className="text-[11px] text-slate-400 font-bold uppercase tracking-[0.2em]">Câmara Municipal de Curitiba - CMC</p>
         <div className="text-xs text-slate-500 font-bold uppercase tracking-wider">Etapa {step} de 6</div>
      </div>

      <div className="w-full max-w-3xl bg-white rounded-[48px] shadow-2xl border border-slate-100 overflow-hidden mb-12">
         {/* Step Content */}
         <div className="p-8 sm:p-12 space-y-8">
            {step === 1 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b pb-3">
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-wide">1. Dados Cadastrais (Formulário 2)</h3>
                  <button 
                    type="button" 
                    onClick={handleSaveDraft}
                    className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all"
                  >
                    <Save className="w-3.5 h-3.5" /> Salvar Rascunho
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-450 uppercase tracking-widest">Nome Completo</label>
                    <input type="text" value={nome} onChange={e => setNome(e.target.value.toUpperCase())} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 uppercase" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-455 uppercase tracking-widest">E-mail</label>
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 lowercase" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-450 uppercase tracking-widest">Telefone / WhatsApp</label>
                    <input type="text" value={phone} onChange={e => setPhone(formatPhone(e.target.value))} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 font-mono" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Data de Nascimento</label>
                    <input type="date" value={birthDate} onChange={e => setBirthDate(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 font-mono" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Estado Civil</label>
                    <select value={estadoCivil} onChange={e => setEstadoCivil(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700">
                      <option value="Solteiro(a)">Solteiro(a)</option>
                      <option value="Casado(a)">Casado(a)</option>
                      <option value="Divorciado(a)">Divorciado(a)</option>
                      <option value="Viúvo(a)">Viúvo(a)</option>
                      <option value="União Estável">União Estável</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Nacionalidade</label>
                    <input type="text" value={nacionalidade} onChange={e => setNacionalidade(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Naturalidade</label>
                    <input type="text" placeholder="Ex: Curitiba - PR" value={naturalidade} onChange={e => setNaturalidade(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">RG</label>
                    <input type="text" placeholder="00.000.000-0" value={rg} onChange={e => setRg(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Órgão Emissor / Data Exp.</label>
                    <div className="flex gap-2">
                      <input type="text" placeholder="SESP/PR" value={rgEmissor} onChange={e => setRgEmissor(e.target.value)} className="w-20 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 uppercase" />
                      <input type="date" value={rgData} onChange={e => setRgData(e.target.value)} className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 font-mono" />
                    </div>
                  </div>
                  <div className="md:col-span-2 space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Endereço Residencial</label>
                    <input type="text" placeholder="Rua, Av..." value={endereco} onChange={e => setEndereco(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Número</label>
                    <input type="text" placeholder="nº" value={numero} onChange={e => setNumero(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Bairro</label>
                    <input type="text" value={bairro} onChange={e => setBairro(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">CEP</label>
                    <input type="text" placeholder="00000-000" value={cep} onChange={e => setCep(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 font-mono" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Cidade</label>
                    <input type="text" value={cidade} onChange={e => setCidade(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">UF</label>
                    <input type="text" maxLength={2} value={uf} onChange={e => setUf(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 uppercase" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Escolaridade Máxima</label>
                    <select value={escolaridade} onChange={e => setEscolaridade(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700">
                      <option value="Médio Completo">Médio Completo</option>
                      <option value="Técnico Completo">Técnico Completo</option>
                      <option value="Superior Incompleto">Superior Incompleto</option>
                      <option value="Superior Completo">Superior Completo</option>
                      <option value="Pós Graduação">Pós Graduação / Especialização</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Curso / Formação</label>
                    <input type="text" placeholder="Ex: Bacharel em Direito" value={formacao} onChange={e => setFormacao(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" />
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-fadeIn">
                <div className="flex items-center justify-between border-b pb-3">
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-wide">2. Parentesco na Câmara (Formulário 3)</h3>
                  <button 
                    type="button" 
                    onClick={handleSaveDraft}
                    className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all"
                  >
                    <Save className="w-3.5 h-3.5" /> Salvar Rascunho
                  </button>
                </div>
                <p className="text-xs text-slate-550 leading-relaxed">
                  Conforme a Súmula Vinculante 13 do STF (Regra do Nepotismo), você possui cônjuge, companheiro ou parente até terceiro grau que exerça cargo na Câmara Municipal de Curitiba?
                </p>

                {/* Parentesco Info Box Legend */}
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-[10px] text-slate-500 space-y-1.5 leading-relaxed font-sans">
                  <p className="font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-blue-500" /> Legenda de Parentesco (Até 3º Grau):
                  </p>
                  <ul className="list-disc pl-4 space-y-1">
                    <li><strong>Linha Reta:</strong> Cônjuge, companheiro(a), pais, avós, bisavós, filhos, netos, bisnetos.</li>
                    <li><strong>Linha Colateral:</strong> Irmãos (2º grau), tios e sobrinhos (3º grau).</li>
                    <li><strong>Por Afinidade:</strong> Sogros, genros, noras, cunhados (2º grau), padrasto, madrasta, enteados.</li>
                  </ul>
                </div>

                <div className="flex bg-slate-100 p-1.5 rounded-2xl max-w-xs">
                  <button type="button" onClick={() => setDeclarouParentesco(false)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${!declarouParentesco ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Não</button>
                  <button type="button" onClick={() => setDeclarouParentesco(true)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${declarouParentesco ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Sim</button>
                </div>

                {declarouParentesco && (
                  <div className="space-y-4 pt-4 border-t border-slate-100 animate-slideDown">
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">Listagem de Parentesco</h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <input type="text" placeholder="Nome do parente" value={newParente.nome} onChange={e => setNewParente({...newParente, nome: e.target.value})} className="bg-slate-50 border rounded-xl px-4 py-3 text-xs font-bold text-slate-700" />
                      <input type="text" placeholder="Cargo/Setor" value={newParente.cargo} onChange={e => setNewParente({...newParente, cargo: e.target.value})} className="bg-slate-50 border rounded-xl px-4 py-3 text-xs font-bold text-slate-700" />
                      <input type="text" placeholder="Grau (Ex: 1º grau / Pai)" value={newParente.parentesco} onChange={e => setNewParente({...newParente, parentesco: e.target.value})} className="bg-slate-50 border rounded-xl px-4 py-3 text-xs font-bold text-slate-700" />
                    </div>
                    
                    <button type="button" onClick={handleAddParente} className="px-4 py-3 bg-slate-950 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2">
                      <Plus className="w-4 h-4" /> Adicionar Parente
                    </button>

                    <div className="border rounded-2xl overflow-hidden divide-y">
                      {parentes.map((p, idx) => (
                        <div key={idx} className="p-4 bg-slate-50/50 flex items-center justify-between">
                          <div className="text-xs font-bold text-slate-705">
                            <span className="font-black text-slate-800">{p.nome.toUpperCase()}</span> - {p.cargo.toUpperCase()} ({p.parentesco.toUpperCase()})
                          </div>
                          <button type="button" onClick={() => handleRemoveParente(idx)} className="text-red-500 hover:text-red-700 transition-colors"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6 animate-fadeIn">
                <div className="flex items-center justify-between border-b pb-3">
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-wide">3. Atividades Externas (Formulário 4)</h3>
                  <button 
                    type="button" 
                    onClick={handleSaveDraft}
                    className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all"
                  >
                    <Save className="w-3.5 h-3.5" /> Salvar Rascunho
                  </button>
                </div>

                <div className="space-y-4">
                  <p className="text-xs text-slate-550 leading-relaxed font-bold uppercase tracking-wider">Pergunta 1: Você exerce outro cargo, emprego ou função pública?</p>
                  <div className="flex bg-slate-100 p-1.5 rounded-2xl max-w-xs">
                    <button type="button" onClick={() => setAcumulaCargoPublico(false)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${!acumulaCargoPublico ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Não</button>
                    <button type="button" onClick={() => setAcumulaCargoPublico(true)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${acumulaCargoPublico ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Sim</button>
                  </div>
                </div>

                <div className="space-y-4 pt-2">
                  <p className="text-xs text-slate-550 leading-relaxed font-bold uppercase tracking-wider">Pergunta 2: Você exerce atividade remunerada na iniciativa privada?</p>
                  <div className="flex bg-slate-100 p-1.5 rounded-2xl max-w-xs">
                    <button type="button" onClick={() => setExerceAtividadePrivada(false)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${!exerceAtividadePrivada ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Não</button>
                    <button type="button" onClick={() => setExerceAtividadePrivada(true)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${exerceAtividadePrivada ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Sim</button>
                  </div>
                </div>

                {/* Always rendered, but travado (disabled) and esmaecido (opacity-40) if both are "Não" */}
                <div className={`space-y-4 pt-6 border-t border-slate-100 transition-all duration-300 ${!hasOutraAtividade ? 'opacity-40 pointer-events-none' : 'opacity-100'}`}>
                  <div className="flex items-center gap-2 text-blue-600 bg-blue-50/50 p-3 rounded-xl border border-blue-150 mb-2">
                    <Info className="w-4 h-4 flex-shrink-0" />
                    <span className="text-[10px] font-black uppercase tracking-wider">Edição habilitada apenas com resposta "Sim" a uma das perguntas acima.</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Nome da entidade pública ou empresa:</label>
                      <input 
                        type="text" 
                        placeholder="Nome completo da instituição ou empresa" 
                        value={empresa} 
                        onChange={e => setEmpresa(e.target.value)} 
                        disabled={!hasOutraAtividade}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Cargo / Função:</label>
                      <input 
                        type="text" 
                        placeholder="Cargo ou atividade desempenhada" 
                        value={cargoEmpresa} 
                        onChange={e => setCargoEmpresa(e.target.value)} 
                        disabled={!hasOutraAtividade}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Endereço e Telefone:</label>
                      <input 
                        type="text" 
                        placeholder="Rua, Número - Bairro - Telefone" 
                        value={enderecoEmpresa} 
                        onChange={e => setEnderecoEmpresa(e.target.value)} 
                        disabled={!hasOutraAtividade}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Horário de Trabalho / Carga Horária:</label>
                      <input 
                        type="text" 
                        placeholder="Ex: Segunda a Sexta, 19:00 às 22:00 (15h/s)" 
                        value={horarioOutroCargo} 
                        onChange={e => setHorarioOutroCargo(e.target.value)} 
                        disabled={!hasOutraAtividade}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700" 
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6 animate-fadeIn">
                <div className="flex items-center justify-between border-b pb-3">
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-wide">4. Dependentes de Imposto de Renda (Formulário 5)</h3>
                  <button 
                    type="button" 
                    onClick={handleSaveDraft}
                    className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all"
                  >
                    <Save className="w-3.5 h-3.5" /> Salvar Rascunho
                  </button>
                </div>
                <p className="text-xs text-slate-550 leading-relaxed">
                  Deseja declarar dependentes legais para fins de dedução tributária de Imposto de Renda?
                </p>

                {/* Receita Federal Code Table */}
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-[9px] text-slate-500 space-y-1.5 leading-relaxed font-sans">
                  <p className="font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-blue-500" /> Tabela de Códigos de Dependência (Receita Federal):
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1">
                    <div><strong>01:</strong> Cônjuge ou companheiro(a)</div>
                    <div><strong>02:</strong> Filho(a)/enteado(a) até 21 anos (ou 24 universitário)</div>
                    <div><strong>03:</strong> Filho(a)/enteado(a) inválido(a) (qualquer idade)</div>
                    <div><strong>04:</strong> Irmão, neto, bisneto até 21 anos sob guarda judicial</div>
                    <div><strong>09:</strong> Pais, avós e bisavós</div>
                    <div><strong>10:</strong> Menor pobre até 21 anos sob guarda judicial</div>
                    <div><strong>11:</strong> Absolutamente incapaz sob tutela/curatela</div>
                  </div>
                </div>

                <div className="flex bg-slate-100 p-1.5 rounded-2xl max-w-xs">
                  <button type="button" onClick={() => setPossuiDependentes(false)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${!possuiDependentes ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Não</button>
                  <button type="button" onClick={() => setPossuiDependentes(true)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${possuiDependentes ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Sim</button>
                </div>

                {/* Always rendered but travados and esmaecidos when "Não" */}
                <div className={`space-y-4 pt-6 border-t border-slate-100 transition-all duration-300 ${!possuiDependentes ? 'opacity-40 pointer-events-none' : 'opacity-100'}`}>
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">Dependentes do Servidor</h4>
                    <button 
                      type="button" 
                      onClick={handleAddDependenteRow} 
                      disabled={!possuiDependentes}
                      className="px-4 py-2 bg-slate-950 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 hover:bg-slate-900"
                    >
                      <Plus className="w-3.5 h-3.5" /> Incluir Dependente
                    </button>
                  </div>

                  <div className="space-y-4">
                    {dependentesList.map((dep, idx) => (
                      <div key={idx} className="grid grid-cols-1 sm:grid-cols-12 gap-3 bg-slate-50/50 p-4 rounded-2xl border items-center">
                        <div className="sm:col-span-2 space-y-1">
                          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Código</label>
                          <select 
                            value={dep.codigo} 
                            onChange={e => handleUpdateDependenteRow(idx, 'codigo', e.target.value)}
                            disabled={!possuiDependentes}
                            className="w-full bg-white border rounded-xl px-3 py-2 text-xs font-bold text-slate-700"
                          >
                            <option value="01">01</option>
                            <option value="02">02</option>
                            <option value="03">03</option>
                            <option value="04">04</option>
                            <option value="09">09</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                          </select>
                        </div>
                        <div className="sm:col-span-4 space-y-1">
                          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Nome do Dependente</label>
                          <input 
                            type="text" 
                            placeholder="Nome Completo" 
                            value={dep.nome} 
                            onChange={e => handleUpdateDependenteRow(idx, 'nome', e.target.value.toUpperCase())}
                            disabled={!possuiDependentes}
                            className="w-full bg-white border rounded-xl px-3 py-2 text-xs font-bold text-slate-700 uppercase" 
                          />
                        </div>
                        <div className="sm:col-span-3 space-y-1">
                          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">CPF</label>
                          <input 
                            type="text" 
                            placeholder="000.000.000-00" 
                            value={dep.cpf} 
                            onChange={e => handleUpdateDependenteRow(idx, 'cpf', formatCPF(e.target.value))}
                            disabled={!possuiDependentes}
                            className="w-full bg-white border rounded-xl px-3 py-2 text-xs font-bold text-slate-700 font-mono" 
                          />
                        </div>
                        <div className="sm:col-span-2 space-y-1">
                          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Data Nasc.</label>
                          <input 
                            type="date" 
                            value={dep.dataNascimento} 
                            onChange={e => handleUpdateDependenteRow(idx, 'dataNascimento', e.target.value)}
                            disabled={!possuiDependentes}
                            className="w-full bg-white border rounded-xl px-3 py-2 text-xs font-bold text-slate-700 font-mono" 
                          />
                        </div>
                        <div className="sm:col-span-1 text-center pt-4">
                          {idx > 0 && (
                            <button 
                              type="button" 
                              onClick={() => handleRemoveDependenteRow(idx)}
                              disabled={!possuiDependentes}
                              className="text-red-500 hover:text-red-700 p-2 transition-colors"
                            >
                              <Trash2 className="w-4 h-4 mx-auto" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 5 && (
              <div className="space-y-6 animate-fadeIn">
                <div className="flex items-center justify-between border-b pb-3">
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-wide">5. Impedimento Legal (Formulário 6)</h3>
                  <button 
                    type="button" 
                    onClick={handleSaveDraft}
                    className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all"
                  >
                    <Save className="w-3.5 h-3.5" /> Salvar Rascunho
                  </button>
                </div>
                <p className="text-xs text-slate-550 leading-relaxed">
                  Você responde a algum processo civil, administrativo disciplinar, ou possui alguma restrição/impedimento legal que inviabilize o exercício do cargo?
                </p>

                <div className="flex bg-slate-100 p-1.5 rounded-2xl max-w-xs">
                  <button type="button" onClick={() => setDeclarouImpedimento(false)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${!declarouImpedimento ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Não</button>
                  <button type="button" onClick={() => setDeclarouImpedimento(true)} className={`flex-1 py-3 text-xs font-black rounded-xl uppercase tracking-wider transition-all ${declarouImpedimento ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Sim</button>
                </div>

                {declarouImpedimento && (
                  <div className="space-y-2 pt-4 border-t border-slate-100 animate-slideDown">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Detalhes das Ressalvas/Processos</label>
                    <textarea rows={4} placeholder="Informe detalhes do impedimento..." value={detalhesImpedimento} onChange={e => { setDeclarouImpedimento(true); setDetalhesImpedimento(e.target.value); }} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-700 animate-fadeIn" />
                  </div>
                )}
              </div>
            )}

            {step === 6 && (
              <div className="space-y-6 animate-fadeIn">
                <h3 className="text-lg font-black text-slate-800 uppercase border-b pb-3 tracking-wide">6. Revisão e Assinatura Digital</h3>
                <p className="text-xs text-slate-650 leading-relaxed text-justify">
                  Eu, <span className="font-black text-slate-900">{nome}</span>, declaro que as informações prestadas são totalmente verdadeiras e que dou ciência aos termos de nomeação contidos no Formulário 1 e declarações anexas dos Formulários de 2 a 6.
                </p>

                <div className="pt-4 border-t flex flex-col items-center gap-6">
                  <button 
                    onClick={() => setShowPad(true)}
                    className="w-full bg-slate-950 text-white font-black py-6 rounded-3xl hover:bg-slate-900 transition-all shadow-xl uppercase text-xs tracking-widest flex items-center justify-center gap-4"
                  >
                    <span>Confirmar e Assinar Todos os Formulários</span>
                    <Signature className="w-5 h-5 text-emerald-450" />
                  </button>
                </div>
              </div>
            )}

            {/* Pagination Controls */}
            <div className="flex items-center justify-between pt-8 border-t">
              {step > 1 ? (
                <button type="button" onClick={handlePrevStep} className="px-5 py-3 rounded-xl border border-slate-200 text-xs font-black uppercase text-slate-600 flex items-center gap-2 hover:bg-slate-50 transition-colors">
                  <ArrowLeft className="w-4 h-4" /> Voltar
                </button>
              ) : (
                <div />
              )}
              
              {step < 6 ? (
                <button type="button" onClick={handleNextStep} className="px-5 py-3 rounded-xl bg-slate-950 text-white text-xs font-black uppercase flex items-center gap-2 hover:bg-slate-900 transition-colors">
                  Avançar <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <div />
              )}
            </div>
         </div>
      </div>

      <p className="text-[9px] text-slate-350 font-bold uppercase tracking-widest">© 2026 Câmara Municipal de Curitiba</p>

      {showPad && (
        <SignaturePad
          title="Assinatura do Nomeado(a)"
          description="Assine na tela para consolidar e enviar seu pré-cadastro (Formulários 2 a 6)."
          onCancel={() => setShowPad(false)}
          onSave={handleSaveSignature}
        />
      )}
    </div>
  );
}
