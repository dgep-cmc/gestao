// Deployment trigger - 2026-05-15
import React, { useRef, useState, useEffect } from 'react';
import SignatureCanvas from 'react-signature-canvas';
import { motion } from 'motion/react';
import { Eraser, Check } from 'lucide-react';

interface SignaturePadProps {
  onSave: (signature: string) => void;
  onCancel: () => void;
  title: string;
  description: string;
}

export default function SignaturePad({ onSave, onCancel, title, description }: SignaturePadProps) {
  const sigCanvas = useRef<SignatureCanvas>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const clear = () => sigCanvas.current?.clear();

  const save = () => {
    if (sigCanvas.current?.isEmpty()) {
      alert("Por favor, assine antes de salvar.");
      return;
    }
    const dataUrl = sigCanvas.current?.getTrimmedCanvas().toDataURL('image/png');
    if (dataUrl) {
      onSave(dataUrl);
    }
  };

  useEffect(() => {
    // Ensure canvas fits the container on mount and resize
    const handleResize = () => {
      if (containerRef.current && sigCanvas.current) {
        const canvas = sigCanvas.current.getCanvas();
        const ratio = Math.max(window.devicePixelRatio || 1, 1);
        canvas.width = containerRef.current.offsetWidth * ratio;
        canvas.height = containerRef.current.offsetHeight * ratio;
        canvas.getContext('2d')?.scale(ratio, ratio);
        sigCanvas.current.clear(); // clearing prevents stretching artifacts on rotation
      }
    };
    
    // Slight delay to ensure DOM is fully rendered
    setTimeout(handleResize, 100);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-xl font-bold text-slate-800">{title}</h3>
            <p className="text-xs text-slate-500 font-medium">{description}</p>
          </div>
          <button onClick={onCancel} className="text-slate-400 hover:text-slate-600 text-3xl leading-none">&times;</button>
        </div>

        <div className="p-6">
          <div ref={containerRef} className="bg-slate-50 rounded-2xl border-2 border-slate-200 border-dashed relative group w-full h-64 touch-none">
            <SignatureCanvas 
              ref={sigCanvas}
              canvasProps={{
                className: "signature-canvas w-full h-full cursor-crosshair touch-none"
              }}
              backgroundColor="rgba(0,0,0,0)"
            />
            <button 
              onClick={clear}
              className="absolute top-4 right-4 p-2 bg-white rounded-xl shadow-sm border border-slate-200 text-slate-400 hover:text-red-500 hover:border-red-100 transition-all active:scale-95"
              title="Limpar assinatura"
            >
              <Eraser className="w-5 h-5" />
            </button>
            <div className="absolute bottom-4 left-0 right-0 flex justify-center pointer-events-none">
              <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest bg-white/80 px-4 py-1 rounded-full border border-slate-100 shadow-sm backdrop-blur-sm">
                Assine aqui
              </span>
            </div>
          </div>
        </div>

        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row gap-3">
          <button 
            onClick={onCancel}
            className="w-full sm:flex-1 px-6 py-4 sm:py-3 text-sm font-bold text-slate-500 hover:bg-white rounded-xl transition-all border border-transparent hover:border-slate-200"
          >
            Cancelar
          </button>
          <button 
            onClick={save}
            className="w-full sm:flex-1 px-6 py-4 sm:py-3 text-sm font-bold bg-blue-600 text-white hover:bg-blue-700 rounded-xl shadow-xl shadow-blue-100 transition-all flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" /> Finalizar Assinatura
          </button>
        </div>
      </motion.div>
    </div>
  );
}
