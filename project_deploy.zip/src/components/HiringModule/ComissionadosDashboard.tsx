import React, { useState, useEffect } from "react";
import {
  Plus,
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  Search,
  Filter,
  MoreVertical,
  UserPlus,
  ArrowRight,
  UserCheck,
  AlertCircle,
  Signature,
  Users,
  LayoutGrid,
  Building2,
  Mail,
  ShieldCheck,
  Send,
  Archive,
  ArrowUpDown,
  ChevronUp,
  ChevronDown,
  Eye,
  Edit,
  Trash2,
  UserMinus,
  Briefcase
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { UserProfile, HiringRequest, HiringStatus } from "../../types";
import { hiringService } from "../../services/hiringService";
import { frequencyService } from "../../services/frequencyService";
import ComissionadosRequestForm from "./ComissionadosRequestForm";
import ComissionadosTracking from "./ComissionadosTracking";

import { format, isValid, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "react-hot-toast";
import { 
  generateComissionadoForm1, 
  generateComissionadoForm2, 
  generateCaixaDeclaration, 
  generateComissionadoExoneration 
} from "../../lib/pdfGenerator";

interface ComissionadosDashboardProps {
  profile: UserProfile;
  activeTab: string;
  onTabChange: (tab: string) => void;
  viewMode: "manager" | "admin";
  onViewModeChange: (mode: "manager" | "admin") => void;
  selectedSector: string;
  onSelectSector: (sector: string) => void;
}

function RequestCard({
  req,
  onClick,
  onEdit,
  getStatusInfo,
  viewMode,
}: {
  req: HiringRequest;
  onClick: () => void;
  onEdit?: () => void;
  getStatusInfo: (status: HiringStatus) => any;
  viewMode: string;
}) {
  const statusInfo = getStatusInfo(req.status);

  const safeFormat = (
    dateStr: string | undefined | null,
    formatStr: string,
  ) => {
    if (!dateStr) return "---";
    try {
      const date = parseISO(dateStr);
      if (!isValid(date)) {
        const altDate = new Date(dateStr);
        if (!isValid(altDate)) return "---";
        return format(altDate, formatStr);
      }
      return format(date, formatStr);
    } catch (e) {
      return "---";
    }
  };

  const details = req.comissionadoDetails || {};

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden relative flex flex-col h-full group hover:shadow-xl transition-all"
    >
      {/* progress top border */}
      <div className="absolute top-0 left-0 w-full h-1 bg-slate-100 flex">
        <div
          className="h-full bg-blue-500 transition-all duration-500"
          style={{
            width:
              req.status === "approved"
                ? "100%"
                : req.status === "submitted"
                  ? "75%"
                  : req.status === "pending"
                    ? "50%"
                    : "25%",
          }}
        ></div>
      </div>

      <div className="p-6 pb-2 mt-2 flex items-start justify-between">
        <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-100">
          {req.type === "resignation" ? (
            <UserMinus className="w-6 h-6 text-rose-500" />
          ) : (
            <UserCheck className="w-6 h-6 text-blue-600" />
          )}
        </div>

        <div
          className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${statusInfo.color}`}
        >
          {statusInfo.label.toUpperCase()}
        </div>
      </div>

      <div className="px-8 mt-4 flex-1">
        <h3 className="text-xl font-bold text-slate-900 leading-tight mb-2 group-hover:text-blue-600 transition-colors">
          {req.student?.name || (req.type === "resignation" ? "EXONERAÇÃO DE COMISSIONADO" : "NOMEAÇÃO")}
        </h3>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
          {details.cargo || "Sem cargo designado"} {details.simbolo ? `• ${details.simbolo.startsWith('CC') ? details.simbolo : 'CC-' + details.simbolo}` : ""}
        </p>
      </div>

      <div className="px-8 py-6 border-t border-dashed border-slate-100 mt-6 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-400/60">
          <Building2 className="w-3.5 h-3.5" />
          <span className="text-[10px] font-bold uppercase tracking-widest truncate max-w-[140px]">
            {req.sector}
          </span>
        </div>
        <span className="text-[10px] font-bold text-slate-400/60 font-mono">
          Criado em {safeFormat(req.createdAt, "dd/MM/yy")}
        </span>
      </div>

      <div className="p-4 px-8 pb-8 flex gap-3">
        <button
          onClick={onClick}
          className="flex-1 bg-[#f8f9fc] hover:bg-slate-100 text-slate-900 py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
        >
          Visualizar <ArrowRight className="w-4 h-4" />
        </button>
        {(req.status === "draft" || req.status === "rejected") &&
          viewMode === "manager" && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onEdit?.();
              }}
              className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center hover:bg-emerald-100 transition-all shrink-0 border border-emerald-100 shadow-sm"
              title="Editar Solicitação"
            >
              <FileText className="w-5 h-5" />
            </button>
          )}
      </div>
    </motion.div>
  );
}

export default function ComissionadosDashboard({
  profile,
  activeTab,
  onTabChange,
  viewMode,
  onViewModeChange,
  selectedSector,
  onSelectSector,
}: ComissionadosDashboardProps) {
  const [dashboardDetailFilter, setDashboardDetailFilter] = useState<string | null>(null);
  const [requests, setRequests] = useState<HiringRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState<HiringRequest | boolean>(false);
  const [trackingRequest, setTrackingRequest] = useState<HiringRequest | null>(null);
  const [selectedType, setSelectedType] = useState<"hiring" | "resignation" | null>(null);
  const [listFilter, setListFilter] = useState<HiringStatus | "all" | "signatures">("all");
  const [adminListFilter, setAdminListFilter] = useState<"all" | "archived">("all");

  const [rejectingRequest, setRejectingRequest] = useState<HiringRequest | null>(null);
  const [deletingRequest, setDeletingRequest] = useState<HiringRequest | null>(null);
  const [archivingRequest, setArchivingRequest] = useState<HiringRequest | null>(null);
  const [unarchivingRequest, setUnarchivingRequest] = useState<HiringRequest | null>(null);
  const [approvingRequest, setApprovingRequest] = useState<HiringRequest | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [search, setSearch] = useState("");

  const [sortField, setSortField] = useState<"student" | "type" | "sector" | "createdAt" | "status" | "signatures">("createdAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  const safeFormat = (
    dateStr: string | undefined | null,
    formatStr: string,
  ) => {
    if (!dateStr) return "---";
    try {
      const date = parseISO(dateStr);
      if (!isValid(date)) {
        const altDate = new Date(dateStr);
        if (!isValid(altDate)) return "---";
        return format(altDate, formatStr);
      }
      return format(date, formatStr);
    } catch (e) {
      return "---";
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const requestsData =
        profile.role === "master"
          ? await hiringService.getAllRequests()
          : await Promise.all(
              (profile.sectors || []).map((s) =>
                hiringService.getRequestsBySector(s),
              ),
            ).then((res) => res.flat());

      // Filter only comissionados requests
      const comissionadosOnly = requestsData.filter(r => r.category === 'comissionado');

      setRequests(
        comissionadosOnly.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        ),
      );
    } catch (error) {
      console.error(error);
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [profile]);

  useEffect(() => {
    setTrackingRequest(null);
    setShowForm(false);
    setDashboardDetailFilter(null);
    setAdminListFilter("all");
  }, [activeTab, selectedSector, viewMode]);

  const getStatusInfo = (status: HiringStatus) => {
    switch (status) {
      case "draft":
        return {
          label: "1. EM PREENCHIMENTO",
          color: "bg-amber-100 text-amber-700",
          icon: <Clock className="w-3 h-3" />,
        };
      case "pending":
        return {
          label: "2. AG. PRÉ-CADASTRO",
          color: "bg-blue-100 text-blue-700",
          icon: <Clock className="w-3 h-3" />,
        };
      case "submitted":
        return {
          label: "3. AG. DGEP",
          color: "bg-indigo-100 text-indigo-700",
          icon: <Send className="w-3 h-3" />,
        };
      case "approved":
        return {
          label: "APROVADO",
          color: "bg-green-100 text-green-700",
          icon: <CheckCircle2 className="w-3 h-3" />,
        };
      case "rejected":
        return {
          label: "DEVOLVIDO",
          color: "bg-red-100 text-red-700",
          icon: <XCircle className="w-3 h-3" />,
        };
      case "archived":
        return {
          label: "ARQUIVADO",
          color: "bg-slate-200 text-slate-500",
          icon: <Archive className="w-3 h-3" />,
        };
      default:
        return {
          label: "Processando",
          color: "bg-gray-100 text-gray-700",
          icon: <AlertCircle className="w-3 h-3" />,
        };
    }
  };

  const handleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDirection(field === "createdAt" ? "desc" : "asc");
    }
  };

  const renderSortIcon = (field: typeof sortField) => {
    if (sortField !== field) {
      return (
        <ArrowUpDown className="w-3.5 h-3.5 text-slate-300 opacity-50 group-hover:opacity-100 transition-opacity ml-1.5 shrink-0" />
      );
    }
    return sortDirection === "asc" ? (
      <ChevronUp className="w-3.5 h-3.5 text-blue-600 ml-1.5 shrink-0" />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 text-blue-600 ml-1.5 shrink-0" />
    );
  };

  const modeFilteredRequests =
    viewMode === "admin"
      ? requests.filter((r) => {
          if (r.type === "resignation") {
            return ["submitted", "approved", "rejected", "archived"].includes(r.status);
          } else {
            return r.status !== "draft";
          }
        })
      : requests.filter((r) => {
          const userSectors = profile.sectors || [];
          return userSectors.includes(r.sector);
        });

  const filteredRequests = modeFilteredRequests.filter((r) => {
    if (listFilter === "all") {
      if (viewMode === "admin") {
        if (["draft", "pending", "rejected"].includes(r.status)) return false;
      }
      return r.status !== "archived";
    } else if (listFilter === "signatures") {
      return ["draft", "pending"].includes(r.status);
    } else {
      return r.status === listFilter;
    }
  });

  const DisplayBase = selectedSector
    ? filteredRequests.filter((r) => r.sector === selectedSector)
    : filteredRequests;

  const displayRequests = search.trim()
    ? DisplayBase.filter(
        (r) =>
          (r.comissionadoDetails?.cargo || "").toLowerCase().includes(search.toLowerCase()) ||
          r.sector.toLowerCase().includes(search.toLowerCase()) ||
          (r.student?.name || "").toLowerCase().includes(search.toLowerCase()),
      )
    : DisplayBase;

  const sortedRequests = React.useMemo(() => {
    const list = [...displayRequests];
    return list.sort((a, b) => {
      let valA: any = "";
      let valB: any = "";

      if (sortField === "student") {
        valA = (a.student?.name || "").toLowerCase();
        valB = (b.student?.name || "").toLowerCase();
      } else if (sortField === "type") {
        valA = a.type || "";
        valB = b.type || "";
      } else if (sortField === "sector") {
        valA = (a.sector || "").toLowerCase();
        valB = (b.sector || "").toLowerCase();
      } else if (sortField === "createdAt") {
        valA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        valB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      } else if (sortField === "status") {
        valA = getStatusInfo(a.status).label || "";
        valB = getStatusInfo(b.status).label || "";
      } else if (sortField === "signatures") {
        valA = (a.supervisor?.signature ? 1 : 0) + (a.student?.signature ? 1 : 0);
        valB = (b.supervisor?.signature ? 1 : 0) + (b.student?.signature ? 1 : 0);
      }

      if (valA < valB) return sortDirection === "asc" ? -1 : 1;
      if (valA > valB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }, [displayRequests, sortField, sortDirection]);

  const stats = {
    total: modeFilteredRequests.length,
    active: modeFilteredRequests.filter((r) => r.status !== "archived").length,
    drafts: modeFilteredRequests.filter((r) => r.status === "draft").length,
    pendingOnboarding: modeFilteredRequests.filter((r) => r.status === "pending").length,
    submitted: modeFilteredRequests.filter((r) => r.status === "submitted").length,
    approved: modeFilteredRequests.filter((r) => r.status === "approved").length,
    rejected: modeFilteredRequests.filter((r) => r.status === "rejected").length,
    archived: modeFilteredRequests.filter((r) => r.status === "archived").length,
  };

  const getFilteredRequestsForDashboard = () => {
    switch (dashboardDetailFilter) {
      case "TOTAL SOLICITAÇÕES":
        return modeFilteredRequests;
      case "AGUARDANDO DIREÇÃO (DGEP)":
        return modeFilteredRequests.filter((r) => r.status === "submitted");
      case "AGUARDANDO CADASTRO":
        return modeFilteredRequests.filter((r) => r.status === "pending");
      case "EM PREENCHIMENTO":
        return modeFilteredRequests.filter((r) => r.status === "draft");
      case "CONTRATAÇÕES APROVADAS":
        return modeFilteredRequests.filter((r) => r.status === "approved");
      default:
        return modeFilteredRequests;
    }
  };

  const adminDisplayRequests = React.useMemo(() => {
    let baseList = getFilteredRequestsForDashboard();
    if (adminListFilter === "all") {
      baseList = baseList.filter((r) => r.status !== "archived");
    } else if (adminListFilter === "archived") {
      baseList = baseList.filter((r) => r.status === "archived");
    }

    if (!search.trim()) return baseList;
    return baseList.filter(
      (r) =>
        (r.comissionadoDetails?.cargo || "").toLowerCase().includes(search.toLowerCase()) ||
        r.sector.toLowerCase().includes(search.toLowerCase()) ||
        (r.student?.name || "").toLowerCase().includes(search.toLowerCase()),
    );
  }, [dashboardDetailFilter, modeFilteredRequests, search, adminListFilter]);

  const sortedAdminRequests = React.useMemo(() => {
    const list = [...adminDisplayRequests];
    return list.sort((a, b) => {
      let valA: any = "";
      let valB: any = "";

      if (sortField === "student") {
        valA = (a.student?.name || "").toLowerCase();
        valB = (b.student?.name || "").toLowerCase();
      } else if (sortField === "type") {
        valA = a.type || "";
        valB = b.type || "";
      } else if (sortField === "sector") {
        valA = (a.sector || "").toLowerCase();
        valB = (b.sector || "").toLowerCase();
      } else if (sortField === "createdAt") {
        valA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        valB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      } else if (sortField === "status") {
        valA = getStatusInfo(a.status).label || "";
        valB = getStatusInfo(b.status).label || "";
      } else if (sortField === "signatures") {
        valA = (a.supervisor?.signature ? 1 : 0) + (a.student?.signature ? 1 : 0);
        valB = (b.supervisor?.signature ? 1 : 0) + (b.student?.signature ? 1 : 0);
      }

      if (valA < valB) return sortDirection === "asc" ? -1 : 1;
      if (valA > valB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }, [adminDisplayRequests, sortField, sortDirection]);

  const handleApprove = async (req: HiringRequest) => {
    try {
      await hiringService.updateStatus(req.id, "approved", {
        approvedBy: profile.email,
        approvedAt: new Date().toISOString(),
      });
      toast.success("Nomeação aprovada!");
      setApprovingRequest(null);
      loadData();
    } catch (e) {
      toast.error("Erro ao aprovar");
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast.error("Motivo obrigatório");
      return;
    }
    if (!rejectingRequest) return;
    try {
      await hiringService.updateStatus(rejectingRequest.id, "rejected", {
        rejectReason,
        rejectedBy: profile.email,
        rejectedAt: new Date().toISOString(),
      });
      toast.success("Retornado para ajustes");
      setRejectingRequest(null);
      setRejectReason("");
      loadData();
    } catch (e) {
      toast.error("Erro ao devolver");
    }
  };

  const handleArchive = async (req: HiringRequest) => {
    try {
      await hiringService.updateStatus(req.id, "archived");
      toast.success("Arquivado!");
      setArchivingRequest(null);
      loadData();
    } catch (e) {
      toast.error("Erro ao arquivar");
    }
  };

  const handleUnarchive = async (req: HiringRequest) => {
    try {
      await hiringService.updateStatus(req.id, "approved");
      toast.success("Desarquivado!");
      setUnarchivingRequest(null);
      loadData();
    } catch (e) {
      toast.error("Erro ao reativar");
    }
  };

  const handleDelete = async (req: HiringRequest) => {
    try {
      await hiringService.deleteRequest(req.id);
      toast.success("Excluído com sucesso");
      setDeletingRequest(null);
      loadData();
    } catch (e) {
      toast.error("Erro ao excluir");
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white">
      <AnimatePresence mode="wait">
        {trackingRequest ? (
          <motion.div
            key="comissionado-tracking"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col"
          >
            <ComissionadosTracking
              request={trackingRequest}
              profile={profile}
              viewMode={viewMode}
              onClose={() => setTrackingRequest(null)}
              onApprove={(updatedReq) => {
                setTrackingRequest(updatedReq);
                loadData();
              }}
              onReject={setRejectingRequest}
              onArchive={setArchivingRequest}
              onUnarchive={setUnarchivingRequest}
              onEdit={
                viewMode === "manager"
                  ? (req) => {
                      setShowForm(req);
                      setSelectedType(req.type === "resignation" ? "resignation" : "hiring");
                      setTrackingRequest(null);
                    }
                  : undefined
              }
            />
          </motion.div>
        ) : showForm ? (
          <motion.div
            key="comissionado-form"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col"
          >
            <ComissionadosRequestForm
              profile={profile}
              onClose={() => {
                setShowForm(false);
                setSelectedType(null);
              }}
              initialData={typeof showForm === "object" ? showForm : undefined}
              initialType={selectedType}
              selectedSector={selectedSector}
              onSuccess={() => {
                setShowForm(false);
                setSelectedType(null);
                loadData();
              }}
            />
          </motion.div>
        ) : (
          <div className="flex-1 flex flex-col">
            {/* Header */}
            <header className="bg-white border-b border-slate-200 p-4 sm:px-8 sm:py-0 sm:h-[84px] flex flex-col sm:flex-row items-center justify-between sticky top-0 z-10 shrink-0 gap-4 shadow-sm">
              <div className="flex items-center gap-4 sm:gap-8 overflow-x-hidden">
                <div className="min-w-0">
                  <div className="flex items-center gap-3">
                    <h2 className="text-xl font-bold text-slate-800 tracking-tight truncate">
                      Contratação de Servidores Comissionados
                    </h2>
                    <span
                      className={`px-2 py-0.5 ${viewMode === "admin" ? "bg-emerald-100 text-emerald-800" : "bg-emerald-100 text-emerald-700"} text-[9px] font-black uppercase rounded tracking-wider ring-1 shrink-0`}
                    >
                      {viewMode === "admin" ? "GESTÃO CENTRAL" : "GESTÃO UNIDADE"}
                    </span>
                  </div>
                  <p className="text-sm font-bold text-blue-600 uppercase tracking-tighter opacity-80 mt-1">
                    Nomeações, exonerações e preenchimento de declarações
                  </p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                {viewMode === "manager" && (
                  <>
                    <button
                      onClick={() => {
                        setSelectedType("hiring");
                        setShowForm(true);
                      }}
                      className="w-full sm:w-auto justify-center bg-blue-600 shadow-blue-100/50 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2 group active:scale-[0.98] cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" /> Nova Nomeação
                    </button>
                    <button
                      onClick={() => {
                        setSelectedType("resignation");
                        setShowForm(true);
                      }}
                      className="w-full sm:w-auto justify-center bg-rose-600 shadow-rose-100/50 hover:bg-rose-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2 group active:scale-[0.98] cursor-pointer"
                    >
                      <UserMinus className="w-4 h-4" /> Indicação Exoneração
                    </button>
                  </>
                )}
              </div>
            </header>

            <main className="flex-1 p-4 sm:p-8 bg-slate-50/30 custom-scrollbar">
              <AnimatePresence mode="wait">
                {activeTab === "stats" && (
                  <motion.div
                    key="stats"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="max-w-7xl mx-auto space-y-8"
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                      <StatusCard
                        label="TOTAL INDICAÇÕES"
                        value={stats.total}
                        icon={<UserCheck className="w-5 h-5" />}
                        active={dashboardDetailFilter === "TOTAL SOLICITAÇÕES"}
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "TOTAL SOLICITAÇÕES" ? null : "TOTAL SOLICITAÇÕES"
                          )
                        }
                        color="bg-emerald-600"
                      />
                      <StatusCard
                        label="AGUARDANDO DIREÇÃO (DGEP)"
                        value={stats.submitted}
                        icon={<FileText className="w-5 h-5" />}
                        active={dashboardDetailFilter === "AGUARDANDO DIREÇÃO (DGEP)"}
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "AGUARDANDO DIREÇÃO (DGEP)" ? null : "AGUARDANDO DIREÇÃO (DGEP)"
                          )
                        }
                        color="bg-orange-500"
                      />
                      <StatusCard
                        label="EM PREENCHIMENTO"
                        value={stats.drafts}
                        icon={<Clock className="w-5 h-5" />}
                        active={dashboardDetailFilter === "EM PREENCHIMENTO"}
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "EM PREENCHIMENTO" ? null : "EM PREENCHIMENTO"
                          )
                        }
                        color="bg-amber-500"
                      />
                      <StatusCard
                        label="AGUARDANDO CADASTRO"
                        value={stats.pendingOnboarding}
                        icon={<Signature className="w-5 h-5" />}
                        active={dashboardDetailFilter === "AGUARDANDO CADASTRO"}
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "AGUARDANDO CADASTRO" ? null : "AGUARDANDO CADASTRO"
                          )
                        }
                        color="bg-blue-500"
                      />
                      <StatusCard
                        label="NOMEAÇÕES APROVADAS"
                        value={stats.approved}
                        icon={<CheckCircle2 className="w-5 h-5" />}
                        active={dashboardDetailFilter === "CONTRATAÇÕES APROVADAS"}
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "CONTRATAÇÕES APROVADAS" ? null : "CONTRATAÇÕES APROVADAS"
                          )
                        }
                        color="bg-emerald-500"
                        className="col-span-2 sm:col-span-1"
                      />
                    </div>

                    {/* Integrated Requirement Management Section */}
                    <div className="bg-white rounded-[32px] border border-slate-200/80 shadow-sm p-5 sm:p-8 space-y-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-1.5 h-6 rounded-full animate-pulse ${
                              dashboardDetailFilter ? "bg-emerald-600" : "bg-emerald-500"
                            }`}
                          />
                          <div>
                            <h3 className="text-base font-black text-slate-800 uppercase tracking-wider">
                              {dashboardDetailFilter ? `Filtrado por: ${dashboardDetailFilter}` : "Todos os Requerimentos"}
                            </h3>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                              Exibindo indicações de servidores comissionados no setor selecionado
                            </p>
                          </div>
                        </div>

                        <div className="flex flex-row items-center gap-2 sm:gap-3 w-full md:w-auto">
                          {dashboardDetailFilter && (
                            <button
                              onClick={() => setDashboardDetailFilter(null)}
                              className="text-[10px] font-black text-slate-400 hover:text-red-500 transition-colors uppercase tracking-widest flex items-center gap-1.5 border border-slate-100 rounded-xl px-2.5 py-2 bg-slate-50/50 hover:bg-slate-50 cursor-pointer whitespace-nowrap shrink-0"
                            >
                              <XCircle className="w-3.5 h-3.5" /> Limpar
                            </button>
                          )}
                          <div className="relative w-full md:max-w-xs">
                            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input
                              type="text"
                              placeholder="Buscar solicitações..."
                              value={search}
                              onChange={(e) => setSearch(e.target.value)}
                              className="w-full bg-slate-50/50 border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-xs font-bold focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Active vs Archived Division Tabs for Admin */}
                      <div className="flex overflow-x-auto bg-slate-100/50 p-1 rounded-2xl border border-slate-100 w-fit shrink-0 custom-scrollbar no-scrollbar">
                        <TabButton
                          active={adminListFilter === "all"}
                          onClick={() => setAdminListFilter("all")}
                          label="Ativos"
                          count={modeFilteredRequests.filter((r) => r.status !== "archived").length}
                        />
                        <TabButton
                          active={adminListFilter === "archived"}
                          onClick={() => setAdminListFilter("archived")}
                          label="Arquivados"
                          count={modeFilteredRequests.filter((r) => r.status === "archived").length}
                        />
                      </div>

                      {/* Table for Desktop */}
                      <div className="hidden md:block overflow-x-auto ring-1 ring-slate-100 rounded-2xl">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50/50 border-b border-slate-100">
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("type")}
                              >
                                <div className="flex items-center">
                                  Tipo {renderSortIcon("type")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("student")}
                              >
                                <div className="flex items-center">
                                  Servidor {renderSortIcon("student")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("sector")}
                              >
                                <div className="flex items-center">
                                  Lotação / Setor {renderSortIcon("sector")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("createdAt")}
                              >
                                <div className="flex items-center">
                                  Data Criação {renderSortIcon("createdAt")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("signatures")}
                              >
                                <div className="flex items-center">
                                  Assinaturas {renderSortIcon("signatures")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("status")}
                              >
                                <div className="flex items-center">
                                  Status {renderSortIcon("status")}
                                </div>
                              </th>
                              <th className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">
                                Ações
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {loading ? (
                              <tr>
                                <td colSpan={7} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-3 justify-center">
                                    <div className="w-8 h-8 border-3 border-blue-650/20 border-t-blue-600 rounded-full animate-spin"></div>
                                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Carregando...</p>
                                  </div>
                                </td>
                              </tr>
                            ) : sortedAdminRequests.length === 0 ? (
                              <tr>
                                <td colSpan={7} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-4 opacity-40 justify-center">
                                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                                      <FileText className="w-8 h-8 text-slate-300" />
                                    </div>
                                    <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Nenhuma indicação encontrada</p>
                                  </div>
                                </td>
                              </tr>
                            ) : (
                              sortedAdminRequests.map((req) => {
                                const statusInfo = getStatusInfo(req.status);
                                const isHiring = req.type === "hiring";
                                const hasSupervisorSig = !!req.supervisor?.signature;
                                const hasStudentSig = !isHiring || !!req.student?.signature;
                                const isSignaturesComplete = isHiring ? (hasSupervisorSig && hasStudentSig) : true;

                                return (
                                  <tr key={req.id} className="hover:bg-slate-50/20 transition-colors">
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[8px] font-black uppercase ${
                                        req.type === "hiring" ? "bg-blue-50 text-blue-700" : "bg-rose-50 text-rose-700"
                                      }`}>
                                        {req.type === "hiring" ? "NOMEAÇÃO" : "EXONERAÇÃO"}
                                      </span>
                                    </td>
                                    <td className="px-4 py-3 max-w-xs">
                                      <p className="text-xs font-bold text-slate-900 leading-tight hover:text-blue-600 cursor-pointer transition-colors truncate" onClick={() => setTrackingRequest(req)}>
                                        {req.student?.name || "Candidato"}
                                      </p>
                                      <p className="text-[9px] text-slate-450 font-bold uppercase mt-0.5">
                                        {req.comissionadoDetails?.cargo || (req.comissionadoDetails?.simbolo ? (req.comissionadoDetails.simbolo.startsWith('CC') ? req.comissionadoDetails.simbolo : "CC-" + req.comissionadoDetails.simbolo) : "")}
                                      </p>
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap text-xs font-bold text-slate-700 uppercase">
                                      {req.sector}
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap text-xs font-semibold text-slate-500 tabular-nums">
                                      {safeFormat(req.createdAt, "dd/MM/yyyy")}
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <div className="flex items-center gap-2">
                                        <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${hasSupervisorSig ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                          Prop: {hasSupervisorSig ? 'Assinado' : 'Pend'}
                                        </span>
                                        {isHiring && (
                                          <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${hasStudentSig ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                            Cand: {hasStudentSig ? 'Assinado' : 'Pend'}
                                          </span>
                                        )}
                                      </div>
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase ${statusInfo.color}`}>
                                        {statusInfo.icon} {statusInfo.label}
                                      </span>
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap text-center">
                                      <div className="flex items-center justify-center gap-1.5">
                                        <button onClick={() => setTrackingRequest(req)} className="p-1.5 text-slate-450 hover:text-slate-700 hover:bg-slate-50 rounded-lg transition-all" title="Ver Detalhes">
                                          <Eye className="w-3.5 h-3.5" />
                                        </button>
                                        {viewMode === "admin" && (
                                          <>
                                            <button onClick={() => setApprovingRequest(req)} disabled={req.status === "approved" || req.status === "archived" || !isSignaturesComplete} className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-all disabled:opacity-30" title="Aprovar">
                                              <CheckCircle2 className="w-3.5 h-3.5" />
                                            </button>
                                            <button onClick={() => setRejectingRequest(req)} disabled={req.status === "approved" || req.status === "archived" || req.status === "rejected" || req.status === "draft"} className="p-1.5 text-red-650 hover:text-red-800 hover:bg-red-50 rounded-lg transition-all disabled:opacity-30" title="Devolver">
                                              <XCircle className="w-3.5 h-3.5" />
                                            </button>
                                          </>
                                        )}
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>

                      {/* Mobile Cards */}
                      <div className="block md:hidden space-y-4">
                        {sortedAdminRequests.map((req) => (
                          <RequestCard
                            key={req.id}
                            req={req}
                            onClick={() => setTrackingRequest(req)}
                            onEdit={() => setShowForm(req)}
                            getStatusInfo={getStatusInfo}
                            viewMode={viewMode}
                          />
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === "requests" && (
                  <motion.div
                    key="requests"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="max-w-7xl mx-auto space-y-6"
                  >
                    <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm p-6 sm:p-8 space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                        <div>
                          <h3 className="text-base font-black text-slate-800 uppercase tracking-wider">
                            Minhas Indicações
                          </h3>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                            Processos de comissionados da sua unidade
                          </p>
                        </div>
                        <div className="flex bg-slate-100 p-1 rounded-xl w-fit">
                          <button onClick={() => setListFilter("all")} className={`px-4 py-2 text-[10px] font-black rounded-lg uppercase tracking-wider ${listFilter === 'all' ? 'bg-white shadow' : 'text-slate-500'}`}>Ativas</button>
                          <button onClick={() => setListFilter("signatures")} className={`px-4 py-2 text-[10px] font-black rounded-lg uppercase tracking-wider ${listFilter === 'signatures' ? 'bg-white shadow' : 'text-slate-500'}`}>Aguardando Ass.</button>
                        </div>
                      </div>

                      {/* Table for Desktop */}
                      <div className="hidden md:block overflow-x-auto ring-1 ring-slate-100 rounded-2xl bg-white">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50/50 border-b border-slate-100">
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("type")}
                              >
                                <div className="flex items-center">
                                  Tipo {renderSortIcon("type")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("student")}
                              >
                                <div className="flex items-center">
                                  Servidor {renderSortIcon("student")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("createdAt")}
                              >
                                <div className="flex items-center">
                                  Data Criação {renderSortIcon("createdAt")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("signatures")}
                              >
                                <div className="flex items-center">
                                  Assinaturas {renderSortIcon("signatures")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("status")}
                              >
                                <div className="flex items-center">
                                  Status {renderSortIcon("status")}
                                </div>
                              </th>
                              <th className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">
                                Ações
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {loading ? (
                              <tr>
                                <td colSpan={6} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-3 justify-center">
                                    <div className="w-8 h-8 border-3 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin"></div>
                                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Carregando...</p>
                                  </div>
                                </td>
                              </tr>
                            ) : sortedRequests.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-4 opacity-40 justify-center">
                                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                                      <FileText className="w-8 h-8 text-slate-300" />
                                    </div>
                                    <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Nenhuma indicação encontrada</p>
                                  </div>
                                </td>
                              </tr>
                            ) : (
                              sortedRequests.map((req) => {
                                const statusInfo = getStatusInfo(req.status);
                                const isHiring = req.type === "hiring";
                                const hasSupervisorSig = !!req.supervisor?.signature;
                                const hasStudentSig = !isHiring || !!req.student?.signature;

                                return (
                                  <tr key={req.id} className="hover:bg-slate-50/20 transition-colors">
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[8px] font-black uppercase ${
                                        req.type === "hiring" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"
                                      }`}>
                                        {req.type === "hiring" ? "NOMEAÇÃO" : "EXONERAÇÃO"}
                                      </span>
                                    </td>
                                    <td className="px-4 py-3 max-w-xs">
                                      <p className="text-xs font-bold text-slate-900 leading-tight hover:text-emerald-600 cursor-pointer transition-colors truncate" onClick={() => setTrackingRequest(req)}>
                                        {req.student?.name || "Candidato"}
                                      </p>
                                      <p className="text-[9px] text-slate-450 font-bold uppercase mt-0.5">
                                        {req.comissionadoDetails?.cargo || (req.comissionadoDetails?.simbolo ? (req.comissionadoDetails.simbolo.startsWith('CC') ? req.comissionadoDetails.simbolo : "CC-" + req.comissionadoDetails.simbolo) : "")}
                                      </p>
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap text-xs font-semibold text-slate-500 tabular-nums">
                                      {safeFormat(req.createdAt, "dd/MM/yyyy")}
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <div className="flex items-center gap-2">
                                        <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${hasSupervisorSig ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                          Prop: {hasSupervisorSig ? 'Assinado' : 'Pend'}
                                        </span>
                                        {isHiring && (
                                          <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${hasStudentSig ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                            Cand: {hasStudentSig ? 'Assinado' : 'Pend'}
                                          </span>
                                        )}
                                      </div>
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase ${statusInfo.color}`}>
                                        {statusInfo.icon} {statusInfo.label}
                                      </span>
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap text-center">
                                      <div className="flex items-center justify-center gap-1.5">
                                        <button onClick={() => setTrackingRequest(req)} className="p-1.5 text-slate-450 hover:text-slate-700 hover:bg-slate-50 rounded-lg transition-all" title="Ver Detalhes">
                                          <Eye className="w-3.5 h-3.5" />
                                        </button>
                                        {(req.status === "draft" || req.status === "rejected") && (
                                          <button onClick={() => { setShowForm(req); setSelectedType(req.type === "resignation" ? "resignation" : "hiring"); }} className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-all" title="Editar Solicitação">
                                            <Edit className="w-3.5 h-3.5" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>

                      {/* Mobile Cards */}
                      <div className="block md:hidden space-y-4">
                        {sortedRequests.map((req) => (
                          <RequestCard
                            key={req.id}
                            req={req}
                            onClick={() => setTrackingRequest(req)}
                            onEdit={() => { setShowForm(req); setSelectedType(req.type === "resignation" ? "resignation" : "hiring"); }}
                            getStatusInfo={getStatusInfo}
                            viewMode={viewMode}
                          />
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </main>
          </div>
        )}
      </AnimatePresence>

      {/* Modals */}
      {rejectingRequest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border">
            <h3 className="text-lg font-black text-slate-900 uppercase">Devolver para Ajustes</h3>
            <p className="text-xs text-slate-500 mt-1 uppercase font-bold">Informe o motivo da devolução para orientar o proponente</p>
            <textarea
              rows={4}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Descreva aqui o motivo..."
              className="w-full bg-slate-50 border rounded-xl p-3.5 mt-4 text-sm font-medium outline-none focus:bg-white"
            />
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setRejectingRequest(null)}
                className="flex-1 py-3 text-xs font-black uppercase text-slate-500 hover:bg-slate-50 rounded-xl"
              >
                Cancelar
              </button>
              <button
                onClick={handleReject}
                className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black uppercase tracking-wider"
              >
                Devolver
              </button>
            </div>
          </div>
        </div>
      )}

      {approvingRequest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900 uppercase">Aprovar Nomeação</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Deseja realmente aprovar a nomeação de {approvingRequest.student?.name}?</p>
            <div className="flex gap-3 pt-4">
              <button onClick={() => setApprovingRequest(null)} className="flex-1 py-3 text-xs font-black uppercase text-slate-500 hover:bg-slate-50 rounded-xl">Cancelar</button>
              <button onClick={() => handleApprove(approvingRequest)} className="flex-1 py-3 bg-emerald-600 text-white rounded-xl text-xs font-black uppercase tracking-wider">Confirmar</button>
            </div>
          </div>
        </div>
      )}

      {archivingRequest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border text-center space-y-4">
            <div className="w-16 h-16 bg-slate-100 text-slate-650 rounded-full flex items-center justify-center mx-auto">
              <Archive className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900 uppercase">Arquivar Registro</h3>
            <p className="text-xs text-slate-500">Deseja realmente arquivar esta nomeação?</p>
            <div className="flex gap-3 pt-4">
              <button onClick={() => setArchivingRequest(null)} className="flex-1 py-3 text-xs font-black uppercase text-slate-500 hover:bg-slate-50 rounded-xl">Cancelar</button>
              <button onClick={() => handleArchive(archivingRequest)} className="flex-1 py-3 bg-slate-700 text-white rounded-xl text-xs font-black uppercase tracking-wider">Arquivar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatusCard({
  label,
  value,
  icon,
  color,
  active,
  onClick,
  className,
}: {
  label: string;
  value: number;
  icon: React.ReactNode;
  color: string;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  let activeStyles = "border-blue-500 ring-4 ring-blue-50/50 bg-blue-50/5";
  let labelActiveColor = "text-blue-600 font-extrabold";
  let iconActiveBg = "bg-blue-50 text-blue-600";

  if (color.includes("emerald")) {
    activeStyles = "border-emerald-500 ring-4 ring-emerald-50/50 bg-emerald-50/5";
    labelActiveColor = "text-emerald-600 font-extrabold";
    iconActiveBg = "bg-emerald-50 text-emerald-600";
  } else if (color.includes("orange")) {
    activeStyles = "border-orange-500 ring-4 ring-orange-50/50 bg-orange-50/5";
    labelActiveColor = "text-orange-600 font-extrabold";
    iconActiveBg = "bg-orange-50 text-orange-650";
  } else if (color.includes("amber")) {
    activeStyles = "border-amber-500 ring-4 ring-amber-50/50 bg-amber-50/5";
    labelActiveColor = "text-amber-600 font-extrabold";
    iconActiveBg = "bg-amber-50 text-amber-600";
  }

  return (
    <button
      onClick={onClick}
      className={`bg-white p-5 rounded-[22px] border transition-all duration-350 w-full text-left cursor-pointer transform hover:-translate-y-0.5 ${
        active ? activeStyles : "border-slate-200 shadow-sm hover:border-slate-350"
      } ${className || ""}`}
    >
      <div className="flex items-center justify-between mb-2">
        <p className={`text-[9px] uppercase tracking-wider font-extrabold ${active ? labelActiveColor : "text-slate-400"}`}>
          {label}
        </p>
        <div className={`p-2 rounded-xl ${active ? iconActiveBg : "bg-slate-50 text-slate-400"}`}>{icon}</div>
      </div>
      <h3 className={`text-3xl font-black tabular-nums ${active ? labelActiveColor : "text-slate-800"}`}>{value}</h3>
      <div className="w-full bg-slate-100 h-1 mt-3.5 rounded-full overflow-hidden">
        <div className={`${color} h-full w-full opacity-60`}></div>
      </div>
    </button>
  );
}

function TabButton({
  active,
  label,
  count,
  onClick,
}: {
  active: boolean;
  label: string;
  count: number;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 sm:px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
        active ? "bg-white text-emerald-700 shadow" : "text-slate-400 hover:text-slate-600 hover:bg-white/50"
      }`}
    >
      {label}
      <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black ${active ? "bg-emerald-100 text-emerald-800" : "bg-slate-200 text-slate-500"}`}>
        {count}
      </span>
    </button>
  );
}
