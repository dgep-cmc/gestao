import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  FileText, 
  ArrowLeft, 
  Clock, 
  CheckCircle2, 
  Signature, 
  Copy,
  User,
  Building2,
  AlertCircle,
  Download,
  Eye,
  ShieldCheck,
  Briefcase,
  ExternalLink,
  Lock,
  Calendar,
  XCircle,
  Archive,
  ArrowUpCircle
} from 'lucide-react';
import { HiringRequest, HiringStatus, UserProfile } from '../../types';
import { format, isValid, parseISO } from 'date-fns';
import { toast } from 'react-hot-toast';
import { 
  generateComissionadoForm1, 
  generateComissionadoForm2, 
  generateComissionadoForm3, 
  generateComissionadoForm4,
  generateComissionadoForm5,
  generateComissionadoForm6,
  generateCaixaDeclaration, 
  generateComissionadoExoneration 
} from '../../lib/pdfGenerator';
import { frequencyService } from '../../services/frequencyService';
import { hiringService } from '../../services/hiringService';
import SignaturePad from './SignaturePad';

interface ComissionadosTrackingProps {
  request: HiringRequest;
  onClose: () => void;
  profile: UserProfile;
  viewMode?: 'admin' | 'manager';
  onApprove?: (request: HiringRequest) => void;
  onReject?: (request: HiringRequest) => void;
  onArchive?: (request: HiringRequest) => void;
  onUnarchive?: (request: HiringRequest) => void;
  onEdit?: (request: HiringRequest) => void;
}

export default function ComissionadosTracking({ 
  request, 
  onClose, 
  profile,
  viewMode = 'admin',
  onApprove,
  onReject,
  onArchive,
  onUnarchive,
  onEdit
}: ComissionadosTrackingProps) {
  const [showCaixaSigPad, setShowCaixaSigPad] = useState(false);
  const [showForm3SigPad, setShowForm3SigPad] = useState(false);
  const [loading, setLoading] = useState(false);

  const safeFormat = (dateStr: string | undefined | null, formatStr: string) => {
    if (!dateStr) return '---';
    try {
      const date = parseISO(dateStr);
      if (!isValid(date)) {
        const altDate = new Date(dateStr);
        if (!isValid(altDate)) return '---';
        return format(altDate, formatStr);
      }
      return format(date, formatStr);
    } catch (e) {
      return '---';
    }
  };

  const handleDownloadDoc = async (fileId: string | undefined | null, fileName: string) => {
    if (!fileId) return;
    if (fileId.startsWith('http://') || fileId.startsWith('https://')) {
      window.open(fileId, '_blank');
      return;
    }
    try {
      const loadingToast = toast.loading(`Baixando ${fileName}...`);
      const { data } = await frequencyService.downloadFile(fileId);
      const url = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 100);
      toast.success("Download concluído", { id: loadingToast });
    } catch (err) {
      toast.error("Erro ao baixar documento");
    }
  };

  const handleViewDoc = (fileId: string | undefined | null, fileName: string) => {
    if (!fileId) return;
    if (fileId.startsWith('http://') || fileId.startsWith('https://')) {
      window.open(fileId, '_blank');
      return;
    }
    handleDownloadDoc(fileId, fileName);
  };

  const copyOnboardingLink = () => {
    let baseUrl = window.location.origin + window.location.pathname;
    if (!baseUrl.endsWith('/')) {
      baseUrl += '/';
    }
    const url = `${baseUrl}?sign=${request.id}`;
    navigator.clipboard.writeText(url);
    toast.success('Link de pré-cadastro copiado!');
  };

  const copySupervisorSignLink = () => {
    let baseUrl = window.location.origin + window.location.pathname;
    if (!baseUrl.endsWith('/')) {
      baseUrl += '/';
    }
    const url = `${baseUrl}?signSupervisor=${request.id}`;
    navigator.clipboard.writeText(url);
    toast.success('Link de assinatura do Vereador copiado!');
  };

  const handleSignForm3 = async (signatureDataUrl: string) => {
    setLoading(true);
    try {
      await hiringService.saveSupervisorSignature(request.id, signatureDataUrl);
      toast.success("Formulário 3 assinado com sucesso! Nomeação enviada para a DGEP.");
      setShowForm3SigPad(false);
      if (onApprove) {
        // Trigger dashboard reload
        onApprove({
          ...request,
          status: 'submitted',
          supervisor: {
            ...(request.supervisor || {}),
            signature: signatureDataUrl,
            signedAt: new Date().toISOString()
          } as any
        });
      }
    } catch (err) {
      console.error(err);
      toast.error("Erro ao assinar Formulário 3.");
    } finally {
      setLoading(false);
    }
  };

  const handleSignCaixa = async (signatureDataUrl: string) => {
    setLoading(true);
    try {
      const updatedDetails = {
        ...(request.comissionadoDetails || {}),
        caixaAssinadoDGEP: true,
        caixaAssinadoPor: profile.name || profile.email,
        caixaAssinadoEm: new Date().toISOString()
      };

      const tempRequestObj = {
        ...request,
        comissionadoDetails: updatedDetails
      };

      const caixaDoc = generateCaixaDeclaration(tempRequestObj, profile.name, profile.email, true);
      const caixaBlob = caixaDoc.output('blob');

      const studentName = request.student?.name || 'Comissionado';
      const requestNameAndId = `${studentName}_${request.id}`.replace(/\s+/g, '_');
      const context = {
        module: 'hiring' as const,
        category: 'comissionado' as const,
        lotacao: request.sector || 'Submissoes_Gerais',
        requestNameAndId,
        requestId: request.id,
        userName: request.supervisor?.name
      };

      const cleanServidorName = studentName.trim().replace(/\s+/g, '_');
      const caixaName = `Declaração_Caixa_${cleanServidorName}.pdf`;
      const caixaFile = new File([caixaBlob], caixaName, { type: 'application/pdf' });

      const fileUrl = await frequencyService.uploadFile(caixaFile, `declaracao_caixa`, context);

      const nextDocs = {
        ...(request.documents || {}),
        declaracaoCaixa: {
          fileId: fileUrl,
          name: caixaName
        }
      };

      await hiringService.updateRequest(request.id, {
        comissionadoDetails: updatedDetails,
        documents: nextDocs
      });

      toast.success("Declaração da Caixa assinada e gerada com sucesso!");
      setShowCaixaSigPad(false);
      if (onApprove) {
        onApprove({
          ...request,
          comissionadoDetails: updatedDetails,
          documents: nextDocs
        });
      }
    } catch (err) {
      console.error(err);
      toast.error("Erro ao assinar declaração da Caixa.");
    } finally {
      setLoading(false);
    }
  };

  const getStatusLabel = (status: HiringStatus) => {
    switch (status) {
      case 'draft': return '1. EM PREENCHIMENTO';
      case 'pending': return '2. AGUARDANDO PRÉ-CADASTRO';
      case 'student_signed': return '2. AG. ASSINATURA VEREADOR';
      case 'submitted': return '3. AG. ANÁLISE DGEP';
      case 'approved': return 'APROVADO';
      case 'rejected': return 'DEVOLVIDO';
      case 'archived': return 'ARQUIVADO';
      default: return 'EM PROCESSAMENTO';
    }
  };

  const isHiring = request.type === 'hiring';
  const statusLabel = getStatusLabel(request.status);
  const details = request.comissionadoDetails || {};

  return (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto">
      <div className="p-4 sm:p-8 max-w-5xl mx-auto w-full space-y-6">
        
        {/* Top Header */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-xl bg-white text-slate-400 hover:text-slate-600 shadow-sm border border-slate-200 flex items-center justify-center transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-4 flex-1">
            <div>
              <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">
                {request.type === 'resignation' 
                  ? 'EXONERAÇÃO DE COMISSIONADO' 
                  : 'NOMEAÇÃO DE COMISSIONADO'}
              </h2>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">DGEP - Gestão de Servidores Comissionados</p>
            </div>
            <div className="px-4 py-1.5 bg-[#fff0f4] text-[#ff0044] rounded-full text-[10px] font-black uppercase tracking-widest border border-[#ffe0e6]">
              {statusLabel}
            </div>
            {onEdit && (request.status === 'draft' || request.status === 'rejected') && (
              <button 
                onClick={() => onEdit(request)}
                className="ml-auto text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 shadow-lg bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100"
              >
                <FileText className="w-4 h-4" /> Editar Agora
              </button>
            )}
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[32px] border border-slate-200 shadow-xl overflow-hidden"
        >
          {/* Section Indicator Bar */}
          <div className={`${request.type === 'resignation' ? 'bg-rose-600' : 'bg-[#10b981]'} px-8 py-5 flex items-center gap-3`}>
             <User className="w-5 h-5 text-white/80" />
             <span className="text-xs font-black text-white uppercase tracking-[0.2em]">
               {request.type === 'resignation' ? 'REQUERIMENTO DE EXONERAÇÃO' : 'DETALHES DA SOLICITAÇÃO'}
             </span>
          </div>

          <div className="p-8 sm:p-12 space-y-12">
            
            {/* Action Banner for Vereador Signature */}
            {request.status === 'student_signed' && (
              <div className="bg-amber-50 border border-amber-200 p-6 rounded-3xl space-y-4 animate-pulse-slow">
                 <div className="flex items-center gap-3 text-amber-800">
                    <AlertCircle className="w-5 h-5" />
                    <h4 className="text-[10px] font-black uppercase tracking-widest">AÇÃO REQUERIDA - ASSINATURA DO VEREADOR</h4>
                 </div>
                 <p className="text-sm font-medium text-amber-900 leading-relaxed">
                   O servidor nomeado preencheu seus dados e assinou os formulários. Agora, o Vereador proponente precisa assinar digitalmente a <strong>Declaração de Parentesco (Formulário 3)</strong> para que o processo seja automaticamente enviado à DGEP.
                 </p>
                 <div className="flex flex-wrap gap-3 pt-2">
                   <button 
                     onClick={() => setShowForm3SigPad(true)}
                     className="px-6 py-2.5 bg-slate-950 hover:bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-md"
                   >
                     <Signature className="w-4 h-4 text-emerald-400" /> Assinar Formulário 3 em Tela
                   </button>
                   <button 
                     onClick={copySupervisorSignLink}
                     className="px-6 py-2.5 bg-white border hover:bg-slate-50 text-slate-700 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2"
                   >
                     <Copy className="w-4 h-4" /> Copiar Link de Assinatura do Vereador
                   </button>
                 </div>
              </div>
            )}

            {/* Rejection Reason Alert */}
            {request.status === 'rejected' && request.rejectReason && (
              <div className="bg-red-50 border border-red-100 p-6 rounded-3xl space-y-2">
                 <div className="flex items-center gap-3 text-red-600">
                    <AlertCircle className="w-5 h-5" />
                    <h4 className="text-[10px] font-black uppercase tracking-widest">MOTIVO DA DEVOLUÇÃO</h4>
                 </div>
                 <p className="text-sm font-medium text-red-700 leading-relaxed italic">
                   "{request.rejectReason}"
                 </p>
                 <div className="pt-2 flex items-center gap-2 text-[9px] font-bold text-red-400 uppercase tracking-tight">
                    <span>Devolvido por {request.rejectedBy || 'DGEP'}</span>
                    <span>•</span>
                    <span>{safeFormat(request.rejectedAt, 'dd/MM/yyyy HH:mm')}</span>
                 </div>
              </div>
            )}

            {/* Main Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-350 uppercase tracking-widest ml-1">SETOR / LOTAÇÃO</label>
                <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                  {request.sector} {details.isBloco && <span className="text-xs font-semibold text-blue-600 ml-1">(BLOCO PARLAMENTAR)</span>}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-350 uppercase tracking-widest ml-1">DATA DE REFERÊNCIA</label>
                <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                  {safeFormat(details.dataNomeacao || request.startDate, 'dd / MM / yyyy')}
                </div>
              </div>
            </div>

            {/* Candidate Details */}
            <section className="space-y-6">
              <div className="flex items-center gap-3 text-emerald-600">
                <Briefcase className="w-5 h-5" />
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-emerald-100 pb-1">DADOS DO CARGO E INDICADO</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-350 uppercase tracking-widest ml-1">NOME DO INDICADO</label>
                  <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                    {request.student?.name || '---'}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-350 uppercase tracking-widest ml-1">CPF DO INDICADO</label>
                  <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 font-mono">
                    {request.student?.cpf || '---'}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-350 uppercase tracking-widest ml-1">CARGO DESIGNADO</label>
                  <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                    {details.cargo || '---'}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-350 uppercase tracking-widest ml-1">SÍMBOLO</label>
                  <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                    {details.simbolo ? (details.simbolo.startsWith('CC') ? details.simbolo : 'CC-' + details.simbolo) : '---'}
                  </div>
                </div>
              </div>
            </section>

            {/* Onboarding Info */}
            {isHiring && request.status !== 'draft' && request.status !== 'pending' && (
              <section className="space-y-6 pt-6 border-t">
                <div className="flex items-center gap-3 text-emerald-600">
                  <CheckCircle2 className="w-5 h-5" />
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-emerald-100 pb-1">DADOS PREENCHIDOS NO PRÉ-CADASTRO</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50/50 p-6 rounded-3xl border border-slate-100">
                  <div>
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">RG</span>
                    <span className="text-xs font-bold text-slate-700">{details.rg || '---'} ({details.rgEmissor || '---'} em {details.rgData || '---'})</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">Estado Civil</span>
                    <span className="text-xs font-bold text-slate-700">{details.estadoCivil || '---'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">Nacionalidade / Naturalidade</span>
                    <span className="text-xs font-bold text-slate-700">{details.nacionalidade || '---'} / {details.naturalidade || '---'}</span>
                  </div>
                  <div className="md:col-span-3">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">Endereço Residencial</span>
                    <span className="text-xs font-bold text-slate-700">{details.endereco || '---'}, nº {details.numero || '---'} - {details.bairro || '---'} - {details.cidade || '---'}/{details.uf || '---'} (CEP: {details.cep || '---'})</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">Escolaridade</span>
                    <span className="text-xs font-bold text-slate-700">{details.escolaridade || '---'}</span>
                  </div>
                  <div className="md:col-span-2">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">Formação / Curso</span>
                    <span className="text-xs font-bold text-slate-700">{details.formacao || '---'}</span>
                  </div>
                </div>

                <div className="space-y-4 pt-4">
                  <h4 className="text-xs font-black text-slate-800 uppercase">Resumo das Declarações do Candidato</h4>
                  
                  {/* F3 */}
                  <div className="p-4 bg-white rounded-2xl border flex items-center justify-between gap-4">
                    <div>
                      <h5 className="text-[10px] font-black text-slate-700 uppercase">Formulário 3: Vínculo de Parentesco (Nepotismo)</h5>
                      <p className="text-xs text-slate-500 mt-1">
                        {details.declarouParentesco 
                          ? `Declarou possuir parentesco com ${details.parentesCMC?.length || 0} parentes na CMC.`
                          : 'Declarou NÃO possuir cônjuge, companheiro ou parente até terceiro grau exercendo cargo na CMC.'}
                      </p>
                    </div>
                    <span className={`text-[8px] font-black px-2 py-1 rounded uppercase ${details.declarouParentesco ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'}`}>
                      {details.declarouParentesco ? 'Possui Vínculos' : 'Sem Nepotismo'}
                    </span>
                  </div>

                  {/* F4 */}
                  <div className="p-4 bg-white rounded-2xl border flex items-center justify-between gap-4">
                    <div>
                      <h5 className="text-[10px] font-black text-slate-700 uppercase">Formulário 4: Outra Atividade Remunerada</h5>
                      <p className="text-xs text-slate-500 mt-1">
                        {details.possuiOutroCargo 
                          ? `Exerce outra atividade: ${details.detalhesOutroCargo} (${details.horarioOutroCargo})`
                          : 'Declarou NÃO exercer qualquer outro cargo público ou atividade privada incompatível.'}
                      </p>
                    </div>
                    <span className={`text-[8px] font-black px-2 py-1 rounded uppercase ${details.possuiOutroCargo ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'}`}>
                      {details.possuiOutroCargo ? 'Outro Vínculo' : 'Sem Acúmulo'}
                    </span>
                  </div>

                  {/* F5 */}
                  <div className="p-4 bg-white rounded-2xl border flex items-center justify-between gap-4">
                    <div>
                      <h5 className="text-[10px] font-black text-slate-700 uppercase">Formulário 5: Dependentes IRRF</h5>
                      <p className="text-xs text-slate-500 mt-1">
                        {details.possuiDependentes 
                          ? `Declarou possuir ${details.dependentes?.length || 0} dependentes para deduções fiscais.`
                          : 'Declarou NÃO possuir dependentes legais para dedução de IRRF.'}
                      </p>
                    </div>
                    <span className="text-[8px] font-black px-2 py-1 rounded uppercase bg-blue-50 text-blue-600 border border-blue-100">
                      {details.possuiDependentes ? 'Com Dependentes' : 'Sem Dependentes'}
                    </span>
                  </div>

                  {/* F6 */}
                  <div className="p-4 bg-white rounded-2xl border flex items-center justify-between gap-4">
                    <div>
                      <h5 className="text-[10px] font-black text-slate-700 uppercase">Formulário 6: Impedimento Legal (Idoneidade)</h5>
                      <p className="text-xs text-slate-500 mt-1">
                        {details.declarouImpedimento 
                          ? `Declarou ressalvas: ${details.detalhesImpedimento}`
                          : 'Declarou NÃO possuir impedimentos legais, processos civis ou demissões do serviço público.'}
                      </p>
                    </div>
                    <span className={`text-[8px] font-black px-2 py-1 rounded uppercase ${details.declarouImpedimento ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'}`}>
                      {details.declarouImpedimento ? 'Possui Ressalvas' : 'Ficha Limpa'}
                    </span>
                  </div>
                </div>
              </section>
            )}

            {/* Signature status grid */}
            {isHiring && (
              <div className="bg-white rounded-[40px] border border-slate-100 p-8 sm:p-10 shadow-inner bg-slate-50/30 grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Supervisor/Proponent Signature */}
                <div className="flex flex-col gap-4">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.1em] text-slate-900">PROPONENTE (VEREADOR)</h4>
                  {request.supervisor?.signature ? (
                    <div className="bg-white rounded-[32px] border-2 border-dashed border-slate-105 p-8 relative flex flex-col items-center justify-center min-h-[160px]">
                      <img src={request.supervisor.signature} alt="Proponent Signature" className="max-h-20 object-contain" />
                      <p className="text-[10px] font-black text-slate-700 uppercase mt-4">{request.supervisor.name}</p>
                      <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Assinado em {safeFormat(request.supervisor.signedAt, 'dd/MM/yyyy HH:mm')}</p>
                    </div>
                  ) : (
                    <div className="bg-[#f8f9fc] rounded-[32px] border border-slate-100 p-8 flex flex-col items-center justify-center min-h-[160px] gap-3">
                      <p className="text-[10px] text-slate-400 font-medium">Assinatura do Vereador pendente (F3)</p>
                      {viewMode === 'manager' && request.status === 'student_signed' && (
                        <button 
                          onClick={() => setShowForm3SigPad(true)}
                          className="bg-slate-900 text-white px-4 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center gap-1.5 shadow-sm"
                        >
                          Assinar Agora (F3)
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Candidate Signature */}
                <div className="flex flex-col gap-4">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.1em] text-slate-900">NOMEADO (SERVIDOR)</h4>
                  {request.student?.signature ? (
                    <div className="bg-white rounded-[32px] border-2 border-dashed border-slate-100 p-8 relative flex flex-col items-center justify-center min-h-[160px]">
                      <img src={request.student.signature} alt="Nominee Signature" className="max-h-20 object-contain" />
                      <p className="text-[10px] font-black text-slate-700 uppercase mt-4">{request.student.name}</p>
                      <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Assinado em {safeFormat(request.student.signedAt, 'dd/MM/yyyy HH:mm')}</p>
                    </div>
                  ) : (
                    <div className="bg-[#f8f9fc] rounded-[32px] border border-slate-100 p-8 flex flex-col items-center justify-center min-h-[160px] gap-3">
                      <p className="text-[10px] text-slate-400 font-medium">Aguardando preenchimento e assinatura</p>
                      {viewMode === 'manager' && request.status === 'pending' && (
                        <button 
                          onClick={copyOnboardingLink}
                          className="bg-white text-slate-700 border border-slate-200 px-4 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center gap-1.5 shadow-sm"
                        >
                          Copiar Link Pré-cadastro
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Generated Documents Area */}
            {request.status !== 'draft' && (
              <section className="space-y-6 pt-6 border-t">
                <div className="flex items-center gap-3 text-slate-700">
                  <FileText className="w-5 h-5" />
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-slate-200 pb-1">DOCUMENTOS OFICIAIS GERADOS</h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans">
                  {/* Form 1 */}
                  {request.documents?.form1 && (
                    <div className="p-5 rounded-2xl border bg-slate-50/50 hover:border-slate-350 transition-all flex items-center justify-between gap-4">
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Formulário 1: Indicação de Nomeação</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Documento assinado digitalmente</p>
                      </div>
                      <button 
                        onClick={() => handleViewDoc(request.documents?.form1?.fileId, request.documents?.form1?.name || '')}
                        className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> Ver
                      </button>
                    </div>
                  )}

                  {/* Form 2 */}
                  {request.documents?.form2 && (
                    <div className="p-5 rounded-2xl border bg-slate-50/50 hover:border-slate-350 transition-all flex items-center justify-between gap-4">
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Formulário 2: Dados Cadastrais</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Ficha Cadastral Preenchida</p>
                      </div>
                      <button 
                        onClick={() => handleViewDoc(request.documents?.form2?.fileId, request.documents?.form2?.name || '')}
                        className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> Ver
                      </button>
                    </div>
                  )}

                  {/* Form 3 */}
                  {request.documents?.form3 && (
                    <div className="p-5 rounded-2xl border bg-slate-50/50 hover:border-slate-350 transition-all flex items-center justify-between gap-4">
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Formulário 3: Declaração de Parentesco</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Assinaturas: Servidor e Vereador</p>
                      </div>
                      <button 
                        onClick={() => handleViewDoc(request.documents?.form3?.fileId, request.documents?.form3?.name || '')}
                        className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> Ver
                      </button>
                    </div>
                  )}

                  {/* Form 4 */}
                  {request.documents?.form4 && (
                    <div className="p-5 rounded-2xl border bg-slate-50/50 hover:border-slate-350 transition-all flex items-center justify-between gap-4">
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Formulário 4: Declaração de Atividades</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Declaração de acúmulo de cargos</p>
                      </div>
                      <button 
                        onClick={() => handleViewDoc(request.documents?.form4?.fileId, request.documents?.form4?.name || '')}
                        className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> Ver
                      </button>
                    </div>
                  )}

                  {/* Form 5 */}
                  {request.documents?.form5 && (
                    <div className="p-5 rounded-2xl border bg-slate-50/50 hover:border-slate-350 transition-all flex items-center justify-between gap-4">
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Formulário 5: Dependentes e Família</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Declaração de dependentes IRRF</p>
                      </div>
                      <button 
                        onClick={() => handleViewDoc(request.documents?.form5?.fileId, request.documents?.form5?.name || '')}
                        className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> Ver
                      </button>
                    </div>
                  )}

                  {/* Form 6 */}
                  {request.documents?.form6 && (
                    <div className="p-5 rounded-2xl border bg-slate-50/50 hover:border-slate-350 transition-all flex items-center justify-between gap-4">
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Formulário 6: Ficha de Impedimentos</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Declaração de inexistência de impedimentos</p>
                      </div>
                      <button 
                        onClick={() => handleViewDoc(request.documents?.form6?.fileId, request.documents?.form6?.name || '')}
                        className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> Ver
                      </button>
                    </div>
                  )}

                  {/* Caixa Account Opening */}
                  {isHiring && request.status !== 'pending' && (
                    <div className={`p-5 rounded-2xl border transition-all flex items-center justify-between gap-4 ${details.caixaAssinadoDGEP ? 'bg-emerald-50/20 border-emerald-100' : 'bg-amber-50/20 border-amber-100'}`}>
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Ofício CEF: Abertura de Conta Caixa</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">
                          {details.caixaAssinadoDGEP 
                            ? `Assinado por ${details.caixaAssinadoPor} em ${safeFormat(details.caixaAssinadoEm, 'dd/MM/yyyy')}` 
                            : 'Aguardando assinatura da DGEP'}
                        </p>
                      </div>
                      <div className="flex gap-1.5 font-sans">
                        {details.caixaAssinadoDGEP ? (
                          <button 
                            onClick={() => handleViewDoc(request.documents?.declaracaoCaixa?.fileId, request.documents?.declaracaoCaixa?.name || '')}
                            className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                          >
                            <Eye className="w-3.5 h-3.5" /> Ver
                          </button>
                        ) : (
                          viewMode === 'admin' && (
                            <button 
                              onClick={() => setShowCaixaSigPad(true)}
                              className="px-3 py-2 bg-slate-900 text-white rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-800 shadow-sm"
                            >
                              <Signature className="w-3.5 h-3.5" /> Assinar CEF
                            </button>
                          )
                        )}
                      </div>
                    </div>
                  )}

                  {/* Exoneracao Document */}
                  {request.type === 'resignation' && request.documents?.exoneracao && (
                    <div className="p-5 rounded-2xl border bg-slate-50/50 hover:border-slate-350 transition-all flex items-center justify-between gap-4">
                      <div>
                        <h5 className="text-[10px] font-black text-slate-800 uppercase">Formulário: Indicação de Exoneração</h5>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1">Documento assinado digitalmente</p>
                      </div>
                      <button 
                        onClick={() => handleViewDoc(request.documents?.exoneracao?.fileId, request.documents?.exoneracao?.name || '')}
                        className="px-3 py-2 bg-white text-slate-700 border rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1 hover:bg-slate-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> Ver
                      </button>
                    </div>
                  )}
                </div>
              </section>
            )}

            {/* Validation / Action Buttons for Admin Review */}
            {viewMode === 'admin' && request.status === 'submitted' && (
              <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 mt-8">
                <div>
                  <h4 className="text-xs font-black text-slate-800 uppercase">Avaliação da Diretoria (DGEP)</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">Verifique se as assinaturas e respostas estão em conformidade</p>
                </div>
                <div className="flex gap-3 w-full sm:w-auto">
                  <button 
                    onClick={() => onReject && onReject(request)}
                    className="flex-1 sm:flex-none px-6 py-3 bg-red-50 text-red-600 hover:bg-red-100 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 border border-red-100"
                  >
                    <XCircle className="w-4 h-4" /> Devolver p/ Ajuste
                  </button>
                  <button 
                    onClick={() => onApprove && onApprove(request)}
                    disabled={isHiring && !details.caixaAssinadoDGEP}
                    title={isHiring && !details.caixaAssinadoDGEP ? "Assine o Ofício da Caixa para habilitar a aprovação da nomeação" : ""}
                    className={`flex-1 sm:flex-none px-8 py-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 ${isHiring && !details.caixaAssinadoDGEP ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-100'}`}
                  >
                    <CheckCircle2 className="w-4 h-4" /> Aprovar Nomeação
                  </button>
                </div>
              </div>
            )}
            
            {/* Approved Stamp */}
            {request.status === 'approved' && (
              <div className="bg-emerald-50/50 border border-emerald-200 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4 mt-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center">
                    <ShieldCheck className="w-6 h-6 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900 uppercase">PROCESSO CONCLUÍDO E APROVADO</h4>
                    <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Aprovado por {request.approvedBy || 'RH / DGEP'} em {safeFormat(request.approvedAt, 'dd/MM/yyyy HH:mm')}</p>
                  </div>
                </div>
                {onArchive && (
                  <button 
                    onClick={() => onArchive(request)}
                    className="w-full md:w-auto px-6 py-3 bg-white text-slate-700 border hover:bg-slate-50 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5"
                  >
                    <Archive className="w-4 h-4" /> Arquivar Processo
                  </button>
                )}
              </div>
            )}
            
            {/* Archived Stamp */}
            {request.status === 'archived' && (
              <div className="bg-slate-100 border border-slate-200 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4 mt-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-200 text-slate-500 rounded-2xl flex items-center justify-center">
                    <Archive className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-700 uppercase">PROCESSO ARQUIVADO</h4>
                    <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">Este registro foi arquivado e mantido no histórico permanente</p>
                  </div>
                </div>
                {onUnarchive && (
                  <button 
                    onClick={() => onUnarchive(request)}
                    className="w-full md:w-auto px-6 py-3 bg-white text-slate-700 border hover:bg-slate-50 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5"
                  >
                    <ArrowUpCircle className="w-4 h-4" /> Reativar Requerimento
                  </button>
                )}
              </div>
            )}

          </div>
        </motion.div>
      </div>

      {showCaixaSigPad && (
        <SignaturePad 
          title="Assinatura da CEF - Diretoria de Gestão de Pessoas"
          description="Assine na tela para validar o Ofício de Abertura de Conta na Caixa Econômica Federal."
          onCancel={() => setShowCaixaSigPad(false)}
          onSave={handleSignCaixa}
        />
      )}

      {showForm3SigPad && (
        <SignaturePad 
          title="Assinatura do Vereador - Formulário 3"
          description="Assine na tela para co-assinar a Declaração de Parentesco e enviar o processo à DGEP."
          onCancel={() => setShowForm3SigPad(false)}
          onSave={handleSignForm3}
        />
      )}
    </div>
  );
}
