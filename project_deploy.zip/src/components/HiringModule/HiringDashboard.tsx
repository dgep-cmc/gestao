import React, { useState, useEffect } from "react";
import {
  Plus,
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  Search,
  Filter,
  MoreVertical,
  UserPlus,
  ArrowRight,
  UserCheck,
  AlertCircle,
  Signature,
  Users,
  LayoutGrid,
  Building2,
  Mail,
  ShieldCheck,
  Send,
  Archive,
  ArrowUpDown,
  ChevronUp,
  ChevronDown,
  Eye,
  Edit,
  Trash2,
  UserMinus,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { UserProfile, HiringRequest, HiringStatus } from "../../types";
import { hiringService } from "../../services/hiringService";
import { frequencyService } from "../../services/frequencyService";
import HiringRequestForm from "./HiringRequestForm";
import HiringRequestTracking from "./HiringRequestTracking";

import { format, isValid, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "react-hot-toast";
import { generateHiringPDF, generateKinshipPDF } from "../../lib/pdfGenerator";

interface HiringDashboardProps {
  profile: UserProfile;
  activeTab: string;
  onTabChange: (tab: string) => void;
  viewMode: "manager" | "admin";
  onViewModeChange: (mode: "manager" | "admin") => void;
  selectedSector: string;
  onSelectSector: (sector: string) => void;
}

function RequestCard({
  req,
  onClick,
  onEdit,
  getStatusInfo,
  viewMode,
}: {
  req: HiringRequest;
  onClick: () => void;
  onEdit?: () => void;
  getStatusInfo: (status: HiringStatus) => any;
  viewMode: string;
}) {
  const statusInfo = getStatusInfo(req.status);

  const safeFormat = (
    dateStr: string | undefined | null,
    formatStr: string,
  ) => {
    if (!dateStr) return "---";
    try {
      const date = parseISO(dateStr);
      if (!isValid(date)) {
        const altDate = new Date(dateStr);
        if (!isValid(altDate)) return "---";
        return format(altDate, formatStr);
      }
      return format(date, formatStr);
    } catch (e) {
      return "---";
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden relative flex flex-col h-full group hover:shadow-xl transition-all"
    >
      {/* progress top border */}
      <div className="absolute top-0 left-0 w-full h-1 bg-slate-100 flex">
        <div
          className="h-full bg-blue-500 transition-all duration-500"
          style={{
            width:
              req.status === "approved"
                ? "100%"
                : req.status === "submitted"
                  ? "75%"
                  : req.status === "student_signed" ||
                      req.status === "supervisor_signed"
                    ? "50%"
                    : "25%",
          }}
        ></div>
      </div>

      <div className="p-6 pb-2 mt-2 flex items-start justify-between">
        <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-100">
          <FileText className="w-6 h-6 " />
        </div>

        <div
          className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
            req.status === "rejected"
              ? "bg-[#ff0044] text-white"
              : req.status === "approved"
                ? "bg-emerald-500 text-white"
                : "bg-[#ff0044] text-white" // The red status in image seems to be the default for some stages
          }`}
        >
          {statusInfo.label.toUpperCase()}
        </div>
      </div>

      <div className="px-8 mt-4 flex-1">
        <h3 className="text-xl font-bold text-slate-900 leading-tight mb-2 group-hover:text-blue-600 transition-colors">
          {req.student?.name ||
            (req.type === "resignation"
              ? "RESCISÃO DE ESTÁGIO"
              : "ABERTURA DE VAGA")}
        </h3>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
          {req.level} • {req.course}
        </p>
      </div>

      <div className="px-8 py-6 border-t border-dashed border-slate-100 mt-6 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-400/60">
          <Signature className="w-3.5 h-3.5" />
          <span className="text-[10px] font-bold uppercase tracking-widest">
            Criado em {safeFormat(req.createdAt, "dd/MM/yy")}
          </span>
        </div>
      </div>

      <div className="p-4 px-8 pb-8 flex gap-3">
        <button
          onClick={onClick}
          className="flex-1 bg-[#f8f9fc] hover:bg-slate-100 text-slate-900 py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
        >
          Visualizar <ArrowRight className="w-4 h-4" />
        </button>
        {(req.status === "draft" || req.status === "rejected") &&
          viewMode === "manager" && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onEdit?.();
              }}
              className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center hover:bg-emerald-100 transition-all shrink-0 border border-emerald-100 shadow-sm"
              title="Editar Solicitação"
            >
              <FileText className="w-5 h-5" />
            </button>
          )}
      </div>
    </motion.div>
  );
}

export default function HiringDashboard({
  profile,
  activeTab,
  onTabChange,
  viewMode,
  onViewModeChange,
  selectedSector,
  onSelectSector,
}: HiringDashboardProps) {
  const [dashboardDetailFilter, setDashboardDetailFilter] = useState<
    string | null
  >(null);
  const [requests, setRequests] = useState<HiringRequest[]>([]);
  const [usersCount, setUsersCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showTypeSelector, setShowTypeSelector] = useState(false);
  const [showForm, setShowForm] = useState<HiringRequest | boolean>(false);
  const [trackingRequest, setTrackingRequest] = useState<HiringRequest | null>(
    null,
  );
  const [selectedType, setSelectedType] = useState<
    "hiring" | "opening" | "resignation" | null
  >(null);
  const [listFilter, setListFilter] = useState<
    HiringStatus | "all" | "signatures"
  >("all");
  const [adminListFilter, setAdminListFilter] = useState<"all" | "archived">("all");

  const [rejectingRequest, setRejectingRequest] =
    useState<HiringRequest | null>(null);
  const [deletingRequest, setDeletingRequest] = useState<HiringRequest | null>(
    null,
  );
  const [archivingRequest, setArchivingRequest] =
    useState<HiringRequest | null>(null);
  const [unarchivingRequest, setUnarchivingRequest] =
    useState<HiringRequest | null>(null);
  const [approvingRequest, setApprovingRequest] =
    useState<HiringRequest | null>(null);
  const [rejectReason, setRejectReason] = useState("");

  const safeFormat = (
    dateStr: string | undefined | null,
    formatStr: string,
  ) => {
    if (!dateStr) return "---";
    try {
      const date = parseISO(dateStr);
      if (!isValid(date)) {
        const altDate = new Date(dateStr);
        if (!isValid(altDate)) return "---";
        return format(altDate, formatStr);
      }
      return format(date, formatStr);
    } catch (e) {
      return "---";
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const requestsData =
        profile.role === "master"
          ? await hiringService.getAllRequests()
          : await Promise.all(
              (profile.sectors || []).map((s) =>
                hiringService.getRequestsBySector(s),
              ),
            ).then((res) => res.flat());

      const internsOnly = requestsData.filter(r => r.category !== 'comissionado');

      if (profile.role === "master") {
        const users = await frequencyService.getAllUsers();
        setUsersCount(users.length);
      }

      setRequests(
        internsOnly.sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return (isNaN(dateB) ? 0 : dateB) - (isNaN(dateA) ? 0 : dateA);
        }),
      );
    } catch (error) {
      console.error(error);
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  const [search, setSearch] = useState("");

  // Refined filtering logic
  const modeFilteredRequests =
    viewMode === "admin"
      ? requests.filter((r) => {
          if (r.type === "opening" || r.type === "resignation") {
            // "apenas requerimentos enviados à dgep (vaga ou rescisão)"
            return (
              r.status === "submitted" ||
              r.status === "approved" ||
              r.status === "rejected" ||
              r.status === "archived"
            );
          } else {
            // "contratações já enviadas para assinatura do supervisor e estudante"
            return r.status !== "draft";
          }
        })
      : requests.filter((r) => {
          // Manager view shows everything from their sectors
          const userSectors = profile.sectors || [];
          return userSectors.includes(r.sector);
        });

  const filteredRequests = modeFilteredRequests.filter((r) => {
    if (listFilter === "all") {
      if (viewMode === "admin") {
        if (
          r.status === "draft" ||
          r.status === "pending" ||
          r.status === "student_signed" ||
          r.status === "supervisor_signed" ||
          r.status === "rejected"
        )
          return false;
      }
      return r.status !== "archived";
    } else if (listFilter === "signatures") {
      return (
        r.status === "draft" ||
        r.status === "pending" ||
        r.status === "student_signed" ||
        r.status === "supervisor_signed"
      );
    } else {
      return r.status === listFilter;
    }
  });

  // If sector is selected, filter by sector in the list
  const DisplayBase = selectedSector
    ? filteredRequests.filter((r) => r.sector === selectedSector)
    : filteredRequests;

  const displayRequests = search.trim()
    ? DisplayBase.filter(
        (r) =>
          r.course.toLowerCase().includes(search.toLowerCase()) ||
          r.sector.toLowerCase().includes(search.toLowerCase()) ||
          (r.student?.name || "").toLowerCase().includes(search.toLowerCase()),
      )
    : DisplayBase;

  const stats = {
    total: modeFilteredRequests.length,
    active: modeFilteredRequests.filter((r) => {
      // Logic same as filteredRequests for 'all'
      if (r.status === "archived") return false;
      if (viewMode === "admin") {
        if (r.status === "rejected") return false;
        if (
          r.status === "draft" ||
          r.status === "pending" ||
          r.status === "student_signed" ||
          r.status === "supervisor_signed"
        )
          return false;
      }
      return true;
    }).length,
    drafts: modeFilteredRequests.filter(
      (r) =>
        r.status === "draft" ||
        r.status === "pending" ||
        r.status === "student_signed" ||
        r.status === "supervisor_signed",
    ).length,
    waitingDGP: modeFilteredRequests.filter((r) => r.status === "submitted")
      .length,
    waitingStudent: modeFilteredRequests.filter(
      (r) => r.status === "supervisor_signed",
    ).length,
    approved: modeFilteredRequests.filter((r) => r.status === "approved")
      .length,
    rejected: modeFilteredRequests.filter((r) => r.status === "rejected")
      .length,
    archived: modeFilteredRequests.filter((r) => r.status === "archived")
      .length,
    users: usersCount,
  };

  const getFilteredRequestsForDashboard = () => {
    switch (dashboardDetailFilter) {
      case "TOTAL SOLICITAÇÕES":
        return modeFilteredRequests;
      case "AGUARDANDO DIREÇÃO (DGEP)":
        return modeFilteredRequests.filter((r) => r.status === "submitted");
      case "AGUARDANDO SUPERVISOR":
        return modeFilteredRequests.filter(
          (r) =>
            r.status === "draft" ||
            r.status === "student_signed" ||
            r.status === "pending",
        );
      case "AGUARDANDO ESTUDANTE":
        return modeFilteredRequests.filter(
          (r) => r.status === "supervisor_signed",
        );
      case "CONTRATAÇÕES APROVADAS":
        return modeFilteredRequests.filter((r) => r.status === "approved");
      case "DEVOLVIDOS":
        return modeFilteredRequests.filter((r) => r.status === "rejected");
      default:
        return modeFilteredRequests; // list all automatically
    }
  };

  const dashboardRequests = getFilteredRequestsForDashboard();

  const [allSectors, setAllSectors] = useState<string[]>([]);

  useEffect(() => {
    setTrackingRequest(null);
    setShowForm(false);
    setShowTypeSelector(false);
    setDashboardDetailFilter(null);
    setAdminListFilter("all");
  }, [activeTab, selectedSector, viewMode]);

  useEffect(() => {
    const fetchSectors = async () => {
      if (profile.role === "master") {
        const dashboardStats = await frequencyService.getDashboardStats(
          new Date().getMonth() + 1,
          new Date().getFullYear(),
        );
        setAllSectors((dashboardStats.allSectors as string[]) || []);
      }
    };
    fetchSectors();
  }, [profile]);

  useEffect(() => {
    loadData();
  }, [profile]);

  const getStatusInfo = (status: HiringStatus) => {
    switch (status) {
      case "draft":
        return {
          label: "1. EM PREENCHIMENTO",
          color: "bg-amber-100 text-amber-700",
          icon: <Clock className="w-3 h-3" />,
        };
      case "supervisor_signed":
        return {
          label: "2. AG. ASS. ESTUDANTE",
          color: "bg-blue-100 text-blue-700",
          icon: <Clock className="w-3 h-3" />,
        };
      case "student_signed":
        return {
          label: "2. AG. ASS. SUPERVISOR",
          color: "bg-blue-100 text-blue-700",
          icon: <Clock className="w-3 h-3" />,
        };
      case "submitted":
        return {
          label: "3. AG. DGEP",
          color: "bg-indigo-100 text-indigo-700",
          icon: <Send className="w-3 h-3" />,
        };
      case "approved":
        return {
          label: "APROVADO",
          color: "bg-green-100 text-green-700",
          icon: <CheckCircle2 className="w-3 h-3" />,
        };
      case "rejected":
        return {
          label: "DEVOLVIDO",
          color: "bg-red-100 text-red-700",
          icon: <XCircle className="w-3 h-3" />,
        };
      case "archived":
        return {
          label: "Arquivado",
          color: "bg-slate-200 text-slate-500",
          icon: <Archive className="w-3 h-3" />,
        };
      default:
        return {
          label: "Processando",
          color: "bg-gray-100 text-gray-700",
          icon: <AlertCircle className="w-3 h-3" />,
        };
    }
  };

  const [sortField, setSortField] = useState<
    "student" | "type" | "sector" | "createdAt" | "status" | "signatures"
  >("createdAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  const handleSort = (
    field: "student" | "type" | "sector" | "createdAt" | "status" | "signatures",
  ) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDirection(field === "createdAt" ? "desc" : "asc");
    }
  };

  const renderSortIcon = (
    field: "student" | "type" | "sector" | "createdAt" | "status" | "signatures",
  ) => {
    if (sortField !== field) {
      return (
        <ArrowUpDown className="w-3.5 h-3.5 text-slate-300 opacity-50 group-hover:opacity-100 transition-opacity ml-1.5 shrink-0" />
      );
    }
    return sortDirection === "asc" ? (
      <ChevronUp className="w-3.5 h-3.5 text-blue-600 ml-1.5 shrink-0" />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 text-blue-600 ml-1.5 shrink-0" />
    );
  };

  const sortedRequests = React.useMemo(() => {
    const list = [...displayRequests];
    return list.sort((a, b) => {
      let valA: any = "";
      let valB: any = "";

      if (sortField === "student") {
        valA = (
          a.student?.name ||
          (a.type === "resignation"
            ? "RESCISÃO DE ESTÁGIO"
            : "ABERTURA DE VAGA")
        ).toLowerCase();
        valB = (
          b.student?.name ||
          (b.type === "resignation"
            ? "RESCISÃO DE ESTÁGIO"
            : "ABERTURA DE VAGA")
        ).toLowerCase();
      } else if (sortField === "type") {
        const labels: Record<string, string> = {
          hiring: "Contratação",
          opening: "Abertura de Vaga",
          resignation: "Rescisão",
        };
        valA = (labels[a.type] || a.type || "").toLowerCase();
        valB = (labels[b.type] || b.type || "").toLowerCase();
      } else if (sortField === "sector") {
        valA = (a.sector || "").toLowerCase();
        valB = (b.sector || "").toLowerCase();
      } else if (sortField === "createdAt") {
        valA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        valB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      } else if (sortField === "status") {
        valA = getStatusInfo(a.status).label || "";
        valB = getStatusInfo(b.status).label || "";
      } else if (sortField === "signatures") {
        const isHiringA = a.type === "hiring";
        const scoreA = (a.supervisor?.signature ? 1 : 0) + (isHiringA && a.student?.signature ? 1 : 0);
        const isHiringB = b.type === "hiring";
        const scoreB = (b.supervisor?.signature ? 1 : 0) + (isHiringB && b.student?.signature ? 1 : 0);
        valA = scoreA;
        valB = scoreB;
      }

      if (valA < valB) return sortDirection === "asc" ? -1 : 1;
      if (valA > valB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }, [displayRequests, sortField, sortDirection]);

  const adminDisplayRequests = React.useMemo(() => {
    let baseList = getFilteredRequestsForDashboard();
    
    // Apply Active vs Archived filter for Admin view
    if (adminListFilter === "all") {
      baseList = baseList.filter((r) => r.status !== "archived");
    } else if (adminListFilter === "archived") {
      baseList = baseList.filter((r) => r.status === "archived");
    }

    if (!search.trim()) return baseList;
    return baseList.filter(
      (r) =>
        r.course.toLowerCase().includes(search.toLowerCase()) ||
        r.sector.toLowerCase().includes(search.toLowerCase()) ||
        (r.student?.name || "").toLowerCase().includes(search.toLowerCase()),
    );
  }, [dashboardDetailFilter, modeFilteredRequests, search, adminListFilter]);

  const sortedAdminRequests = React.useMemo(() => {
    const list = [...adminDisplayRequests];
    return list.sort((a, b) => {
      let valA: any = "";
      let valB: any = "";

      if (sortField === "student") {
        valA = (
          a.student?.name ||
          (a.type === "resignation"
            ? "RESCISÃO DE ESTÁGIO"
            : "ABERTURA DE VAGA")
        ).toLowerCase();
        valB = (
          b.student?.name ||
          (b.type === "resignation"
            ? "RESCISÃO DE ESTÁGIO"
            : "ABERTURA DE VAGA")
        ).toLowerCase();
      } else if (sortField === "type") {
        const labels: Record<string, string> = {
          hiring: "Contratação",
          opening: "Abertura de Vaga",
          resignation: "Rescisão",
        };
        valA = (labels[a.type] || a.type || "").toLowerCase();
        valB = (labels[b.type] || b.type || "").toLowerCase();
      } else if (sortField === "sector") {
        valA = (a.sector || "").toLowerCase();
        valB = (b.sector || "").toLowerCase();
      } else if (sortField === "createdAt") {
        valA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        valB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      } else if (sortField === "status") {
        valA = getStatusInfo(a.status).label || "";
        valB = getStatusInfo(b.status).label || "";
      } else if (sortField === "signatures") {
        const isHiringA = a.type === "hiring";
        const scoreA = (a.supervisor?.signature ? 1 : 0) + (isHiringA && a.student?.signature ? 1 : 0);
        const isHiringB = b.type === "hiring";
        const scoreB = (b.supervisor?.signature ? 1 : 0) + (isHiringB && b.student?.signature ? 1 : 0);
        valA = scoreA;
        valB = scoreB;
      }

      if (valA < valB) return sortDirection === "asc" ? -1 : 1;
      if (valA > valB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }, [adminDisplayRequests, sortField, sortDirection]);

  const handleApprove = async () => {
    if (!approvingRequest) return;
    try {
      await hiringService.updateStatus(approvingRequest.id, "approved", {
        approvedBy: profile.email,
        approvedAt: new Date().toISOString(),
      });
      toast.success("Solicitação aprovada com sucesso!");
      setApprovingRequest(null);
      setTrackingRequest(null);
      loadData();
    } catch (error) {
      toast.error("Erro ao aprovar");
    }
  };

  const handleReject = async () => {
    if (!rejectingRequest || !rejectReason) return;
    try {
      await hiringService.updateStatus(rejectingRequest.id, "rejected", {
        rejectReason: rejectReason,
        rejectedBy: profile.email,
        rejectedAt: new Date().toISOString(),
        // Clear signatures to allow re-signing
        "supervisor.signature": null,
        "supervisor.signedAt": null,
        "student.signature": null,
        "student.signedAt": null,
      });
      toast.success("Solicitação devolvida para ajustes.");
      setRejectingRequest(null);
      setTrackingRequest(null);
      setRejectReason("");
      await loadData();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao devolver");
    }
  };

  const handleArchive = async () => {
    if (!archivingRequest) return;
    try {
      await hiringService.updateStatus(archivingRequest.id, "archived", {
        previousStatus: archivingRequest.status
      });
      toast.success("Solicitação arquivada.");
      setArchivingRequest(null);
      setTrackingRequest(null);
      await loadData();
    } catch (error) {
      toast.error("Erro ao arquivar");
    }
  };

  const handleUnarchive = async () => {
    if (!unarchivingRequest) return;
    try {
      const fallbackStatus: HiringStatus = "submitted";
      const targetStatus = unarchivingRequest.previousStatus || 
        (unarchivingRequest.approvedAt ? "approved" : 
         unarchivingRequest.rejectReason ? "rejected" : fallbackStatus);
         
      await hiringService.updateStatus(unarchivingRequest.id, targetStatus, {
        previousStatus: null
      });
      toast.success("Solicitação desarquivada com sucesso.");
      setUnarchivingRequest(null);
      setTrackingRequest(null);
      await loadData();
    } catch (error) {
      toast.error("Erro ao desarquivar");
    }
  };

  const handleDeleteDraft = async () => {
    if (!deletingRequest) return;
    try {
      await hiringService.deleteRequest(deletingRequest.id);
      toast.success("Solicitação excluída com sucesso.");
      setDeletingRequest(null);
      loadData();
    } catch (error) {
      toast.error("Erro ao excluir solicitação");
    }
  };

  const copyLink = (role: "supervisor" | "student", reqId: string) => {
    let baseUrl = window.location.origin + window.location.pathname;
    if (!baseUrl.endsWith("/")) {
      baseUrl += "/";
    }
    const url =
      role === "supervisor"
        ? `${baseUrl}?signSupervisor=${reqId}`
        : `${baseUrl}?sign=${reqId}`;
    navigator.clipboard.writeText(url);
    toast.success("Link copiado!");
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-white">
      <AnimatePresence mode="wait">
        {trackingRequest ? (
          <motion.div
            key="hiring-tracking"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col"
          >
            <HiringRequestTracking
              request={trackingRequest}
              profile={profile}
              viewMode={viewMode}
              onClose={() => setTrackingRequest(null)}
              onApprove={setApprovingRequest}
              onReject={setRejectingRequest}
              onArchive={setArchivingRequest}
              onUnarchive={setUnarchivingRequest}
              onEdit={
                viewMode === "manager"
                  ? (req) => {
                      setShowForm(req);
                      setTrackingRequest(null);
                    }
                  : undefined
              }
            />
            {/* Optional Edit button for drafts/rejected */}
            {(trackingRequest.status === "draft" ||
              trackingRequest.status === "rejected") &&
              viewMode === "manager" && (
                <div className="bg-white p-6 sm:px-12 border-t border-slate-100 flex items-center justify-between gap-4">
                  <div className="hidden sm:block">
                    <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest">
                      Ações Disponíveis
                    </p>
                    <p className="text-[9px] text-slate-400 font-bold uppercase">
                      Esta solicitação pode ser alterada e reenviada
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setShowForm(trackingRequest);
                      setTrackingRequest(null);
                    }}
                    className="flex-1 sm:flex-initial bg-emerald-600 text-white px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-700 transition-all flex items-center justify-center gap-3 shadow-xl shadow-emerald-100 ring-4 ring-emerald-50"
                  >
                    <FileText className="w-5 h-5" /> Editar e Corrigir
                    Requerimento
                  </button>
                </div>
              )}
          </motion.div>
        ) : showForm ? (
          <motion.div
            key="hiring-form"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col"
          >
            <HiringRequestForm
              profile={profile}
              onClose={() => {
                setShowForm(false);
                setSelectedType(null);
              }}
              initialData={typeof showForm === "object" ? showForm : undefined}
              initialType={selectedType}
              selectedSector={selectedSector}
              onSuccess={() => {
                setShowForm(false);
                setSelectedType(null);
                loadData();
              }}
            />
          </motion.div>
        ) : (
          <div className="flex-1 flex flex-col">
            {/* Header */}
            <header className="bg-white border-b border-slate-200 p-4 sm:px-8 sm:py-0 sm:h-[84px] flex flex-col sm:flex-row items-center justify-between sticky top-0 z-10 shrink-0 gap-4 shadow-sm">
              <div className="flex items-center gap-4 sm:gap-8 overflow-x-hidden">
                <div className="min-w-0">
                  <div className="flex items-center gap-3">
                    <h2 className="text-xl font-bold text-slate-800 tracking-tight truncate">
                      Portal de Estágios
                    </h2>
                    <span
                      className={`px-2 py-0.5 ${viewMode === "admin" ? "bg-indigo-100 text-indigo-700 ring-indigo-200" : "bg-emerald-100 text-emerald-700 ring-emerald-200"} text-[9px] font-black uppercase rounded tracking-wider ring-1 shrink-0`}
                    >
                      {viewMode === "admin"
                        ? "GESTÃO CENTRAL"
                        : "GESTÃO UNIDADE"}
                    </span>
                  </div>
                  <p className="text-sm font-bold text-blue-600 uppercase tracking-tighter opacity-80 mt-1">
                    {viewMode === "admin"
                      ? "Requerimentos de Contratação"
                      : "Gestão de Vagas e Contratos"}
                  </p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                {viewMode === "manager" && (
                  <>
                    <button
                      onClick={() => {
                        setSelectedType("hiring");
                        setShowForm(true);
                        setShowTypeSelector(false);
                      }}
                      className="w-full sm:w-auto justify-center bg-emerald-600 shadow-emerald-100/50 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2 group active:scale-[0.98] cursor-pointer"
                    >
                      <UserCheck className="w-4 h-4" /> Nova Contratação
                    </button>
                    <button
                      onClick={() => {
                        setSelectedType("opening");
                        setShowForm(true);
                        setShowTypeSelector(false);
                      }}
                      className="w-full sm:w-auto justify-center bg-blue-600 shadow-blue-100/50 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2 group active:scale-[0.98] cursor-pointer"
                    >
                      <Plus className="w-4 h-4" /> Abertura de Vaga
                    </button>
                    <button
                      onClick={() => {
                        setSelectedType("resignation");
                        setShowForm(true);
                        setShowTypeSelector(false);
                      }}
                      className="w-full sm:w-auto justify-center bg-rose-600 shadow-rose-100/50 hover:bg-rose-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2 group active:scale-[0.98] cursor-pointer"
                    >
                      <UserMinus className="w-4 h-4" /> Rescisão
                    </button>
                  </>
                )}
              </div>
            </header>

            <main className="flex-1 p-4 sm:p-8 bg-slate-50/30 custom-scrollbar">
              <AnimatePresence mode="wait">
                {activeTab === "stats" && (
                  <motion.div
                    key="stats"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="max-w-7xl mx-auto space-y-8"
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                      <StatusCard
                        label="TOTAL SOLICITAÇÕES"
                        value={stats.total}
                        icon={<UserCheck className="w-5 h-5" />}
                        active={dashboardDetailFilter === "TOTAL SOLICITAÇÕES"}
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "TOTAL SOLICITAÇÕES"
                              ? null
                              : "TOTAL SOLICITAÇÕES",
                          )
                        }
                        color="bg-indigo-500"
                      />
                      <StatusCard
                        label="AGUARDANDO DIREÇÃO (DGEP)"
                        value={stats.waitingDGP}
                        icon={<FileText className="w-5 h-5" />}
                        active={
                          dashboardDetailFilter === "AGUARDANDO DIREÇÃO (DGEP)"
                        }
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter ===
                              "AGUARDANDO DIREÇÃO (DGEP)"
                              ? null
                              : "AGUARDANDO DIREÇÃO (DGEP)",
                          )
                        }
                        color="bg-orange-500"
                      />
                      <StatusCard
                        label="AGUARDANDO SUPERVISOR"
                        value={stats.drafts}
                        icon={<Clock className="w-5 h-5" />}
                        active={
                          dashboardDetailFilter === "AGUARDANDO SUPERVISOR"
                        }
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "AGUARDANDO SUPERVISOR"
                              ? null
                              : "AGUARDANDO SUPERVISOR",
                          )
                        }
                        color="bg-amber-500"
                      />
                      <StatusCard
                        label="AGUARDANDO ESTUDANTE"
                        value={stats.waitingStudent}
                        icon={<Signature className="w-5 h-5" />}
                        active={
                          dashboardDetailFilter === "AGUARDANDO ESTUDANTE"
                        }
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "AGUARDANDO ESTUDANTE"
                              ? null
                              : "AGUARDANDO ESTUDANTE",
                          )
                        }
                        color="bg-blue-500"
                      />
                      <StatusCard
                        label="CONTRATAÇÕES APROVADAS"
                        value={stats.approved}
                        icon={<CheckCircle2 className="w-5 h-5" />}
                        active={
                          dashboardDetailFilter === "CONTRATAÇÕES APROVADAS"
                        }
                        onClick={() =>
                          setDashboardDetailFilter(
                            dashboardDetailFilter === "CONTRATAÇÕES APROVADAS"
                              ? null
                              : "CONTRATAÇÕES APROVADAS",
                          )
                        }
                        color="bg-emerald-500"
                        className="col-span-2 sm:col-span-1"
                      />
                    </div>

                    {/* Integrated Requirement Management Section */}
                    <div className="bg-white rounded-[32px] border border-slate-200/80 shadow-sm p-5 sm:p-8 space-y-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-1.5 h-6 rounded-full animate-pulse ${
                              dashboardDetailFilter
                                ? "bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.4)]"
                                : "bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.4)]"
                            }`}
                          />
                          <div>
                            <h3 className="text-base font-black text-slate-800 uppercase tracking-wider">
                              {dashboardDetailFilter
                                ? `Filtrado por: ${dashboardDetailFilter}`
                                : "Todos os Requerimentos"}
                            </h3>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                              {dashboardDetailFilter
                                ? `Exibindo apenas registros que correspondem ao filtro selecionado`
                                : "Listagem completa de todos os requerimentos do sistema"}
                            </p>
                          </div>
                        </div>

                        <div className="flex flex-row items-center gap-2 sm:gap-3 w-full md:w-auto">
                          {dashboardDetailFilter && (
                            <button
                              onClick={() => setDashboardDetailFilter(null)}
                              className="text-[10px] font-black text-slate-400 hover:text-red-500 transition-colors uppercase tracking-widest flex items-center gap-1.5 border border-slate-100 rounded-xl px-2.5 py-2 bg-slate-50/50 hover:bg-slate-50 cursor-pointer whitespace-nowrap shrink-0"
                            >
                              <XCircle className="w-3.5 h-3.5" /> Limpar
                            </button>
                          )}
                          <div className="relative w-full md:max-w-xs">
                            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input
                              type="text"
                              placeholder="Buscar solicitações..."
                              value={search}
                              onChange={(e) => setSearch(e.target.value)}
                              className="w-full bg-slate-50/50 border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-xs font-bold focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Active vs Archived Division Tabs for Admin */}
                      <div className="flex overflow-x-auto bg-slate-100/50 p-1 rounded-2xl border border-slate-100 w-fit shrink-0 custom-scrollbar no-scrollbar">
                        <TabButton
                          active={adminListFilter === "all"}
                          onClick={() => setAdminListFilter("all")}
                          label="Ativos"
                          count={modeFilteredRequests.filter((r) => r.status !== "archived").length}
                        />
                        <TabButton
                          active={adminListFilter === "archived"}
                          onClick={() => setAdminListFilter("archived")}
                          label="Arquivados"
                          count={modeFilteredRequests.filter((r) => r.status === "archived").length}
                        />
                      </div>

                      {/* Tabela de Requerimentos - Desktop */}
                      <div className="hidden md:block overflow-x-auto ring-1 ring-slate-100 rounded-2xl">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50/50 border-b border-slate-100">
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("type")}
                              >
                                <div className="flex items-center">
                                  Tipo
                                  {renderSortIcon("type")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("student")}
                              >
                                <div className="flex items-center">
                                  Estudante / Vaga
                                  {renderSortIcon("student")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("sector")}
                              >
                                <div className="flex items-center">
                                  Lotação / Setor
                                  {renderSortIcon("sector")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("createdAt")}
                              >
                                <div className="flex items-center">
                                  Data Criação
                                  {renderSortIcon("createdAt")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("signatures")}
                              >
                                <div className="flex items-center">
                                  Assinaturas
                                  {renderSortIcon("signatures")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("status")}
                              >
                                <div className="flex items-center">
                                  Status
                                  {renderSortIcon("status")}
                                </div>
                              </th>
                              <th className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">
                                Ações
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {loading ? (
                              <tr>
                                <td colSpan={7} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-3 justify-center">
                                    <div className="w-8 h-8 border-3 border-blue-600/20 border-t-blue-600 rounded-full animate-spin"></div>
                                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                                      Carregando...
                                    </p>
                                  </div>
                                </td>
                              </tr>
                            ) : sortedAdminRequests.length === 0 ? (
                              <tr>
                                <td colSpan={7} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-4 opacity-40 justify-center">
                                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                                      <FileText className="w-8 h-8 text-slate-300" />
                                    </div>
                                    <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">
                                      Nenhuma solicitação encontrada
                                    </p>
                                  </div>
                                </td>
                              </tr>
                            ) : (
                              sortedAdminRequests.map((req) => {
                                const statusInfo = getStatusInfo(req.status);
                                const isHiring = req.type === "hiring";
                                const hasSupervisorSig =
                                  !!req.supervisor.signature;
                                const hasStudentSig =
                                  !isHiring || !!req.student?.signature;
                                const isSignaturesComplete =
                                  req.type === "hiring"
                                    ? hasSupervisorSig && hasStudentSig
                                    : true;

                                return (
                                  <tr
                                    key={req.id}
                                    className="hover:bg-slate-50/20 transition-colors"
                                  >
                                    {/* Tipo */}
                                    <td className="px-4 py-3 whitespace-nowrap overflow-visible">
                                      <span
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[8px] font-black uppercase ${
                                          req.type === "hiring"
                                            ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"
                                            : req.type === "resignation"
                                              ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100"
                                              : "bg-blue-50 text-blue-700 ring-1 ring-blue-100"
                                        }`}
                                      >
                                        {req.type === "hiring" ? (
                                          <>
                                            <UserCheck className="w-3 h-3" />
                                            CONTRATO
                                          </>
                                        ) : req.type === "resignation" ? (
                                          <>
                                            <UserMinus className="w-3 h-3" />
                                            RESCISÃO
                                          </>
                                        ) : (
                                          <>
                                            <Search className="w-3 h-3" />
                                            VAGA
                                          </>
                                        )}
                                      </span>
                                    </td>

                                    {/* Estudante / Vaga */}
                                    <td className="px-4 py-3 max-w-xs">
                                      <p
                                        className="text-xs font-bold text-slate-900 whitespace-normal break-words leading-tight hover:text-blue-600 cursor-pointer transition-colors"
                                        onClick={() => setTrackingRequest(req)}
                                      >
                                        {req.student?.name ||
                                          (req.type === "resignation"
                                            ? "RESCISÃO DE ESTÁGIO"
                                            : "ABERTURA DE VAGA")}
                                      </p>
                                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wide whitespace-normal mt-0.5">
                                        {req.level} • {req.course}
                                      </p>
                                    </td>

                                    {/* Setor */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <p className="text-xs font-bold text-slate-700 uppercase tracking-tight">
                                        {req.sector}
                                      </p>
                                    </td>

                                    {/* Data Criação */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <p className="text-xs font-semibold text-slate-500 tabular-nums">
                                        {safeFormat(
                                          req.createdAt,
                                          "dd/MM/yyyy",
                                        )}
                                      </p>
                                    </td>

                                    {/* Assinaturas */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      {isHiring ? (
                                        <div className="flex items-center gap-3">
                                          {/* Supervisor */}
                                          <div
                                            className="flex items-center gap-1"
                                            title={
                                              hasSupervisorSig
                                                ? `Supervisor assinou em ${safeFormat(req.supervisor.signedAt, "dd/MM/yy HH:mm")}`
                                                : "Assinatura Supervisor pendente"
                                            }
                                          >
                                            <div
                                              className={`p-0.5 rounded ${hasSupervisorSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                            >
                                              <Building2 className="w-3 h-3" />
                                            </div>
                                            <span
                                              className={`text-[8px] font-black uppercase ${hasSupervisorSig ? "text-emerald-600" : "text-amber-500"}`}
                                            >
                                              {hasSupervisorSig ? "OK" : "PEND"}
                                            </span>
                                          </div>

                                          {/* Estudante */}
                                          <div
                                            className="flex items-center gap-1"
                                            title={
                                              hasStudentSig
                                                ? `Estudante assinou em ${safeFormat(req.student?.signedAt, "dd/MM/yy HH:mm")}`
                                                : "Assinatura Estudante pendente"
                                            }
                                          >
                                            <div
                                              className={`p-0.5 rounded ${hasStudentSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                            >
                                              <UserPlus className="w-3 h-3" />
                                            </div>
                                            <span
                                              className={`text-[8px] font-black uppercase ${hasStudentSig ? "text-emerald-600" : "text-amber-500"}`}
                                            >
                                              {hasStudentSig ? "OK" : "PEND"}
                                            </span>
                                          </div>
                                        </div>
                                      ) : (
                                        <span className="text-[10px] text-slate-400 font-bold uppercase">
                                          N/A
                                        </span>
                                      )}
                                    </td>

                                    {/* Status */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <span
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] font-black uppercase ${statusInfo.color}`}
                                      >
                                        {statusInfo.icon}
                                        {statusInfo.label}
                                      </span>
                                    </td>

                                    {/* Ações */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <div className="flex items-center justify-center gap-1">
                                        {/* Visualizar */}
                                        <button
                                          onClick={() =>
                                            setTrackingRequest(req)
                                          }
                                          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
                                          title="Visualizar em Tela"
                                        >
                                          <Eye className="w-3.5 h-3.5" />
                                        </button>

                                        {/* Download Requerimento */}
                                        <button
                                          onClick={() => {
  if (req.documents?.requerimento?.fileId) {
    window.open(req.documents.requerimento.fileId, "_blank");
  } else {
    generateHiringPDF(req);
  }
}}
                                          className="p-1.5 text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
                                          title="Baixar Requerimento PDF"
                                        >
                                          <FileText className="w-3.5 h-3.5" />
                                        </button>

                                        {/* Download Declaração (if hiring) */}
                                        {isHiring && (
                                          <button
                                            onClick={() => {
  if (req.documents?.parentesco?.fileId) {
    window.open(req.documents.parentesco.fileId, "_blank");
  } else {
    generateKinshipPDF(req);
  }
}}
                                            className="p-1.5 text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
                                            title="Baixar Declaração Parentesco PDF"
                                          >
                                            <Signature className="w-3.5 h-3.5" />
                                          </button>
                                        )}

                                        {/* Admin/Manager specific quick actions */}
                                        {(profile.role === "master" ||
                                          profile.role === "manager") && (
                                          <>
                                            <div className="h-4 w-px bg-slate-200 mx-0.5 align-middle self-center"></div>

                                            {viewMode === "admin" && (
                                              <>
                                                {/* Aprovar */}
                                                <button
                                                  onClick={() =>
                                                    setApprovingRequest(req)
                                                  }
                                                  disabled={
                                                    req.status === "approved" ||
                                                    req.status === "archived" ||
                                                    !isSignaturesComplete
                                                  }
                                                  className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-all disabled:opacity-30 disabled:bg-transparent cursor-pointer"
                                                  title={
                                                    req.status === "approved"
                                                      ? "Já aprovado"
                                                      : !isSignaturesComplete
                                                        ? "Aguardando assinaturas necessárias para habilitar a aprovação"
                                                        : "Aprovar e Validar Requerimento"
                                                  }
                                                >
                                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                                </button>

                                                {/* Devolver */}
                                                <button
                                                  onClick={() =>
                                                    setRejectingRequest(req)
                                                  }
                                                  disabled={
                                                    req.status === "approved" ||
                                                    req.status === "archived" ||
                                                    req.status === "rejected" ||
                                                    req.status === "draft"
                                                  }
                                                  className="p-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-all disabled:opacity-30 disabled:bg-transparent cursor-pointer"
                                                  title={
                                                    req.status === "approved"
                                                      ? "Não pode devolver após aprovação"
                                                      : req.status ===
                                                            "draft" ||
                                                          req.status ===
                                                            "rejected"
                                                        ? "Ainda sob ajuste ou em rascunho"
                                                        : "Devolver para Ajustes"
                                                  }
                                                >
                                                  <XCircle className="w-3.5 h-3.5" />
                                                </button>
                                              </>
                                            )}

                                            {/* Arquivar / Desarquivar */}
                                            {req.status === "archived" ? (
                                              <button
                                                onClick={() => setUnarchivingRequest(req)}
                                                className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
                                                title="Desarquivar Solicitação"
                                              >
                                                <Archive className="w-3.5 h-3.5 rotate-180" />
                                              </button>
                                            ) : (
                                              <button
                                                onClick={() => setArchivingRequest(req)}
                                                className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
                                                title="Arquivar Solicitação"
                                              >
                                                <Archive className="w-3.5 h-3.5" />
                                              </button>
                                            )}
                                          </>
                                        )}
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>

                      {/* Lista de Requerimentos - Mobile */}
                      <div className="block md:hidden grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {loading ? (
                          <div className="col-span-full py-20 text-center">
                            <div className="flex flex-col items-center gap-3 justify-center">
                              <div className="w-8 h-8 border-3 border-blue-600/20 border-t-blue-600 rounded-full animate-spin"></div>
                              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest block">
                                Carregando...
                              </p>
                            </div>
                          </div>
                        ) : sortedAdminRequests.length === 0 ? (
                          <div className="col-span-full py-20 text-center">
                            <div className="flex flex-col items-center gap-4 opacity-40 justify-center">
                              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                                <FileText className="w-8 h-8 text-slate-300" />
                              </div>
                              <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">
                                Nenhuma solicitação encontrada
                              </p>
                            </div>
                          </div>
                        ) : (
                          sortedAdminRequests.map((req) => {
                            const statusInfo = getStatusInfo(req.status);
                            const isHiring = req.type === "hiring";
                            const hasSupervisorSig = !!req.supervisor.signature;
                            const hasStudentSig =
                              !isHiring || !!req.student?.signature;
                            const isSignaturesComplete =
                              req.type === "hiring"
                                ? hasSupervisorSig && hasStudentSig
                                : true;

                            return (
                              <div
                                key={req.id}
                                className="p-3.5 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-2.5 hover:border-blue-200 transition-colors"
                              >
                                <div className="flex items-start justify-between gap-3">
                                  <div className="space-y-1 min-w-0">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-wider ${
                                          req.type === "hiring"
                                            ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"
                                            : req.type === "resignation"
                                              ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100"
                                              : "bg-blue-50 text-blue-700 ring-1 ring-blue-100"
                                        }`}
                                      >
                                        {req.type === "hiring"
                                          ? "CONTRATO"
                                          : req.type === "resignation"
                                            ? "RESCISÃO"
                                            : "VAGA"}
                                      </span>
                                      <span className="text-[10px] text-slate-400 font-bold">
                                        {safeFormat(
                                          req.createdAt,
                                          "dd/MM/yyyy",
                                        )}
                                      </span>
                                    </div>
                                    <p
                                      className="text-xs sm:text-sm font-black text-slate-900 leading-snug hover:text-blue-600 transition-colors cursor-pointer truncate"
                                      onClick={() => setTrackingRequest(req)}
                                    >
                                      {req.student?.name ||
                                        (req.type === "resignation"
                                          ? "RESCISÃO DE ESTÁGIO"
                                          : "ABERTURA DE VAGA")}
                                    </p>
                                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider truncate">
                                      {req.level} • {req.course}
                                    </p>
                                  </div>

                                  <span
                                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] font-black uppercase shrink-0 ${statusInfo.color}`}
                                  >
                                    {statusInfo.icon}
                                    {statusInfo.label}
                                  </span>
                                </div>

                                <div className="grid grid-cols-2 gap-3 text-xs border-y border-slate-100 py-2">
                                  <div className="min-w-0">
                                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-wider">
                                      Setor / Lotação
                                    </p>
                                    <p className="font-bold text-slate-700 truncate uppercase mt-0.5">
                                      {req.sector}
                                    </p>
                                  </div>
                                  <div>
                                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-wider">
                                      Assinaturas
                                    </p>
                                    {isHiring ? (
                                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                                        <div
                                          className="flex items-center gap-1"
                                          title="Supervisor"
                                        >
                                          <div
                                            className={`p-0.5 rounded ${hasSupervisorSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                          >
                                            <Building2 className="w-2.5 h-2.5" />
                                          </div>
                                          <span
                                            className={`text-[8px] font-bold ${hasSupervisorSig ? "text-emerald-600" : "text-amber-500"}`}
                                          >
                                            Sup:{" "}
                                            {hasSupervisorSig ? "OK" : "PEND"}
                                          </span>
                                        </div>
                                        <div
                                          className="flex items-center gap-1"
                                          title="Estudante"
                                        >
                                          <div
                                            className={`p-0.5 rounded ${hasStudentSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                          >
                                            <UserPlus className="w-2.5 h-2.5" />
                                          </div>
                                          <span
                                            className={`text-[8px] font-bold ${hasStudentSig ? "text-emerald-600" : "text-amber-500"}`}
                                          >
                                            Est: {hasStudentSig ? "OK" : "PEND"}
                                          </span>
                                        </div>
                                      </div>
                                    ) : (
                                      <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">
                                        N/A
                                      </p>
                                    )}
                                  </div>
                                </div>

                                <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                                  <div className="flex items-center gap-1 border-slate-50">
                                    <button
                                      onClick={() => setTrackingRequest(req)}
                                      className="p-1.5 sm:p-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl transition-all flex items-center justify-center gap-1 text-[9px] font-black uppercase tracking-wider"
                                    >
                                      <Eye className="w-3.5 h-3.5" /> Ver
                                    </button>
                                    <button
                                      onClick={() => {
  if (req.documents?.requerimento?.fileId) {
    window.open(req.documents.requerimento.fileId, "_blank");
  } else {
    generateHiringPDF(req);
  }
}}
                                      className="p-1.5 sm:p-2 bg-blue-50/50 hover:bg-blue-50 text-blue-700 rounded-xl transition-all flex items-center justify-center gap-1 text-[9px] font-black uppercase tracking-wider"
                                    >
                                      <FileText className="w-3.5 h-3.5" /> Ficha
                                    </button>
                                    {isHiring && (
                                      <button
                                        onClick={() => {
  if (req.documents?.parentesco?.fileId) {
    window.open(req.documents.parentesco.fileId, "_blank");
  } else {
    generateKinshipPDF(req);
  }
}}
                                        className="p-1.5 sm:p-2 bg-blue-50/50 hover:bg-blue-50 text-blue-700 rounded-xl transition-all flex items-center justify-center gap-1 text-[9px] font-black uppercase tracking-wider"
                                      >
                                        <Signature className="w-3.5 h-3.5" />{" "}
                                        Parentesco
                                      </button>
                                    )}
                                  </div>

                                  {profile.role === "master" && (
                                    <div className="flex items-center gap-1">
                                      <button
                                        onClick={() => setApprovingRequest(req)}
                                        disabled={
                                          req.status === "approved" ||
                                          req.status === "archived" ||
                                          !isSignaturesComplete
                                        }
                                        className="p-2 text-emerald-600 bg-emerald-50/50 hover:bg-emerald-100 disabled:opacity-30 rounded-xl transition-all"
                                        title="Aprovar"
                                      >
                                        <CheckCircle2 className="w-4 h-4" />
                                      </button>
                                      <button
                                        onClick={() => setRejectingRequest(req)}
                                        disabled={
                                          req.status === "approved" ||
                                          req.status === "archived" ||
                                          req.status === "rejected" ||
                                          req.status === "draft"
                                        }
                                        className="p-2 text-red-600 bg-rose-50/50 hover:bg-rose-100 disabled:opacity-30 rounded-xl transition-all"
                                        title="Devolver"
                                      >
                                        <XCircle className="w-4 h-4" />
                                      </button>
                                      {req.status === "archived" ? (
                                        <button
                                          onClick={() => setUnarchivingRequest(req)}
                                          className="p-2 text-blue-600 bg-blue-50/50 hover:bg-blue-100 rounded-xl transition-all cursor-pointer"
                                          title="Desarquivar"
                                        >
                                          <Archive className="w-4 h-4 rotate-180" />
                                        </button>
                                      ) : (
                                        <button
                                          onClick={() => setArchivingRequest(req)}
                                          className="p-2 text-slate-500 bg-slate-50 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                                          title="Arquivar"
                                        >
                                          <Archive className="w-4 h-4" />
                                        </button>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === "requests" && (
                  <motion.div
                    key="requests"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="max-w-7xl mx-auto space-y-6"
                  >
                    {viewMode === "manager" && (
                      <div className="space-y-6">
                        {/* Sector Header */}
                        <div className="flex flex-col gap-1.5 p-1">
                          <div className="flex items-center gap-2.5">
                            <div className="w-2.5 h-6 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_12px_rgba(16,185,129,0.3)]"></div>
                            <h3 className="text-xl font-bold text-slate-800 uppercase tracking-tight">
                              Lotação: {selectedSector || "Minha Lotação"}
                            </h3>
                          </div>
                          <p className="text-xs text-slate-400 font-bold uppercase tracking-wider ml-5">
                            Realize contratações, aberturas de vagas de estágio
                            e acompanhe o fluxo de assinaturas.
                          </p>
                        </div>

                        {/* Sector specific mini counter cards */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                          {/* Card 1: Geral */}
                          <div
                            onClick={() => setListFilter("all")}
                            className={`p-5 bg-white rounded-3xl border transition-all cursor-pointer shadow-sm hover:shadow-md flex items-center justify-between group ${
                              listFilter === "all"
                                ? "border-emerald-500 ring-4 ring-emerald-50/50"
                                : "border-slate-200/80 hover:border-slate-300"
                            }`}
                          >
                            <div>
                              <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                Total de Solicitações
                              </p>
                              <p className="text-2xl font-black text-slate-800 mt-1 tabular-nums">
                                {
                                  (selectedSector
                                    ? modeFilteredRequests.filter(
                                        (r) => r.sector === selectedSector,
                                      )
                                    : modeFilteredRequests
                                  ).length
                                }
                              </p>
                            </div>
                            <div
                              className={`p-3 rounded-2xl transition-all ${
                                listFilter === "all"
                                  ? "bg-emerald-50 text-emerald-600"
                                  : "bg-slate-50 text-slate-400 group-hover:bg-slate-100 group-hover:text-slate-600"
                              }`}
                            >
                              <UserPlus className="w-5 h-5" />
                            </div>
                          </div>

                          {/* Card 2: Devolvidos */}
                          <div
                            onClick={() =>
                              setListFilter(
                                listFilter === "rejected" ? "all" : "rejected",
                              )
                            }
                            className={`p-5 bg-white rounded-3xl border transition-all cursor-pointer shadow-sm hover:shadow-md flex items-center justify-between group ${
                              listFilter === "rejected"
                                ? "border-red-500 ring-4 ring-red-50/50"
                                : "border-slate-200/80 hover:border-slate-300"
                            }`}
                          >
                            <div>
                              <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                Devolvidos p/ Ajuste
                              </p>
                              <p
                                className={`text-2xl font-black mt-1 tabular-nums ${
                                  (selectedSector
                                    ? modeFilteredRequests.filter(
                                        (r) => r.sector === selectedSector,
                                      )
                                    : modeFilteredRequests
                                  ).filter((r) => r.status === "rejected")
                                    .length > 0
                                    ? "text-red-500"
                                    : "text-slate-600"
                                }`}
                              >
                                {
                                  (selectedSector
                                    ? modeFilteredRequests.filter(
                                        (r) => r.sector === selectedSector,
                                      )
                                    : modeFilteredRequests
                                  ).filter((r) => r.status === "rejected")
                                    .length
                                }
                              </p>
                            </div>
                            <div
                              className={`p-3 rounded-2xl transition-all ${
                                listFilter === "rejected"
                                  ? "bg-rose-50 text-rose-600"
                                  : "bg-slate-50 text-slate-400 group-hover:bg-slate-100 group-hover:text-rose-600"
                              }`}
                            >
                              <XCircle className="w-5 h-5" />
                            </div>
                          </div>

                          {/* Card 3: Pendentes de Assinatura */}
                          <div
                            onClick={() =>
                              setListFilter(
                                listFilter === "signatures"
                                  ? "all"
                                  : "signatures",
                              )
                            }
                            className={`p-5 bg-white rounded-3xl border transition-all cursor-pointer shadow-sm hover:shadow-md flex items-center justify-between group ${
                              listFilter === "signatures"
                                ? "border-amber-500 ring-4 ring-amber-50/50"
                                : "border-slate-200/80 hover:border-slate-300"
                            }`}
                          >
                            <div>
                              <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                Aguardando Assinatura
                              </p>
                              <p className="text-2xl font-black text-slate-800 mt-1 tabular-nums">
                                {
                                  (selectedSector
                                    ? modeFilteredRequests.filter(
                                        (r) => r.sector === selectedSector,
                                      )
                                    : modeFilteredRequests
                                  ).filter(
                                    (r) =>
                                      r.status === "draft" ||
                                      r.status === "pending" ||
                                      r.status === "student_signed" ||
                                      r.status === "supervisor_signed",
                                  ).length
                                }
                              </p>
                            </div>
                            <div
                              className={`p-3 rounded-2xl transition-all ${
                                listFilter === "signatures"
                                  ? "bg-amber-50 text-amber-600"
                                  : "bg-slate-50 text-slate-400 group-hover:bg-slate-100 group-hover:text-amber-500"
                              }`}
                            >
                              <Clock className="w-5 h-5" />
                            </div>
                          </div>

                          {/* Card 4: Aprovadas */}
                          <div
                            onClick={() =>
                              setListFilter(
                                listFilter === "approved" ? "all" : "approved",
                              )
                            }
                            className={`p-5 bg-white rounded-3xl border transition-all cursor-pointer shadow-sm hover:shadow-md flex items-center justify-between group ${
                              listFilter === "approved"
                                ? "border-emerald-500 ring-4 ring-emerald-50/50"
                                : "border-slate-200/80 hover:border-slate-300"
                            }`}
                          >
                            <div>
                              <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                Contratos Aprovados
                              </p>
                              <p className="text-2xl font-black text-emerald-600 mt-1 tabular-nums">
                                {
                                  (selectedSector
                                    ? modeFilteredRequests.filter(
                                        (r) => r.sector === selectedSector,
                                      )
                                    : modeFilteredRequests
                                  ).filter((r) => r.status === "approved")
                                    .length
                                }
                              </p>
                            </div>
                            <div
                              className={`p-3 rounded-2xl transition-all ${
                                listFilter === "approved"
                                  ? "bg-emerald-50 text-emerald-600"
                                  : "bg-slate-50 text-slate-400 group-hover:bg-slate-100 group-hover:text-emerald-500"
                              }`}
                            >
                              <CheckCircle2 className="w-5 h-5" />
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Filters Section */}
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-2">
                      <div className="flex overflow-x-auto bg-slate-100/50 p-1 rounded-2xl border border-slate-100 shrink-0 custom-scrollbar no-scrollbar">
                        <TabButton
                          active={listFilter === "all"}
                          onClick={() => setListFilter("all")}
                          label="Ativos"
                          count={stats.active}
                        />
                        {viewMode !== "manager" && (
                          <TabButton
                            active={listFilter === "rejected"}
                            onClick={() => setListFilter("rejected")}
                            label="Devolvidos"
                            count={stats.rejected}
                          />
                        )}
                        <TabButton
                          active={listFilter === "archived"}
                          onClick={() => setListFilter("archived")}
                          label="Arquivados"
                          count={stats.archived}
                        />
                      </div>

                      <div className="relative flex-1 max-w-sm">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input
                          type="text"
                          placeholder="Buscar solicitações..."
                          value={search}
                          onChange={(e) => setSearch(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl pl-11 pr-4 py-3 text-sm font-medium focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                        />
                      </div>
                    </div>

                    {/* Lista / Table View */}
                    <div className="hidden md:block bg-white rounded-[32px] border border-slate-200 overflow-hidden shadow-sm">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50/50 border-b border-slate-100">
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("type")}
                              >
                                <div className="flex items-center">
                                  Tipo
                                  {renderSortIcon("type")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("student")}
                              >
                                <div className="flex items-center">
                                  Estudante / Vaga
                                  {renderSortIcon("student")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("sector")}
                              >
                                <div className="flex items-center">
                                  Lotação / Setor
                                  {renderSortIcon("sector")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("createdAt")}
                              >
                                <div className="flex items-center">
                                  Data Criação
                                  {renderSortIcon("createdAt")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("signatures")}
                              >
                                <div className="flex items-center">
                                  Assinaturas
                                  {renderSortIcon("signatures")}
                                </div>
                              </th>
                              <th
                                className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest cursor-pointer hover:bg-slate-100/50 transition-colors group select-none"
                                onClick={() => handleSort("status")}
                              >
                                <div className="flex items-center">
                                  Status
                                  {renderSortIcon("status")}
                                </div>
                              </th>
                              <th className="px-4 py-3 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">
                                Ações
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {loading ? (
                              <tr>
                                <td colSpan={7} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-3 justify-center">
                                    <div className="w-8 h-8 border-3 border-blue-600/20 border-t-blue-600 rounded-full animate-spin"></div>
                                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                                      Carregando...
                                    </p>
                                  </div>
                                </td>
                              </tr>
                            ) : sortedRequests.length === 0 ? (
                              <tr>
                                <td colSpan={7} className="py-20 text-center">
                                  <div className="flex flex-col items-center gap-4 opacity-40 justify-center">
                                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                                      <FileText className="w-8 h-8 text-slate-300" />
                                    </div>
                                    <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">
                                      Nenhuma solicitação encontrada
                                    </p>
                                  </div>
                                </td>
                              </tr>
                            ) : (
                              sortedRequests.map((req) => {
                                const statusInfo = getStatusInfo(req.status);
                                const isHiring = req.type === "hiring";
                                const hasSupervisorSig =
                                  !!req.supervisor.signature;
                                const hasStudentSig =
                                  !isHiring || !!req.student?.signature;
                                const isSignaturesComplete =
                                  req.type === "hiring"
                                    ? hasSupervisorSig && hasStudentSig
                                    : true;

                                return (
                                  <tr
                                    key={req.id}
                                    className="hover:bg-slate-50/20 transition-colors"
                                  >
                                    {/* Tipo */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <span
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[8px] font-black uppercase ${
                                          req.type === "hiring"
                                            ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"
                                            : req.type === "resignation"
                                              ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100"
                                              : "bg-blue-50 text-blue-700 ring-1 ring-blue-100"
                                        }`}
                                      >
                                        {req.type === "hiring" ? (
                                          <>
                                            <UserCheck className="w-3 h-3" />
                                            CONTRATO
                                          </>
                                        ) : req.type === "resignation" ? (
                                          <>
                                            <UserMinus className="w-3 h-3" />
                                            RESCISÃO
                                          </>
                                        ) : (
                                          <>
                                            <Search className="w-3 h-3" />
                                            VAGA
                                          </>
                                        )}
                                      </span>
                                    </td>

                                    {/* Estudante / Vaga */}
                                    <td className="px-4 py-3 max-w-xs">
                                      <p
                                        className="text-xs font-bold text-slate-900 whitespace-normal break-words leading-tight hover:text-blue-600 cursor-pointer transition-colors"
                                        onClick={() => setTrackingRequest(req)}
                                      >
                                        {req.student?.name ||
                                          (req.type === "resignation"
                                            ? "RESCISÃO DE ESTÁGIO"
                                            : "ABERTURA DE VAGA")}
                                      </p>
                                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wide whitespace-normal mt-0.5">
                                        {req.level} • {req.course}
                                      </p>
                                    </td>

                                    {/* Setor */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <p className="text-xs font-bold text-slate-700 uppercase tracking-tight">
                                        {req.sector}
                                      </p>
                                    </td>

                                    {/* Data Criação */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <p className="text-xs font-semibold text-slate-500 tabular-nums">
                                        {safeFormat(
                                          req.createdAt,
                                          "dd/MM/yyyy",
                                        )}
                                      </p>
                                    </td>

                                    {/* Assinaturas */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      {isHiring ? (
                                        <div className="flex items-center gap-3">
                                          {/* Supervisor */}
                                          <div
                                            className="flex items-center gap-1"
                                            title={
                                              hasSupervisorSig
                                                ? `Supervisor assinou em ${safeFormat(req.supervisor.signedAt, "dd/MM/yy HH:mm")}`
                                                : "Assinatura Supervisor pendente"
                                            }
                                          >
                                            <div
                                              className={`p-0.5 rounded ${hasSupervisorSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                            >
                                              <Building2 className="w-3 h-3" />
                                            </div>
                                            <span
                                              className={`text-[8px] font-black uppercase ${hasSupervisorSig ? "text-emerald-600" : "text-amber-500"}`}
                                            >
                                              {hasSupervisorSig ? "OK" : "PEND"}
                                            </span>
                                          </div>

                                          {/* Estudante */}
                                          <div
                                            className="flex items-center gap-1"
                                            title={
                                              hasStudentSig
                                                ? `Estudante assinou em ${safeFormat(req.student?.signedAt, "dd/MM/yy HH:mm")}`
                                                : "Assinatura Estudante pendente"
                                            }
                                          >
                                            <div
                                              className={`p-0.5 rounded ${hasStudentSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                            >
                                              <UserPlus className="w-3 h-3" />
                                            </div>
                                            <span
                                              className={`text-[8px] font-black uppercase ${hasStudentSig ? "text-emerald-600" : "text-amber-500"}`}
                                            >
                                              {hasStudentSig ? "OK" : "PEND"}
                                            </span>
                                          </div>
                                        </div>
                                      ) : (
                                        <span className="text-[10px] text-slate-400 font-bold uppercase">
                                          N/A
                                        </span>
                                      )}
                                    </td>

                                    {/* Status */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <span
                                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] font-black uppercase ${statusInfo.color}`}
                                      >
                                        {statusInfo.icon}
                                        {statusInfo.label}
                                      </span>
                                    </td>

                                    {/* Ações */}
                                    <td className="px-4 py-3 whitespace-nowrap">
                                      <div className="flex items-center justify-center gap-1">
                                        {/* Visualizar */}
                                        <button
                                          onClick={() =>
                                            setTrackingRequest(req)
                                          }
                                          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all"
                                          title="Visualizar em Tela"
                                        >
                                          <Eye className="w-3.5 h-3.5" />
                                        </button>

                                        {/* Download Requerimento */}
                                        <button
                                          onClick={() => {
  if (req.documents?.requerimento?.fileId) {
    window.open(req.documents.requerimento.fileId, "_blank");
  } else {
    generateHiringPDF(req);
  }
}}
                                          className="p-1.5 text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-all"
                                          title="Baixar Requerimento PDF"
                                        >
                                          <FileText className="w-3.5 h-3.5" />
                                        </button>

                                        {/* Download Declaração (if hiring) */}
                                        {isHiring && (
                                          <button
                                            onClick={() => {
  if (req.documents?.parentesco?.fileId) {
    window.open(req.documents.parentesco.fileId, "_blank");
  } else {
    generateKinshipPDF(req);
  }
}}
                                            className="p-1.5 text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-all"
                                            title="Baixar Declaração Parentesco PDF"
                                          >
                                            <Signature className="w-3.5 h-3.5" />
                                          </button>
                                        )}

                                        {/* Admin/Manager specific quick actions */}
                                        {(profile.role === "master" ||
                                          profile.role === "manager") && (
                                          <>
                                            <div className="h-4 w-px bg-slate-200 mx-0.5 align-middle self-center"></div>

                                            {viewMode === "admin" && (
                                              <>
                                                {/* Aprovar */}
                                                <button
                                                  onClick={() =>
                                                    setApprovingRequest(req)
                                                  }
                                                  disabled={
                                                    req.status === "approved" ||
                                                    req.status === "archived" ||
                                                    !isSignaturesComplete
                                                  }
                                                  className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-all disabled:opacity-30 disabled:bg-transparent"
                                                  title={
                                                    req.status === "approved"
                                                      ? "Já aprovado"
                                                      : !isSignaturesComplete
                                                        ? "Aguardando assinaturas necessárias para habilitar a aprovação"
                                                        : "Aprovar e Validar Requerimento"
                                                  }
                                                >
                                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                                </button>

                                                {/* Devolver */}
                                                <button
                                                  onClick={() =>
                                                    setRejectingRequest(req)
                                                  }
                                                  disabled={
                                                    req.status === "approved" ||
                                                    req.status === "archived" ||
                                                    req.status === "rejected" ||
                                                    req.status === "draft"
                                                  }
                                                  className="p-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-all disabled:opacity-30 disabled:bg-transparent"
                                                  title={
                                                    req.status === "approved"
                                                      ? "Não pode devolver após aprovação"
                                                      : req.status ===
                                                            "draft" ||
                                                          req.status ===
                                                            "rejected"
                                                        ? "Ainda sob ajuste ou em rascunho"
                                                        : "Devolver para Ajustes"
                                                  }
                                                >
                                                  <XCircle className="w-3.5 h-3.5" />
                                                </button>
                                              </>
                                            )}

                                            {/* Arquivar / Desarquivar */}
                                            {req.status === "archived" ? (
                                              <button
                                                onClick={() => setUnarchivingRequest(req)}
                                                className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
                                                title="Desarquivar Solicitação"
                                              >
                                                <Archive className="w-3.5 h-3.5 rotate-180" />
                                              </button>
                                            ) : (
                                              <button
                                                onClick={() => setArchivingRequest(req)}
                                                className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
                                                title="Arquivar Solicitação"
                                              >
                                                <Archive className="w-3.5 h-3.5" />
                                              </button>
                                            )}
                                          </>
                                        )}

                                        {/* Edit/Trash Actions for Managers on drafts/rejected */}
                                        {viewMode === "manager" &&
                                          (req.status === "draft" ||
                                            req.status === "rejected") && (
                                            <>
                                              <div className="h-4 w-px bg-slate-200 mx-0.5 align-middle self-center"></div>
                                              <button
                                                onClick={() => setShowForm(req)}
                                                className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-all"
                                                title="Editar Requerimento"
                                              >
                                                <Edit className="w-3.5 h-3.5" />
                                              </button>
                                              <button
                                                onClick={() =>
                                                  setDeletingRequest(req)
                                                }
                                                className="p-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-all"
                                                title="Excluir Rascunho/Solicitação"
                                              >
                                                <Trash2 className="w-3.5 h-3.5" />
                                              </button>
                                            </>
                                          )}
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Lista de Requerimentos - Mobile - Perfil Gestor */}
                    <div className="block md:hidden grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {loading ? (
                        <div className="col-span-full py-20 text-center">
                          <div className="flex flex-col items-center gap-3 justify-center">
                            <div className="w-8 h-8 border-3 border-blue-600/20 border-t-blue-600 rounded-full animate-spin"></div>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest block font-sans">
                              Carregando...
                            </p>
                          </div>
                        </div>
                      ) : sortedRequests.length === 0 ? (
                        <div className="col-span-full py-20 text-center">
                          <div className="flex flex-col items-center gap-4 opacity-40 justify-center">
                            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                              <FileText className="w-8 h-8 text-slate-300" />
                            </div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-widest font-sans">
                              Nenhuma solicitação encontrada
                            </p>
                          </div>
                        </div>
                      ) : (
                        sortedRequests.map((req) => {
                          const statusInfo = getStatusInfo(req.status);
                          const isHiring = req.type === "hiring";
                          const hasSupervisorSig = !!req.supervisor.signature;
                          const hasStudentSig =
                            !isHiring || !!req.student?.signature;
                          const isSignaturesComplete =
                            req.type === "hiring"
                              ? hasSupervisorSig && hasStudentSig
                              : true;

                          return (
                            <div
                              key={req.id}
                              className="p-3.5 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-2.5 hover:border-blue-200 transition-colors"
                            >
                              <div className="flex items-start justify-between gap-3">
                                <div className="space-y-1 min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span
                                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-wider ${
                                        req.type === "hiring"
                                          ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"
                                          : req.type === "resignation"
                                            ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100"
                                            : "bg-blue-50 text-blue-700 ring-1 ring-blue-100"
                                      }`}
                                    >
                                      {req.type === "hiring"
                                        ? "CONTRATO"
                                        : req.type === "resignation"
                                          ? "RESCISÃO"
                                          : "VAGA"}
                                    </span>
                                    <span className="text-[10px] text-slate-400 font-bold">
                                      {safeFormat(
                                        req.createdAt,
                                        "dd/MM/yyyy",
                                      )}
                                    </span>
                                  </div>
                                  <p
                                    className="text-xs sm:text-sm font-black text-slate-900 leading-snug hover:text-blue-600 transition-colors cursor-pointer truncate font-sans"
                                    onClick={() => setTrackingRequest(req)}
                                  >
                                    {req.student?.name ||
                                      (req.type === "resignation"
                                        ? "RESCISÃO DE ESTÁGIO"
                                        : "ABERTURA DE VAGA")}
                                  </p>
                                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider truncate font-sans">
                                    {req.level} • {req.course}
                                  </p>
                                </div>

                                <span
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] font-black uppercase shrink-0 ${statusInfo.color}`}
                                >
                                  {statusInfo.icon}
                                  {statusInfo.label}
                                </span>
                              </div>

                              <div className="grid grid-cols-2 gap-3 text-xs border-y border-slate-100 py-2">
                                <div className="min-w-0">
                                  <p className="text-[8px] font-black uppercase text-slate-400 tracking-wider font-sans">
                                    Setor / Lotação
                                  </p>
                                  <p className="font-bold text-slate-700 truncate uppercase mt-0.5 font-sans">
                                    {req.sector}
                                  </p>
                                </div>
                                <div>
                                  <p className="text-[8px] font-black uppercase text-slate-400 tracking-wider font-sans">
                                    Assinaturas
                                  </p>
                                  {isHiring ? (
                                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                                      <div
                                        className="flex items-center gap-1"
                                        title="Supervisor"
                                      >
                                        <div
                                          className={`p-0.5 rounded ${hasSupervisorSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                        >
                                          <Building2 className="w-2.5 h-2.5" />
                                        </div>
                                        <span
                                          className={`text-[8px] font-bold font-sans ${hasSupervisorSig ? "text-emerald-600" : "text-amber-500"}`}
                                        >
                                          Sup:{" "}
                                          {hasSupervisorSig ? "OK" : "PEND"}
                                        </span>
                                      </div>
                                      <div
                                        className="flex items-center gap-1"
                                        title="Estudante"
                                      >
                                        <div
                                          className={`p-0.5 rounded ${hasStudentSig ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}
                                        >
                                          <UserPlus className="w-2.5 h-2.5" />
                                        </div>
                                        <span
                                          className={`text-[8px] font-bold font-sans ${hasStudentSig ? "text-emerald-600" : "text-amber-500"}`}
                                        >
                                          Est: {hasStudentSig ? "OK" : "PEND"}
                                        </span>
                                      </div>
                                    </div>
                                  ) : (
                                    <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 font-sans">
                                      N/A
                                    </p>
                                  )}
                                </div>
                              </div>

                              <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                                <div className="flex items-center gap-1 border-slate-50">
                                  <button
                                    onClick={() => setTrackingRequest(req)}
                                    className="p-1.5 sm:p-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl transition-all flex items-center justify-center gap-1 text-[9px] font-black uppercase tracking-wider cursor-pointer font-sans"
                                  >
                                    <Eye className="w-3.5 h-3.5" /> Ver
                                  </button>
                                  <button
                                    onClick={() => {
                                      if (req.documents?.requerimento?.fileId) {
                                        window.open(req.documents.requerimento.fileId, "_blank");
                                      } else {
                                        generateHiringPDF(req);
                                      }
                                    }}
                                    className="p-1.5 sm:p-2 bg-blue-50/50 hover:bg-blue-50 text-blue-700 rounded-xl transition-all flex items-center justify-center gap-1 text-[9px] font-black uppercase tracking-wider cursor-pointer font-sans"
                                  >
                                    <FileText className="w-3.5 h-3.5" /> Ficha
                                  </button>
                                  {isHiring && (
                                    <button
                                      onClick={() => {
                                        if (req.documents?.parentesco?.fileId) {
                                          window.open(req.documents.parentesco.fileId, "_blank");
                                        } else {
                                          generateKinshipPDF(req);
                                        }
                                      }}
                                      className="p-1.5 sm:p-2 bg-blue-50/50 hover:bg-blue-50 text-blue-700 rounded-xl transition-all flex items-center justify-center gap-1 text-[9px] font-black uppercase tracking-wider cursor-pointer font-sans"
                                    >
                                      <Signature className="w-3.5 h-3.5" />{" "}
                                      Parentesco
                                    </button>
                                  )}
                                </div>

                                <div className="flex items-center gap-1 font-sans">
                                  {(profile.role === "master" || profile.role === "manager") && (
                                    <>
                                      {viewMode === "admin" && (
                                        <>
                                          <button
                                            onClick={() => setApprovingRequest(req)}
                                            disabled={
                                              req.status === "approved" ||
                                              req.status === "archived" ||
                                              !isSignaturesComplete
                                            }
                                            className="p-2 text-emerald-600 bg-emerald-50/50 hover:bg-emerald-100 disabled:opacity-30 rounded-xl transition-all cursor-pointer"
                                            title="Aprovar"
                                          >
                                            <CheckCircle2 className="w-4 h-4" />
                                          </button>
                                          <button
                                            onClick={() => setRejectingRequest(req)}
                                            disabled={
                                              req.status === "approved" ||
                                              req.status === "archived" ||
                                              req.status === "rejected" ||
                                              req.status === "draft"
                                            }
                                            className="p-2 text-red-600 bg-rose-50/50 hover:bg-rose-100 disabled:opacity-30 rounded-xl transition-all cursor-pointer"
                                            title="Devolver"
                                          >
                                            <XCircle className="w-4 h-4" />
                                          </button>
                                        </>
                                      )}
                                      {req.status === "archived" ? (
                                        <button
                                          onClick={() => setUnarchivingRequest(req)}
                                          className="p-2 text-blue-600 bg-blue-50/50 hover:bg-blue-100 rounded-xl transition-all cursor-pointer"
                                          title="Desarquivar"
                                        >
                                          <Archive className="w-4 h-4 rotate-180" />
                                        </button>
                                      ) : (
                                        <button
                                          onClick={() => setArchivingRequest(req)}
                                          className="p-2 text-slate-500 bg-slate-50 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                                          title="Arquivar"
                                        >
                                          <Archive className="w-4 h-4" />
                                        </button>
                                      )}
                                    </>
                                  )}

                                  {viewMode === "manager" &&
                                    (req.status === "draft" ||
                                      req.status === "rejected") && (
                                      <>
                                        <button
                                          onClick={() => setShowForm(req)}
                                          className="p-2 text-emerald-600 bg-emerald-50/50 hover:bg-emerald-100 rounded-xl transition-all cursor-pointer"
                                          title="Editar Requerimento"
                                        >
                                          <Edit className="w-4 h-4" />
                                        </button>
                                        <button
                                          onClick={() => setDeletingRequest(req)}
                                          className="p-2 text-red-600 bg-rose-50/50 hover:bg-rose-100 rounded-xl transition-all cursor-pointer"
                                          title="Excluir"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </button>
                                      </>
                                    )}
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </main>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {approvingRequest && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[32px] shadow-2xl max-w-sm w-full overflow-hidden"
            >
              <div className="p-8 border-b border-slate-100 flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center border border-emerald-100">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-900 uppercase">
                    Aprovar?
                  </h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                    Concluir processo
                  </p>
                </div>
              </div>

              <div className="p-8 space-y-6">
                <p className="text-sm text-slate-600 leading-relaxed font-medium">
                  Deseja realmente aprovar a solicitação de{" "}
                  <span className="font-bold text-slate-900">
                    {approvingRequest.student?.name || "abertura de vaga"}
                  </span>
                  ? Esta ação não poderá ser desfeita.
                </p>

                <div className="flex gap-4">
                  <button
                    onClick={() => setApprovingRequest(null)}
                    className="flex-1 py-4 bg-slate-100 text-slate-400 font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all font-bold"
                  >
                    CANCELAR
                  </button>
                  <button
                    onClick={handleApprove}
                    className="flex-1 py-4 bg-emerald-600 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-100 font-bold"
                  >
                    APROVAR
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {archivingRequest && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[32px] shadow-2xl max-w-sm w-full overflow-hidden"
            >
              <div className="p-8 border-b border-slate-100 flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center border border-amber-100">
                  <Archive className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-900 uppercase">
                    Arquivar?
                  </h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                    Sairá da lista ativa
                  </p>
                </div>
              </div>

              <div className="p-8 space-y-6">
                <p className="text-sm text-slate-600 leading-relaxed font-medium">
                  Deseja realmente arquivar a solicitação de{" "}
                  <span className="font-bold text-slate-900">
                    {archivingRequest.student?.name || "abertura de vaga"}
                  </span>
                  ? Ela poderá ser consultada na aba de arquivados.
                </p>

                <div className="flex gap-4">
                  <button
                    onClick={() => setArchivingRequest(null)}
                    className="flex-1 py-4 bg-slate-100 text-slate-400 font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all font-bold"
                  >
                    CANCELAR
                  </button>
                  <button
                    onClick={handleArchive}
                    className="flex-1 py-4 bg-amber-600 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-amber-700 transition-all shadow-xl shadow-amber-100 font-bold"
                  >
                    ARQUIVAR
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {unarchivingRequest && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[32px] shadow-2xl max-w-sm w-full overflow-hidden"
            >
              <div className="p-8 border-b border-slate-100 flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center border border-blue-100">
                  <Archive className="w-6 h-6 rotate-180" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-900 uppercase">
                    Desarquivar?
                  </h3>
                  <p className="text-[10px] text-blue-500 font-bold uppercase tracking-widest mt-1">
                    Retornará para a lista ativa
                  </p>
                </div>
              </div>

              <div className="p-8 space-y-6">
                <p className="text-sm text-slate-600 leading-relaxed font-medium">
                  Deseja realmente desarquivar a solicitação de{" "}
                  <span className="font-bold text-slate-900">
                    {unarchivingRequest.student?.name || "abertura de vaga"}
                  </span>
                  ? Ela voltará a aparecer na lista de solicitações ativas.
                </p>

                <div className="flex gap-4">
                  <button
                    onClick={() => setUnarchivingRequest(null)}
                    className="flex-1 py-4 bg-slate-100 text-slate-400 font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all font-bold cursor-pointer"
                  >
                    CANCELAR
                  </button>
                  <button
                    onClick={handleUnarchive}
                    className="flex-1 py-4 bg-blue-600 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 font-bold cursor-pointer"
                  >
                    DESARQUIVAR
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deletingRequest && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[32px] shadow-2xl max-w-sm w-full overflow-hidden"
            >
              <div className="p-8 border-b border-slate-100 flex items-center gap-4">
                <div className="w-12 h-12 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center border border-red-100">
                  <XCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-900 uppercase">
                    Excluir?
                  </h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                    Ação irreversível
                  </p>
                </div>
              </div>

              <div className="p-8 space-y-6">
                <p className="text-sm text-slate-600 leading-relaxed font-medium">
                  Deseja realmente excluir permanentemente a solicitação de{" "}
                  <span className="font-bold text-slate-900">
                    {deletingRequest.student?.name || "abertura de vaga"}
                  </span>
                  ?
                </p>

                <div className="flex gap-4">
                  <button
                    onClick={() => setDeletingRequest(null)}
                    className="flex-1 py-4 bg-slate-100 text-slate-400 font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all font-bold"
                  >
                    CANCELAR
                  </button>
                  <button
                    onClick={handleDeleteDraft}
                    className="flex-1 py-4 bg-red-600 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-red-700 transition-all shadow-xl shadow-red-100 font-bold"
                  >
                    EXCLUIR
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {rejectingRequest && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[32px] shadow-2xl max-w-lg w-full overflow-hidden"
            >
              <div className="p-8 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center border border-red-100">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-slate-900 uppercase">
                      Devolver Solicitação
                    </h3>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                      Informe a justificativa da devolução
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setRejectingRequest(null)}
                  className="p-2 hover:bg-slate-100 rounded-xl transition-all"
                >
                  <XCircle className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              <div className="p-8 space-y-6">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                    Motivo / Justificativa
                  </label>
                  <textarea
                    rows={6}
                    placeholder="Descreva o motivo da devolução ou o que precisa ser ajustado..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-5 text-sm font-medium text-slate-700 outline-none focus:ring-4 focus:ring-red-500/10 focus:border-red-500 transition-all resize-none"
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => setRejectingRequest(null)}
                    className="flex-1 py-4 bg-slate-100 text-slate-400 font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all"
                  >
                    CANCELAR
                  </button>
                  <button
                    onClick={handleReject}
                    disabled={!rejectReason}
                    className="flex-[2] py-4 bg-red-600 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-red-700 transition-all shadow-xl shadow-red-100 disabled:opacity-50"
                  >
                    CONFIRMAR DEVOLUÇÃO
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatusCard({
  label,
  value,
  icon,
  color,
  active,
  onClick,
  className,
}: {
  label: string;
  value: number;
  icon: React.ReactNode;
  color: string;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  // Determine dynamic discrete highlight styles, glows, active label colors, and active icon backgrounds
  let activeStyles = "border-blue-500 ring-4 ring-blue-50/50 bg-blue-50/5";
  let labelActiveColor = "text-blue-600 font-extrabold";
  let iconActiveBg = "bg-blue-50 text-blue-600";

  if (color.includes("emerald-500")) {
    activeStyles =
      "border-emerald-500 ring-4 ring-emerald-50/50 bg-emerald-50/5";
    labelActiveColor = "text-emerald-600 font-extrabold";
    iconActiveBg = "bg-emerald-50 text-emerald-600";
  } else if (color.includes("orange-500")) {
    activeStyles = "border-orange-500 ring-4 ring-orange-50/50 bg-orange-50/5";
    labelActiveColor = "text-orange-600 font-extrabold";
    iconActiveBg = "bg-orange-50 text-orange-600";
  } else if (color.includes("amber-500")) {
    activeStyles = "border-amber-500 ring-4 ring-amber-50/50 bg-amber-50/5";
    labelActiveColor = "text-amber-600 font-extrabold";
    iconActiveBg = "bg-amber-50 text-amber-600";
  } else if (color.includes("blue-500")) {
    activeStyles = "border-blue-500 ring-4 ring-blue-50/50 bg-blue-50/5";
    labelActiveColor = "text-blue-600 font-extrabold";
    iconActiveBg = "bg-blue-50 text-blue-600";
  } else if (color.includes("indigo-500")) {
    activeStyles = "border-indigo-500 ring-4 ring-indigo-50/50 bg-indigo-50/5";
    labelActiveColor = "text-indigo-600 font-extrabold";
    iconActiveBg = "bg-indigo-50 text-indigo-600";
  } else if (color.includes("red-600") || color.includes("rose-550")) {
    activeStyles = "border-red-500 ring-4 ring-red-50/50 bg-red-50/5";
    labelActiveColor = "text-red-600 font-extrabold";
    iconActiveBg = "bg-red-50 text-red-600";
  }

  return (
    <button
      onClick={onClick}
      className={`bg-white p-4 sm:p-5 rounded-[22px] border transition-all duration-350 group w-full text-left cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0 ${
        active
          ? `${activeStyles}`
          : "border-slate-200/80 shadow-sm hover:border-slate-300 hover:shadow-md"
      } ${className || ""}`}
    >
      <div className="flex items-center justify-between mb-2">
        <p
          className={`text-[9px] uppercase tracking-wider font-extrabold transition-colors ${active ? labelActiveColor : "text-slate-400 group-hover:text-slate-500"}`}
        >
          {label}
        </p>
        <div
          className={`p-2 rounded-xl transition-all ${active ? iconActiveBg : "bg-slate-50 text-slate-400 group-hover:bg-slate-100 group-hover:text-slate-600"}`}
        >
          {icon}
        </div>
      </div>
      <h3
        className={`text-2xl sm:text-3xl font-black mt-1 tabular-nums transition-colors ${active ? labelActiveColor : "text-slate-800"}`}
      >
        {value}
      </h3>
      <div className="w-full bg-slate-100 h-1 mt-3.5 rounded-full overflow-hidden">
        <div className={`${color} h-full w-full opacity-60`}></div>
      </div>
    </button>
  );
}

function TabButton({
  active,
  label,
  count,
  onClick,
}: {
  active: boolean;
  label: string;
  count: number;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 sm:px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-2 sm:gap-3 shrink-0 ${active ? "bg-white text-emerald-600 shadow-lg shadow-emerald-100/50" : "text-slate-400 hover:text-slate-600 hover:bg-white/50"}`}
    >
      {label}
      <span
        className={`px-2 py-0.5 rounded-lg text-[9px] font-black tabular-nums ${active ? "bg-emerald-100 text-emerald-700" : "bg-slate-200 text-slate-500"}`}
      >
        {count}
      </span>
    </button>
  );
}

function SendIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="22" y1="2" x2="11" y2="13" />
      <polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
  );
}
