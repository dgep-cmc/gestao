import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Building2, 
  User, 
  Briefcase, 
  Clock, 
  GraduationCap, 
  Save, 
  Send,
  AlertCircle,
  X,
  Phone,
  Mail,
  FileText,
  Search,
  ShieldCheck,
  ArrowLeft,
  ArrowDown,
  LayoutGrid,
  Paperclip,
  Trash2,
  Loader2,
  Download,
  UserMinus
} from 'lucide-react';
import { hiringService } from '../../services/hiringService';
import { frequencyService } from '../../services/frequencyService';
import { emailNotificationService } from '../../services/emailNotificationService';
import { UserProfile, HiringRequest, HiringStatus } from '../../types';
import { toast } from 'react-hot-toast';
import { validateCPF, formatCPF, formatPhone } from '../../lib/validation';
import { generateHiringPDF, generateKinshipPDF } from '../../lib/pdfGenerator';

const formatInputDate = (val: string | null | undefined): string => {
  if (!val) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(val)) return val;
  if (val.includes('T') || val.includes(' ')) {
    const parts = val.split(/[T ]/);
    if (parts[0] && /^\d{4}-\d{2}-\d{2}$/.test(parts[0])) {
      return parts[0];
    }
  }
  try {
    const d = new Date(val);
    if (!isNaN(d.getTime())) {
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }
  } catch (e) {
    // ignore
  }
  return '';
};

interface HiringRequestFormProps {
  profile: UserProfile;
  onClose: () => void;
  onSuccess: () => void;
}

export default function HiringRequestForm({ profile, onClose, onSuccess, initialData, initialType, selectedSector }: { 
  profile: UserProfile; 
  onClose: () => void; 
  onSuccess: () => void;
  initialData?: HiringRequest;
  initialType?: 'hiring' | 'opening' | 'resignation' | null;
  selectedSector?: string;
}) {
  const [activeRequestId] = useState<string>(() => {
    return initialData?.id || hiringService.generateNewId();
  });
  const [loading, setLoading] = useState(false);
  const [type, setType] = useState<'hiring' | 'opening' | 'resignation'>(initialData?.type || initialType || 'hiring');
  
  const [formData, setFormData] = useState({
    sector: initialData?.sector || selectedSector || profile.sectors?.[0] || '',
    level: initialData?.level || 'Superior',
    course: initialData?.course || '',
    activities: initialData?.activities || '',
    startDate: initialData?.startDate || '',
    startTime: initialData?.startTime || '08:00',
    endTime: initialData?.endTime || '12:00',
    period: (initialData?.period as any) || 'Manhã',
    supervisor: {
      name: initialData?.supervisor?.name || '',
      role: initialData?.supervisor?.role || '',
      rg: initialData?.supervisor?.rg || '',
      cpf: initialData?.supervisor?.cpf || '',
      email: initialData?.supervisor?.email || '',
      phone: initialData?.supervisor?.phone || '',
      education: initialData?.supervisor?.education || 'Superior',
      course: initialData?.supervisor?.course || '',
      experience: initialData?.supervisor?.experience || ''
    },
    student: {
      name: initialData?.student?.name || '',
      birthDate: initialData?.student?.birthDate || '',
      cpf: initialData?.student?.cpf || '',
      email: initialData?.student?.email || '',
      phone: initialData?.student?.phone || '',
      isMandatory: initialData?.student?.isMandatory || false
    },
    documents: {
      rg: initialData?.documents?.rg || null,
      cpf: initialData?.documents?.cpf || null,
      photo: initialData?.documents?.photo || null,
      bank: initialData?.documents?.bank || null,
      address: initialData?.documents?.address || null,
      enrollment: initialData?.documents?.enrollment || null,
      parent: initialData?.documents?.parent || null
    }
  });

  const handlePeriodChange = (p: 'Manhã' | 'Tarde') => {
    setFormData({
      ...formData,
      period: p,
      startTime: p === 'Manhã' ? '08:00' : '14:00',
      endTime: p === 'Manhã' ? '12:00' : '18:00'
    });
  };

  const isUnder18Student = () => {
    if (!formData.student.birthDate) return false;
    const birthDate = new Date(formData.student.birthDate);
    if (isNaN(birthDate.getTime())) return false;
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age < 18;
  };

  const [uploadingSlots, setUploadingSlots] = useState<{ [key: string]: boolean }>({});

  const handleFileUpload = async (slotKey: string, file: File | null) => {
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      toast.error(`Arquivo ${file.name} excede o limite de 8MB.`);
      return;
    }
    setUploadingSlots(prev => ({ ...prev, [slotKey]: true }));
    try {
      // Check if there is already a file in this slot, and delete it from Google Drive if exists
      const existingDoc = (formData.documents as any)?.[slotKey];
      if (existingDoc) {
        const fileIdOrUrl = typeof existingDoc === 'string' ? existingDoc : existingDoc.fileId;
        if (fileIdOrUrl) {
          frequencyService.deleteFile(fileIdOrUrl).catch(err => {
            console.warn("Could not delete previous file from Google Drive on replacement:", err);
          });
        }
      }

      const studentName = formData.student?.name || 'Candidato';
      const requestId = activeRequestId;
      const requestNameAndId = `${studentName}_${requestId}`.replace(/\s+/g, '_');
      const cleanStudentName = studentName.trim().replace(/\s+/g, '_');
      
      // Exact naming mapping as requested by user
      const docNames: { [key: string]: string } = {
        rg: `1-RG_${cleanStudentName}.pdf`,
        cpf: `2-CPF_${cleanStudentName}.pdf`,
        photo: `3-Foto_${cleanStudentName}.pdf`,
        bank: `4-Dados_Bancários_${cleanStudentName}.pdf`,
        address: `5-Comprovante_Endereço_${cleanStudentName}.pdf`,
        enrollment: `6-Declaração_Matrícula_${cleanStudentName}.pdf`,
        parent: `7-Docs_Responsável_${cleanStudentName}.pdf`
      };

      const renamedFileName = docNames[slotKey] || `${slotKey}_${cleanStudentName}.pdf`;
      
      // Construct renamed File object safely
      const renamedFile = new File([file], renamedFileName, { type: file.type });

      const fileId = await frequencyService.uploadFile(renamedFile, `hiring_doc_${slotKey}`, {
        module: 'hiring',
        category: 'intern',
        lotacao: formData.sector || 'Submissoes_Gerais',
        requestNameAndId,
        requestId
      });
      setFormData(prev => ({
        ...prev,
        documents: {
          ...prev.documents,
          [slotKey]: { fileId, name: renamedFileName }
        }
      }));
      toast.success(`Documento enviado com sucesso!`);
    } catch (err) {
      console.error(err);
      toast.error(`Erro ao enviar ${file.name}`);
    } finally {
      setUploadingSlots(prev => ({ ...prev, [slotKey]: false }));
    }
  };

  const handleDocDownload = async (fileId: string, fileName: string) => {
    if (fileId && (fileId.startsWith('http://') || fileId.startsWith('https://'))) {
      window.open(fileId, '_blank');
      return;
    }
    try {
      const loadingToast = toast.loading(`Baixando ${fileName}...`);
      const { data } = await frequencyService.downloadFile(fileId);
      const url = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 100);
      toast.success("Download concluído", { id: loadingToast });
    } catch (err) {
      toast.error("Erro ao baixar documento");
    }
  };

  const removeDoc = (slotKey: string) => {
    // Identify file to delete from Google Drive if exists
    const docToDelete = (formData.documents as any)?.[slotKey];
    if (docToDelete) {
      const fileIdOrUrl = typeof docToDelete === 'string' ? docToDelete : docToDelete.fileId;
      if (fileIdOrUrl) {
        // Trigger background deletion for responsive, non-blocking UI
        frequencyService.deleteFile(fileIdOrUrl).catch(err => {
          console.warn("Erro ao deletar arquivo do Google Drive:", err);
        });
      }
    }

    setFormData(prev => ({
      ...prev,
      documents: {
        ...prev.documents,
        [slotKey]: null
      }
    }));
    toast.success("Documento removido.");
  };

  const documentList = [
    {
      key: 'rg',
      title: '1. Documento de Identidade (RG)',
      description: 'Cópia legível frente e verso do RG do estudante.',
      required: true
    },
    {
      key: 'cpf',
      title: '2. CPF',
      description: 'Cópia legível do CPF do estudante.',
      required: true
    },
    {
      key: 'photo',
      title: '3. Foto 3x4 Colorida',
      description: 'Foto 3x4 colorida e recente para cadastro.',
      required: true
    },
    {
      key: 'bank',
      title: '4. Comprovante de Dados Bancários',
      description: 'Comprovante com agência e conta corrente ativa ou conta poupança em nome do estudante.',
      required: true
    },
    {
      key: 'address',
      title: '5. Comprovante de Endereço',
      description: 'Emitido nos últimos 30 dias (luz, água, telefone ou declaração).',
      required: true
    },
    {
      key: 'enrollment',
      title: '6. Declaração de Matrícula',
      description: 'Emitida nos últimos 60 dias pela instituição de ensino de forma atualizada.',
      required: true
    },
    {
      key: 'parent',
      title: '7. RG e CPF do Responsável',
      description: 'Obrigatório somente em caso de estudante menor de 18 anos de idade.',
      required: false
    }
  ];

  const validateForm = () => {
    // Basic fields
    if (!formData.sector) return "Selecione o setor";

    if (type === 'resignation') {
      if (!formData.student.name) return "Nome do estagiário é obrigatório";
      if (!formData.startDate) return "Data de desligamento é obrigatória";
      return null;
    }

    if (type === 'hiring' && !formData.startDate) return "Informe a data inicial";
    if (!formData.course) return "Informe o curso";
    if (!formData.activities) return "Descreva as atividades";

    // Supervisor fields
    if (type === 'hiring') {
      if (!formData.supervisor.name) return "Nome do supervisor é obrigatório";
      if (!formData.supervisor.cpf) return "CPF do supervisor é obrigatório";
      if (!validateCPF(formData.supervisor.cpf)) return "CPF do supervisor inválido";
    }
    
    if (!formData.supervisor.email) return type === 'hiring' ? "Email do supervisor é obrigatório" : "Email para retorno é obrigatório";

    // Student fields (only for hiring)
    if (type === 'hiring') {
      if (!formData.student.name) return "Nome do estudante é obrigatório";
      if (!formData.student.birthDate) return "Data de nascimento do estudante é obrigatória";
      if (!formData.student.email) return "Email do estudante é obrigatório";
      if (!formData.student.cpf) return "CPF do estudante é obrigatório";
      if (!validateCPF(formData.student.cpf)) return "CPF do estudante inválido";

      // Document validation
      const missingDocs: string[] = [];
      if (!formData.documents.rg) missingDocs.push("1. RG");
      if (!formData.documents.cpf) missingDocs.push("2. CPF");
      if (!formData.documents.photo) missingDocs.push("3. Foto 3x4 colorida");
      if (!formData.documents.bank) missingDocs.push("4. Comprovante de dados bancários");
      if (!formData.documents.address) missingDocs.push("5. Comprovante de endereço");
      if (!formData.documents.enrollment) missingDocs.push("6. Declaração de matrícula");

      const isUnder18 = isUnder18Student();
      if (isUnder18 && !formData.documents.parent) {
        missingDocs.push("7. Cópia do RG e CPF do responsável (estudante menor de idade)");
      }

      if (missingDocs.length > 0) {
        return `Estão faltando os seguintes documentos obrigatórios:\n` + missingDocs.map(d => `• ${d}`).join('\n');
      }
    }

    return null;
  };

  const handleSave = async (status: HiringStatus) => {
    // Only validate complete fields if saving for signatures
    if (status !== 'draft') {
      const error = validateForm();
      if (error) {
        toast.error(error);
        return;
      }
    }

    setLoading(true);
    try {
      const data: any = {
        type,
        ...formData,
        createdBy: profile.email,
        status: status,
        createdAt: initialData?.createdAt || new Date().toISOString()
      };
      
      if (status !== 'rejected') {
        data.rejectReason = "";
        data.rejectedBy = "";
        data.rejectedAt = "";
      }
      
      let requestId = activeRequestId;
      
      if (initialData?.id) {
        await hiringService.updateRequest(initialData.id, data);
      } else {
        requestId = await hiringService.createRequest(data as Partial<HiringRequest>, activeRequestId);
      }

      // Automatically generate and upload Requerimento & Declaração to Google Drive if not draft
      if (status !== 'draft') {
        const completeRequest: HiringRequest = {
          id: requestId,
          ...data
        };

        try {
          const studentName = completeRequest.student?.name || 'Candidato';
          const requestNameAndId = `${studentName}_${requestId}`.replace(/\s+/g, '_');
          const context = {
            module: 'hiring' as const,
            category: 'intern' as const,
            lotacao: completeRequest.sector || 'Submissoes_Gerais',
            requestNameAndId,
            requestId
          };

          const cleanStudentName = studentName.trim().replace(/\s+/g, '_');

          // Generate files silently
          const hiringDoc = generateHiringPDF(completeRequest, profile.name || '', profile.email, true);
          const hiringBlob = hiringDoc.output('blob');
          const reqFileName = `${cleanStudentName}_Requerimento_Para_Contratação.pdf`;
          const hiringFile = new File([hiringBlob], reqFileName, { type: 'application/pdf' });
          
          const requerimentoUrl = await frequencyService.uploadFile(hiringFile, `hiring_doc_requerimento`, context);
          
          let parentescoUrl = null;
          let kinshipFileName = '';
          if (completeRequest.type === 'hiring') {
            const kinshipDoc = generateKinshipPDF(completeRequest, true);
            if (kinshipDoc) {
              const kinshipBlob = kinshipDoc.output('blob');
              kinshipFileName = `${cleanStudentName}_Declaração_de_Parentesco.pdf`;
              const kinshipFile = new File([kinshipBlob], kinshipFileName, { type: 'application/pdf' });
              parentescoUrl = await frequencyService.uploadFile(kinshipFile, `hiring_doc_parentesco`, context);
            }
          }

          // Update saved database with direct webViewLink file IDs on Drive
          await hiringService.updateRequest(requestId, {
            documents: {
              ...(data.documents || {}),
              requerimento: { fileId: requerimentoUrl, name: reqFileName },
              parentesco: parentescoUrl ? { fileId: parentescoUrl, name: kinshipFileName } : null
            }
          });

          // Queue signature invitation emails automatically for the supervisor and student if pending
          if (status === 'pending') {
            try {
              // Always invite the supervisor
              await emailNotificationService.sendSupervisorInvite(completeRequest);
              
              // If hiring type and student email exists, invite student too
              if (completeRequest.type === 'hiring' && completeRequest.student?.email) {
                await emailNotificationService.sendStudentInvite(completeRequest);
              }
            } catch (mailErr) {
              console.warn("Erro ao registrar envios automáticos de assinatura por e-mail:", mailErr);
            }
          }
        } catch (driveErr) {
          console.warn("Erro ao gerar/salvar formulários no Google Drive:", driveErr);
        }
      }
      
      let successMessage = "Solicitação enviada para assinaturas!";
      if (status === 'draft') {
        successMessage = "Progresso salvo como rascunho!";
      } else if (type === 'opening' || type === 'resignation') {
        successMessage = "Requerimento enviado. Aguarde análise da DGEP.";
      }
      
      toast.success(successMessage);
      onSuccess();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao processar solicitação");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-white overflow-hidden">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex-1 flex flex-col overflow-hidden"
      >
        <div className="p-4 sm:p-8 border-b border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between bg-white sticky top-0 z-10 shrink-0 gap-4">
          <div className="flex items-center gap-4 sm:gap-6 w-full md:w-auto">
             <button 
               onClick={onClose}
               className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-slate-50 text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-all border border-slate-200 shrink-0"
             >
                <ArrowLeft className="w-5 h-5 sm:w-6 sm:h-6" />
             </button>
             <div className="hidden sm:block h-10 w-[1px] bg-slate-100"></div>
             <div className="flex items-center gap-3 sm:gap-4 overflow-hidden">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center border border-emerald-100 shrink-0">
                    <FileText className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0">
                    <h2 className="text-lg sm:text-2xl font-black text-slate-900 leading-tight tracking-tight uppercase truncate">
                      {initialData ? 'EDITAR SOLICITAÇÃO' : 'NOVA SOLICITAÇÃO DE ESTÁGIO'}
                    </h2>
                    <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1 truncate">DGEP - Diretoria de Gestão de Pessoas</p>
                </div>
             </div>
          </div>
          
          <div className="flex items-center justify-between w-full md:w-auto gap-4 sm:gap-6 px-4 sm:px-6 py-2 bg-slate-50 rounded-2xl border border-slate-100 overflow-hidden">
             <div className="flex flex-col items-start md:items-end min-w-0 flex-1 md:flex-initial">
                <span className="text-[8px] sm:text-[9px] font-black text-slate-400 uppercase tracking-widest truncate">Unidade / Setor</span>
                <span className="text-[10px] sm:text-xs font-black text-slate-700 uppercase truncate">{formData.sector || 'NÃO SELECIONADO'}</span>
             </div>
             <div className="h-8 w-[1px] bg-slate-200 shrink-0"></div>
             <div className="flex flex-col items-end shrink-0">
                <span className="text-[8px] sm:text-[9px] font-black text-slate-400 uppercase tracking-widest truncate">Tipo</span>
                <span className={`text-[10px] sm:text-xs font-black uppercase tracking-tighter truncate ${type === 'hiring' ? 'text-emerald-600' : type === 'resignation' ? 'text-rose-600' : 'text-blue-600'}`}>
                  {type === 'hiring' ? 'CONTRATAÇÃO' : type === 'resignation' ? 'RESCISÃO DE ESTÁGIO' : 'ABERTURA VAGA'}
                </span>
             </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-10 space-y-10 bg-slate-50/20 custom-scrollbar">
          {/* Progress Indicators */}
          {type === 'hiring' ? (
            <div className="flex items-center justify-center gap-4 py-4 border-b border-slate-100 mb-6 bg-white rounded-2xl shadow-sm border border-slate-100">
               {[
                 { id: 1, label: 'Preenchimento', active: true },
                 { id: 2, label: 'Assinaturas', active: false },
                 { id: 3, label: 'Análise DGEP', active: false }
               ].map((step, idx) => (
                 <div key={step.id} className="flex items-center gap-3">
                   <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black ${step.active ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'bg-slate-100 text-slate-400'}`}>
                     {step.id}
                   </div>
                   <span className={`text-[10px] font-black uppercase tracking-widest ${step.active ? 'text-emerald-700' : 'text-slate-400'}`}>{step.label}</span>
                   {idx < 2 && <ArrowRight className="w-3 h-3 text-slate-300" />}
                 </div>
               ))}
            </div>
          ) : (
            <div className="flex items-center justify-center gap-4 py-4 border-b border-slate-100 mb-6 bg-white rounded-2xl shadow-sm border border-slate-100">
               {[
                 { id: 1, label: type === 'resignation' ? 'Rescisão' : 'Solicitação', active: true },
                 { id: 2, label: 'Análise DGEP', active: false }
               ].map((step, idx) => (
                 <div key={step.id} className="flex items-center gap-3">
                   <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black ${step.active ? (type === 'resignation' ? 'bg-rose-600 text-white shadow-lg shadow-rose-100' : 'bg-blue-600 text-white shadow-lg shadow-blue-100') : 'bg-slate-100 text-slate-400'}`}>
                     {step.id}
                   </div>
                   <span className={`text-[10px] font-black uppercase tracking-widest ${step.active ? (type === 'resignation' ? 'text-rose-700' : 'text-blue-700') : 'text-slate-400'}`}>{step.label}</span>
                   {idx < 1 && <ArrowRight className="w-3 h-3 text-slate-300" />}
                 </div>
               ))}
            </div>
          )}

          <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden">
            <div className="bg-slate-900 px-8 py-5 flex items-center justify-between">
               <div className="flex items-center gap-3">
                 <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white">
                    <UserPlus className="w-4 h-4" />
                 </div>
                 <h3 className="text-[11px] font-black text-white uppercase tracking-[0.2em]">Formulário do Requerimento</h3>
               </div>
               <div className="px-3 py-1 bg-white/10 rounded-lg text-[9px] font-black text-white tracking-widest uppercase">
                 {type === 'hiring' ? 'CONTRATAÇÃO' : 'ABERTURA VAGA'}
               </div>
            </div>
            
            <div className="p-10 space-y-12">
              {type === 'opening' ? (
                <div className="space-y-10">
                  <div className="space-y-4">
                    <label className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.15em]">
                      <Building2 className="w-3 h-3" /> LOCAL DE LOTAÇÃO (UNIDADE/SETOR)
                    </label>
                    <div className="relative">
                      <select 
                        className="w-full bg-blue-50/30 border border-blue-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all appearance-none cursor-pointer"
                        value={formData.sector}
                        onChange={e => setFormData({...formData, sector: e.target.value})}
                      >
                        <option value="">Selecione o setor...</option>
                        {[...(profile.sectors || [])].sort((a, b) => a.localeCompare(b, 'pt-BR', { sensitivity: 'base' })).map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                      <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-blue-400">
                        <ArrowDown className="w-4 h-4" />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div className="space-y-4">
                      <label className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.15em]">
                        <Clock className="w-3 h-3" /> HORÁRIO DE ESTÁGIO
                      </label>
                      <div className="flex items-center gap-4">
                        <input 
                          type="time"
                          className="flex-1 max-w-[160px] bg-blue-50/30 border border-blue-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all cursor-pointer"
                          value={formData.startTime}
                          onChange={e => setFormData({...formData, startTime: e.target.value})}
                        />
                        <span className="text-blue-400 font-bold uppercase text-[10px] tracking-widest">às</span>
                        <input 
                          type="time"
                          className="flex-1 max-w-[160px] bg-blue-50/30 border border-blue-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all cursor-pointer"
                          value={formData.endTime}
                          onChange={e => setFormData({...formData, endTime: e.target.value})}
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <label className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.15em]">
                        <Clock className="w-3 h-3" /> TURNO DO ESTÁGIO
                      </label>
                      <div className="flex bg-blue-50/50 p-1.5 rounded-2xl border border-blue-100 max-w-xs">
                        {['Manhã', 'Tarde'].map(p => (
                          <button
                            key={p}
                            type="button"
                            onClick={() => handlePeriodChange(p as any)}
                            className={`flex-1 py-4 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${formData.period === p ? 'bg-white border-blue-200 text-blue-600 shadow-lg shadow-blue-100/50' : 'text-blue-400/60 hover:text-blue-500 hover:bg-white/50'}`}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div className="space-y-4">
                      <label className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.15em]">
                        <GraduationCap className="w-3 h-3" /> CURSO PRETENDIDO
                      </label>
                      <input 
                        type="text"
                        placeholder="Ex: Administração, Direito, etc."
                        className="w-full bg-blue-50/30 border border-blue-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                        value={formData.course}
                        onChange={e => setFormData({...formData, course: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.15em]">
                      <Mail className="w-3 h-3" /> E-MAIL PARA RETORNO DE CURRÍCULOS
                    </label>
                    <input 
                      type="email"
                      placeholder="seuemail@cmc.pr.gov.br"
                      className="w-full bg-blue-50/30 border border-blue-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                      value={formData.supervisor.email}
                      onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, email: e.target.value}})}
                    />
                  </div>

                  <div className="space-y-4">
                    <label className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-[0.15em]">
                      <FileText className="w-3 h-3" /> DESCRIÇÃO DAS ATIVIDADES
                    </label>
                    <textarea 
                      rows={6}
                      placeholder="Descreva as tarefas que o estagiário irá desempenhar no setor..."
                      className="w-full bg-blue-50/30 border border-blue-100 rounded-2xl px-6 py-5 text-sm font-medium text-slate-700 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all resize-none"
                      value={formData.activities}
                      onChange={e => setFormData({...formData, activities: e.target.value})}
                    />
                  </div>
                </div>
              ) : type === 'resignation' ? (
                <div className="space-y-10">
                  {/* LOCAL DE LOTAÇÃO */}
                  <div className="space-y-4">
                    <label className="flex items-center gap-2 text-[10px] font-black text-rose-600 uppercase tracking-[0.15em]">
                      <Building2 className="w-3 h-3" /> LOCAL DE LOTAÇÃO (UNIDADE/SETOR)
                    </label>
                    <div className="relative">
                      <select 
                        className="w-full bg-rose-50/30 border border-rose-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-500 transition-all appearance-none cursor-pointer"
                        value={formData.sector}
                        onChange={e => setFormData({...formData, sector: e.target.value})}
                      >
                        <option value="">Selecione o setor...</option>
                        {[...(profile.sectors || [])].sort((a, b) => a.localeCompare(b, 'pt-BR', { sensitivity: 'base' })).map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                      <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-rose-400">
                        <ArrowDown className="w-4 h-4" />
                      </div>
                    </div>
                  </div>

                  {/* NOME COMPLETO DO ESTAGIÁRIO */}
                  <div className="space-y-4">
                    <label className="flex items-center gap-2 text-[10px] font-black text-rose-600 uppercase tracking-[0.15em]">
                      <User className="w-3 h-3" /> NOME COMPLETO DO ESTAGIÁRIO
                    </label>
                    <input 
                      type="text"
                      placeholder="Nome completo do estagiário conforme RG"
                      className="w-full bg-rose-50/30 border border-rose-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-500 transition-all uppercase"
                      value={formData.student.name}
                      onChange={e => setFormData({...formData, student: {...formData.student, name: e.target.value.toUpperCase()}})}
                    />
                  </div>

                  {/* DATA DE DESLIGAMENTO */}
                  <div className="space-y-4">
                    <label className="flex items-center gap-2 text-[10px] font-black text-rose-600 uppercase tracking-[0.15em]">
                      <Clock className="w-3 h-3" /> DATA DE DESLIGAMENTO (A PARTIR DE)
                    </label>
                    <input 
                      type="date"
                      className="w-full bg-rose-50/30 border border-rose-100 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-500 transition-all cursor-pointer"
                      value={formatInputDate(formData.startDate)}
                      onChange={e => setFormData({...formData, startDate: e.target.value})}
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-12">
                  {/* Identificação da Vaga */}
                  <section>
                    <div className="flex items-center gap-3 mb-8">
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-[12px] uppercase font-black text-slate-800 tracking-widest">IDENTIFICAÇÃO DA VAGA</h4>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Setor e Período de Estágio</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">SETOR / GABINETE</label>
                        <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                          value={formData.sector}
                          onChange={e => setFormData({...formData, sector: e.target.value})}
                        >
                          <option value="">Selecione o setor...</option>
                          {[...(profile.sectors || [])].sort((a, b) => a.localeCompare(b, 'pt-BR', { sensitivity: 'base' })).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">DATA INICIAL DESEJADA</label>
                        <input 
                          type="date"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all appearance-none"
                          value={formatInputDate(formData.startDate)}
                          onChange={e => setFormData({...formData, startDate: e.target.value})}
                        />
                        <p className="text-[9px] text-slate-400 font-bold italic ml-1">* Mínimo 07 dias úteis (Médio) ou 15 dias (Superior)</p>
                      </div>
                    </div>
                  </section>

                  {/* Dados do Estudante */}
                  <section>
                    <div className="flex items-center gap-3 mb-8">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-[12px] uppercase font-black text-slate-800 tracking-widest">DADOS DO ESTUDANTE</h4>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Informações Pessoais e Acadêmicas</p>
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">NOME COMPLETO DO ESTUDANTE</label>
                          <input 
                            type="text"
                            placeholder="Nome completo conforme RG"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all uppercase"
                            value={formData.student.name}
                            onChange={e => setFormData({...formData, student: {...formData.student, name: e.target.value.toUpperCase()}})}
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">DATA DE NASCIMENTO DO ESTUDANTE</label>
                          <input 
                            type="date"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all cursor-pointer"
                            value={formatInputDate(formData.student.birthDate)}
                            onChange={e => setFormData({...formData, student: {...formData.student, birthDate: e.target.value}})}
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">NÍVEL DE ESCOLARIDADE</label>
                          <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl">
                            {['Médio', 'Técnico', 'Superior', 'Pós Graduação'].map(l => (
                              <button
                                key={l}
                                type="button"
                                onClick={() => setFormData({...formData, level: l as any})}
                                className={`flex-1 py-2.5 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${formData.level === l ? 'bg-white text-emerald-600 shadow-md shadow-emerald-100/50' : 'text-slate-400 hover:text-slate-500'}`}
                              >
                                {l}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">CURSO / FORMAÇÃO</label>
                          <input 
                            type="text"
                            placeholder="Ex: Direito, Administração, Ensino Médio..."
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                            value={formData.course}
                            onChange={e => setFormData({...formData, course: e.target.value})}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">ATIVIDADES A SEREM DESENVOLVIDAS</label>
                        <textarea 
                          rows={4}
                          placeholder="Descreva as tarefas que o estagiário irá desempenhar no setor..."
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-medium text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
                          value={formData.activities}
                          onChange={e => setFormData({...formData, activities: e.target.value})}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                        <div className="bg-slate-50 border border-slate-100 rounded-[24px] p-6 flex flex-col gap-4">
                           <div className="flex items-center justify-between">
                             <span className="text-[10px] font-black text-slate-700 uppercase tracking-wider">Estágio Obrigatório?</span>
                             <label className="relative inline-flex items-center cursor-pointer">
                               <input 
                                  type="checkbox" 
                                  className="sr-only peer"
                                  checked={formData.student.isMandatory}
                                  onChange={e => setFormData({...formData, student: {...formData.student, isMandatory: e.target.checked}})}
                               />
                               <div className="w-11 h-6 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-emerald-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                             </label>
                           </div>
                           <p className="text-[9px] text-slate-400 font-bold leading-relaxed uppercase">Marque apenas se houver necessidade de convênio específico para estágio curricular obrigatório.</p>
                        </div>
                        <div className="space-y-2">
                           <div className="flex items-center justify-between ml-1">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CPF DO ESTUDANTE</label>
                              {formData.student.cpf.length === 14 && !validateCPF(formData.student.cpf) && (
                                <span className="text-[9px] font-black text-red-500 uppercase tracking-tight">CPF Inválido</span>
                              )}
                           </div>
                           <input 
                              type="text"
                              placeholder="000.000.000-00"
                              className={`w-full bg-slate-50 border rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 transition-all font-mono ${
                                formData.student.cpf.length === 14 && !validateCPF(formData.student.cpf)
                                  ? 'border-red-200 focus:ring-red-500/20 focus:border-red-500 text-red-600'
                                  : 'border-slate-200 focus:ring-emerald-500/20 focus:border-emerald-500'
                              }`}
                              value={formData.student.cpf}
                              onChange={e => setFormData({...formData, student: {...formData.student, cpf: formatCPF(e.target.value)}})}
                           />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                        <div className="space-y-2">
                           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">E-MAIL DO ESTUDANTE</label>
                           <input 
                              type="email"
                              placeholder="estudante@email.com"
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all lowercase"
                              value={formData.student.email}
                              onChange={e => setFormData({...formData, student: {...formData.student, email: e.target.value}})}
                           />
                        </div>
                        <div className="space-y-2">
                           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">TELEFONE / WHATSAPP</label>
                           <input 
                              type="text"
                              placeholder="(00) 00000-0000"
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
                              value={formData.student.phone}
                              onChange={e => setFormData({...formData, student: {...formData.student, phone: formatPhone(e.target.value)}})}
                           />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                        <div className="space-y-2">
                           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">HORÁRIO DO ESTÁGIO</label>
                           <div className="flex items-center gap-4">
                             <input 
                                type="time"
                                className="flex-1 max-w-[160px] bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
                                value={formData.startTime}
                                onChange={e => setFormData({...formData, startTime: e.target.value})}
                             />
                             <span className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">às</span>
                             <input 
                                type="time"
                                className="flex-1 max-w-[160px] bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
                                value={formData.endTime}
                                onChange={e => setFormData({...formData, endTime: e.target.value})}
                             />
                           </div>
                        </div>
                        
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">TURNO DO ESTÁGIO</label>
                          <div className="flex bg-slate-100 p-1.5 rounded-2xl max-w-xs">
                            {['Manhã', 'Tarde'].map(p => (
                              <button
                                key={p}
                                type="button"
                                onClick={() => handlePeriodChange(p as any)}
                                className={`flex-1 py-3 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${formData.period === p ? 'bg-white text-emerald-600 shadow-md shadow-emerald-100/50' : 'text-slate-400 hover:text-slate-500'}`}
                              >
                                {p}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>

                  {/* Dados do Supervisor */}
                  <section>
                    <div className="flex items-center gap-3 mb-8">
                      <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                        <Briefcase className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-[12px] uppercase font-black text-slate-800 tracking-widest">DADOS DO SUPERVISOR</h4>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Informações do Responsável Direto</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">NOME DO SUPERVISOR</label>
                        <input 
                          type="text"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all uppercase"
                          value={formData.supervisor.name}
                          onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, name: e.target.value.toUpperCase()}})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">CARGO / FUNÇÃO</label>
                        <input 
                          type="text"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                          value={formData.supervisor.role}
                          onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, role: e.target.value}})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">RG</label>
                        <input 
                          type="text"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
                          value={formData.supervisor.rg}
                          onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, rg: e.target.value}})}
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between ml-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CPF</label>
                          {formData.supervisor.cpf.length === 14 && !validateCPF(formData.supervisor.cpf) && (
                            <span className="text-[9px] font-black text-red-500 uppercase tracking-tight">CPF Inválido</span>
                          )}
                        </div>
                        <input 
                          type="text"
                          placeholder="000.000.000-00"
                          className={`w-full bg-slate-50 border rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 transition-all font-mono ${
                            formData.supervisor.cpf.length === 14 && !validateCPF(formData.supervisor.cpf)
                              ? 'border-red-200 focus:ring-red-500/20 focus:border-red-500 text-red-600'
                              : 'border-slate-200 focus:ring-emerald-500/20 focus:border-emerald-500'
                          }`}
                          value={formData.supervisor.cpf}
                          onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, cpf: formatCPF(e.target.value)}})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">E-MAIL INSTITUCIONAL</label>
                        <input 
                          type="email"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                          value={formData.supervisor.email}
                          onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, email: e.target.value}})}
                        />
                      </div>
                       <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">TELEFONE / WHATSAPP</label>
                         <input 
                           type="text"
                           placeholder="(00) 00000-0000"
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
                           value={formData.supervisor.phone}
                           onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, phone: formatPhone(e.target.value)}})}
                         />
                       </div>

                       <div className="space-y-2 md:col-span-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">ESCOLARIDADE DO SUPERVISOR</label>
                         <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl max-w-md">
                           {['Médio / Técnico', 'Superior'].map(lvl => (
                             <button
                               key={lvl}
                               type="button"
                               onClick={() => setFormData({...formData, supervisor: {...formData.supervisor, education: lvl}})}
                               className={`flex-1 py-1.5 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${
                                 formData.supervisor.education === lvl
                                   ? 'bg-white text-emerald-600 shadow-md shadow-emerald-100/50'
                                   : 'text-slate-400 hover:text-slate-500'
                               }`}
                             >
                               {lvl}
                             </button>
                           ))}
                         </div>
                       </div>

                       {formData.supervisor.education === 'Superior' && (
                         <div className="space-y-2 md:col-span-2">
                           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">CURSO / ÁREA DA FORMAÇÃO DO SUPERVISOR</label>
                           <input 
                             type="text"
                             placeholder="Ex: Administração, Ciências Contábeis, Psicologia..."
                             className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all uppercase"
                             value={formData.supervisor.course}
                             onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, course: e.target.value.toUpperCase()}})}
                           />
                         </div>
                       )}

                       <div className="space-y-2 md:col-span-2">
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">EXPERIÊNCIA NA ÁREA DE CONTRATAÇÃO</label>
                         <textarea 
                           rows={3}
                           placeholder="Descreva a experiência do supervisor na área de contratação (Ex: Atuação de 5 anos no setor...)."
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                           value={formData.supervisor.experience}
                           onChange={e => setFormData({...formData, supervisor: {...formData.supervisor, experience: e.target.value}})}
                         />
                       </div>
                     </div>
                   </section>

                    {/* Secao de Documentos Anexados */}
                    <section className="border-t border-slate-100 pt-12">
                      <div className="flex items-center gap-3 mb-8">
                        <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                          <Paperclip className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-[12px] uppercase font-black text-slate-800 tracking-widest">DOCUMENTOS OBRIGATÓRIOS PARA CONTRATAÇÃO</h4>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Anexe os documentos solicitados em formato PDF ou Imagem</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {documentList.map((docItem) => {
                          const slotKey = docItem.key;
                          const docObj = (formData.documents as any)[slotKey];
                          const isUploading = uploadingSlots[slotKey];
                          const isUnder18 = isUnder18Student();
                          const isRequired = docItem.required || (slotKey === 'parent' && isUnder18);

                          return (
                            <div 
                              key={slotKey} 
                              className={`p-5 rounded-2xl border transition-all ${
                                isRequired && !docObj 
                                  ? 'bg-red-50/10 border-red-100 hover:border-red-200' 
                                  : docObj
                                    ? 'bg-emerald-50/10 border-emerald-100 hover:border-emerald-200'
                                    : 'bg-slate-50/50 border-slate-200 hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-4 mb-3">
                                <div>
                                  <h5 className="text-[11px] font-black text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                                    {docItem.title}
                                    {isRequired ? (
                                      <span className="text-[9px] font-black text-red-500 bg-red-100 px-1.5 py-0.5 rounded-md uppercase">Obrigatório</span>
                                    ) : (
                                      <span className="text-[9px] font-black text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-md uppercase">Opcional</span>
                                    )}
                                  </h5>
                                  <p className="text-[10px] text-slate-500 font-bold leading-relaxed mt-1">
                                    {docItem.description}
                                  </p>
                                </div>
                              </div>

                              {docObj ? (
                                <div className="bg-white border border-slate-100 rounded-xl p-3 flex items-center justify-between gap-3 shadow-sm">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <Paperclip className="w-4 h-4 text-emerald-600 shrink-0" />
                                    <span className="text-[11px] font-bold text-slate-700 truncate">
                                      {docObj.name}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-1 shrink-0">
                                    <button
                                      type="button"
                                      onClick={() => handleDocDownload(docObj.fileId, docObj.name)}
                                      title="Baixar comprovante"
                                      className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-all cursor-pointer"
                                    >
                                      <Download className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => removeDoc(slotKey)}
                                      title="Remover comprovante"
                                      className="p-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-all cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <label className={`border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-all ${
                                  isRequired
                                    ? 'border-red-200 hover:border-red-300 hover:bg-red-50/5'
                                    : 'border-slate-300 hover:border-slate-400 hover:bg-slate-50/30'
                                }`}>
                                  <input
                                    type="file"
                                    accept="image/*,application/pdf"
                                    onChange={(e) => handleFileUpload(slotKey, e.target.files?.[0] || null)}
                                    className="hidden"
                                    disabled={isUploading}
                                  />
                                  {isUploading ? (
                                    <div className="flex flex-col items-center gap-2">
                                      <Loader2 className="w-5 h-5 text-emerald-600 animate-spin" />
                                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Enviando...</span>
                                    </div>
                                  ) : (
                                    <div className="flex flex-col items-center gap-1.5">
                                      <Paperclip className={`w-5 h-5 ${isRequired ? 'text-red-400' : 'text-slate-400'}`} />
                                      <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Anexar PDF ou Imagem</span>
                                    </div>
                                  )}
                                </label>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </section>
                  </div>
              )}

              {type === 'opening' ? (
                <div className="bg-blue-50/50 rounded-[28px] p-8 border border-blue-100 flex items-start gap-6">
                   <div className="w-12 h-12 rounded-2xl bg-blue-100 flex items-center justify-center shrink-0 border border-blue-200 shadow-sm shadow-blue-100 font-bold uppercase">
                      <ShieldCheck className="w-6 h-6 text-blue-700" />
                   </div>
                   <div>
                      <h5 className="text-[11px] font-black text-blue-900 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                        PRÓXIMOS PASSOS
                      </h5>
                      <p className="text-[11px] text-blue-700/80 leading-relaxed font-bold uppercase tracking-tight">
                        Após o envio, a DGEP analisará a disponibilidade de vagas e o perfil solicitado. Você receberá a confirmação e os currículos selecionados no e-mail informado acima.
                      </p>
                   </div>
                </div>
              ) : type === 'resignation' ? (
                <div className="bg-rose-50/50 rounded-[28px] p-8 border border-rose-100 flex items-start gap-6">
                   <div className="w-12 h-12 rounded-2xl bg-rose-100 flex items-center justify-center shrink-0 border border-rose-200 shadow-sm shadow-rose-100 font-bold uppercase">
                      <ShieldCheck className="w-6 h-6 text-rose-700" />
                   </div>
                   <div>
                      <h5 className="text-[11px] font-black text-rose-900 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                        PRÓXIMOS PASSOS
                      </h5>
                      <p className="text-[11px] text-rose-700/80 leading-relaxed font-bold uppercase tracking-tight">
                        Após o envio, a DGEP processará o desligamento do estagiário a partir da data de desligamento informada.
                      </p>
                   </div>
                </div>
              ) : (
                <div className="bg-amber-50/50 rounded-[28px] p-8 border border-amber-100 flex items-start gap-6">
                   <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center shrink-0 border border-amber-200 shadow-sm shadow-amber-100 font-bold uppercase">
                      <AlertCircle className="w-6 h-6 text-amber-700" />
                   </div>
                   <div>
                      <h5 className="text-[11px] font-black text-amber-900 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                        <ShieldCheck className="w-3 h-3" /> ATENÇÃO AOS FLUXOS
                      </h5>
                      <p className="text-[11px] text-amber-700/80 leading-relaxed font-bold uppercase tracking-tight">
                        A CONTRATAÇÃO SÓ É FINALIZADA APÓS AS ASSINATURAS DIGITAIS DO SUPERVISOR E ESTAGIÁRIO, SEGUIDA DA ANÁLISE DO DGEP. CERTIFIQUE-SE DE QUE OS E-MAILS INFORMADOS ESTÃO CORRETOS.
                      </p>
                   </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 sm:p-8 border-t border-slate-100 flex flex-col sm:flex-row gap-4 bg-white sticky bottom-0 shrink-0 shadow-[0_-10px_30px_rgba(0,0,0,0.02)]">
          <div className="flex-1 flex flex-col sm:flex-row gap-3">
            <button 
              type="button" 
              onClick={onClose}
              className="flex-1 px-4 sm:px-8 py-3 sm:py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:bg-slate-100 rounded-2xl transition-all border border-slate-100 flex items-center justify-center gap-2 group"
            >
              <X className="w-4 h-4 group-hover:rotate-90 transition-transform" /> CANCELAR
            </button>
            <button 
              type="button"
              onClick={() => handleSave('draft')}
              disabled={loading}
              className="flex-1 px-4 sm:px-8 py-3 sm:py-4 bg-white text-slate-700 rounded-2xl border-2 border-slate-200 shadow-md hover:bg-slate-50 transition-all font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" /> Salvar Rascunho
            </button>
          </div>
          <button 
            type="button"
            onClick={() => handleSave(type === 'hiring' ? 'pending' : 'submitted')}
            disabled={loading}
            className={`sm:w-1/3 px-4 sm:px-8 py-4 sm:py-4 text-white rounded-2xl shadow-xl transition-all font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 group disabled:opacity-50 ${type === 'hiring' ? 'bg-emerald-600 shadow-emerald-100 hover:bg-emerald-700' : type === 'resignation' ? 'bg-rose-600 shadow-rose-100 hover:bg-rose-700' : 'bg-blue-600 shadow-blue-100 hover:bg-blue-700'}`}
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              <>
                <Send className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /> 
                {type === 'hiring' ? 'SALVAR E PROSSEGUIR' : type === 'resignation' ? 'ENVIAR RESCISÃO' : 'ENVIAR SOLICITAÇÃO (CIEE)'}
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function ArrowRight(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
  );
}

function UserPlus(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
  );
}


function CheckCircle2(props: any) {
  return (
    <svg 
      {...props} 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
