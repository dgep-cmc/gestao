import React from 'react';
import { motion } from 'motion/react';
import { 
  FileText, 
  ArrowLeft, 
  Clock, 
  CheckCircle2, 
  Signature, 
  Share2, 
  Copy,
  User,
  Building2,
  Calendar,
  AlertCircle,
  Download,
  XCircle,
  Archive,
  ArrowUpCircle,
  ShieldCheck,
  Mail,
  Paperclip,
  Eye
} from 'lucide-react';
import { HiringRequest, HiringStatus, UserProfile } from '../../types';
import { format, isValid, parseISO } from 'date-fns';
import { toast } from 'react-hot-toast';
import { generateHiringPDF, generateKinshipPDF } from '../../lib/pdfGenerator';
import { emailNotificationService } from '../../services/emailNotificationService';
import { frequencyService } from '../../services/frequencyService';

interface HiringRequestTrackingProps {
  request: HiringRequest;
  onClose: () => void;
  profile: UserProfile;
  viewMode?: 'admin' | 'manager';
  onApprove?: (request: HiringRequest) => void;
  onReject?: (request: HiringRequest) => void;
  onArchive?: (request: HiringRequest) => void;
  onUnarchive?: (request: HiringRequest) => void;
  onEdit?: (request: HiringRequest) => void;
}

export default function HiringRequestTracking({ 
  request, 
  onClose, 
  profile,
  viewMode = 'admin',
  onApprove,
  onReject,
  onArchive,
  onUnarchive,
  onEdit
}: HiringRequestTrackingProps) {
  const safeFormat = (dateStr: string | undefined | null, formatStr: string) => {
    if (!dateStr) return '---';
    try {
      const date = parseISO(dateStr);
      if (!isValid(date)) {
        // Try direct Date constructor as fallback for non-ISO formats if any
        const altDate = new Date(dateStr);
        if (!isValid(altDate)) return '---';
        return format(altDate, formatStr);
      }
      return format(date, formatStr);
    } catch (e) {
      return '---';
    }
  };

  const handleDownloadDoc = async (fileId: string | undefined | null, fileName: string) => {
    if (!fileId) return;
    if (fileId.startsWith('http://') || fileId.startsWith('https://')) {
      window.open(fileId, '_blank');
      return;
    }
    try {
      const loadingToast = toast.loading(`Baixando ${fileName}...`);
      const { data } = await frequencyService.downloadFile(fileId);
      const url = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 100);
      toast.success("Download concluído", { id: loadingToast });
    } catch (err) {
      toast.error("Erro ao baixar documento");
    }
  };

  const handleViewDoc = (fileId: string | undefined | null, fileName: string) => {
    if (!fileId) return;
    if (fileId.startsWith('http://') || fileId.startsWith('https://')) {
      window.open(fileId, '_blank');
      return;
    }
    if (fileId.startsWith('data:')) {
      const w = window.open();
      if (w) {
        w.document.write(`<iframe src="${fileId}" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
      } else {
        toast.error("Bloqueador de popups ativo. Permita popups para visualizar o arquivo.");
      }
      return;
    }
    handleDownloadDoc(fileId, fileName);
  };

  const copyLink = (role: 'supervisor' | 'student') => {
    let baseUrl = window.location.origin + window.location.pathname;
    if (!baseUrl.endsWith('/')) {
      baseUrl += '/';
    }
    const url = role === 'supervisor' ? `${baseUrl}?signSupervisor=${request.id}` : `${baseUrl}?sign=${request.id}`;
    navigator.clipboard.writeText(url);
    toast.success('Link copiado!');
  };

  const sendEmailNotification = async (role: 'supervisor' | 'student') => {
    try {
      if (role === 'supervisor') {
        if (!request.supervisor.email) {
          toast.error('E-mail do supervisor não informado!');
          return;
        }
        toast.loading('Preparando e-mail para supervisor...', { id: 'sendMail' });
        await emailNotificationService.sendSupervisorInvite(request);
        toast.success(`E-mail enfileirado para envio: ${request.supervisor.email}`, { id: 'sendMail' });
      } else {
        if (!request.student?.email) {
          toast.error('E-mail do estudante não informado!');
          return;
        }
        toast.loading('Preparando e-mail para estudante...', { id: 'sendMail' });
        await emailNotificationService.sendStudentInvite(request);
        toast.success(`E-mail enfileirado para envio: ${request.student.email}`, { id: 'sendMail' });
      }
    } catch (err) {
      console.error(err);
      toast.error('Erro ao registrar envio de e-mail.', { id: 'sendMail' });
    }
  };

  const getStatusLabel = (status: HiringStatus) => {
    switch (status) {
      case 'draft': return '1. EM PREENCHIMENTO';
      case 'pending': return '2. AGUARDANDO ASSINATURAS';
      case 'supervisor_signed': return '2. AG. ASS. ESTUDANTE';
      case 'student_signed': return '2. AG. ASS. SUPERVISOR';
      case 'submitted': return '3. AG. DGEP';
      case 'approved': return 'APROVADO';
      case 'rejected': return 'DEVOLVIDO';
      case 'archived': return 'ARQUIVADO';
      default: return 'EM PROCESSAMENTO';
    }
  };

  const statusLabel = request.status === 'submitted' ? '3. AG. DGEP' : getStatusLabel(request.status);
  const isHiring = request.type === 'hiring';
  const isSignaturesComplete = isHiring
    ? !!request.supervisor?.signature && !!request.student?.signature
    : true;

  return (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto">
      <div className="p-4 sm:p-8 max-w-5xl mx-auto w-full space-y-6">
        {/* Top Header */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-xl bg-white text-slate-400 hover:text-slate-600 shadow-sm border border-slate-200 flex items-center justify-center transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-4 flex-1">
            <div>
              <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">
                {request.type === 'resignation' 
                  ? 'RESCISÃO DE ESTÁGIO' 
                  : request.type === 'opening' 
                    ? 'ABERTURA DE VAGA DE ESTÁGIO' 
                    : 'REQUERIMENTO DE CONTRATAÇÃO'}
              </h2>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">DGEP - Diretoria de Gestão de Pessoas</p>
            </div>
            <div className="px-4 py-1.5 bg-[#fff0f4] text-[#ff0044] rounded-full text-[10px] font-black uppercase tracking-widest border border-[#ffe0e6]">
              {statusLabel}
            </div>
            {onEdit && (request.status === 'draft' || request.status === 'rejected') && (
              <button 
                onClick={() => onEdit(request)}
                className={`ml-auto text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 shadow-lg ${request.type === 'resignation' ? 'bg-rose-600 hover:bg-rose-700 shadow-rose-100' : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100'}`}
              >
                <FileText className="w-4 h-4" /> Editar Agora
              </button>
            )}
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[32px] border border-slate-200 shadow-xl overflow-hidden"
        >
          {/* Section Indicator Bar */}
          <div className={`${request.type === 'resignation' ? 'bg-rose-600' : 'bg-[#2563eb]'} px-8 py-5 flex items-center gap-3`}>
             <User className="w-5 h-5 text-white/80" />
             <span className="text-xs font-black text-white uppercase tracking-[0.2em]">
               {request.type === 'resignation' ? 'REQUERIMENTO DE RESCISÃO DE ESTÁGIO' : 'PREENCHIMENTO DO REQUERIMENTO'}
             </span>
          </div>

          <div className="p-8 sm:p-12 space-y-12">
            
            {/* Rejection Reason Alert */}
            {request.status === 'rejected' && request.rejectReason && (
              <div className="bg-red-50 border border-red-100 p-6 rounded-3xl space-y-2">
                 <div className="flex items-center gap-3 text-red-600">
                    <AlertCircle className="w-5 h-5" />
                    <h4 className="text-[10px] font-black uppercase tracking-widest">MOTIVO DA DEVOLUÇÃO</h4>
                 </div>
                 <p className="text-sm font-medium text-red-700 leading-relaxed italic">
                   "{request.rejectReason}"
                 </p>
                 <div className="pt-2 flex items-center gap-2 text-[9px] font-bold text-red-400 uppercase tracking-tight">
                    <span>Devolvido por {request.rejectedBy || 'DGEP'}</span>
                    <span>•</span>
                    <span>{safeFormat(request.rejectedAt, 'dd/MM/yyyy HH:mm')}</span>
                 </div>
              </div>
            )}

            {request.type === 'resignation' ? (
              <div className="space-y-8 py-4">
                <div className="text-center space-y-6 max-w-2xl mx-auto py-6">
                  <h3 className="text-xl font-black text-rose-600 uppercase tracking-wide">RESCISÃO DE ESTÁGIO</h3>
                  
                  <div className="space-y-4 text-slate-700 font-medium leading-relaxed bg-rose-50/20 border border-rose-100/30 p-8 sm:p-10 rounded-[32px] text-base shadow-sm">
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">REQUERIMENTO DE DESLIGAMENTO DE ESTAGIÁRIO</p>
                    <p className="text-base sm:text-lg text-slate-800 font-bold leading-relaxed">
                      Solicitamos a rescisão do termo de compromisso de estágio do(a) estagiário(a) <span className="font-extrabold text-rose-600 underline decoration-rose-300 decoration-2">{request.student?.name || 'ESTUDANTE'}</span>, lotado(a) no setor <span className="font-extrabold text-slate-900">{request.sector}</span>, a partir de <span className="font-extrabold text-slate-900">{safeFormat(request.startDate, 'dd/MM/yyyy')}</span>.
                    </p>
                  </div>

                  <div className="text-slate-500 text-xs font-bold uppercase tracking-widest">
                    Curitiba, {safeFormat(request.createdAt, 'dd/MM/yyyy')}.
                  </div>

                  {/* Centered Digital Signature Box */}
                  <div className="pt-6 border-t border-slate-100 flex flex-col items-center">
                    <div className="bg-[#f8f9fc] border border-slate-200/60 p-6 rounded-2xl max-w-md w-full shadow-sm flex flex-col items-center text-center space-y-3">
                      <div className="flex items-center gap-2 text-rose-600">
                        <ShieldCheck className="w-5 h-5" />
                        <span className="text-[9px] font-black uppercase tracking-widest">ASSINATURA DIGITAL VALIDADA</span>
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-900 uppercase">
                          {request.supervisor?.name?.toUpperCase() || (request.createdBy ? request.createdBy.split('@')[0].toUpperCase() : 'SUPERVISOR')}
                        </p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase mt-0.5">Assinatura Eletrônica do Supervisor / Gestor</p>
                        <p className="text-[9px] text-slate-400 font-bold break-all mt-1 font-mono">ID: {(request.id.substring(0, 8) + request.id.substring(request.id.length - 8)).toUpperCase()}</p>
                      </div>
                      <div className="text-[8px] font-black text-rose-600 bg-rose-50 px-3 py-1 rounded-full uppercase tracking-wider border border-rose-100">
                        Assinado em {safeFormat(request.createdAt, 'dd/MM/yyyy HH:mm:ss')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : request.type === 'opening' ? (
              <>
                {/* Abertura de Vaga Layout */}
                {/* 1. Especificações da Vaga Solicitada */}
                <section className="space-y-8">
                  <div className="flex items-center gap-3 text-blue-600">
                    <Building2 className="w-5 h-5" />
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-blue-100 pb-1">IDENTIFICAÇÃO E ESPECIFICAÇÕES DA VAGA</h3>
                  </div>

                  <div className="space-y-8">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">SETOR / GABINETE SOLICITANTE</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                        {request.sector}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">PERÍODO DO ESTÁGIO</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                          {request.period === 'Manhã' ? 'MANHÃ (08:00 às 12:00)' : 'TARDE (14:00 às 18:00)'}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">CURSO / ÁREA REQUISITADA</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                          {request.course || 'QUALQUER ÁREA CORRELATA'}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">E-MAIL PARA RETORNO DE CURRÍCULOS</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                        {request.supervisor?.email || 'NÃO INFORMADO'}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">ATIVIDADES A SEREM DESENVOLVIDAS</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-xs font-medium text-slate-700 leading-relaxed min-h-[120px]">
                        {request.activities}
                      </div>
                    </div>
                  </div>
                </section>

                {/* Centered Digital Signature Box for Gestor (Opening request creator) */}
                <div className="pt-6 border-t border-slate-100 flex flex-col items-center">
                  <div className="bg-[#f8f9fc] border border-slate-200/60 p-6 rounded-2xl max-w-md w-full shadow-sm flex flex-col items-center text-center space-y-3">
                    <div className="flex items-center gap-2 text-blue-600">
                      <ShieldCheck className="w-5 h-5 animate-pulse" />
                      <span className="text-[9px] font-black uppercase tracking-widest">ASSINATURA DIGITAL VALIDADA</span>
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-900 uppercase">
                        {request.supervisor?.name?.toUpperCase() || (request.createdBy ? request.createdBy.split('@')[0].toUpperCase() : 'SOLICITANTE')}
                      </p>
                      <p className="text-[9px] text-slate-400 font-bold uppercase mt-0.5">Assinatura Eletrônica do GESTOR / SOLICITANTE</p>
                      <p className="text-[9px] text-slate-400 font-bold break-all mt-1 font-mono">ID: {(request.id.substring(0, 8) + request.id.substring(request.id.length - 8)).toUpperCase()}</p>
                    </div>
                    <div className="text-[8px] font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-full uppercase tracking-wider border border-blue-100">
                      Assinado em {safeFormat(request.createdAt, 'dd/MM/yyyy HH:mm:ss')}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* 1. Identificação da Vaga */}
                <section className="space-y-8">
                  <div className="flex items-center gap-3 text-blue-600">
                    <Building2 className="w-5 h-5" />
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-blue-100 pb-1">IDENTIFICAÇÃO DA VAGA</h3>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">SETOR / GABINETE</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                        {request.sector}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">DATA INICIAL DESEJADA</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                        {safeFormat(request.startDate, 'dd / MM / yyyy')}
                      </div>
                      <p className="text-[9px] text-slate-400 font-medium italic">* Mínimo 07 dias úteis (médio) ou 15 dias corridos (superior)</p>
                    </div>
                  </div>
                </section>

                {/* 2. Dados do Estudante */}
                <section className="space-y-8">
                  <div className="flex items-center gap-3 text-blue-600">
                    <CheckCircle2 className="w-5 h-5" />
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-blue-100 pb-1">DADOS DO ESTUDANTE</h3>
                  </div>

                  <div className="space-y-8">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">NOME COMPLETO DO ESTUDANTE</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                        {request.student?.name || 'VAGA ABERTA'}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">ESCOLARIDADE</label>
                      <div className="grid grid-cols-3 gap-4">
                        {['Nível Médio', 'Técnico', 'Superior'].map(lvl => (
                          <div 
                            key={lvl}
                            className={`py-4 rounded-xl text-center text-[10px] font-black uppercase tracking-widest transition-all ${
                              request.level === lvl 
                                ? 'bg-[#2563eb] text-white shadow-lg shadow-blue-200' 
                                : 'bg-[#f8f9fc] text-slate-300'
                            }`}
                          >
                            {lvl}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">CURSO (SÉ TÉCNICO OU SUPERIOR)</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                        {request.course}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">ATIVIDADES A SEREM DESENVOLVIDAS</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-xs font-medium text-slate-700 leading-relaxed min-h-[120px]">
                        {request.activities}
                      </div>
                    </div>

                    {request.type === 'hiring' && (
                      <div className="flex items-center gap-4 bg-[#f8f9fc] p-4 rounded-2xl border border-slate-100">
                        <div className={`w-6 h-6 rounded border flex items-center justify-center transition-colors ${request.student?.isMandatory ? 'bg-blue-600 border-blue-600' : 'bg-white border-slate-200'}`}>
                          {request.student?.isMandatory && <CheckCircle2 className="w-4 h-4 text-white" />}
                        </div>
                        <span className="text-xs font-bold text-slate-600">O estágio é obrigatório pela instituição?</span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">CPF DO ESTUDANTE</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 font-mono">
                          {request.student?.cpf || '---'}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">CONTATO / WHATSAPP</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 font-mono">
                          {request.student?.phone || '---'}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">PERÍODO DO ESTÁGIO</label>
                      <div className="grid grid-cols-2 gap-4">
                        {['Manhã', 'Tarde'].map(p => (
                          <div 
                            key={p}
                            className={`py-4 rounded-xl text-center text-[10px] font-black uppercase tracking-widest transition-all ${
                              request.period === p 
                                ? 'bg-[#2563eb] text-white shadow-lg shadow-blue-200' 
                                : 'bg-[#f8f9fc] text-slate-300'
                            }`}
                          >
                            PERÍODO {p.toUpperCase()} ({p === 'Manhã' ? '08:00 às 12:00' : '14:00 às 18:00'})
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </section>

                {/* 3. Dados do Supervisor */}
                <section className="space-y-8">
                  <div className="flex items-center gap-3 text-blue-600">
                    <FileText className="w-5 h-5" />
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-blue-100 pb-1">DADOS DO SUPERVISOR</h3>
                  </div>

                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">NOME DO SUPERVISOR</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                          {request.supervisor.name}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">CARGO DO SUPERVISOR</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800">
                          {request.supervisor.role}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">RG</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 font-mono">
                          {request.supervisor.rg}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">CPF</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 font-mono">
                          {request.supervisor.cpf}
                        </div>
                      </div>
                      <div className="space-y-2 text-wrap break-all">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">E-MAIL</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 break-all">
                          {request.supervisor.email}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">TELEFONE</label>
                        <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 font-mono">
                          {request.supervisor.phone}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">ESCOLARIDADE DO SUPERVISOR</label>
                        <div className="grid grid-cols-2 gap-4">
                          {['Médio / Técnico', 'Superior'].map(lvl => (
                            <div 
                              key={lvl}
                              className={`py-4 rounded-xl text-center text-[10px] font-black uppercase tracking-widest transition-all ${
                                request.supervisor.education === lvl || (lvl === 'Médio / Técnico' && request.supervisor.education === 'Médio')
                                  ? 'bg-[#2563eb] text-white shadow-lg shadow-blue-200' 
                                  : 'bg-[#f8f9fc] text-slate-300'
                              }`}
                            >
                              {lvl.toUpperCase()}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">CURSO / ÁREA (SE SUPERIOR)</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-sm font-bold text-slate-800 uppercase">
                        {request.supervisor.course || '---'}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">EXPERIÊNCIA NA ÁREA DE CONTRATAÇÃO</label>
                      <div className="w-full bg-[#f8f9fc] border border-slate-100 rounded-2xl px-6 py-4 text-xs font-medium text-slate-700 leading-relaxed min-h-[60px] text-wrap break-words">
                        {request.supervisor.experience || '---'}
                      </div>
                    </div>
                  </div>
                </section>

                {/* 4. Documentos Anexos (Admin exclusive) */}
                {viewMode === 'admin' && request.type === 'hiring' && (
                  <section className="space-y-8">
                    <div className="flex items-center gap-3 text-blue-600">
                      <Paperclip className="w-5 h-5" />
                      <h3 className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-blue-100 pb-1">DOCUMENTOS ANEXOS DO ESTUDANTE</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { key: 'rg', title: '1. Documento de Identidade (RG)', desc: 'RG do estudante.' },
                        { key: 'cpf', title: '2. CPF', desc: 'CPF do estudante.' },
                        { key: 'photo', title: '3. Foto 3x4 Colorida', desc: 'Foto 3x4 identificadora.' },
                        { key: 'bank', title: '4. Comprovante de Dados Bancários', desc: 'Banco, agência e conta.' },
                        { key: 'address', title: '5. Comprovante de Endereço', desc: 'Emitido nos últimos 30 dias.' },
                        { key: 'enrollment', title: '6. Declaração de Matrícula', desc: 'Emissão nos últimos 60 dias.' },
                        { key: 'parent', title: '7. RG e CPF do Responsável', desc: 'Obrigatório para menores.' },
                      ].map((docItem) => {
                        const docObj = request.documents?.[docItem.key as keyof typeof request.documents];
                        const isUnder18 = request.student?.birthDate ? (
                          (new Date().getTime() - new Date(request.student.birthDate).getTime()) / (1000 * 60 * 60 * 24 * 365) < 18
                        ) : false;
                        const isRequired = docItem.key !== 'parent' || isUnder18;

                        return (
                          <div 
                            key={docItem.key}
                            className={`p-5 rounded-2xl border transition-all ${
                              docObj 
                                ? 'bg-emerald-50/10 border-emerald-100 hover:border-emerald-200 shadow-sm'
                                : isRequired
                                  ? 'bg-red-50/5 border-red-100/55 opacity-60'
                                  : 'bg-slate-50/50 border-slate-100 opacity-50'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-4">
                              <div className="min-w-0">
                                <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider ${
                                  docObj 
                                    ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                                    : isRequired
                                      ? 'bg-red-50 text-red-500 border border-red-100'
                                      : 'bg-slate-50 text-slate-400 border border-slate-100'
                                }`}>
                                  {docObj ? 'Enviado' : isRequired ? 'Obrigatório' : 'Opcional'}
                                </span>
                                <h5 className="text-[11px] font-black text-slate-800 uppercase tracking-wide mt-2">
                                  {docItem.title}
                                </h5>
                                <p className="text-[9px] text-slate-400 font-bold truncate mt-0.5 uppercase">
                                  {docObj ? docObj.name : 'Não fornecido'}
                                </p>
                              </div>

                              {docObj && (
                                <div className="flex items-center gap-1.5 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => handleViewDoc(docObj.fileId, docObj.name)}
                                    title="Visualizar documento"
                                    className="p-2 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-100 border border-blue-100 transition-all cursor-pointer flex items-center gap-1 text-[8px] font-black uppercase tracking-wider"
                                  >
                                    <Eye className="w-3.5 h-3.5" /> Ver
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </section>
                )}

                {/* Signature Flow Area - Only for Hiring Type */}
                {request.type === 'hiring' && (
                  <div className="bg-white rounded-[40px] border border-slate-100 p-8 sm:p-10 shadow-inner bg-slate-50/30 grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Step 2: Supervisor Signature */}
                    <div className={`flex flex-col gap-6 transition-all min-h-[300px] h-full ${request.supervisor.signature ? 'bg-transparent' : 'bg-[#f8f9fc] rounded-[32px] border border-slate-100 p-8 shadow-sm text-slate-900'}`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 ${request.supervisor.signature ? 'bg-emerald-50 text-emerald-500' : 'bg-white text-blue-600 shadow-sm'} rounded-2xl flex items-center justify-center border border-slate-100/50`}>
                              {request.supervisor.signature ? <CheckCircle2 className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
                            </div>
                            <div>
                              <h4 className="text-[10px] font-black uppercase tracking-[0.1em] text-slate-900">PASSO 2: ASSINATURA DO SUPERVISOR</h4>
                              <p className="text-[9px] font-bold mt-0.5 text-slate-400">
                                {request.supervisor.signature 
                                  ? `Assinado em ${safeFormat(request.supervisor.signedAt, 'dd/MM/yyyy')}`
                                  : 'Aguardando assinatura do supervisor'}
                              </p>
                            </div>
                          </div>
                        </div>
      
                        {request.supervisor.signature ? (
                          <div className="bg-white rounded-[32px] border-2 border-dashed border-slate-100 p-8 relative flex items-center justify-center flex-1">
                            <span className="absolute top-4 left-6 text-[8px] font-black text-slate-200 uppercase tracking-widest">ASSINATURA CAPTURADA</span>
                            <img src={request.supervisor.signature} alt="Signature" className="max-h-32 object-contain" />
                            <div className="absolute bottom-4 right-6 bg-[#e7f9ee] text-[#10b981] px-3 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest border border-[#d1f4df]">
                              VALIDADO
                            </div>
                          </div>
                        ) : (
                          <div className="flex flex-col gap-4 flex-1 justify-center">
                            <div className="flex-1 flex items-center justify-center">
                                <p className="text-[10px] text-slate-400 font-medium text-center">Aguardando assinatura do supervisor</p>
                            </div>
                            <div className="space-y-3">
                                <div className="grid grid-cols-2 gap-2">
                                  <button 
                                    onClick={() => copyLink('supervisor')}
                                    className="bg-white text-slate-700 border border-slate-200 px-4 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                                  >
                                    <Copy className="w-3.5 h-3.5" /> COPIAR LINK
                                  </button>
                                  <button 
                                    disabled
                                    title="Envio de e-mail desabilitado (aguardando liberação do SMTP)"
                                    className="bg-blue-600 text-white px-4 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-1.5 border border-blue-700 cursor-not-allowed opacity-40"
                                  >
                                    <Mail className="w-3.5 h-3.5" /> ENVIAR E-MAIL
                                  </button>
                                </div>
                                <div className="flex items-center gap-2 justify-center pt-1">
                                  <div className="w-1.5 h-1.5 bg-blue-400/40 rounded-full animate-pulse"></div>
                                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                    Aguardando: {request.supervisor.email}
                                  </span>
                                </div>
                            </div>
                          </div>
                        )}
                    </div>
      
                    {/* Step 3: Student Signature */}
                    <div className={`flex flex-col gap-6 transition-all min-h-[300px] h-full ${request.student?.signature ? 'bg-transparent' : 'bg-[#f8f9fc] rounded-[32px] border border-slate-100 p-8 shadow-sm text-slate-900'}`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                              <div className={`w-12 h-12 ${request.student?.signature ? 'bg-emerald-50 text-emerald-500' : 'bg-white text-blue-600 shadow-sm'} rounded-2xl flex items-center justify-center border border-slate-100/50`}>
                                {request.student?.signature ? <CheckCircle2 className="w-6 h-6" /> : <Signature className="w-6 h-6" />}
                              </div>
                              <div>
                                <h4 className="text-[10px] font-black uppercase tracking-[0.1em] text-slate-900">PASSO 3: ASSINATURA DO ESTUDANTE</h4>
                                <p className="text-[9px] font-bold mt-0.5 text-slate-400">
                                    {request.student?.signature 
                                      ? `Assinado em ${safeFormat(request.student.signedAt, 'dd/MM/yyyy')}`
                                      : 'Aguardando assinatura do estudante'}
                                </p>
                              </div>
                          </div>
                        </div>
      
                        {request.student?.signature ? (
                          <div className="bg-white rounded-[32px] border-2 border-dashed border-slate-100 p-8 relative flex items-center justify-center flex-1">
                              <span className="absolute top-4 left-6 text-[8px] font-black text-slate-200 uppercase tracking-widest">ASSINATURA CAPTURADA</span>
                              <img src={request.student.signature} alt="Signature" className="max-h-32 object-contain" />
                              <div className="absolute bottom-4 right-6 bg-[#e7f9ee] text-[#10b981] px-3 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest border border-[#d1f4df]">
                                VALIDADO
                              </div>
                          </div>
                        ) : (
                          <div className="flex flex-col gap-4 flex-1 justify-center">
                              <div className="flex-1 flex items-center justify-center">
                                <p className="text-[10px] text-slate-400 font-medium text-center">Aguardando assinatura do estudante</p>
                              </div>
                              <div className="space-y-3">
                                <div className="grid grid-cols-2 gap-2">
                                  <button 
                                    onClick={() => copyLink('student')}
                                    className="bg-white text-slate-700 border border-slate-200 px-4 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                                  >
                                    <Copy className="w-3.5 h-3.5" /> COPIAR LINK
                                  </button>
                                  <button 
                                    disabled
                                    title="Envio de e-mail desabilitado (aguardando liberação do SMTP)"
                                    className="bg-emerald-600 text-white px-4 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-1.5 border border-emerald-700 cursor-not-allowed opacity-40"
                                  >
                                    <Mail className="w-3.5 h-3.5" /> ENVIAR E-MAIL
                                  </button>
                                </div>
                                <div className="flex items-center gap-2 justify-center pt-1">
                                    <div className="w-1.5 h-1.5 bg-emerald-400/40 rounded-full animate-pulse"></div>
                                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                      Aguardando: {request.student?.email}
                                    </span>
                                </div>
                              </div>
                          </div>
                        )}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* DGEP Validation Stamp / Footer */}
            {request.status === 'approved' && (
              <div className="bg-emerald-50/50 border border-emerald-200 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4 mt-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-600 text-white rounded-2xl flex items-center justify-center border border-emerald-100 shadow-sm shrink-0">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <h4 className="text-emerald-700 font-black text-xs uppercase tracking-tight">VALIDADO PELA DGEP</h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Diretoria de Gestão de Pessoas</p>
                  </div>
                </div>
                <div className="md:text-right text-xs text-slate-600 font-medium">
                  <p className="text-[10px] text-slate-500 font-normal leading-relaxed">
                    Requerimento validado pela DGEP - Diretoria de Gestão de Pessoas, em <strong className="font-black text-emerald-800">{safeFormat(request.approvedAt, 'dd/MM/yyyy')}</strong> às <strong className="font-black text-emerald-800">{safeFormat(request.approvedAt, 'HH:mm:ss')}</strong> pelo usuário <strong className="font-bold text-slate-800">{request.approvedBy || '---'}</strong>.
                  </p>
                </div>
              </div>
            )}

            {/* View Mode Footer Message */}
            {profile.role !== 'master' && (
              <div className={`${request.status === 'rejected' || request.status === 'draft' ? 'bg-amber-50 border-amber-100' : 'bg-blue-50 border-blue-100'} p-6 rounded-3xl text-center space-y-1`}>
                 <p className={`text-[10px] font-black ${request.status === 'rejected' || request.status === 'draft' ? 'text-amber-600' : 'text-blue-600'} uppercase tracking-widest`}>
                   {request.status === 'rejected' ? 'SOLICITAÇÃO DEVOLVIDA' : request.status === 'draft' ? 'RASCUNHO' : 'MODO DE VISUALIZAÇÃO'}
                 </p>
                 <p className={`text-[10px] ${request.status === 'rejected' || request.status === 'draft' ? 'text-amber-500 font-bold' : 'text-blue-500 font-medium'} italic`}>
                   {request.status === 'rejected' 
                     ? 'Esta solicitação foi devolvida para ajustes. Clique no botão "Editar" abaixo para realizar as alterações necessárias.'
                     : request.status === 'draft'
                       ? 'Este é um rascunho que ainda não foi enviado para assinaturas.'
                       : `Este requerimento já foi enviado e não pode mais ser editado. Status atual: ${statusLabel}.`}
                 </p>
              </div>
            )}

            {/* Admin Actions Area */}
            {(profile.role === 'master' || profile.role === 'manager') && (
              <div className="bg-[#f8f9fc] rounded-[40px] border border-slate-100 p-8 sm:p-10 space-y-8 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-emerald-500/5 rounded-full -ml-16 -mb-16 blur-2xl"></div>
                
                <div className="flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center border border-slate-100 shadow-sm">
                      <ShieldCheck className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="text-slate-900 font-black text-sm uppercase tracking-tight">
                        {viewMode === 'admin' ? 'GESTÃO ADMINISTRATIVA' : 'AÇÕES DA GESTÃO'}
                      </h4>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                        {viewMode === 'admin' ? 'Ações exclusivas da diretoria (DGEP)' : 'Ações disponíveis'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => {
                        if (request.documents?.requerimento?.fileId) {
                          window.open(request.documents.requerimento.fileId, '_blank');
                        } else {
                          generateHiringPDF(request);
                        }
                      }}
                      className="bg-white hover:bg-slate-50 text-slate-600 px-4 py-3 rounded-xl border border-slate-200 transition-all flex items-center gap-2 group shadow-sm"
                    >
                      <Download className="w-4 h-4 text-blue-500 group-hover:scale-110 transition-transform" />
                      <span className="text-[10px] font-black uppercase tracking-widest">REQUERIMENTO</span>
                    </button>
                    {request.type === 'hiring' && (
                      <button 
                        onClick={() => {
                          if (request.documents?.parentesco?.fileId) {
                            window.open(request.documents.parentesco.fileId, '_blank');
                          } else {
                            generateKinshipPDF(request);
                          }
                        }}
                        className="bg-white hover:bg-slate-50 text-slate-600 px-4 py-3 rounded-xl border border-slate-200 transition-all flex items-center gap-2 group shadow-sm"
                      >
                        <Download className="w-4 h-4 text-emerald-500 group-hover:scale-110 transition-transform" />
                        <span className="text-[10px] font-black uppercase tracking-widest">DECL. PARENTESCO</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 relative z-10">
                  {viewMode === 'admin' && (
                    <>
                      <button 
                        onClick={() => onReject?.(request)}
                        className="flex flex-col items-center justify-center gap-3 p-6 bg-red-50 hover:bg-red-100/50 rounded-3xl border border-red-100 transition-all group shadow-sm"
                      >
                        <XCircle className="w-6 h-6 text-red-500 group-hover:scale-110 transition-transform" />
                        <span className="text-[9px] font-black text-red-600 uppercase tracking-widest text-center">Devolver para Ajustes</span>
                      </button>

                      <button 
                        disabled={
                          request.status === 'approved' || 
                          request.status === 'archived' || 
                          !isSignaturesComplete
                        }
                        onClick={() => onApprove?.(request)}
                        className="flex flex-col items-center justify-center gap-3 p-6 bg-emerald-50 hover:bg-emerald-100/50 rounded-3xl border border-emerald-100 transition-all group shadow-sm disabled:opacity-30 disabled:grayscale"
                      >
                        <CheckCircle2 className="w-6 h-6 text-emerald-600 group-hover:scale-110 transition-transform" />
                        <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest text-center">Aprovar Solicitação</span>
                      </button>
                    </>
                  )}

                  {request.status === 'archived' ? (
                    <button 
                      onClick={() => onUnarchive?.(request)}
                      className="flex flex-col items-center justify-center gap-3 p-6 bg-blue-50 hover:bg-blue-100/50 rounded-3xl border border-blue-100 transition-all group shadow-sm lg:col-start-3 cursor-pointer"
                    >
                      <Archive className="w-6 h-6 text-blue-600 group-hover:scale-110 transition-transform rotate-180" />
                      <span className="text-[9px] font-black text-blue-600 uppercase tracking-widest text-center">Desarquivar Solicitação</span>
                    </button>
                  ) : (
                    <button 
                      onClick={() => onArchive?.(request)}
                      className="flex flex-col items-center justify-center gap-3 p-6 bg-white hover:bg-slate-50 rounded-3xl border border-slate-100 transition-all group shadow-sm lg:col-start-3 cursor-pointer"
                    >
                      <Archive className="w-6 h-6 text-slate-400 group-hover:scale-110 transition-transform" />
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Arquivar no Estado</span>
                    </button>
                  )}
                </div>

                {viewMode === 'admin' && !isSignaturesComplete && (
                   <div className="flex items-center gap-3 text-amber-600 bg-amber-50 p-4 rounded-2xl border border-amber-100 justify-center">
                     <AlertCircle className="w-4 h-4" />
                     <p className="text-[9px] font-bold uppercase tracking-widest">Aguardando todas as assinaturas para habilitar aprovação</p>
                   </div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}

