import React, { useState, useEffect } from 'react';
import { hiringService } from '../../services/hiringService';
import { HiringRequest } from '../../types';
import SignaturePad from './SignaturePad';
import { LOGO_BASE64 } from '../../lib/logo';
import { 
  ShieldCheck, 
  User, 
  Building2, 
  CheckCircle2, 
  FileText,
  Lock,
  Signature
} from 'lucide-react';

export default function SupervisorSignature({ requestId }: { requestId: string }) {
  const [request, setRequest] = useState<HiringRequest | null>(null);
  const [loading, setLoading] = useState(true);
  const [cpf, setCpf] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [error, setError] = useState('');
  const [showPad, setShowPad] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    hiringService.getRequest(requestId).then(req => {
      setRequest(req);
      setLoading(false);
    }).catch(err => {
      console.error(err);
      setError('Erro ao carregar a solicitação.');
      setLoading(false);
    });
  }, [requestId]);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!request) return;
    const cleanInput = cpf.replace(/\D/g, '');
    const cleanTarget = (request.supervisor?.cpf || '').replace(/\D/g, '');
    if (cleanInput === cleanTarget && cleanInput.length === 11) {
      setAuthenticated(true);
      setError('');
    } else {
      setError('CPF incorreto ou inválido.');
    }
  };

  const handleSaveSignature = async (signature: string) => {
    try {
      if (!request) return;
      await hiringService.saveSupervisorSignature(requestId, signature);
      setShowPad(false);
      setSuccess(true);
    } catch (err) {
      console.error(err);
      setError('Erro ao salvar assinatura. Tente novamente.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-4">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 font-black text-[10px] uppercase tracking-widest">Carregando formulário...</p>
      </div>
    );
  }

  if (!request) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-[32px] shadow-xl max-w-md w-full text-center border border-slate-100">
           <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Lock className="w-8 h-8" />
           </div>
           <h1 className="text-xl font-black text-slate-900 uppercase mb-2">Acesso Negado</h1>
           <p className="text-sm text-slate-500 font-medium leading-relaxed">
             {error || 'Solicitação não encontrada ou você não possui permissão para acessá-la.'}
           </p>
        </div>
      </div>
    );
  }

  if (request.supervisor?.signature) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full text-center border border-slate-100">
          <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-[32px] flex items-center justify-center mx-auto mb-6 border border-emerald-100 shadow-sm shadow-emerald-100/50">
             <CheckCircle2 className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 uppercase mb-3">Assinatura Realizada</h1>
          <p className="text-slate-500 font-medium leading-relaxed">Sua assinatura já foi capturada e validada pelo sistema. Não são necessárias mais ações.</p>
        </div>
      </div>
    );
  }

  if (request.status === 'approved' || request.status === 'archived' || request.status === 'rejected') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full text-center border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 text-slate-400 rounded-[32px] flex items-center justify-center mx-auto mb-6 border border-slate-200">
             <Lock className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-black text-slate-400 uppercase mb-3">Solicitação Encerrada</h1>
          <p className="text-slate-400 font-medium leading-relaxed">Este processo já foi finalizado ou arquivado e não permite novas assinaturas.</p>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full text-center border border-slate-100">
          <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-[32px] flex items-center justify-center mx-auto mb-6 border border-emerald-100 shadow-sm">
             <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-black text-slate-900 uppercase mb-3">Sucesso!</h2>
          <p className="text-slate-600 font-medium leading-relaxed mb-8">
            Sua assinatura foi salva com sucesso. O processo seguirá para aprovação da DGEP.
          </p>
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Protocolo Digital</p>
             <p className="text-[10px] font-mono text-slate-600 mt-1">{requestId}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-[#f8f9fc] flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full border border-slate-100 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
          
          <div className="text-center relative z-10 mb-10">
             <div className="w-20 h-20 bg-blue-50 border border-blue-100 rounded-[32px] flex items-center justify-center mx-auto mb-6 shadow-sm shadow-blue-100/50">
               <ShieldCheck className="w-10 h-10 text-blue-600" />
             </div>
             <h1 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Assinatura do Supervisor</h1>
             <p className="text-[10px] text-blue-600 font-black uppercase tracking-widest mt-2">Validação de Identidade</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-6 relative z-10">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Informe seu CPF</label>
              <input 
                type="text" 
                value={cpf}
                onChange={e => setCpf(e.target.value)}
                placeholder="000.000.000-00"
                className="w-full bg-slate-50 border-slate-100 border-2 rounded-2xl px-6 py-5 text-xl text-center font-bold text-slate-900 focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all placeholder:text-slate-200"
                required
              />
            </div>
            
            {error && (
              <div className="bg-red-50 text-red-500 p-4 rounded-2xl border border-red-100 flex items-center gap-3 animate-shake">
                <Lock className="w-4 h-4 flex-shrink-0" />
                <p className="text-[10px] font-black uppercase tracking-widest">{error}</p>
              </div>
            )}

            <button 
              type="submit" 
              className="w-full bg-slate-900 text-white font-black py-5 rounded-2xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 uppercase text-xs tracking-widest flex items-center justify-center gap-3 group"
            >
              Acessar Documento 
              <ShieldCheck className="w-4 h-4 group-hover:scale-110 transition-transform text-blue-400" />
            </button>

            <p className="text-[9px] text-slate-300 font-bold uppercase text-center tracking-widest pt-4">Ambiente Seguro de Assinaturas CMC</p>
          </form>
        </div>
      </div>
    );
  }

  const studentName = request.type === 'hiring' ? request.student?.name || 'Vaga em Aberto' : 'ABERTURA DE VAGA';
  const sectorName = request.sector || 'NÃO INFORMADO';
  const courseName = request.course || 'ESTÁGIO REGULAR';

  return (
    <div className="min-h-screen bg-[#f8f9fc] py-12 px-4 flex flex-col items-center">
      <div className="w-full max-w-2xl mb-8 flex justify-center">
         <div className="bg-white p-4 rounded-[28px] shadow-sm border border-slate-100">
           <img src={LOGO_BASE64} alt="CMC Logo" className="h-10 w-auto" />
         </div>
      </div>

      <div className="w-full max-w-2xl text-center mb-10 space-y-2">
         <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Assinatura do Supervisor</h1>
         <p className="text-[11px] text-slate-400 font-bold uppercase tracking-[0.2em]">DGEP - Diretoria de Gestão de Pessoas</p>
      </div>

      <div className="w-full max-w-3xl bg-white rounded-[48px] shadow-2xl shadow-slate-200/50 border border-slate-100 overflow-hidden mb-12">
         {/* Blue Header */}
         <div className="bg-blue-600 px-10 py-6 flex items-center gap-4">
            <ShieldCheck className="w-6 h-6 text-white/80" />
            <h2 className="text-white font-black text-[11px] uppercase tracking-widest">Confirmação de Supervisão - Estágio</h2>
         </div>

         <div className="p-10 space-y-8">
            {/* Intern and Sector Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <div className="bg-slate-50/50 rounded-3xl p-6 border border-slate-100 flex flex-col gap-1">
                  <div className="flex items-center gap-2 text-slate-400 mb-1">
                    <User className="w-3.5 h-3.5" />
                    <span className="text-[9px] font-black uppercase tracking-widest">Estagiário</span>
                  </div>
                  <p className="text-sm font-black text-slate-800 uppercase">{studentName}</p>
                  <p className="text-[10px] text-slate-500 font-medium font-italic mt-0.5">{courseName}</p>
               </div>
               <div className="bg-slate-50/50 rounded-3xl p-6 border border-slate-100 flex flex-col gap-1">
                  <div className="flex items-center gap-2 text-slate-400 mb-1">
                    <Building2 className="w-3.5 h-3.5" />
                    <span className="text-[9px] font-black uppercase tracking-widest">Setor Destino</span>
                  </div>
                  <p className="text-sm font-black text-slate-800 uppercase">{sectorName}</p>
               </div>
            </div>

            <div className="bg-emerald-50/30 rounded-3xl p-6 border border-emerald-100 flex items-center justify-between">
               <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white text-emerald-500 rounded-2xl flex items-center justify-center border border-emerald-50 shadow-sm">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">Identidade Verificada</h4>
                    <p className="text-[9px] text-emerald-600/70 font-bold uppercase mt-1 tracking-widest flex items-center gap-2">
                       <CheckCircle2 className="w-3 h-3" /> CPF {cpf.slice(0,3)}.***.***-{cpf.slice(-2)} validado
                    </p>
                  </div>
               </div>
            </div>

            {/* Declaration Block */}
            <div className="bg-blue-50/30 rounded-[32px] p-8 border border-blue-100 flex flex-col gap-6 relative overflow-hidden">
               <div className="absolute top-0 right-0 -mr-4 -mt-4 opacity-5 rotate-12">
                  <FileText className="w-32 h-32 text-blue-600" />
               </div>
               <div className="flex items-center gap-4 relative z-10">
                  <div className="w-10 h-10 bg-white text-blue-600 rounded-2xl flex items-center justify-center border border-blue-50 shadow-sm">
                    <FileText className="w-5 h-5" />
                  </div>
                  <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Declaração de Supervisão</h4>
               </div>
               <p className="text-sm text-slate-600 leading-relaxed font-medium relative z-10">
                 Eu, <span className="font-bold text-blue-600 uppercase">{request.supervisor.name}</span>, na condição de supervisor(a) designado(a), declaro aceitar a supervisão do(a) estagiário(a) acima citado(a), comprometendo-me a orientar as suas atividades conforme o plano de estágio e as normas vigentes na Câmara Municipal de Curitiba.
               </p>
            </div>

            <div className="pt-4 border-t border-slate-100 flex flex-col items-center gap-8">
               <div className="w-full flex items-center justify-between">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Assinatura Digital</h4>
                  <div className="flex items-center gap-2 px-3 py-1 bg-slate-50 rounded-full border border-slate-100">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Pronto para Captura</span>
                  </div>
               </div>

               <button 
                  onClick={() => setShowPad(true)}
                  className="w-full bg-slate-900 text-white font-black py-6 rounded-3xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 uppercase text-xs tracking-[0.2em] flex items-center justify-center gap-4 group"
               >
                 <span>Confirmar e Assinar Requerimento</span>
                 <Signature className="w-5 h-5 group-hover:-translate-y-1 group-hover:rotate-12 transition-all text-blue-400" />
               </button>
            </div>
         </div>
      </div>

      <p className="text-[9px] text-slate-300 font-bold uppercase tracking-widest">© 2026 Câmara Municipal de Curitiba</p>

      {showPad && (
        <SignaturePad
          title="Assinatura do Supervisor"
          description="Assine no quadro abaixo para validar tecnicamente o requerimento."
          onCancel={() => setShowPad(false)}
          onSave={handleSaveSignature}
        />
      )}
    </div>
  );
}

