import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Building2, 
  User, 
  Briefcase, 
  Clock, 
  Save, 
  Send,
  AlertCircle,
  X,
  Phone,
  Mail,
  FileText,
  ArrowLeft,
  ArrowDown,
  ArrowRight,
  UserPlus,
  UserMinus
} from 'lucide-react';
import { hiringService } from '../../services/hiringService';
import { frequencyService } from '../../services/frequencyService';
import { emailNotificationService } from '../../services/emailNotificationService';
import { UserProfile, HiringRequest, HiringStatus } from '../../types';
import { toast } from 'react-hot-toast';
import { validateCPF, formatCPF, formatPhone } from '../../lib/validation';
import { 
  generateComissionadoForm1, 
  generateComissionadoExoneration 
} from '../../lib/pdfGenerator';

const formatInputDate = (val: string | null | undefined): string => {
  if (!val) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(val)) return val;
  try {
    const d = new Date(val);
    if (!isNaN(d.getTime())) {
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }
  } catch (e) {}
  return '';
};

export default function ComissionadosRequestForm({ profile, onClose, onSuccess, initialData, initialType, selectedSector }: { 
  profile: UserProfile; 
  onClose: () => void; 
  onSuccess: () => void;
  initialData?: HiringRequest;
  initialType?: 'hiring' | 'resignation' | null;
  selectedSector?: string;
}) {
  const [activeRequestId] = useState<string>(() => {
    return initialData?.id || hiringService.generateNewId();
  });
  const [loading, setLoading] = useState(false);
  const [type, setType] = useState<'hiring' | 'resignation'>(() => {
    if (initialData?.type) return initialData.type as any;
    return initialType || 'hiring';
  });

  // Determine initial cargo selection
  const initialCargo = initialData?.comissionadoDetails?.cargo || 'Assessor de Gabinete Parlamentar';
  const isPresetCargo = initialCargo === 'Assessor de Gabinete Parlamentar' || initialCargo === 'Chefe de Gabinete Parlamentar';
  
  const [cargoChoice, setCargoChoice] = useState<'Assessor de Gabinete Parlamentar' | 'Chefe de Gabinete Parlamentar' | 'Outros'>(
    isPresetCargo ? (initialCargo as any) : 'Outros'
  );

  const [formData, setFormData] = useState({
    sector: initialData?.sector || selectedSector || profile.sectors?.[0] || '',
    supervisor: {
      name: profile.name || initialData?.supervisor?.name || '',
      role: profile.role || initialData?.supervisor?.role || 'Vereador',
      rg: initialData?.supervisor?.rg || '',
      cpf: initialData?.supervisor?.cpf || '',
      email: profile.email || initialData?.supervisor?.email || '',
      phone: initialData?.supervisor?.phone || '',
      education: 'Superior',
      experience: ''
    },
    student: {
      name: initialData?.student?.name || '',
      cpf: initialData?.student?.cpf || '',
      email: initialData?.student?.email || '',
      phone: initialData?.student?.phone || ''
    },
    comissionadoDetails: {
      cargo: initialCargo,
      simbolo: initialData?.comissionadoDetails?.simbolo || 'CC2',
      dataNomeacao: initialData?.comissionadoDetails?.dataNomeacao || '',
      isBloco: initialData?.comissionadoDetails?.isBloco || false,
      declarouParentesco: false,
      possuiOutroCargo: false,
      possuiDependentes: false,
      declarouImpedimento: false
    }
  });

  // Dynamic Symbol rules based on Cargo
  useEffect(() => {
    if (cargoChoice === 'Assessor de Gabinete Parlamentar') {
      setFormData(prev => ({
        ...prev,
        comissionadoDetails: {
          ...prev.comissionadoDetails,
          cargo: 'Assessor de Gabinete Parlamentar',
          simbolo: 'CC2' // Default for Assessor
        }
      }));
    } else if (cargoChoice === 'Chefe de Gabinete Parlamentar') {
      setFormData(prev => ({
        ...prev,
        comissionadoDetails: {
          ...prev.comissionadoDetails,
          cargo: 'Chefe de Gabinete Parlamentar',
          simbolo: 'CC1'
        }
      }));
    } else {
      // Outros
      setFormData(prev => ({
        ...prev,
        comissionadoDetails: {
          ...prev.comissionadoDetails,
          cargo: initialData?.comissionadoDetails?.cargo && !isPresetCargo ? initialData.comissionadoDetails.cargo : '',
          simbolo: initialData?.comissionadoDetails?.simbolo || ''
        }
      }));
    }
  }, [cargoChoice]);

  // Ensure supervisor is always tied to profile
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      supervisor: {
        ...prev.supervisor,
        name: profile.name || prev.supervisor.name,
        email: profile.email || prev.supervisor.email,
        role: profile.role || prev.supervisor.role
      }
    }));
  }, [profile]);

  const validateForm = () => {
    if (!formData.sector) return "Selecione a lotação/setor";

    if (type === 'resignation') {
      if (!formData.student.name) return "Nome do servidor é obrigatório";
      if (!formData.comissionadoDetails.dataNomeacao) return "Data da exoneração é obrigatória";
      return null;
    }

    if (!formData.comissionadoDetails.dataNomeacao) return "Informe a data da nomeação";
    
    // Cargo name validation
    if (!formData.comissionadoDetails.cargo.trim()) {
      return "Informe o nome do cargo";
    }

    // Symbol validation
    if (!formData.comissionadoDetails.simbolo.trim()) {
      return "Informe o símbolo do cargo";
    }

    // Candidate details
    if (!formData.student.name.trim()) return "Nome do comissionado é obrigatório";
    if (!formData.student.email.trim()) return "Email do comissionado é obrigatório";
    if (!formData.student.cpf) return "CPF do comissionado é obrigatório";
    if (!validateCPF(formData.student.cpf)) return "CPF do comissionado inválido";

    return null;
  };

  const handleSave = async (status: HiringStatus) => {
    if (status !== 'draft') {
      const error = validateForm();
      if (error) {
        toast.error(error);
        return;
      }
    }

    setLoading(true);
    try {
      const data: any = {
        type: type === 'resignation' ? 'resignation' : 'hiring',
        category: 'comissionado',
        ...formData,
        createdBy: profile.email,
        status: status,
        createdAt: initialData?.createdAt || new Date().toISOString()
      };
      
      let requestId = activeRequestId;
      
      if (initialData?.id) {
        await hiringService.updateRequest(initialData.id, data);
      } else {
        requestId = await hiringService.createRequest(data as Partial<HiringRequest>, activeRequestId);
      }

      if (status !== 'draft') {
        const completeRequest: HiringRequest = {
          id: requestId,
          ...data
        };

        try {
          const studentName = completeRequest.student?.name || 'Candidato';
          const requestNameAndId = `${studentName}_${requestId}`.replace(/\s+/g, '_');
          const context = {
            module: 'hiring' as const,
            category: 'comissionado' as const,
            lotacao: completeRequest.sector || 'Submissoes_Gerais',
            requestNameAndId,
            requestId,
            userName: completeRequest.supervisor?.name
          };

          const cleanServidorName = studentName.trim().replace(/\s+/g, '_');

          let fileUrl = null;
          if (type === 'hiring') {
            const form1Doc = generateComissionadoForm1(completeRequest, true);
            const form1Blob = form1Doc.output('blob');
            const form1Name = `Formulário_1_Indicação_${cleanServidorName}.pdf`;
            const form1File = new File([form1Blob], form1Name, { type: 'application/pdf' });
            fileUrl = await frequencyService.uploadFile(form1File, `hiring_doc_form1`, context);
            
            await hiringService.updateRequest(requestId, {
              documents: {
                form1: { fileId: fileUrl, name: form1Name }
              }
            });

            // Send invite email to comissionado candidate
            if (status === 'pending') {
              await emailNotificationService.sendStudentInvite(completeRequest);
            }
          } else {
            const exonDoc = generateComissionadoExoneration(completeRequest, undefined, undefined, true);
            const exonBlob = exonDoc.output('blob');
            const exonName = `Formulário_Exoneração_${cleanServidorName}.pdf`;
            const exonFile = new File([exonBlob], exonName, { type: 'application/pdf' });
            fileUrl = await frequencyService.uploadFile(exonFile, `hiring_doc_exoneracao`, context);

            await hiringService.updateRequest(requestId, {
              documents: {
                exoneracao: { fileId: fileUrl, name: exonName }
              }
            });
          }
        } catch (driveErr) {
          console.warn("Erro ao gerar/salvar formulários no Google Drive:", driveErr);
        }
      }
      
      toast.success(status === 'draft' ? "Progresso salvo como rascunho!" : "Solicitação enviada com sucesso!");
      onSuccess();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao processar solicitação");
    } finally {
      setLoading(false);
    }
  };

  // Símbolo CC options (ordered alphabetically/numerically)
  const assessorSymbols = ['CC2', 'CC3', 'CC4', 'CC5', 'CC6', 'CC7', 'CC8', 'CC9'];

  return (
    <div className="flex-1 flex flex-col bg-white overflow-hidden">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex-1 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="p-4 sm:p-8 border-b border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between bg-white sticky top-0 z-10 shrink-0 gap-4">
          <div className="flex items-center gap-4 sm:gap-6 w-full md:w-auto">
             <button 
               onClick={onClose}
               className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-slate-50 text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-all border border-slate-200 shrink-0"
             >
                <ArrowLeft className="w-5 h-5 sm:w-6 sm:h-6" />
             </button>
             <div className="hidden sm:block h-10 w-[1px] bg-slate-100"></div>
             <div className="flex items-center gap-3 sm:gap-4 overflow-hidden">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center border border-emerald-100 shrink-0">
                    <FileText className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0">
                    <h2 className="text-lg sm:text-2xl font-black text-slate-900 leading-tight tracking-tight uppercase truncate">
                      {type === 'resignation'
                        ? (initialData ? 'EDITAR EXONERAÇÃO' : 'SOLICITAÇÃO DE EXONERAÇÃO')
                        : (initialData ? 'EDITAR NOMEAÇÃO' : 'SOLICITAÇÃO DE NOMEAÇÃO')
                      }
                    </h2>
                    <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1 truncate">Servidores Comissionados • DGEP</p>
                </div>
             </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-10 space-y-10 bg-slate-50/20 custom-scrollbar">
          
          {/* Steps */}
          <div className="flex items-center justify-center gap-4 py-4 border-b border-slate-100 mb-6 bg-white rounded-2xl shadow-sm border border-slate-100">
             {[
               { id: 1, label: 'Preenchimento', active: true },
               { id: 2, label: 'Assinaturas', active: false },
               { id: 3, label: 'Análise DGEP', active: false }
             ].map((step, idx) => (
               <div key={step.id} className="flex items-center gap-3">
                 <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black ${step.active ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'bg-slate-100 text-slate-400'}`}>
                   {step.id}
                 </div>
                 <span className={`text-[10px] font-black uppercase tracking-widest ${step.active ? 'text-emerald-700' : 'text-slate-400'}`}>{step.label}</span>
                 {idx < 2 && <ArrowRight className="w-3 h-3 text-slate-300" />}
               </div>
             ))}
          </div>

          <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden">
            <div className="bg-slate-900 px-8 py-5 flex items-center justify-between">
               <div className="flex items-center gap-3">
                 <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white">
                    <UserPlus className="w-4 h-4" />
                 </div>
                 <h3 className="text-[11px] font-black text-white uppercase tracking-[0.2em]">Formulário do Requerimento</h3>
               </div>
               <div className="px-3 py-1 bg-white/10 rounded-lg text-[9px] font-black text-white tracking-widest uppercase">
                 {type === 'hiring' ? 'NOMEAÇÃO' : 'EXONERAÇÃO'}
               </div>
            </div>
            
            <div className="p-10 space-y-12">
              
              {/* Lotação */}
              <section className="space-y-4">
                <label className="flex items-center gap-2 text-[10px] font-black text-emerald-600 uppercase tracking-[0.15em]">
                  <Building2 className="w-3 h-3" /> LOCAL DE LOTAÇÃO (GABINETE)
                </label>
                <div className="relative">
                  <select 
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all appearance-none cursor-pointer"
                    value={formData.sector}
                    onChange={e => setFormData({...formData, sector: e.target.value})}
                  >
                    <option value="">Selecione o setor...</option>
                    {[...(profile.sectors || [])].sort((a, b) => a.localeCompare(b, 'pt-BR', { sensitivity: 'base' })).map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    <ArrowDown className="w-4 h-4" />
                  </div>
                </div>
              </section>

              {type === 'hiring' ? (
                <>
                  {/* Informações do Cargo */}
                  <section>
                    <div className="flex items-center gap-3 mb-8">
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <Briefcase className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-[12px] uppercase font-black text-slate-800 tracking-widest">DADOS DA NOMEAÇÃO</h4>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Cargo, Símbolo e Data de Início</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome do Cargo</label>
                        <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                          value={cargoChoice}
                          onChange={e => setCargoChoice(e.target.value as any)}
                        >
                          <option value="Assessor de Gabinete Parlamentar">Assessor de Gabinete Parlamentar</option>
                          <option value="Chefe de Gabinete Parlamentar">Chefe de Gabinete Parlamentar</option>
                          <option value="Outros">Outros</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Símbolo (CC)</label>
                        {cargoChoice === 'Outros' ? (
                          <input 
                            type="text"
                            placeholder="Ex: CC10"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all uppercase"
                            value={formData.comissionadoDetails.simbolo}
                            onChange={e => setFormData({
                              ...formData,
                              comissionadoDetails: { ...formData.comissionadoDetails, simbolo: e.target.value }
                            })}
                          />
                        ) : (
                          <select 
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                            value={formData.comissionadoDetails.simbolo}
                            onChange={e => setFormData({
                              ...formData,
                              comissionadoDetails: { ...formData.comissionadoDetails, simbolo: e.target.value }
                            })}
                          >
                            {cargoChoice === 'Chefe de Gabinete Parlamentar' ? (
                              <option value="CC1">CC1</option>
                            ) : (
                              assessorSymbols.map(sym => <option key={sym} value={sym}>{sym}</option>)
                            )}
                          </select>
                        )}
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nomear a Partir de</label>
                        <input 
                          type="date"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all cursor-pointer font-mono"
                          value={formatInputDate(formData.comissionadoDetails.dataNomeacao)}
                          onChange={e => setFormData({
                            ...formData,
                            comissionadoDetails: { ...formData.comissionadoDetails, dataNomeacao: e.target.value }
                          })}
                        />
                      </div>
                    </div>

                    {/* Cargo name text input in case of 'Outros' */}
                    {cargoChoice === 'Outros' && (
                      <div className="mt-6 space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Especifique o Nome do Cargo</label>
                        <input 
                          type="text"
                          placeholder="Digite o nome completo do cargo"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                          value={formData.comissionadoDetails.cargo}
                          onChange={e => setFormData({
                            ...formData,
                            comissionadoDetails: { ...formData.comissionadoDetails, cargo: e.target.value }
                          })}
                        />
                      </div>
                    )}

                    <div className="mt-8 flex items-center gap-3 bg-slate-50 border border-slate-100 p-4 rounded-2xl">
                      <input 
                        type="checkbox" 
                        id="isBloco"
                        checked={formData.comissionadoDetails.isBloco}
                        onChange={e => setFormData({
                          ...formData,
                          comissionadoDetails: { ...formData.comissionadoDetails, isBloco: e.target.checked }
                        })}
                        className="w-4 h-4 rounded text-slate-900 focus:ring-slate-950 cursor-pointer" 
                      />
                      <label htmlFor="isBloco" className="text-xs font-bold text-slate-700 cursor-pointer select-none">Esta é uma indicação em Bloco Parlamentar?</label>
                    </div>
                  </section>

                  {/* Dados do Servidor Indicado */}
                  <section>
                    <div className="flex items-center gap-3 mb-8">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-[12px] uppercase font-black text-slate-800 tracking-widest">DADOS DO INDICADO</h4>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Informações Básicas do Novo Servidor</p>
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome Completo</label>
                        <input 
                          type="text"
                          placeholder="Nome completo do indicado conforme RG"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all uppercase"
                          value={formData.student.name}
                          onChange={e => setFormData({
                            ...formData,
                            student: { ...formData.student, name: e.target.value.toUpperCase() }
                          })}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between ml-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CPF</label>
                            {formData.student.cpf.length === 14 && !validateCPF(formData.student.cpf) && (
                              <span className="text-[9px] font-black text-red-500 uppercase tracking-tight">CPF Inválido</span>
                            )}
                          </div>
                          <input 
                            type="text"
                            placeholder="000.000.000-00"
                            className={`w-full bg-slate-50 border rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 transition-all font-mono ${
                              formData.student.cpf.length === 14 && !validateCPF(formData.student.cpf)
                                ? 'border-red-200 focus:ring-red-500/20 focus:border-red-500 text-red-600'
                                : 'border-slate-200 focus:ring-emerald-500/20 focus:border-emerald-500'
                            }`}
                            value={formData.student.cpf}
                            onChange={e => setFormData({
                              ...formData,
                              student: { ...formData.student, cpf: formatCPF(e.target.value) }
                            })}
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">E-mail Institucional/Pessoal</label>
                          <input 
                            type="email"
                            placeholder="servidor@email.com"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all lowercase"
                            value={formData.student.email}
                            onChange={e => setFormData({
                              ...formData,
                              student: { ...formData.student, email: e.target.value }
                            })}
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Telefone / WhatsApp</label>
                          <input 
                            type="text"
                            placeholder="(00) 00000-0000"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
                            value={formData.student.phone}
                            onChange={e => setFormData({
                              ...formData,
                              student: { ...formData.student, phone: formatPhone(e.target.value) }
                            })}
                          />
                        </div>
                      </div>
                    </div>
                  </section>
                </>
              ) : (
                <section className="space-y-8">
                  {/* Exoneração */}
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                      <UserMinus className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-[12px] uppercase font-black text-slate-800 tracking-widest">DADOS DA EXONERAÇÃO</h4>
                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Servidor a ser Exonerado</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome Completo do Servidor</label>
                      <input 
                        type="text" 
                        placeholder="Nome completo do servidor"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all uppercase"
                        value={formData.student.name} 
                        onChange={e => setFormData({
                          ...formData, 
                          student: { ...formData.student, name: e.target.value.toUpperCase() }
                        })} 
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Data da Exoneração (A partir de)</label>
                      <input 
                        type="date" 
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all font-mono cursor-pointer"
                        value={formatInputDate(formData.comissionadoDetails.dataNomeacao)} 
                        onChange={e => setFormData({
                          ...formData, 
                          comissionadoDetails: { ...formData.comissionadoDetails, dataNomeacao: e.target.value }
                        })} 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Cargo Ocupado</label>
                      <select 
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all cursor-pointer"
                        value={cargoChoice}
                        onChange={e => setCargoChoice(e.target.value as any)}
                      >
                        <option value="Assessor de Gabinete Parlamentar">Assessor de Gabinete Parlamentar</option>
                        <option value="Chefe de Gabinete Parlamentar">Chefe de Gabinete Parlamentar</option>
                        <option value="Outros">Outros</option>
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Símbolo (CC)</label>
                      {cargoChoice === 'Outros' ? (
                        <input 
                          type="text" 
                          placeholder="Ex: CC10"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all uppercase"
                          value={formData.comissionadoDetails.simbolo} 
                          onChange={e => setFormData({
                            ...formData, 
                            comissionadoDetails: { ...formData.comissionadoDetails, simbolo: e.target.value }
                          })} 
                        />
                      ) : (
                        <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all cursor-pointer"
                          value={formData.comissionadoDetails.simbolo} 
                          onChange={e => setFormData({
                            ...formData, 
                            comissionadoDetails: { ...formData.comissionadoDetails, simbolo: e.target.value }
                          })} 
                        >
                          {cargoChoice === 'Chefe de Gabinete Parlamentar' ? (
                            <option value="CC1">CC1</option>
                          ) : (
                            assessorSymbols.map(sym => <option key={sym} value={sym}>{sym}</option>)
                          )}
                        </select>
                      )}
                    </div>
                  </div>

                  {cargoChoice === 'Outros' && (
                    <div className="mt-6 space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Especifique o Nome do Cargo</label>
                      <input 
                        type="text"
                        placeholder="Digite o nome completo do cargo"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
                        value={formData.comissionadoDetails.cargo}
                        onChange={e => setFormData({
                          ...formData,
                          comissionadoDetails: { ...formData.comissionadoDetails, cargo: e.target.value }
                        })}
                      />
                    </div>
                  )}
                </section>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-8 bg-white border-t border-slate-100 flex items-center justify-end gap-3 sticky bottom-0 z-10 shrink-0">
          <button 
            type="button" 
            onClick={onClose} 
            disabled={loading}
            className="px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider text-slate-500 hover:bg-slate-50 transition-colors"
          >
            Cancelar
          </button>
          <button 
            type="button" 
            onClick={() => handleSave('draft')} 
            disabled={loading}
            className="px-5 py-3 rounded-xl border border-slate-200 text-xs font-black uppercase tracking-wider text-slate-700 hover:bg-slate-50 flex items-center gap-2 transition-all"
          >
            <Save className="w-4 h-4" /> Salvar Rascunho
          </button>
          <button 
            type="button" 
            onClick={() => handleSave(type === 'hiring' ? 'pending' : 'submitted')} 
            disabled={loading}
            className="px-6 py-3 rounded-xl bg-slate-950 text-white text-xs font-black uppercase tracking-wider hover:bg-slate-900 flex items-center gap-2 transition-all"
          >
            <Send className="w-4 h-4 text-emerald-400" /> {type === 'hiring' ? 'Enviar para Assinaturas' : 'Enviar Requerimento'}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
