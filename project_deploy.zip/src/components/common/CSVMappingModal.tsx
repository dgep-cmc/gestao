import React, { useState, useEffect } from 'react';
import { HelpCircle, Check, AlertCircle } from 'lucide-react';
import Button from './Button';

interface UnresolvedSector {
  alias: string;
  action: 'map' | 'create';
  selectedTargetId?: string;
}

interface CSVMappingModalProps {
  isOpen: boolean;
  unrecognizedSectors: string[];
  officialSectors: { id: string; name: string }[];
  onConfirm: (mappings: Record<string, { action: 'map' | 'create'; targetSectorId?: string }>) => Promise<void>;
  onCancel: () => void;
}

export default function CSVMappingModal({
  isOpen,
  unrecognizedSectors,
  officialSectors,
  onConfirm,
  onCancel
}: CSVMappingModalProps) {
  const [unresolved, setUnresolved] = useState<UnresolvedSector[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setUnresolved(
        unrecognizedSectors.map(alias => ({
          alias,
          action: 'map',
          selectedTargetId: officialSectors.length > 0 ? officialSectors[0].id : undefined
        }))
      );
    }
  }, [isOpen, unrecognizedSectors, officialSectors]);

  if (!isOpen) return null;

  const handleActionChange = (index: number, action: 'map' | 'create') => {
    const next = [...unresolved];
    next[index] = {
      ...next[index],
      action,
      selectedTargetId: action === 'map' && officialSectors.length > 0 ? officialSectors[0].id : undefined
    };
    setUnresolved(next);
  };

  const handleTargetChange = (index: number, targetSectorId: string) => {
    const next = [...unresolved];
    next[index] = { ...next[index], selectedTargetId: targetSectorId };
    setUnresolved(next);
  };

  const handleSave = async () => {
    setSubmitting(true);
    try {
      const mappingPayload: Record<string, { action: 'map' | 'create'; targetSectorId?: string }> = {};
      unresolved.forEach(item => {
        mappingPayload[item.alias] = {
          action: item.action,
          targetSectorId: item.selectedTargetId
        };
      });
      await onConfirm(mappingPayload);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" onClick={onCancel} />
      
      {/* Modal Card */}
      <div className="relative bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center gap-3 bg-amber-50/50">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-slate-800 uppercase tracking-wide leading-none">Validação de Lotações</h3>
            <p className="text-[10px] text-slate-500 mt-1.5 font-semibold">Identificamos setores no CSV que não correspondem ao cadastro oficial.</p>
          </div>
        </div>

        {/* Scrollable list */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          <p className="text-xs text-slate-500 leading-relaxed">
            Selecione uma ação para cada setor desconhecido. Você pode vincular a uma lotação oficial existente ou cadastrar como uma nova lotação oficial na hora:
          </p>

          <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-200 bg-slate-50/20">
            {unresolved.map((item, index) => (
              <div key={item.alias} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Setor na Planilha:</span>
                  <span className="text-xs font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-lg inline-block font-mono">
                    "{item.alias}"
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  {/* Action Selector */}
                  <select 
                    value={item.action}
                    onChange={(e) => handleActionChange(index, e.target.value as 'map' | 'create')}
                    className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 shadow-sm focus:ring-blue-500"
                  >
                    <option value="map">Vincular a Existente</option>
                    <option value="create">Cadastrar Novo</option>
                  </select>

                  {/* Sector Target Dropdown */}
                  {item.action === 'map' && (
                    <select
                      value={item.selectedTargetId || ''}
                      onChange={(e) => handleTargetChange(index, e.target.value)}
                      className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-blue-700 max-w-[200px] shadow-sm focus:ring-blue-500"
                    >
                      {officialSectors.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  )}
                  {item.action === 'create' && (
                    <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl uppercase tracking-wider">
                      Adicionará ao Cadastro
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-end gap-3 bg-slate-50/50">
          <button
            onClick={onCancel}
            disabled={submitting}
            className="px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider text-slate-500 hover:bg-slate-100 transition-colors"
          >
            Cancelar Importação
          </button>
          <Button
            onClick={handleSave}
            isLoading={submitting}
            className="flex items-center gap-2 px-6 py-2.5"
          >
            <Check className="w-4 h-4" />
            CONFIRMAR MAPEAMENTOS
          </Button>
        </div>
      </div>
    </div>
  );
}
