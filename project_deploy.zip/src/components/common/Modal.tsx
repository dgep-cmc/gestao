import React, { ReactNode } from 'react';
import { X, LucideIcon } from 'lucide-react';
import Button from './Button';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  icon?: LucideIcon;
  iconColor?: string;
  children?: ReactNode;
  confirmLabel?: string;
  onConfirm?: () => void;
  confirmVariant?: 'primary' | 'secondary' | 'danger' | 'success';
  isLoading?: boolean;
}

export default function Modal({
  isOpen,
  onClose,
  title,
  description,
  icon: Icon,
  iconColor = 'text-blue-600 bg-blue-50',
  children,
  confirmLabel,
  onConfirm,
  confirmVariant = 'primary',
  isLoading
}: ModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />

      {/* Content Container */}
      <div className="relative w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 shadow-2xl transition-all border border-slate-100">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-start gap-4 mb-4">
          {Icon && (
            <div className={`p-3 rounded-xl shrink-0 ${iconColor}`}>
              <Icon className="w-6 h-6" />
            </div>
          )}
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-slate-900 leading-6">{title}</h3>
            {description && (
              <p className="text-sm text-slate-500 leading-relaxed font-medium">
                {description}
              </p>
            )}
          </div>
        </div>

        {/* Content Body */}
        {children && <div className="mb-6">{children}</div>}

        {/* Actions Footer */}
        {confirmLabel && onConfirm && (
          <div className="flex items-center justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={onClose} disabled={isLoading}>
              Cancelar
            </Button>
            <Button 
              variant={confirmVariant} 
              onClick={onConfirm} 
              isLoading={isLoading}
            >
              {confirmLabel}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
