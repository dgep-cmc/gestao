import React, { useState, useEffect } from 'react';
import { auth, loginWithGoogle, logout, db, isFirebaseConfigured } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { Toaster, toast } from 'react-hot-toast';
import { LOGO_BASE64 } from './lib/logo';
import { 
  Building2, 
  LayoutDashboard, 
  Upload, 
  Users, 
  LogOut, 
  ChevronRight,
  ShieldCheck,
  FileText,
  Search,
  CheckCircle2,
  Archive,
  ZoomIn,
  ZoomOut,
  Menu,
  X,
  Settings,
  Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { frequencyService } from './services/frequencyService';
import { UserProfile } from './types';
import AdminDashboard from './components/AdminDashboard';
import ManagerDashboard from './components/ManagerDashboard';
import ModuleSelector from './components/ModuleSelector';
import UserManagement from './components/UserManagement';
import HiringDashboard from './components/HiringModule/HiringDashboard';
import ComissionadosDashboard from './components/HiringModule/ComissionadosDashboard';
import SupervisorSignature from './components/HiringModule/SupervisorSignature';
import StudentSignature from './components/HiringModule/StudentSignature';
import ComissionadosOnboarding from './components/HiringModule/ComissionadosOnboarding';
import DriveDiagnostics from './components/DriveDiagnostics';
import { hiringService } from './services/hiringService';
import { CornerUpLeft } from 'lucide-react';
import { userNamesCache, userCpfsCache } from './lib/pdfGenerator';

export default function App() {
  if (!isFirebaseConfigured) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-xl w-full bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-slate-800 mb-2">Portal em Manutenção</h1>
            <p className="text-slate-600">O sistema está sendo configurado. Por favor, tente novamente em alguns instantes.</p>
          </div>
        </div>
      </div>
    );
  }

  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLoginLoading, setIsLoginLoading] = useState(false);
  const [currentModule, setCurrentModule] = useState<'frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados' | null>(() => {
    return (localStorage.getItem('currentModule') as any) || null;
  });
  const [activeTab, setActiveTab] = useState<string>(() => {
    const saved = sessionStorage.getItem('activeTab');
    if (saved) return saved;
    return 'manager'; // Default, will be refined in useEffect
  });
  const [adminSubTab, setAdminSubTab] = useState<string>((sessionStorage.getItem('adminSubTab') as any) || 'stats');
  const [hiringTab, setHiringTab] = useState<string>((sessionStorage.getItem('hiringTab') as any) || 'requests');
  const [hiringViewMode, setHiringViewMode] = useState<'manager' | 'admin'>(() => {
    const saved = sessionStorage.getItem('hiringViewMode');
    if (saved === 'admin' || saved === 'manager') return saved as any;
    return 'manager'; // Temporary default
  });
  const [selectedSector, setSelectedSector] = useState<string>(sessionStorage.getItem('selectedSector') || '');
  const [viewingUserManagement, setViewingUserManagement] = useState(false);
  const [userMgmtTab, setUserMgmtTab] = useState<'users' | 'drive'>('users');
  const [allSectors, setAllSectors] = useState<string[]>([]);

  useEffect(() => {
    if (profile?.role === 'master') {
      frequencyService.getAllSectorsList().then(list => {
        setAllSectors(list.map(s => s.name));
      }).catch(err => console.warn(err));
    }
  }, [profile]);

  const now = new Date();
  const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const [frequencyMonth, setFrequencyMonth] = useState<number>(() => {
    const saved = sessionStorage.getItem('frequency_selected_month');
    return saved ? parseInt(saved, 10) : lastMonthDate.getMonth() + 1;
  });
  const [frequencyYear, setFrequencyYear] = useState<number>(() => {
    const saved = sessionStorage.getItem('frequency_selected_year');
    return saved ? parseInt(saved, 10) : lastMonthDate.getFullYear();
  });

  const hiringColor = 'bg-emerald-600';
  const hiringLabel = currentModule === 'hiring_comissionados' ? 'Meu Gabinete' : 'Minha Lotação';

  useEffect(() => {
    sessionStorage.setItem('frequency_selected_month', frequencyMonth.toString());
    sessionStorage.setItem('frequency_selected_year', frequencyYear.toString());
  }, [frequencyMonth, frequencyYear]);

  useEffect(() => {
    if (currentModule === null) {
      sessionStorage.removeItem('frequency_selected_month');
      sessionStorage.removeItem('frequency_selected_year');
      const freshNow = new Date();
      const freshLastMonthDate = new Date(freshNow.getFullYear(), freshNow.getMonth() - 1, 1);
      setFrequencyMonth(freshLastMonthDate.getMonth() + 1);
      setFrequencyYear(freshLastMonthDate.getFullYear());
    }
  }, [currentModule]);

  useEffect(() => {
    if (profile) {
      if (!sessionStorage.getItem('hiringViewMode')) {
        const mode = profile.role === 'master' ? 'admin' : 'manager';
        setHiringViewMode(mode);
        sessionStorage.setItem('hiringViewMode', mode);
      }
      if (profile.role !== 'master') {
        // Enforce requests tab and first sector for general managers
        setHiringTab('requests');
        sessionStorage.setItem('hiringTab', 'requests');
        setHiringViewMode('manager');
        sessionStorage.setItem('hiringViewMode', 'manager');
        
        if (activeTab !== 'manager') {
          setActiveTab('manager');
          sessionStorage.setItem('activeTab', 'manager');
        }

        if (currentModule === 'frequency_comissionados') {
          if (selectedSector !== '__gabinete__') {
            setSelectedSector('__gabinete__');
            sessionStorage.setItem('selectedSector', '__gabinete__');
          }
        } else if (selectedSector === '__gabinete__') {
          const firstSector = profile.sectors && profile.sectors.length > 0 ? profile.sectors[0] : '';
          setSelectedSector(firstSector);
          sessionStorage.setItem('selectedSector', firstSector);
        } else if (!selectedSector && profile.sectors && profile.sectors.length > 0) {
          setSelectedSector(profile.sectors[0]);
          sessionStorage.setItem('selectedSector', profile.sectors[0]);
        }
      }
    }
  }, [profile, selectedSector, activeTab]);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [sidebarWidth, setSidebarWidth] = useState<number>(() => {
    const saved = localStorage.getItem('sidebarWidth');
    return saved ? parseInt(saved, 10) : 256;
  });
  const [isDragging, setIsDragging] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const startResizing = (mouseDownEvent: React.MouseEvent) => {
    mouseDownEvent.preventDefault();
    setIsDragging(true);
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = Math.min(Math.max(e.clientX, 160), 480);
      setSidebarWidth(newWidth);
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  useEffect(() => {
    localStorage.setItem('sidebarWidth', sidebarWidth.toString());
  }, [sidebarWidth]);

  const [fontSize, setFontSize] = useState<number>(() => {
    const saved = localStorage.getItem('systemFontSize');
    return saved ? parseInt(saved, 10) : 100;
  });

  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}%`;
    localStorage.setItem('systemFontSize', fontSize.toString());
  }, [fontSize]);

  const adjustFontSize = (delta: number) => {
    setFontSize(prev => {
      const next = prev + delta;
      return Math.min(Math.max(next, 70), 150); // Limit range between 70% and 150%
    });
  };

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (user) {
        const email = (user.email || '').toLowerCase();
        
        // Load from localStorage first to guarantee instant loader-free startup and offline support
        const cached = localStorage.getItem(`cached_profile_v1_${email}`);
        if (cached) {
          try {
            const parsed = JSON.parse(cached) as UserProfile;
            setProfile(parsed);
            if (!sessionStorage.getItem('activeTab')) {
              if (parsed.role === 'master') {
                setActiveTab('admin');
                setAdminSubTab('stats');
              } else {
                setActiveTab('manager');
                setSelectedSector('');
              }
            }
            setLoading(false);
          } catch (e) {
            console.warn("Failed parsing cached profile:", e);
          }
        }

        try {
          // Ensure base profile exists (especially for master user)
          await frequencyService.ensureProfileExists(email);

          // Populate user names and CPFs cache for electronic signatures
          frequencyService.getAllUsers().then(users => {
            users.forEach(u => {
              if (u.email && u.name) {
                userNamesCache[u.email.trim().toLowerCase()] = u.name;
              }
              if (u.email && u.cpf) {
                userCpfsCache[u.email.trim().toLowerCase()] = u.cpf;
              }
            });
          }).catch(err => {
            console.warn("Error pre-populating caches:", err);
          });

          // Setup real-time listener for the profile
          unsubscribeProfile = onSnapshot(doc(db, 'users', email), async (snapshot) => {
            if (snapshot.exists()) {
              const p = { uid: snapshot.id, name: user.displayName || undefined, ...snapshot.data() } as UserProfile;
              setProfile(p);
              try {
                localStorage.setItem(`cached_profile_v1_${email}`, JSON.stringify(p));
              } catch (e) {}
              
              // Handle first time load or role-based defaults
              if (!sessionStorage.getItem('activeTab')) {
                if (p.role === 'master') {
                  setActiveTab('admin');
                  setAdminSubTab('stats');
                } else {
                  setActiveTab('manager');
                  setSelectedSector('');
                }
              }
              
              setLoading(false);
            } else {
              // Only treat as non-existent if we are truly online and verified
              toast.error("Acesso não autorizado. Perfil não encontrado.");
              await logout();
              setUser(null);
              setProfile(null);
              setLoading(false);
            }
          }, (error) => {
            console.warn("Profile snapshot subscription update skipped (offline mode):", error);
            // If the listener has an error but we already loaded/bootstrapped from cache or ensureProfileExists,
            // we should not kick the user out, nor keep showing the loading state forever.
            setLoading(false);
          });

        } catch (error) {
          console.warn("Auth process warning (handled gracefully):", error);
          setLoading(false);
        }
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const handleToggleTab = (tab: string) => {
    setActiveTab(tab);
    sessionStorage.setItem('activeTab', tab);
    if (tab === 'manager') {
      setSelectedSector('');
      sessionStorage.setItem('selectedSector', '');
    }
    setIsMobileMenuOpen(false);
  };

  const handleSelectSector = (sector: string) => {
    setSelectedSector(sector);
    sessionStorage.setItem('selectedSector', sector);
    setActiveTab('manager');
    sessionStorage.setItem('activeTab', 'manager');
    setIsMobileMenuOpen(false);
  };

  const handleLogin = async () => {
    if (isLoginLoading) return;
    setIsLoginLoading(true);
    try {
      await loginWithGoogle();
    } catch (error: any) {
      console.warn("Caught auth exception:", error);
      // Ignore common benign Firebase popup closure errors and internal pending assertions
      const isBenign = error?.message?.includes("Pending promise was never set") ||
                       error?.code === "auth/cancelled-popup-request" ||
                       error?.code === "auth/popup-closed-by-user";
      if (!isBenign) {
        toast.error("Erro ao fazer login");
      }
    } finally {
      setIsLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      localStorage.removeItem('currentModule');
      setCurrentModule(null);
      toast.success("Desconectado");
    } catch (error) {
      toast.error("Erro ao sair");
    }
  };

  const isModuleAllowed = (module: 'frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados' | null) => {
    if (!module) return true;
    if (!profile) return false;
    if (profile.role === 'master') return true;
    return profile.allowedModules?.includes(module);
  };

  useEffect(() => {
    if (profile && currentModule) {
      if (!isModuleAllowed(currentModule)) {
        toast.error("Você não tem permissão para acessar este módulo.");
        setCurrentModule(null);
        localStorage.removeItem('currentModule');
      }
    }
  }, [profile, currentModule]);

  const handleSelectModule = (module: 'frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados') => {
    if (!isModuleAllowed(module)) {
      toast.error("Acesso negado para este módulo.");
      return;
    }
    setCurrentModule(module);
    localStorage.setItem('currentModule', module);

    if (module === 'frequency' || module === 'frequency_comissionados') {
       if (profile?.role === 'master') {
          setActiveTab('admin');
          sessionStorage.setItem('activeTab', 'admin');
          setAdminSubTab('stats');
          sessionStorage.setItem('adminSubTab', 'stats');
       } else {
          setActiveTab('manager');
          sessionStorage.setItem('activeTab', 'manager');
       }
       setSelectedSector('');
       sessionStorage.setItem('selectedSector', '');
    } else if (module === 'hiring' || module === 'hiring_comissionados') {
       const isMaster = profile?.role === 'master';
       setHiringViewMode(isMaster ? 'admin' : 'manager');
       sessionStorage.setItem('hiringViewMode', isMaster ? 'admin' : 'manager');
       setHiringTab(isMaster ? 'stats' : 'requests');
       sessionStorage.setItem('hiringTab', isMaster ? 'stats' : 'requests');
       if (!isMaster && profile?.sectors && profile.sectors.length > 0) {
         setSelectedSector(profile.sectors[0]);
         sessionStorage.setItem('selectedSector', profile.sectors[0]);
       } else {
         setSelectedSector('');
         sessionStorage.setItem('selectedSector', '');
       }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-12 text-center">
          <div className="flex flex-col items-center gap-6">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-blue-600/10 rounded-full"></div>
              <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Portal de Gerenciamento de Pessoas</h1>
              <p className="text-gray-600 text-sm font-medium">Iniciando ambiente seguro...</p>
              <p className="text-slate-400 text-[10px] mt-4 uppercase tracking-widest font-bold">Diretoria de Gestão de Pessoas</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const urlParams = new URLSearchParams(window.location.search);
  const signSupervisorId = urlParams.get('signSupervisor');
  const signStudentId = urlParams.get('sign');

  if (signSupervisorId) {
    return <SupervisorSignature requestId={signSupervisorId} />;
  }

  if (signStudentId) {
    return <CandidateSignatureSelector requestId={signStudentId} />;
  }

  // Dashboard only if user AND profile exist AND profile is active
  const isAuthorized = user && profile && profile.active !== false;

  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Toaster position="top-right" />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center"
        >
          <div className="mx-auto mb-8">
            <img src={LOGO_BASE64} alt="CMC Logo" className="h-20 w-auto mx-auto object-contain mix-blend-multiply" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Portal de Gerenciamento de Pessoas</h1>
          <p className="text-gray-600 mb-4">Diretoria de Gestão de Pessoas</p>

          {profile?.active === false ? (
            <div className="bg-red-50 border border-red-100 p-4 rounded-xl mb-8">
              <p className="text-red-600 font-bold text-sm">Conta Inativada</p>
              <p className="text-xs text-red-500 mt-1">Sua conta está inativa. Entre em contato com a Diretoria de Gestão de Pessoas</p>
              <button
                onClick={handleLogout}
                className="mt-4 text-xs font-bold text-red-700 hover:text-red-800 uppercase"
              >
                Voltar
              </button>
            </div>
          ) : (
            <>
              <button
                onClick={handleLogin}
                disabled={isLoginLoading}
                className="w-full flex items-center justify-center gap-3 bg-white border border-gray-300 py-3 px-4 rounded-xl font-medium text-gray-700 hover:bg-gray-50 transition-all shadow-sm mb-4 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoginLoading ? (
                  <div className="w-5 h-5 border-2 border-slate-500 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
                )}
                {isLoginLoading ? "Conectando..." : "Entrar com Google"}
              </button>

              {(window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') && (
                <button
                  onClick={() => {
                    setUser({ email: 'diego.martins@cmc.pr.gov.br', displayName: 'Diego Martins' } as any);
                    setProfile({
                      uid: 'diego.martins@cmc.pr.gov.br',
                      email: 'diego.martins@cmc.pr.gov.br',
                      name: 'Diego Martins (Local Test)',
                      role: 'master',
                      sectors: ['GABINETE 1', 'DIRETORIA DE GESTÃO DE PESSOAS'],
                      active: true,
                      allowedModules: ['frequency', 'hiring', 'frequency_comissionados']
                    });
                  }}
                  className="w-full flex items-center justify-center gap-3 bg-blue-50 border border-blue-200 py-3 px-4 rounded-xl font-bold text-blue-700 hover:bg-blue-100 transition-all shadow-sm"
                >
                  Entrar em Modo de Teste (Localhost)
                </button>
              )}
              
              <p className="text-xs text-gray-400 mt-6 italic">
                Área restrita para funcionários e gestores da CMC.
              </p>
            </>
          )}
        </motion.div>
      </div>
    );
  }

  if (!currentModule) {
    return (
      <>
        <Toaster position="top-right" />
        {viewingUserManagement ? (
          <div className="min-h-screen bg-slate-50 p-6 md:p-12">
            <div className="max-w-6xl mx-auto space-y-6">
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setViewingUserManagement(false)}
                  className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-xs font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all active:scale-[0.98]"
                >
                  ← Voltar para o Menu
                </button>
                <div className="flex items-center gap-3">
                  <img src={LOGO_BASE64} alt="CMC Logo" className="h-10 w-auto object-contain mix-blend-multiply" />
                  <span className="text-xs font-black uppercase text-slate-800 tracking-wider">Painel Administrativo</span>
                </div>
              </div>
              
              <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-4">
                <button
                  onClick={() => setUserMgmtTab('users')}
                  className={`flex items-center gap-2 px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                    userMgmtTab === 'users'
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-100'
                      : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  Gestão de Usuários e Acessos
                </button>
                <button
                  onClick={() => setUserMgmtTab('drive')}
                  className={`flex items-center gap-2 px-5 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                    userMgmtTab === 'drive'
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-100'
                      : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  Status do Google Drive
                </button>
              </div>

              {userMgmtTab === 'users' ? (
                <UserManagement allSectors={allSectors} />
              ) : (
                <DriveDiagnostics />
              )}
            </div>
          </div>
        ) : (
          <ModuleSelector 
            onSelect={handleSelectModule} 
            profile={profile} 
            onOpenUserManagement={() => {
              setUserMgmtTab('users');
              setViewingUserManagement(true);
            }}
          />
        )}
        <div className="fixed top-6 right-6">
           <button 
             onClick={handleLogout}
             className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-full shadow-lg text-xs font-bold text-slate-500 hover:text-red-600 hover:border-red-100 transition-all hover:scale-105"
           >
             <LogOut className="w-4 h-4" /> Sair
           </button>
        </div>
      </>
    );
  }

  return (
    <div 
      className="min-h-screen bg-slate-50 flex flex-col md:flex-row font-sans text-inherit"
      style={{ userSelect: isDragging ? 'none' : 'auto' }}
    >
      <Toaster position="top-right" />
      
      {/* Mobile Header Toggle */}
      <div className="md:hidden flex items-center justify-between p-4 bg-white border-b border-slate-200 shrink-0 z-20 sticky top-0">
        <div className="flex items-center gap-2 text-slate-800 font-bold uppercase tracking-widest text-xs">
          <img src={LOGO_BASE64} alt="CMC Logo" className="h-8 w-auto object-contain mix-blend-multiply" />
          <span className="truncate">Portal de Gerenciamento</span>
        </div>
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Sidebar */}
      <aside 
        id="system-sidebar"
        className={`${isMobileMenuOpen ? 'flex' : 'hidden'} md:flex fixed md:sticky top-[65px] md:top-0 left-0 right-0 bottom-0 z-50 md:z-20 w-full bg-white text-slate-600 flex-col border-r border-slate-200 shrink-0 h-[calc(100vh-65px)] md:h-screen overflow-y-auto ${isDragging ? '' : 'transition-colors'}`}
        style={{ width: isMobile ? '100%' : `${sidebarWidth}px` }}
      >
        <div className="p-6 border-b border-slate-100">
          <div className="flex flex-col items-center gap-3 text-center">
            <img 
              src={LOGO_BASE64} 
              alt="CMC Logo" 
              className="hidden md:block h-16 w-auto object-contain mix-blend-multiply" 
            />
            <div className="w-full">
              <h1 className="hidden md:block font-bold tracking-tight text-slate-800 text-sm leading-tight uppercase font-black mb-3">
                Portal de Gerenciamento de Pessoas
              </h1>
              {currentModule && (
                <div 
                  id="active-module-indicator" 
                  className={`hidden md:block text-[11px] font-extrabold uppercase tracking-wider mb-4 mt-2 px-2.5 py-1.5 rounded-lg text-center border ${
                    (currentModule === 'hiring' || currentModule === 'hiring_comissionados')
                      ? 'text-emerald-700 bg-emerald-50 border-emerald-100'
                      : 'text-blue-700 bg-blue-50 border-blue-100'
                  }`}
                >
                  {currentModule === 'frequency' && 'Frequências Estagiários'}
                  {currentModule === 'frequency_comissionados' && 'Frequências Comissionados'}
                  {currentModule === 'hiring' && 'Contratações Estagiários'}
                  {currentModule === 'hiring_comissionados' && 'Contratações Comissionados'}
                </div>
              )}
              <button 
                id="btn-alterar-modulo" 
                onClick={() => {
                  setCurrentModule(null);
                  localStorage.removeItem('currentModule');
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest py-2 rounded-lg transition-all border active:scale-[0.98] ${
                  (currentModule === 'hiring' || currentModule === 'hiring_comissionados')
                    ? 'bg-white text-emerald-600 border-slate-200 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 shadow-sm'
                    : 'bg-white text-blue-600 border-slate-200 hover:bg-blue-600 hover:text-white hover:border-blue-600 shadow-sm'
                }`}
              >
                <CornerUpLeft className="w-3.5 h-3.5" />
                TELA INICIAL
              </button>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-4">
          {(currentModule === 'frequency' || currentModule === 'frequency_comissionados') ? (
            <>
              {profile?.role === 'master' && (
                <div className="space-y-4">
                  <div>
                    <p className="px-3 text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Monitoramento</p>
                    <SidebarItem 
                      icon={<LayoutDashboard className="w-4 h-4" />} 
                      label="Painel" 
                      active={activeTab === 'admin' && adminSubTab === 'stats'} 
                      colorClass="bg-blue-600"
                      onClick={() => {
                        handleToggleTab('admin');
                        setAdminSubTab('stats');
                        sessionStorage.setItem('adminSubTab', 'stats');
                        setIsMobileMenuOpen(false);
                      }} 
                    />
                    <SidebarItem 
                      icon={<Users className="w-4 h-4" />} 
                      label="Listagem Geral" 
                      active={activeTab === 'admin' && adminSubTab === 'records_list'} 
                      colorClass="bg-blue-600"
                      onClick={() => {
                        handleToggleTab('admin');
                        setAdminSubTab('records_list');
                        sessionStorage.setItem('adminSubTab', 'records_list');
                        setIsMobileMenuOpen(false);
                      }} 
                    />
                  </div>

                  <div>
                    <p className="px-3 text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Validação</p>
                    <div className="space-y-1">
                      <SidebarItem 
                        icon={<Search className="w-4 h-4" />} 
                        label="Frequências Pendentes" 
                        active={activeTab === 'admin' && adminSubTab === 'records_pending'} 
                        colorClass="bg-blue-600"
                        onClick={() => {
                          handleToggleTab('admin');
                          setAdminSubTab('records_pending');
                          sessionStorage.setItem('adminSubTab', 'records_pending');
                          setIsMobileMenuOpen(false);
                        }} 
                      />
                      <SidebarItem 
                        icon={<FileText className="w-4 h-4" />} 
                        label="Frequências Recebidas" 
                        active={activeTab === 'admin' && adminSubTab === 'records_received'} 
                        colorClass="bg-blue-600"
                        onClick={() => {
                          handleToggleTab('admin');
                          setAdminSubTab('records_received');
                          sessionStorage.setItem('adminSubTab', 'records_received');
                          setIsMobileMenuOpen(false);
                        }} 
                      />
                      <SidebarItem 
                        icon={<CheckCircle2 className="w-4 h-4" />} 
                        label="Frequências Validadas" 
                        active={activeTab === 'admin' && adminSubTab === 'records_validated'} 
                        colorClass="bg-blue-600"
                        onClick={() => {
                          handleToggleTab('admin');
                          setAdminSubTab('records_validated');
                          sessionStorage.setItem('adminSubTab', 'records_validated');
                          setIsMobileMenuOpen(false);
                        }} 
                      />
                    </div>
                  </div>

                  <div>
                    <p className="px-3 text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Sistema</p>
                    <div className="space-y-1">
                      <SidebarItem 
                        icon={<Settings className="w-4 h-4" />} 
                        label="Configurações" 
                        active={activeTab === 'admin' && adminSubTab === 'settings'} 
                        colorClass="bg-blue-600"
                        onClick={() => {
                          handleToggleTab('admin');
                          setAdminSubTab('settings');
                          sessionStorage.setItem('adminSubTab', 'settings');
                          setIsMobileMenuOpen(false);
                        }} 
                      />
                    </div>
                  </div>
                </div>
              )}


              <div className="pt-2 border-t border-slate-100">
                <p className="px-3 text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">
                  {currentModule === 'frequency_comissionados' ? 'Gabinete Parlamentar' : 'Envio de Frequências'}
                </p>
                <div className="space-y-1 mt-1">
                  {currentModule === 'frequency_comissionados' ? (
                    <>
                      <SidebarItem
                        icon={<Building2 className="w-4 h-4" />}
                        label="Gerenciar Gabinete"
                        active={activeTab === 'manager' && selectedSector === '__gabinete__'}
                        colorClass="bg-blue-600"
                        onClick={() => handleSelectSector('__gabinete__')}
                      />
                      {profile?.sectors?.some(s => s.trim().toUpperCase() === 'GABINETE DA PRESIDÊNCIA') && (
                        <SidebarItem
                          icon={<Building2 className="w-4 h-4" />}
                          label="Gabinete da Presidência"
                          active={activeTab === 'manager' && selectedSector === 'GABINETE DA PRESIDÊNCIA'}
                          colorClass="bg-blue-600"
                          onClick={() => handleSelectSector('GABINETE DA PRESIDÊNCIA')}
                        />
                      )}
                    </>
                  ) : (
                    profile?.sectors?.map(sector => (
                      <SidebarItem
                        key={sector}
                        icon={<Building2 className="w-4 h-4" />}
                        label={sector}
                        active={activeTab === 'manager' && selectedSector === sector}
                        colorClass="bg-blue-600"
                        onClick={() => handleSelectSector(sector)}
                      />
                    ))
                  )}
                  {(!profile?.sectors || profile.sectors.length === 0) && (
                    <p className="px-4 py-2 text-[10px] text-slate-400 italic font-medium">Nenhuma lotação vinculada</p>
                  )}
                </div>
              </div>
            </>
          ) : (
            // Hiring Module Sidebar
            <div className="space-y-4">
              {profile?.role === 'master' && (
                <div className="space-y-4">
                  <div>
                    <p className="px-3 text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Gestão</p>
                    <SidebarItem 
                      icon={<LayoutDashboard className="w-4 h-4" />} 
                      label="Gestão de Requerimentos" 
                      active={hiringTab === 'stats' && hiringViewMode === 'admin'} 
                      colorClass={hiringColor}
                      onClick={() => {
                        setHiringTab('stats');
                        setHiringViewMode('admin');
                        sessionStorage.setItem('hiringTab', 'stats');
                        sessionStorage.setItem('hiringViewMode', 'admin');
                        setSelectedSector('');
                        sessionStorage.setItem('selectedSector', '');
                        setIsMobileMenuOpen(false);
                      }} 
                    />
                  </div>


                </div>
              )}

              <div className="pt-2 border-t border-slate-100">
                <p className="px-3 text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">{hiringLabel}</p>
                <div className="space-y-1 mt-1">
                  {profile?.sectors?.map(sector => (
                    <SidebarItem
                      key={sector}
                      icon={<Building2 className="w-4 h-4" />}
                      label={sector}
                      active={hiringTab === 'requests' && hiringViewMode === 'manager' && selectedSector === sector}
                      colorClass={hiringColor}
                      onClick={() => {
                        handleSelectSector(sector);
                        setHiringTab('requests');
                        setHiringViewMode('manager');
                        sessionStorage.setItem('hiringViewMode', 'manager');
                        setIsMobileMenuOpen(false);
                      }}
                    />
                  ))}
                  {(!profile?.sectors || profile.sectors.length === 0) && (
                    <p className="px-4 py-2 text-[10px] text-slate-400 italic font-medium">Nenhuma lotação vinculada</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </nav>

        <div className="p-4 mt-auto border-t border-slate-100">
          <div className="flex flex-col gap-2 mb-4">
            <p className="px-3 text-[9px] uppercase font-bold text-slate-400 tracking-wider">Acessibilidade</p>
            <div className="flex items-center gap-2 px-2">
              <button 
                onClick={() => adjustFontSize(-10)}
                className="flex-1 flex items-center justify-center gap-1.5 text-[10px] font-bold text-slate-500 hover:text-blue-600 p-2 rounded-lg transition-all border border-slate-200 hover:bg-blue-50 active:scale-95"
                title="Diminuir fonte"
              >
                <ZoomOut className="w-3 h-3" />
                A-
              </button>
              <button 
                onClick={() => setFontSize(100)}
                className="px-2.5 py-2 text-[10px] font-bold text-slate-400 hover:text-slate-600 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all"
                title="Resetar fonte"
              >
                100%
              </button>
              <button 
                onClick={() => adjustFontSize(10)}
                className="flex-1 flex items-center justify-center gap-1.5 text-[10px] font-bold text-slate-500 hover:text-blue-600 p-2 rounded-lg transition-all border border-slate-200 hover:bg-blue-50 active:scale-95"
                title="Aumentar fonte"
              >
                <ZoomIn className="w-3 h-3" />
                A+
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100 mb-4">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-[10px] uppercase font-bold text-blue-600">
              {user.displayName?.charAt(0) || user.email?.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <p className="text-[11px] font-bold text-slate-900 truncate">{user.displayName || 'Usuário'}</p>
                <span className="text-[8px] font-mono text-slate-400 shrink-0">v1.5.1</span>
              </div>
              <p className="text-[9px] text-slate-500 truncate tracking-tight">{user.email}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-red-600 py-2.5 rounded-lg transition-all border border-slate-200 hover:bg-red-50 hover:border-red-100 active:scale-[0.98]"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sair do sistema
          </button>
        </div>
      </aside>

      {/* Resizer Handle */}
      {!isMobile && (
        <div
          id="sidebar-resizer"
          onMouseDown={startResizing}
          className={`hidden md:flex items-center justify-center w-1 hover:w-1.5 bg-slate-200/80 hover:bg-blue-300 cursor-col-resize transition-all shrink-0 relative z-30 select-none ${
            isDragging ? 'bg-blue-400 w-1.5 ring-2 ring-blue-100/50' : ''
          }`}
          title="Arraste para redimensionar o menu"
        >
          <div className={`w-[2px] h-6 rounded bg-slate-400/60 transition-opacity hover:opacity-100 ${isDragging ? 'opacity-100 bg-blue-600' : ''}`} />
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col bg-slate-50 min-h-screen">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentModule + activeTab + (activeTab === 'admin' ? adminSubTab : selectedSector)}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="flex-1 flex flex-col"
          >
            {(currentModule === 'frequency' || currentModule === 'frequency_comissionados') && (
              <>
                {activeTab === 'admin' && profile?.role === 'master' && (
                  <AdminDashboard 
                    profile={profile} 
                    initialTab={adminSubTab as any} 
                    onTabChange={(tab: string) => {
                      setAdminSubTab(tab);
                      sessionStorage.setItem('adminSubTab', tab);
                    }}
                    month={frequencyMonth}
                    setMonth={setFrequencyMonth}
                    year={frequencyYear}
                    setYear={setFrequencyYear}
                    isComissionados={currentModule === 'frequency_comissionados'}
                  />
                )}
                {activeTab === 'manager' && (
                  <ManagerDashboard 
                    profile={profile} 
                    selectedSector={selectedSector}
                    setSelectedSector={handleSelectSector}
                    month={frequencyMonth}
                    setMonth={setFrequencyMonth}
                    year={frequencyYear}
                    setYear={setFrequencyYear}
                    isComissionados={currentModule === 'frequency_comissionados'}
                  />
                )}
              </>
            )}
            {currentModule === 'hiring' && (
              <HiringDashboard 
                profile={profile} 
                activeTab={hiringTab} 
                onTabChange={(tab) => {
                  setHiringTab(tab);
                  sessionStorage.setItem('hiringTab', tab);
                }}
                viewMode={hiringViewMode}
                onViewModeChange={(mode) => {
                  setHiringViewMode(mode);
                  sessionStorage.setItem('hiringViewMode', mode);
                }}
                selectedSector={selectedSector}
                onSelectSector={handleSelectSector}
              />
            )}
            {currentModule === 'hiring_comissionados' && (
              <ComissionadosDashboard 
                profile={profile} 
                activeTab={hiringTab} 
                onTabChange={(tab) => {
                  setHiringTab(tab);
                  sessionStorage.setItem('hiringTab', tab);
                }}
                viewMode={hiringViewMode}
                onViewModeChange={(mode) => {
                  setHiringViewMode(mode);
                  sessionStorage.setItem('hiringViewMode', mode);
                }}
                selectedSector={selectedSector}
                onSelectSector={handleSelectSector}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick, colorClass = 'bg-blue-600' }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void, colorClass?: string }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
        active 
          ? `${colorClass} text-white shadow-lg` 
          : `text-slate-500 hover:${colorClass.replace('bg-', 'text-')} hover:${colorClass.replace('bg-', 'bg-').replace('600', '50').replace('700', '50').replace('500', '50')}/50`
      }`}
    >
      <span className={`${active ? 'text-white' : 'text-slate-400'}`}>{icon}</span>
      <span className="text-left whitespace-normal break-words leading-tight flex-1">{label}</span>
      {active && <div className="ml-auto w-1 h-3 bg-white/30 rounded-full shrink-0" />}
    </button>
  );
}

function CandidateSignatureSelector({ requestId }: { requestId: string }) {
  const [category, setCategory] = useState<'comissionado' | 'intern' | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    hiringService.getRequest(requestId).then(req => {
      if (req) {
        setCategory(req.category === 'comissionado' ? 'comissionado' : 'intern');
      } else {
        setError('Solicitação não encontrada.');
      }
      setLoading(false);
    }).catch(err => {
      console.error(err);
      setError('Erro ao carregar os dados.');
      setLoading(false);
    });
  }, [requestId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-4">
        <div className="w-12 h-12 border-4 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest font-sans">Carregando ambiente...</p>
      </div>
    );
  }

  if (error || !category) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-[32px] shadow-xl max-w-md w-full text-center border border-slate-100">
           <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Lock className="w-8 h-8" />
           </div>
           <h1 className="text-xl font-black text-slate-900 uppercase mb-2">Acesso Negado</h1>
           <p className="text-sm text-slate-500 font-medium leading-relaxed">
             {error || 'Não foi possível carregar a solicitação correspondente.'}
           </p>
        </div>
      </div>
    );
  }

  if (category === 'comissionado') {
    return <ComissionadosOnboarding requestId={requestId} />;
  }

  return <StudentSignature requestId={requestId} />;
}
