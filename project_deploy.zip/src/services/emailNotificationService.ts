import { collection, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { HiringRequest } from '../types';

export const emailNotificationService = {
  /**
   * Helper to format action emails for the Firebase "Trigger Email" extension.
   * Default collection is 'mail' as recommended by Firebase
   */
  async queueEmail(to: string, subject: string, text: string, html: string) {
    try {
      await addDoc(collection(db, 'mail'), {
        to: [to],
        message: {
          subject,
          text,
          html,
        },
        createdAt: new Date().toISOString(),
      });
      console.log(`E-mail enfileirado com sucesso no Firestore para: ${to}`);
    } catch (error) {
      console.error('Erro ao registrar e-mail no Firestore para envio automático:', error);
    }
  },

  /**
   * Sends or queues the signature invite for the Supervisor.
   */
  async sendSupervisorInvite(request: HiringRequest) {
    let baseUrl = window.location.origin + window.location.pathname;
    if (!baseUrl.endsWith('/')) {
      baseUrl += '/';
    }
    const signUrl = `${baseUrl}?signSupervisor=${request.id}`;
    
    const isComissionado = request.category === 'comissionado';
    const studentName = request.student?.name || (isComissionado ? 'Servidor Indicado' : 'Estudante Selecionado');
    const sectorName = request.sector || 'sua respectiva unidade';

    const subject = isComissionado
      ? `[PORTAL DE NOMEAÇÕES - CMC] Nova Assinatura Pendente - Proponente`
      : `[PORTAL DE ESTÁGIOS - CMC] Nova Assinatura Pendente - Supervisor`;
    
    const text = isComissionado
      ? `Olá, ${request.supervisor.name}.\n\n` +
        `Uma nova solicitação de nomeação relacionada ao gabinete/setor "${sectorName}" para o candidato "${studentName}" aguarda sua assinatura digital (Assinatura de Vereador/Proponente).\n\n` +
        `Por favor, acesse o link abaixo para registrar sua assinatura digital no sistema:\n` +
        `${signUrl}\n\n` +
        `Atenciosamente,\n` +
        `DGEP - Diretoria de Gestão de Pessoas\n` +
        `Câmara Municipal de Curitiba`
      : `Olá, ${request.supervisor.name}.\n\n` +
        `Uma nova solicitação de estágio relacionada ao setor "${sectorName}" para o candidato "${studentName}" aguarda sua assinatura digital (Assinatura de Supervisor).\n\n` +
        `Por favor, acesse o link abaixo para registrar sua assinatura digital no sistema:\n` +
        `${signUrl}\n\n` +
        `Atenciosamente,\n` +
        `DGEP - Diretoria de Gestão de Pessoas\n` +
        `Câmara Municipal de Curitiba`;

    const html = isComissionado
      ? `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 16px; color: #1e293b;">
        <div style="border-bottom: 2px solid #4f46e5; padding-bottom: 16px; margin-bottom: 24px;">
          <h2 style="margin: 0; color: #1e3a8a; font-size: 20px; font-weight: 800; letter-spacing: -0.025em; text-transform: uppercase;">Portal de Nomeações - CMC</h2>
          <p style="margin: 4px 0 0 0; font-size: 10px; color: #64748b; font-weight: bold; text-transform: uppercase; letter-spacing: 0.1em;">Câmara Municipal de Curitiba</p>
        </div>
        
        <p style="font-size: 15px; line-height: 1.6; margin-bottom: 16px;">Prezado(a) <strong>${request.supervisor.name}</strong>,</p>
        
        <p style="font-size: 14px; line-height: 1.6; color: #334155; margin-bottom: 20px;">
          Uma indicação de nomeação de servidor comissionado para o gabinete/setor <strong>${sectorName}</strong> com o candidato <strong>${studentName}</strong> aguarda a sua assinatura de proponente no Formulário 3.
        </p>
        
        <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; border-radius: 12px; padding: 16px; margin-bottom: 24px;">
          <h4 style="margin: 0 0 8px 0; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #475569;">Detalhes do Requerimento</h4>
          <table style="width: 100%; font-size: 13px; color: #475569;">
            <tr>
              <td style="padding: 4px 0; font-weight: bold; width: 120px;">Tipo:</td>
              <td style="padding: 4px 0; color: #0f172a;">${request.type === 'resignation' ? 'Exoneração de Comissionado' : 'Nomeação de Comissionado'}</td>
            </tr>
            <tr>
              <td style="padding: 4px 0; font-weight: bold;">Gabinete/Setor:</td>
              <td style="padding: 4px 0; color: #0f172a;">${sectorName}</td>
            </tr>
            <tr>
              <td style="padding: 4px 0; font-weight: bold;">Candidato:</td>
              <td style="padding: 4px 0; color: #0f172a;">${studentName}</td>
            </tr>
          </table>
        </div>
        
        <div style="text-align: center; margin: 32px 0;">
          <a href="${signUrl}" target="_blank" style="background-color: #4f46e5; color: #ffffff; padding: 14px 28px; border-radius: 10px; font-size: 14px; font-weight: bold; text-decoration: none; display: inline-block; cursor: pointer; box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2);">
            ASSINAR REQUERIMENTO
          </a>
        </div>
        
        <p style="font-size: 12px; color: #64748b; line-height: 1.5; margin-top: 32px;">
          Caso o botão acima não funcione, copie e cole o seguinte endereço em seu navegador:<br>
          <a href="${signUrl}" target="_blank" style="color: #4f46e5; word-break: break-all;">${signUrl}</a>
        </p>
        
        <div style="border-top: 1px solid #e2e8f0; margin-top: 32px; padding-top: 16px; font-size: 11px; color: #94a3b8; text-align: center; line-height: 1.5;">
          Este é um e-mail automático enviado pelo Portal de Gestão de Pessoas.<br>
          Dúvidas ou problemas? Contate: <strong>dgep@cmc.pr.gov.br</strong>
        </div>
      </div>
      `
      : `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 16px; color: #1e293b;">
        <div style="border-bottom: 2px solid #3b82f6; padding-bottom: 16px; margin-bottom: 24px;">
          <h2 style="margin: 0; color: #1e3a8a; font-size: 20px; font-weight: 800; letter-spacing: -0.025em; text-transform: uppercase;">Portal de Estágios - CMC</h2>
          <p style="margin: 4px 0 0 0; font-size: 10px; color: #64748b; font-weight: bold; text-transform: uppercase; letter-spacing: 0.1em;">Câmara Municipal de Curitiba</p>
        </div>
        
        <p style="font-size: 15px; line-height: 1.6; margin-bottom: 16px;">Prezado(a) <strong>${request.supervisor.name}</strong>,</p>
        
        <p style="font-size: 14px; line-height: 1.6; color: #334155; margin-bottom: 20px;">
          Uma solicitação de estágio para o setor <strong>${sectorName}</strong> com o candidato <strong>${studentName}</strong> aguarda a sua assinatura técnica de supervisor.
        </p>
        
        <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; border-radius: 12px; padding: 16px; margin-bottom: 24px;">
          <h4 style="margin: 0 0 8px 0; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #475569;">Detalhes do Requerimento</h4>
          <table style="width: 100%; font-size: 13px; color: #475569;">
            <tr>
              <td style="padding: 4px 0; font-weight: bold; width: 120px;">Tipo:</td>
              <td style="padding: 4px 0; color: #0f172a;">${request.type === 'resignation' ? 'Rescisão de Estágio' : request.type === 'opening' ? 'Abertura de Vaga' : 'Contratação'}</td>
            </tr>
            <tr>
              <td style="padding: 4px 0; font-weight: bold;">Unidade/Setor:</td>
              <td style="padding: 4px 0; color: #0f172a;">${sectorName}</td>
            </tr>
            <tr>
              <td style="padding: 4px 0; font-weight: bold;">Candidato:</td>
              <td style="padding: 4px 0; color: #0f172a;">${studentName}</td>
            </tr>
          </table>
        </div>
        
        <div style="text-align: center; margin: 32px 0;">
          <a href="${signUrl}" target="_blank" style="background-color: #2563eb; color: #ffffff; padding: 14px 28px; border-radius: 10px; font-size: 14px; font-weight: bold; text-decoration: none; display: inline-block; cursor: pointer; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);">
            ASSINAR REQUERIMENTO
          </a>
        </div>
        
        <p style="font-size: 12px; color: #64748b; line-height: 1.5; margin-top: 32px;">
          Caso o botão acima não funcione, copie e cole o seguinte endereço em seu navegador:<br>
          <a href="${signUrl}" target="_blank" style="color: #2563eb; word-break: break-all;">${signUrl}</a>
        </p>
        
        <div style="border-top: 1px solid #e2e8f0; margin-top: 32px; padding-top: 16px; font-size: 11px; color: #94a3b8; text-align: center; line-height: 1.5;">
          Este é um e-mail automático enviado pelo Portal de Gestão de Estágios.<br>
          Dúvidas ou problemas? Contate: <strong>dgep@cmc.pr.gov.br</strong>
        </div>
      </div>
    `;

    await this.queueEmail(request.supervisor.email, subject, text, html);
  },

  /**
   * Sends or queues the signature invite for the Student.
   */
  async sendStudentInvite(request: HiringRequest) {
    if (!request.student?.email) return;

    let baseUrl = window.location.origin + window.location.pathname;
    if (!baseUrl.endsWith('/')) {
      baseUrl += '/';
    }
    const signUrl = `${baseUrl}?sign=${request.id}`;
    
    const isComissionado = request.category === 'comissionado';
    const studentName = request.student?.name || (isComissionado ? 'Candidato' : 'Estudante');
    const sectorName = request.sector || 'unidade designada';

    const subject = isComissionado
      ? `[PORTAL DE NOMEAÇÕES - CMC] Novo Pré-Cadastro Pendente - Servidor`
      : `[PORTAL DE ESTÁGIOS - CMC] Nova Assinatura Pendente - Estudante`;
    
    const text = isComissionado
      ? `Olá, ${studentName}.\n\n` +
        `Seu pré-cadastro para nomeação em cargo comissionado na Câmara Municipal de Curitiba (Setor/Gabinete: ${sectorName}) foi iniciado e aguarda o preenchimento de seus dados e assinaturas digitais obrigatórias.\n\n` +
        `Por favor, acesse o link abaixo para completar seu pré-cadastro:\n` +
        `${signUrl}\n\n` +
        `Atenciosamente,\n` +
        `DGEP - Diretoria de Gestão de Pessoas\n` +
        `Câmara Municipal de Curitiba`
      : `Olá, ${studentName}.\n\n` +
        `Seu requerimento para início de estágio na Câmara Municipal de Curitiba (Setor: ${sectorName}) foi gerado e aguarda sua assinatura digital obrigatória.\n\n` +
        `Por favor, acesse o link abaixo para assinar digitalmente e concluir a sua etapa do requerimento:\n` +
        `${signUrl}\n\n` +
        `Atenciosamente,\n` +
        `DGEP - Diretoria de Gestão de Pessoas\n` +
        `Câmara Municipal de Curitiba`;

    const html = isComissionado
      ? `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 16px; color: #1e293b;">
        <div style="border-bottom: 2px solid #4f46e5; padding-bottom: 16px; margin-bottom: 24px;">
          <h2 style="margin: 0; color: #1e3a8a; font-size: 20px; font-weight: 800; letter-spacing: -0.025em; text-transform: uppercase;">Portal de Nomeações - CMC</h2>
          <p style="margin: 4px 0 0 0; font-size: 10px; color: #64748b; font-weight: bold; text-transform: uppercase; letter-spacing: 0.1em;">Câmara Municipal de Curitiba</p>
        </div>
        
        <p style="font-size: 15px; line-height: 1.6; margin-bottom: 16px;">Prezado(a) <strong>${studentName}</strong>,</p>
        
        <p style="font-size: 14px; line-height: 1.6; color: #334155; margin-bottom: 20px;">
          Seu pré-cadastro de nomeação para cargo comissionado na Câmara Municipal de Curitiba junto ao gabinete/setor <strong>${sectorName}</strong> foi iniciado e aguarda suas informações.
        </p>
        
        <div style="background-color: #eef2ff; border: 1px solid #e0e7ff; border-radius: 12px; padding: 16px; margin-bottom: 24px;">
          <p style="margin: 0; font-size: 12px; color: #4338ca; font-weight: 600;">
            O preenchimento dos Formulários de 2 a 6 e suas respectivas assinaturas digitais são etapas obrigatórias para consolidação do seu processo de nomeação.
          </p>
        </div>
        
        <div style="text-align: center; margin: 32px 0;">
          <a href="${signUrl}" target="_blank" style="background-color: #4f46e5; color: #ffffff; padding: 14px 28px; border-radius: 10px; font-size: 14px; font-weight: bold; text-decoration: none; display: inline-block; cursor: pointer; box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2);">
            REALIZAR MEU PRÉ-CADASTRO
          </a>
        </div>
        
        <p style="font-size: 12px; color: #64748b; line-height: 1.5; margin-top: 32px;">
          Caso o botão acima não funcione, copie e cole o seguinte endereço em seu navegador:<br>
          <a href="${signUrl}" target="_blank" style="color: #4f46e5; word-break: break-all;">${signUrl}</a>
        </p>
        
        <div style="border-top: 1px solid #e2e8f0; margin-top: 32px; padding-top: 16px; font-size: 11px; color: #94a3b8; text-align: center; line-height: 1.5;">
          Este é um e-mail automático enviado pelo Portal de Gestão de Pessoas.<br>
          Dúvidas ou problemas? Contate: <strong>dgep@cmc.pr.gov.br</strong>
        </div>
      </div>
      `
      : `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 16px; color: #1e293b;">
        <div style="border-bottom: 2px solid #10b981; padding-bottom: 16px; margin-bottom: 24px;">
          <h2 style="margin: 0; color: #065f46; font-size: 20px; font-weight: 800; letter-spacing: -0.025em; text-transform: uppercase;">Portal de Estágios - CMC</h2>
          <p style="margin: 4px 0 0 0; font-size: 10px; color: #64748b; font-weight: bold; text-transform: uppercase; letter-spacing: 0.1em;">Câmara Municipal de Curitiba</p>
        </div>
        
        <p style="font-size: 15px; line-height: 1.6; margin-bottom: 16px;">Prezado(a) <strong>${studentName}</strong>,</p>
        
        <p style="font-size: 14px; line-height: 1.6; color: #334155; margin-bottom: 20px;">
          Seu requerimento de ingresso de estágio na Câmara Municipal de Curitiba para atuação junto à unidade <strong>${sectorName}</strong> foi formalizado e está aguardando a sua assinatura digital.
        </p>
        
        <div style="background-color: #f0fdf4; border: 1px solid #dcfce7; border-radius: 12px; padding: 16px; margin-bottom: 24px;">
          <p style="margin: 0; font-size: 12px; color: #15803d; font-weight: 600;">
            A assinatura é um passo fundamental e obrigatório para que a DGEP dê andamento à sua contratação e emissão de termos regulamentares.
          </p>
        </div>
        
        <div style="text-align: center; margin: 32px 0;">
          <a href="${signUrl}" target="_blank" style="background-color: #10b981; color: #ffffff; padding: 14px 28px; border-radius: 10px; font-size: 14px; font-weight: bold; text-decoration: none; display: inline-block; cursor: pointer; box-shadow: 0 4px 6px -1px rgba(16, 185, 129, 0.2);">
            EFETUAR MINHA ASSINATURA INDIVIDUAL
          </a>
        </div>
        
        <p style="font-size: 12px; color: #64748b; line-height: 1.5; margin-top: 32px;">
          Caso o botão acima não funcione, copie e cole o seguinte endereço em seu navegador:<br>
          <a href="${signUrl}" target="_blank" style="color: #10b981; word-break: break-all;">${signUrl}</a>
        </p>
        
        <div style="border-top: 1px solid #e2e8f0; margin-top: 32px; padding-top: 16px; font-size: 11px; color: #94a3b8; text-align: center; line-height: 1.5;">
          Este é um e-mail automático enviado pelo Portal de Gestão de Estágios.<br>
          Dúvidas ou problemas? Contate: <strong>dgep@cmc.pr.gov.br</strong>
        </div>
      </div>
    `;

    await this.queueEmail(request.student.email, subject, text, html);
  }
};
