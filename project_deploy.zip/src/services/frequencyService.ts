// Deployment trigger - 2026-06-05
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  limit,
  setDoc, 
  updateDoc, 
  deleteDoc, 
  addDoc,
  writeBatch,
  Timestamp,
  Bytes 
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { FrequencyRecord, UserProfile, FrequencyStatus, GeneratedDocument } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { googleDriveService, UploadContext, extractDriveFileId } from './googleDriveService';
import { userNamesCache } from '../lib/pdfGenerator';
import { getBackendUrl } from '../lib/api';

const FREQ_COLLECTION = 'frequencies';
const FREQ_COM_COLLECTION = 'frequencies_comissionados';
const INTERNS_COLLECTION = 'interns';
const COMISSIONADOS_COLLECTION = 'comissionados';
const USER_COLLECTION = 'users';
const ARCHIVE_COLLECTION = 'archive';
const ARCHIVE_COM_COLLECTION = 'archive_comissionados';
const BLOBS_COLLECTION = 'blobs';

function sanitizeDetails(details: any): any {
  if (!details) return {};
  const cleaned: any = {};
  Object.keys(details).forEach(key => {
    const val = details[key];
    if (val === undefined) {
      cleaned[key] = '';
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      cleaned[key] = sanitizeDetails(val);
    } else if (Array.isArray(val)) {
      cleaned[key] = val.map(item => (item && typeof item === 'object') ? sanitizeDetails(item) : (item === undefined ? '' : item));
    } else {
      cleaned[key] = val;
    }
  });
  return cleaned;
}

const compressImage = async (file: Blob, maxDimension: number = 1600, quality: number = 0.75): Promise<Blob> => {
  return new Promise((resolve) => {
    if (!file.type.startsWith('image/') || file.type.includes('svg') || file.type.includes('gif')) {
      resolve(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(file);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);

        const outputType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const name = (file as any).name || 'image';
              const compressedFile = new File([blob], name, {
                type: outputType,
                lastModified: Date.now(),
              });
              console.log(`Optimized image from ${file.size} to ${compressedFile.size} bytes`);
              resolve(compressedFile);
            } else {
              resolve(file);
            }
          },
          outputType,
          quality
        );
      };
      img.onerror = () => resolve(file);
      img.src = event.target?.result as string;
    };
    reader.onerror = () => resolve(file);
    reader.readAsDataURL(file);
  });
};

export const frequencyService = {
  // Generic helper for getting frequencies by period with auto-deduplication and auto-creation
  async getFrequenciesByPeriodGeneric(
    month: number,
    year: number,
    isComissionados: boolean,
    lotacoesInput?: string | string[]
  ): Promise<any[]> {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    const peopleColl = isComissionados ? COMISSIONADOS_COLLECTION : INTERNS_COLLECTION;
    
    let lotacoes: string[] | undefined = undefined;
    if (lotacoesInput) {
      lotacoes = Array.isArray(lotacoesInput) ? lotacoesInput : [lotacoesInput];
    }

    try {
      // 1. Get existing records first
      let rawRecords: any[] = [];
      if (lotacoes && lotacoes.length > 0) {
        for (let i = 0; i < lotacoes.length; i += 10) {
          const chunk = lotacoes.slice(i, i + 10);
          const chunkQ = query(collection(db, freqColl),
            where('month', '==', month),
            where('year', '==', year),
            where('lotacao', 'in', chunk)
          );
          const snap = await getDocs(chunkQ);
          snap.docs.forEach(doc => {
            rawRecords.push({ id: doc.id, ...doc.data() });
          });
        }
      } else {
        const q = query(collection(db, freqColl), 
          where('month', '==', month), 
          where('year', '==', year)
        );
        const querySnapshot = await getDocs(q);
        rawRecords = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      }

      // Auto-deduplicate
      const uniqueRecordsMap: { [key: string]: any } = {};
      const duplicatesToDelete: string[] = [];

      rawRecords.forEach(rec => {
        const key = rec.internName.trim().toUpperCase();
        if (uniqueRecordsMap[key]) {
          duplicatesToDelete.push(rec.id);
        } else {
          uniqueRecordsMap[key] = rec;
        }
      });

      if (duplicatesToDelete.length > 0) {
        const delBatch = writeBatch(db);
        duplicatesToDelete.forEach(id => {
          delBatch.delete(doc(db, freqColl, id));
        });
        await delBatch.commit();
      }

      const existingRecords = rawRecords.filter(r => !duplicatesToDelete.includes(r.id));

      // 2. Fetch all active people (interns or comissionados)
      let allPeople: any[] = [];
      try {
        if (lotacoes && lotacoes.length > 0) {
          for (let i = 0; i < lotacoes.length; i += 10) {
            const chunk = lotacoes.slice(i, i + 10);
            const chunkQ = query(collection(db, peopleColl), where('lotacao', 'in', chunk));
            const snap = await getDocs(chunkQ);
            snap.docs.forEach(doc => {
              allPeople.push({ id: doc.id, ...doc.data() });
            });
          }
        } else {
          const snap = await getDocs(collection(db, peopleColl));
          allPeople = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        }
      } catch (err) {
        console.warn(`Could not fetch ${peopleColl}:`, err);
        return existingRecords;
      }

      if (allPeople.length === 0) {
        return existingRecords;
      }
      
      const startMonth = new Date(year, month - 1, 1);
      const endMonth = new Date(year, month, 0);

      const activePeople = allPeople.filter(person => {
        if (person.importYear !== undefined && person.importMonth !== undefined) {
          if (year < person.importYear) return false;
          if (year === person.importYear && month < person.importMonth) return false;
        }

        const adm = parseDateBR(person.dataAdmissao);
        if (!adm) return true;
        if (adm > endMonth) return false;

        const res = parseDateBR(person.dataRescisao);
        if (res && res < startMonth) return false;

        return true;
      });

      const filteredActivePeople = lotacoes && lotacoes.length > 0
        ? activePeople.filter(i => lotacoes!.includes(i.lotacao))
        : activePeople;

      let syncedRecordsCount = 0;
      const syncBatch = writeBatch(db);
      const updatedExistingRecords = [...existingRecords];

      existingRecords.forEach((record, index) => {
        const match = filteredActivePeople.find(person =>
          (record.matricula && person.matricula && String(record.matricula).trim().toUpperCase() === String(person.matricula).trim().toUpperCase()) ||
          record.internName.trim().toUpperCase() === person.internName.trim().toUpperCase()
        );

        if (match) {
          let recChanged = false;
          const updateData: any = {};

          if (!record.matricula && match.matricula) {
            updateData.matricula = match.matricula;
            record.matricula = match.matricula;
            recChanged = true;
          }

          if (match.internName && record.internName !== match.internName) {
            updateData.internName = match.internName;
            record.internName = match.internName;
            recChanged = true;
          }

          if (match.lotacao && record.lotacao !== match.lotacao) {
            updateData.lotacao = match.lotacao;
            record.lotacao = match.lotacao;
            recChanged = true;
          }

          if (isComissionados) {
            if (match.cargo && record.cargo !== match.cargo) {
              updateData.cargo = match.cargo;
              record.cargo = match.cargo;
              recChanged = true;
            }
            if (match.ferias && record.ferias !== match.ferias) {
              updateData.ferias = match.ferias;
              record.ferias = match.ferias;
              recChanged = true;
            }
          } else {
            if (match.categoria && record.categoria !== match.categoria) {
              updateData.categoria = match.categoria;
              record.categoria = match.categoria;
              recChanged = true;
            }
          }

          const adm = parseDateBR(match.dataAdmissao);
          const res = parseDateBR(match.dataRescisao);

          let pStart = 1;
          if (adm && adm.getFullYear() === year && (adm.getMonth() + 1) === month) {
            pStart = adm.getDate();
          }

          let pEnd = endMonth.getDate();
          if (res && res.getFullYear() === year && (res.getMonth() + 1) === month) {
            pEnd = res.getDate();
          }

          const pad = (n: number) => String(n).padStart(2, '0');
          const computedPeriod = `${pad(pStart)}/${pad(month)} a ${pad(pEnd)}/${pad(month)}`;

          if (record.periodoOriginal !== computedPeriod) {
            updateData.periodoOriginal = computedPeriod;
            record.periodoOriginal = computedPeriod;
            recChanged = true;
          }

          if (!isComissionados && record.details) {
            const defaultStartStr = `${year}-${pad(month)}-${pad(pStart)}`;
            const defaultEndStr = `${year}-${pad(month)}-${pad(pEnd)}`;
            let detailsChanged = false;
            const updatedDetails = { ...record.details };

            if (!updatedDetails.startDate) {
              updatedDetails.startDate = defaultStartStr;
              detailsChanged = true;
            }
            if (!updatedDetails.endDate) {
              updatedDetails.endDate = defaultEndStr;
              detailsChanged = true;
            }

            if (res && res.getFullYear() === year && (res.getMonth() + 1) === month) {
              const currentEnd = parseDateBR(updatedDetails.endDate);
              if (currentEnd && currentEnd > res) {
                updatedDetails.endDate = defaultEndStr;
                detailsChanged = true;
              }
            }

            if (detailsChanged) {
              updateData.details = updatedDetails;
              record.details = updatedDetails;
              recChanged = true;
            }
          }

          if (recChanged) {
            const docRef = doc(db, freqColl, record.id);
            syncBatch.update(docRef, updateData);
            updatedExistingRecords[index] = { ...record, ...updateData };
            syncedRecordsCount++;
          }
        }
      });

      if (syncedRecordsCount > 0) {
        await syncBatch.commit();
      }

      const missingPeople = filteredActivePeople.filter(person => {
        return !updatedExistingRecords.some(r => 
          (r.matricula && person.matricula && String(r.matricula).trim().toUpperCase() === String(person.matricula).trim().toUpperCase()) ||
          r.internName.trim().toUpperCase() === person.internName.trim().toUpperCase()
        );
      });

      if (missingPeople.length > 0) {
        const batch = writeBatch(db);
        const pad = (n: number) => String(n).padStart(2, '0');
        const newRecords: any[] = [];

        missingPeople.forEach(person => {
          const adm = parseDateBR(person.dataAdmissao);
          const res = parseDateBR(person.dataRescisao);

          let pStart = 1;
          if (adm && adm.getFullYear() === year && (adm.getMonth() + 1) === month) {
            pStart = adm.getDate();
          }

          let pEnd = endMonth.getDate();
          if (res && res.getFullYear() === year && (res.getMonth() + 1) === month) {
            pEnd = res.getDate();
          }

          const computedPeriod = `${pad(pStart)}/${pad(month)} a ${pad(pEnd)}/${pad(month)}`;

          const docRef = doc(collection(db, freqColl));
          const newRec: any = {
            id: docRef.id,
            matricula: person.matricula || '',
            internName: person.internName,
            lotacao: person.lotacao,
            month,
            year,
            periodoOriginal: computedPeriod,
            status: 'pending',
            details: null,
            submittedAt: null,
            submittedBy: null,
          };

          if (isComissionados) {
            newRec.cargo = person.cargo || '';
            newRec.ferias = person.ferias || '';
          } else {
            newRec.responsavel = '';
            newRec.recessoOriginal = person.recessoOriginal || '';
            newRec.categoria = person.categoria || 'Ensino Superior';
          }

          batch.set(docRef, newRec);
          newRecords.push(newRec);
        });

        await batch.commit();
        return [...updatedExistingRecords, ...newRecords];
      }

      return updatedExistingRecords;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, freqColl);
      return [];
    }
  },

  async getComissionadosFrequenciesByPeriod(month: number, year: number, lotacoes?: string[]): Promise<any[]> {
    return this.getFrequenciesByPeriodGeneric(month, year, true, lotacoes);
  },

  async getFrequenciesByPeriod(month: number, year: number, lotacao?: string): Promise<FrequencyRecord[]> {
    return this.getFrequenciesByPeriodGeneric(month, year, false, lotacao);
  },

  async deleteMonthDataGeneric(month: number, year: number, isComissionados: boolean) {
    const existing = isComissionados 
      ? await this.getComissionadosFrequenciesByPeriod(month, year)
      : await this.getFrequenciesByPeriod(month, year);
    if (existing.length === 0) return;
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    
    for (let i = 0; i < existing.length; i += 500) {
      const batch = writeBatch(db);
      const chunk = existing.slice(i, i + 500);
      chunk.forEach(rec => {
        batch.delete(doc(db, freqColl, rec.id));
      });
      await batch.commit();
    }
  },

  async deleteComissionadosMonthData(month: number, year: number) {
    return this.deleteMonthDataGeneric(month, year, true);
  },

  async deleteMonthData(month: number, year: number) {
    return this.deleteMonthDataGeneric(month, year, false);
  },

  // Generic CSV importer
  async uploadCSVDataGeneric(parsedRows: any[], month: number, year: number, isComissionados: boolean) {
    const peopleColl = isComissionados ? COMISSIONADOS_COLLECTION : INTERNS_COLLECTION;
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;

    try {
      const peopleToImport = parsedRows.map(row => {
        const valMatricula = String(findCSVColumn(row, ['matricula', 'registro', 'id', 'codigo']) || '').trim();
        const valNome = String(findCSVColumn(row, ['nome', 'estagiario', 'servidor', 'internName', 'nome do estagiario', 'nome do servidor', 'nome do comissionado']) || '').trim();
        const valLotacao = String(findCSVColumn(row, ['lotacao', 'setor', 'gabinete', 'departamento']) || 'Não Definido').trim();
        const valAdmissao = String(findCSVColumn(row, ['data de admissao', 'data admissao', 'admissao', 'contratacao', 'inicio']) || '').trim();
        const valRescisao = String(findCSVColumn(row, ['data de rescisao', 'data rescisao', 'rescisao', 'fim', 'desligamento']) || '').trim();
        
        const baseObj: any = {
          matricula: valMatricula || valNome.toLowerCase().replace(/[^a-z0-9]/g, ''),
          internName: valNome,
          lotacao: valLotacao,
          dataAdmissao: valAdmissao,
          dataRescisao: valRescisao,
        };

        if (isComissionados) {
          const valCargo = String(findCSVColumn(row, ['cargo', 'funcao', 'atividade']) || '').trim();
          const valFerias = String(findCSVColumn(row, ['ferias', 'periodo de ferias', 'recesso']) || '').trim();
          baseObj.cargo = valCargo;
          baseObj.ferias = valFerias;
        } else {
          const valNivel = String(findCSVColumn(row, ['nivel', 'categoria', 'grau', 'ensino', 'tipo']) || '').toLowerCase();
          let mappedNivel: 'Ensino Médio' | 'Ensino Superior' | 'Pós Graduação' = 'Ensino Superior';
          if (valNivel.includes('medio') || valNivel.includes('médio') || valNivel.includes('tecnico') || valNivel.includes('técnico')) {
            mappedNivel = 'Ensino Médio';
          } else if (valNivel.includes('pos') || valNivel.includes('pós') || valNivel.includes('gradua') || valNivel.includes('especializa')) {
            mappedNivel = 'Pós Graduação';
          }
          baseObj.categoria = mappedNivel;
          baseObj.recessoOriginal = '';
        }

        return baseObj;
      }).filter(p => p.internName);

      const querySnapshot = await getDocs(collection(db, peopleColl));
      const existingPeople = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));

      const batch = writeBatch(db);

      for (const person of peopleToImport) {
        const match = existingPeople.find(existing => 
          (existing.matricula && person.matricula && String(existing.matricula).trim().toUpperCase() === String(person.matricula).trim().toUpperCase()) ||
          String(existing.internName).trim().toUpperCase() === String(person.internName).trim().toUpperCase()
        );

        if (match) {
          const docRef = doc(db, peopleColl, match.id);
          const mergedData = {
            ...match,
            matricula: person.matricula || match.matricula || match.id,
            internName: person.internName || match.internName,
            lotacao: person.lotacao || match.lotacao,
            dataAdmissao: person.dataAdmissao || match.dataAdmissao,
            dataRescisao: person.dataRescisao !== undefined ? person.dataRescisao : (match.dataRescisao || ''),
            importMonth: match.importMonth !== undefined ? match.importMonth : month,
            importYear: match.importYear !== undefined ? match.importYear : year,
          };

          if (isComissionados) {
            mergedData.cargo = person.cargo || match.cargo || '';
            if (person.ferias !== undefined && person.ferias !== '') {
              mergedData.ferias = person.ferias;
            }
          } else {
            mergedData.categoria = person.categoria || match.categoria;
          }

          batch.set(docRef, mergedData, { merge: true });
        } else {
          const docRef = doc(db, peopleColl, person.matricula);
          batch.set(docRef, {
            ...person,
            importMonth: month,
            importYear: year
          }, { merge: true });
        }
      }

      await batch.commit();
      await this.getFrequenciesByPeriodGeneric(month, year, isComissionados);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `upload-${isComissionados ? 'comissionados-' : ''}csv`);
      throw error;
    }
  },

  async uploadComissionadosCSVData(parsedRows: any[], month: number, year: number, overwrite: boolean) {
    return this.uploadCSVDataGeneric(parsedRows, month, year, true);
  },

  async uploadCSVData(parsedRows: any[], month: number, year: number, overwrite: boolean) {
    return this.uploadCSVDataGeneric(parsedRows, month, year, false);
  },

  // Save drafts generic helper
  async saveDraftGeneric(id: string, details: any, isComissionados: boolean) {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    try {
      await updateDoc(doc(db, freqColl, id), {
        details: sanitizeDetails(details),
        status: 'pending' as const
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${freqColl}/${id}`);
    }
  },

  async saveComissionadosDraft(id: string, details: any) {
    return this.saveDraftGeneric(id, details, true);
  },

  async saveDraft(id: string, details: any) {
    return this.saveDraftGeneric(id, details, false);
  },

  // Submit generic helper
  async submitFrequencyGeneric(id: string, details: any, isComissionados: boolean) {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    try {
      await updateDoc(doc(db, freqColl, id), {
        details: sanitizeDetails(details),
        status: 'submitted' as const,
        submittedAt: new Date().toISOString(),
        submittedBy: auth.currentUser?.email
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${freqColl}/${id}`);
    }
  },

  async submitComissionadosFrequency(id: string, details: any) {
    return this.submitFrequencyGeneric(id, details, true);
  },

  async submitFrequency(id: string, details: any) {
    return this.submitFrequencyGeneric(id, details, false);
  },

  // Batch submit generic helper
  async submitMultipleFrequenciesGeneric(payloads: { id: string, details: any }[], isComissionados: boolean, customTimestamp?: string) {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    const batch = writeBatch(db);
    const now = customTimestamp || new Date().toISOString();
    const user = auth.currentUser?.email || 'unknown';

    payloads.forEach(p => {
      batch.update(doc(db, freqColl, p.id), {
        details: sanitizeDetails(p.details),
        status: 'submitted' as const,
        submittedAt: now,
        submittedBy: user
      });
    });

    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `${isComissionados ? 'comissionados-' : ''}batch-submit`);
      throw error;
    }
  },

  async submitComissionadosMultipleFrequencies(payloads: { id: string, details: any }[], customTimestamp?: string) {
    return this.submitMultipleFrequenciesGeneric(payloads, true, customTimestamp);
  },

  async submitMultipleFrequencies(payloads: { id: string, details: any }[], customTimestamp?: string) {
    return this.submitMultipleFrequenciesGeneric(payloads, false, customTimestamp);
  },

  // Return to draft generic helper
  async returnToDraftGeneric(id: string, isComissionados: boolean) {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    try {
      await updateDoc(doc(db, freqColl, id), {
        status: 'devolvida' as const,
        submittedAt: null,
        submittedBy: null
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${freqColl}/${id}`);
    }
  },

  async returnComissionadosToDraft(id: string) {
    return this.returnToDraftGeneric(id, true);
  },

  async returnToDraft(id: string) {
    return this.returnToDraftGeneric(id, false);
  },

  // Get Dashboard stats generic helper
  async getDashboardStatsGeneric(month: number, year: number, isComissionados: boolean) {
    const all = isComissionados 
      ? await this.getComissionadosFrequenciesByPeriod(month, year)
      : await this.getFrequenciesByPeriod(month, year);
    const sectors = [...new Set(all.map(r => r.lotacao))];
    const submittedOrValidated = all.filter(r => r.status === 'submitted' || r.status === 'validada').length;
    const validatedCount = all.filter(r => r.status === 'validada').length;
    
    const sectorStatus = sectors.map(name => {
      const sectorInterns = all.filter(r => r.lotacao === name);
      const allDone = sectorInterns.every(r => r.status === 'submitted' || r.status === 'validada');
      const allValidated = sectorInterns.every(r => r.status === 'validada');
      const internNames = sectorInterns.map(i => i.internName);
      return { 
        name, 
        allDone, 
        allValidated,
        internNames,
        status: allValidated ? 'validada' : allDone ? 'submitted' : 'pending'
      };
    });

    const totalInterns = all.length;
    const pendingInterns = all.filter(r => r.status === 'pending' || r.status === 'devolvida').length;
    const submittedInterns = all.filter(r => r.status === 'submitted').length;
    const validatedInterns = all.filter(r => r.status === 'validada').length;

    return {
      totalSectors: sectors.length,
      submittedSectors: sectorStatus.filter(s => s.allDone).length,
      validatedSectors: sectorStatus.filter(s => s.allValidated).length,
      totalInterns,
      pendingInterns,
      submittedInterns,
      validatedInterns,
      totalSubmitted: submittedOrValidated,
      allSectors: sectors,
      allSectorsDetail: sectorStatus
    };
  },

  async getComissionadosDashboardStats(month: number, year: number) {
    return this.getDashboardStatsGeneric(month, year, true);
  },

  async getDashboardStats(month: number, year: number) {
    return this.getDashboardStatsGeneric(month, year, false);
  },

  // Get manager stats generic helper
  async getManagerDashboardStatsGeneric(month: number, year: number, sectors: string[], isComissionados: boolean) {
    if (!sectors || sectors.length === 0) return {
      totalInterns: 0,
      totalSectors: 0,
      submittedFrequencies: 0,
      validatedFrequencies: 0
    };

    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    const allRecords: any[] = [];
    for (let i = 0; i < sectors.length; i += 10) {
      const chunk = sectors.slice(i, i + 10);
      const q = query(
        collection(db, freqColl),
        where('month', '==', month),
        where('year', '==', year),
        where('lotacao', 'in', chunk)
      );
      const snap = await getDocs(q);
      snap.docs.forEach(d => allRecords.push({ id: d.id, ...d.data() }));
    }

    const submittedCount = allRecords.filter(r => r.status === 'submitted' || r.status === 'validada').length;
    const validatedCount = allRecords.filter(r => r.status === 'validada').length;

    return {
      totalInterns: allRecords.length,
      totalSectors: sectors.length,
      submittedFrequencies: submittedCount,
      validatedFrequencies: validatedCount
    };
  },

  async getComissionadosManagerDashboardStats(month: number, year: number, sectors: string[]) {
    return this.getManagerDashboardStatsGeneric(month, year, sectors, true);
  },

  async getManagerDashboardStats(month: number, year: number, sectors: string[]) {
    return this.getManagerDashboardStatsGeneric(month, year, sectors, false);
  },

  // Save generated document generic helper
  async saveGeneratedDocumentGeneric(docData: GeneratedDocument, isComissionados: boolean) {
    const archiveColl = isComissionados ? ARCHIVE_COM_COLLECTION : ARCHIVE_COLLECTION;
    try {
      await addDoc(collection(db, archiveColl), docData);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, archiveColl);
    }
  },

  async saveComissionadosGeneratedDocument(docData: GeneratedDocument) {
    return this.saveGeneratedDocumentGeneric(docData, true);
  },

  async saveGeneratedDocument(docData: GeneratedDocument) {
    return this.saveGeneratedDocumentGeneric(docData, false);
  },

  // Return sector to draft generic helper
  async returnSectorToDraftGeneric(
    sector: string, 
    month: number, 
    year: number, 
    returnReason: string, 
    isComissionados: boolean,
    archiveId?: string, 
    recordIds?: string[]
  ) {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    const archiveColl = isComissionados ? ARCHIVE_COM_COLLECTION : ARCHIVE_COLLECTION;

    try {
      const batch = writeBatch(db);
      if (recordIds && recordIds.length > 0) {
        recordIds.forEach(id => {
          batch.update(doc(db, freqColl, id), {
            status: 'devolvida' as const,
            submittedAt: null,
            submittedBy: null,
            returnReason: returnReason || null
          });
        });
      } else {
        const q = query(
          collection(db, freqColl),
          where('lotacao', '==', sector),
          where('month', '==', month),
          where('year', '==', year)
        );
        const snap = await getDocs(q);
        snap.docs.forEach(d => {
          batch.update(d.ref, {
            status: 'devolvida' as const,
            submittedAt: null,
            submittedBy: null,
            returnReason: returnReason || null
          });
        });
      }
      await batch.commit();

      if (archiveId) {
        const docRef = doc(db, archiveColl, archiveId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const docData = docSnap.data() as GeneratedDocument;
          if (docData.pdfUrl) {
            try {
              await this.deleteFile(docData.pdfUrl);
            } catch (deleteError) {
              console.warn("Could not delete GDrive PDF for returned archive:", deleteError);
            }
          }
          await deleteDoc(docRef);
        }
      } else {
        const archiveQ = query(
          collection(db, archiveColl),
          where('lotacao', '==', sector),
          where('month', '==', month),
          where('year', '==', year)
        );
        const archiveSnap = await getDocs(archiveQ);
        for (const docSnap of archiveSnap.docs) {
          const docData = docSnap.data() as GeneratedDocument;
          if (docData.pdfUrl) {
            try {
              await this.deleteFile(docData.pdfUrl);
            } catch (deleteError) {
              console.warn("Could not delete GDrive PDF for returned archive:", deleteError);
            }
          }
          await deleteDoc(doc(db, archiveColl, docSnap.id));
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, freqColl);
    }
  },

  async returnComissionadosSectorToDraft(sector: string, month: number, year: number, returnReason: string, archiveId?: string, recordIds?: string[]) {
    return this.returnSectorToDraftGeneric(sector, month, year, returnReason, true, archiveId, recordIds);
  },

  async returnSectorToDraft(sector: string, month: number, year: number, returnReason: string, archiveId?: string, recordIds?: string[]) {
    return this.returnSectorToDraftGeneric(sector, month, year, returnReason, false, archiveId, recordIds);
  },

  // Validate generic helper
  async validateSectorFrequencyGeneric(sector: string, month: number, year: number, isComissionados: boolean, recordIds?: string[]) {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    try {
      const batch = writeBatch(db);
      const now = new Date().toISOString();
      const user = auth.currentUser?.email || 'dgep@cmc.pr.gov.br';

      if (recordIds && recordIds.length > 0) {
        recordIds.forEach(id => {
          batch.update(doc(db, freqColl, id), {
            status: 'validada' as const,
            validatedAt: now,
            validatedBy: user
          });
        });
      } else {
        const q = query(
          collection(db, freqColl),
          where('lotacao', '==', sector),
          where('month', '==', month),
          where('year', '==', year)
        );
        const snap = await getDocs(q);
        snap.docs.forEach(d => {
          batch.update(d.ref, {
            status: 'validada' as const,
            validatedAt: now,
            validatedBy: user
          });
        });
      }
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, freqColl);
    }
  },

  async validateComissionadosSectorFrequency(sector: string, month: number, year: number, recordIds?: string[]) {
    return this.validateSectorFrequencyGeneric(sector, month, year, true, recordIds);
  },

  async validateSectorFrequency(sector: string, month: number, year: number, recordIds?: string[]) {
    return this.validateSectorFrequencyGeneric(sector, month, year, false, recordIds);
  },

  // Reopen generic helper
  async reopenSectorFrequencyGeneric(sector: string, month: number, year: number, isComissionados: boolean, recordIds?: string[]) {
    const freqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
    try {
      const batch = writeBatch(db);
      if (recordIds && recordIds.length > 0) {
        recordIds.forEach(id => {
          batch.update(doc(db, freqColl, id), {
            status: 'submitted' as const,
            validatedAt: null,
            validatedBy: null
          });
        });
      } else {
        const q = query(
          collection(db, freqColl),
          where('lotacao', '==', sector),
          where('month', '==', month),
          where('year', '==', year)
        );
        const snap = await getDocs(q);
        snap.docs.forEach(d => {
          batch.update(d.ref, {
            status: 'submitted' as const,
            validatedAt: null,
            validatedBy: null
          });
        });
      }
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, freqColl);
    }
  },

  async reopenComissionadosSectorFrequency(sector: string, month: number, year: number, recordIds?: string[]) {
    return this.reopenSectorFrequencyGeneric(sector, month, year, true, recordIds);
  },

  async reopenSectorFrequency(sector: string, month: number, year: number, recordIds?: string[]) {
    return this.reopenSectorFrequencyGeneric(sector, month, year, false, recordIds);
  },

  async validateFrequency(id: string) {
    try {
      const now = new Date().toISOString();
      const user = auth.currentUser?.email || 'dgep@cmc.pr.gov.br';
      await updateDoc(doc(db, FREQ_COLLECTION, id), {
        status: 'validada' as const,
        validatedAt: now,
        validatedBy: user
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${FREQ_COLLECTION}/${id}`);
    }
  },

  // Archive retrieval generic helpers
  async getArchiveByPeriodGeneric(month: number, year: number, isComissionados: boolean): Promise<GeneratedDocument[]> {
    const archiveColl = isComissionados ? ARCHIVE_COM_COLLECTION : ARCHIVE_COLLECTION;
    try {
      const q = query(
        collection(db, archiveColl),
        where('month', '==', month),
        where('year', '==', year)
      );
      const snap = await getDocs(q);
      const all = snap.docs.map(d => ({ id: d.id, ...d.data() } as GeneratedDocument));
      
      all.sort((a, b) => {
        const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return timeB - timeA;
      });
      
      return all;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, archiveColl);
      return [];
    }
  },

  async getComissionadosArchiveByPeriod(month: number, year: number): Promise<GeneratedDocument[]> {
    return this.getArchiveByPeriodGeneric(month, year, true);
  },

  async getArchiveByPeriod(month: number, year: number): Promise<GeneratedDocument[]> {
    return this.getArchiveByPeriodGeneric(month, year, false);
  },

  async getArchiveForSectorGeneric(month: number, year: number, sector: string, isComissionados: boolean): Promise<GeneratedDocument | null> {
    const archiveColl = isComissionados ? ARCHIVE_COM_COLLECTION : ARCHIVE_COLLECTION;
    try {
      const q = query(
        collection(db, archiveColl),
        where('month', '==', month),
        where('year', '==', year),
        where('lotacao', '==', sector)
      );
      const snap = await getDocs(q);
      if (snap.empty) return null;
      
      const all = snap.docs.map(d => ({ id: d.id, ...d.data() } as GeneratedDocument));
      all.sort((a, b) => {
        const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return timeB - timeA;
      });
      
      return all[0];
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `${archiveColl}/${sector}`);
      return null;
    }
  },

  async getComissionadosArchiveForSector(month: number, year: number, sector: string): Promise<GeneratedDocument | null> {
    return this.getArchiveForSectorGeneric(month, year, sector, true);
  },

  async getArchiveForSector(month: number, year: number, sector: string): Promise<GeneratedDocument | null> {
    return this.getArchiveForSectorGeneric(month, year, sector, false);
  },

  async getProfile(email: string): Promise<UserProfile | null> {
    const cleanEmail = email.trim().toLowerCase();
    try {
      const docRef = doc(db, USER_COLLECTION, cleanEmail);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const profileData = { uid: cleanEmail, ...docSnap.data() } as UserProfile;
        if (profileData.name) {
          userNamesCache[cleanEmail] = profileData.name;
        }
        try {
          localStorage.setItem(`cached_profile_v1_${cleanEmail}`, JSON.stringify(profileData));
        } catch (e) {
          console.warn("Could not write profile to localStorage:", e);
        }
        return profileData;
      }
      return null;
    } catch (error) {
      console.warn("getProfile failed, using local cache fallback:", error);
      const cached = localStorage.getItem(`cached_profile_v1_${cleanEmail}`);
      if (cached) {
        try {
          return JSON.parse(cached) as UserProfile;
        } catch {
          // ignore parsing errors
        }
      }
      
      const isMaster = cleanEmail === 'diegofmartins@gmail.com' || cleanEmail === 'diego.martins@cmc.pr.gov.br';
      if (isMaster) {
        return {
          uid: cleanEmail,
          email: cleanEmail,
          role: 'master',
          sectors: [],
          active: true,
          name: 'Master User (Offline)'
        };
      }
      
      const errMsg = error instanceof Error ? error.message : String(error);
      if (errMsg.toLowerCase().includes('offline')) {
        return null;
      }

      handleFirestoreError(error, OperationType.GET, `${USER_COLLECTION}/${cleanEmail}`);
      return null;
    }
  },

  async ensureProfileExists(email: string): Promise<UserProfile | null> {
    if (!auth.currentUser) return null;
    const cleanEmail = email.trim().toLowerCase();
    const isMaster = cleanEmail === 'diegofmartins@gmail.com' || cleanEmail === 'diego.martins@cmc.pr.gov.br';

    let existing: UserProfile | null = null;
    try {
      existing = await this.getProfile(cleanEmail);
    } catch (error) {
      console.warn("ensureProfileExists error fetching getProfile:", error);
    }
    
    if (existing) {
      if (isMaster && existing.role !== 'master') {
        const updated = { ...existing, role: 'master' as const };
        try {
          await updateDoc(doc(db, USER_COLLECTION, cleanEmail), { role: 'master' });
        } catch (error) {
          console.warn("Could not automatically promote master in Firestore:", error);
        }
        return updated;
      }
      return existing;
    }

    if (!isMaster) {
      return null;
    }

    const profile: Partial<UserProfile> = {
      email: cleanEmail,
      role: 'master',
      sectors: [],
      active: true
    };

    try {
      await setDoc(doc(db, USER_COLLECTION, cleanEmail), profile);
      const fullProfile = { uid: cleanEmail, ...profile } as UserProfile;
      try {
        localStorage.setItem(`cached_profile_v1_${cleanEmail}`, JSON.stringify(fullProfile));
      } catch (e) {
        console.warn("Could not cache profile:", e);
      }
      return fullProfile;
    } catch (error) {
      console.warn("setDoc failed in ensureProfileExists, running local fallback", error);
      const offlineProfile = { uid: cleanEmail, ...profile } as UserProfile;
      try {
        localStorage.setItem(`cached_profile_v1_${cleanEmail}`, JSON.stringify(offlineProfile));
      } catch (e) {}
      return offlineProfile;
    }
  },

  async getAllUsers(): Promise<UserProfile[]> {
    try {
      const querySnapshot = await getDocs(collection(db, USER_COLLECTION));
      const users = querySnapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
      users.forEach(u => {
        if (u.email && u.name) {
          userNamesCache[u.email.trim().toLowerCase()] = u.name;
        }
      });
      return users;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, USER_COLLECTION);
      return [];
    }
  },

  async addUserByEmail(email: string, role: string, sectors: string[], allowedModules: ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[] = ['frequency'], cpf?: string, phone?: string) {
    try {
      const cleanEmail = email.trim().toLowerCase();
      await setDoc(doc(db, USER_COLLECTION, cleanEmail), {
        email: cleanEmail,
        role,
        sectors,
        allowedModules,
        active: true,
        cpf: cpf || '',
        phone: phone || ''
      });
    } catch (error) {
      const cleanEmail = email.trim().toLowerCase();
      handleFirestoreError(error, OperationType.WRITE, `${USER_COLLECTION}/${cleanEmail}`);
    }
  },

  async updateUserRole(uid: string, role: string, sectors: string[], allowedModules?: ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[], cpf?: string, phone?: string) {
    try {
      const data: any = { role, sectors };
      if (allowedModules) data.allowedModules = allowedModules;
      if (cpf !== undefined) data.cpf = cpf;
      if (phone !== undefined) data.phone = phone;
      await updateDoc(doc(db, USER_COLLECTION, uid), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${USER_COLLECTION}/${uid}`);
    }
  },

  async toggleUserActive(uid: string, active: boolean) {
    try {
      await updateDoc(doc(db, USER_COLLECTION, uid), { active });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${USER_COLLECTION}/${uid}`);
    }
  },

  async deleteUser(uid: string) {
    try {
      await deleteDoc(doc(db, USER_COLLECTION, uid));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${USER_COLLECTION}/${uid}`);
    }
  },

  async getAllSectorsList(): Promise<{ id: string; name: string }[]> {
    try {
      const snap = await getDocs(collection(db, 'sectors'));
      const list = snap.docs.map(doc => ({ id: doc.id, name: doc.data().name } as { id: string; name: string }));
      return list.sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'sectors');
      return [];
    }
  },

  async getSectorMappings(): Promise<{ id: string; alias: string; targetSectorId: string }[]> {
    try {
      const snap = await getDocs(collection(db, 'sector_mappings'));
      return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'sector_mappings');
      return [];
    }
  },

  async createSector(name: string): Promise<void> {
    try {
      const docRef = doc(collection(db, 'sectors'));
      await setDoc(docRef, { name });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'sectors');
    }
  },

  async deleteSector(id: string): Promise<void> {
    try {
      await deleteDoc(doc(db, 'sectors', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `sectors/${id}`);
    }
  },

  async deleteSectorMapping(id: string): Promise<void> {
    try {
      await deleteDoc(doc(db, 'sector_mappings', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `sector_mappings/${id}`);
    }
  },

  async resetDatabase(isComissionados: boolean = false) {
    try {
      const activeFreqColl = isComissionados ? FREQ_COM_COLLECTION : FREQ_COLLECTION;
      const activeInternsColl = isComissionados ? COMISSIONADOS_COLLECTION : INTERNS_COLLECTION;
      const activeArchiveColl = isComissionados ? ARCHIVE_COM_COLLECTION : ARCHIVE_COLLECTION;

      const freqsSnap = await getDocs(collection(db, activeFreqColl));
      if (!freqsSnap.empty) {
        const docs = freqsSnap.docs;
        for (let i = 0; i < docs.length; i += 500) {
          const batch = writeBatch(db);
          docs.slice(i, i + 500).forEach(d => {
            batch.delete(doc(db, activeFreqColl, d.id));
          });
          await batch.commit();
        }
      }

      const internsSnap = await getDocs(collection(db, activeInternsColl));
      if (!internsSnap.empty) {
        const docs = internsSnap.docs;
        for (let i = 0; i < docs.length; i += 500) {
          const batch = writeBatch(db);
          docs.slice(i, i + 500).forEach(d => {
            batch.delete(doc(db, activeInternsColl, d.id));
          });
          await batch.commit();
        }
      }

      const archiveSnap = await getDocs(collection(db, activeArchiveColl));
      if (!archiveSnap.empty) {
        const docs = archiveSnap.docs;
        for (let i = 0; i < docs.length; i += 500) {
          const batch = writeBatch(db);
          docs.slice(i, i + 500).forEach(d => {
            batch.delete(doc(db, activeArchiveColl, d.id));
          });
          await batch.commit();
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'reset-database');
      throw error;
    }
  },

  async uploadFileLegacy(file: Blob, idPrefix: string): Promise<string> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);
      const CHUNK_SIZE = 800 * 1024;
      const totalChunks = Math.ceil(bytes.length / CHUNK_SIZE);
      
      if (totalChunks > 10) { 
        throw new Error("Arquivo exede o limite de 8MB.");
      }

      const fileId = `${idPrefix}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      const batch = writeBatch(db);

      const metaRef = doc(db, BLOBS_COLLECTION, fileId);
      batch.set(metaRef, {
        fileName: (file as any).name || 'file',
        type: file.type,
        totalChunks,
        size: bytes.length,
        createdAt: new Date().toISOString()
      });

      for (let i = 0; i < totalChunks; i++) {
        const chunkRef = doc(db, `${BLOBS_COLLECTION}/${fileId}/chunks`, i.toString());
        const start = i * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, bytes.length);
        batch.set(chunkRef, {
          data: Bytes.fromUint8Array(bytes.slice(start, end))
        });
      }

      await batch.commit();
      return fileId;
    } catch (error) {
      console.error('Firestore upload error:', error);
      throw error;
    }
  },

  async uploadFile(file: Blob, idPrefix: string, context?: UploadContext): Promise<string> {
    try {
      const processedFile = await compressImage(file);
      
      if (context) {
        const fileName = (processedFile as any).name || `${idPrefix}.pdf`;
        try {
          return await googleDriveService.upload(processedFile, fileName, context);
        } catch (driveErr) {
          console.warn('Google Drive context upload unavailable, falling back to legacy Firestore chunks:', driveErr);
          return await this.uploadFileLegacy(processedFile, idPrefix);
        }
      }

      const defaultContext: UploadContext = {
        module: 'frequency',
        lotacao: 'Arquivos Gerais',
        monthYear: new Date().toISOString().substring(0, 7)
      };
      const fileName = (processedFile as any).name || `${idPrefix}.pdf`;

      try {
        return await googleDriveService.upload(processedFile, fileName, defaultContext);
      } catch (driveErr) {
        console.warn('Google Drive unavailable, falling back to legacy Firestore chunks:', driveErr);
        return await this.uploadFileLegacy(processedFile, idPrefix);
      }
    } catch (error) {
      console.error('File upload error:', error);
      throw error;
    }
  },

  async updateFile(fileIdOrUrl: string, file: Blob): Promise<boolean> {
    try {
      if (fileIdOrUrl && fileIdOrUrl.startsWith('http')) {
        return await googleDriveService.updateFileContent(fileIdOrUrl, file);
      }
      return false;
    } catch (error) {
      console.error('File update error:', error);
      return false;
    }
  },

  async deleteFile(fileIdOrUrl: string): Promise<boolean> {
    try {
      if (fileIdOrUrl && fileIdOrUrl.startsWith('http')) {
        return await googleDriveService.deleteFile(fileIdOrUrl);
      }
      return false;
    } catch (error) {
      console.error('File delete error:', error);
      return false;
    }
  },

  async downloadFile(fileId: string): Promise<{ data: Blob; type: string }> {
    if (!fileId) {
      throw new Error("Identificador do arquivo (ID) não fornecido. Este registro pode ser antigo ou inválido.");
    }

    try {
      if (fileId.startsWith('http')) {
        const driveId = extractDriveFileId(fileId);
        if (driveId) {
          try {
            const url = `/api/drive/download?fileId=${encodeURIComponent(driveId)}`;
            const response = await fetch(getBackendUrl(url));
            if (response.ok) {
              const blob = await response.blob();
              return {
                data: blob,
                type: blob.type || 'application/pdf'
              };
            } else {
              const text = await response.text();
              console.warn(`Google Drive API download failed for ID ${driveId}: ${text}. Trying normal fetch fallback...`);
            }
          } catch (driveErr) {
            console.warn(`Drive direct API download failed for ID ${driveId}, attempting normal fetch fallback:`, driveErr);
          }
        }

        const response = await fetch(fileId);
        if (!response.ok) throw new Error("Could not fetch old file from URL");
        const blob = await response.blob();
        return {
          data: blob,
          type: blob.type || 'application/pdf'
        };
      }

      const metaRef = doc(db, BLOBS_COLLECTION, fileId);
      const metaSnap = await getDoc(metaRef);
      if (!metaSnap.exists()) {
        throw new Error(`Metadados do arquivo não encontrados: ${fileId}`);
      }
      
      const meta = metaSnap.data();
      if (!meta || typeof meta.totalChunks !== 'number') {
        throw new Error("Metadados do arquivo inválidos ou incompletos.");
      }

      const chunks: Uint8Array[] = [];

      for (let i = 0; i < meta.totalChunks; i++) {
        const chunkRef = doc(db, `${BLOBS_COLLECTION}/${fileId}/chunks`, i.toString());
        const chunkSnap = await getDoc(chunkRef);
        
        if (chunkSnap.exists()) {
          const chunkData = chunkSnap.data()?.data;
          if (chunkData) {
            if (chunkData instanceof Bytes) {
              chunks.push(chunkData.toUint8Array());
            } else if (chunkData instanceof Uint8Array) {
              chunks.push(chunkData);
            } else {
              console.warn(`Chunk ${i} for ${fileId} is not a valid Bytes object`);
            }
          }
        } else {
          console.warn(`Chunk ${i} for ${fileId} is missing.`);
        }
      }

      if (chunks.length === 0) {
        throw new Error("Nenhum fragmento do arquivo foi encontrado.");
      }

      const totalLength = chunks.reduce((acc, val) => acc + (val?.length || 0), 0);
      const joined = new Uint8Array(totalLength);
      let offset = 0;
      for (const chunk of chunks) {
        if (chunk) {
          joined.set(chunk, offset);
          offset += chunk.length;
        }
      }

      const type = meta.type || 'application/octet-stream';
      return {
        data: new Blob([joined], { type }),
        type
      };
    } catch (error) {
      console.error('Firestore download error:', error);
      throw error;
    }
  }
};

function parseDateBR(dateStr: any): Date | null {
  if (!dateStr) return null;
  if (dateStr instanceof Date) return isNaN(dateStr.getTime()) ? null : dateStr;
  const str = String(dateStr).trim();
  if (!str) return null;

  const brParts = str.split(/[/\-]/);
  if (brParts.length === 3) {
    if (brParts[2].length === 4) {
      const day = parseInt(brParts[0], 10);
      const month = parseInt(brParts[1], 10);
      const year = parseInt(brParts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month - 1, day);
      }
    } else if (brParts[0].length === 4) {
      const year = parseInt(brParts[0], 10);
      const month = parseInt(brParts[1], 10);
      const day = parseInt(brParts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month - 1, day);
      }
    }
  }

  const normalized = new Date(str);
  return isNaN(normalized.getTime()) ? null : normalized;
}

function findCSVColumn(row: any, searchNames: string[]): any {
  const keys = Object.keys(row);
  for (const name of searchNames) {
    const cleanSearch = name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
    for (const key of keys) {
      const cleanKey = key.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
      if (cleanKey === cleanSearch || cleanKey.includes(cleanSearch) || cleanSearch.includes(cleanKey)) {
        return row[key];
      }
    }
  }
  return null;
}
