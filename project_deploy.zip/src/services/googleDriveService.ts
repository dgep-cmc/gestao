import { getBackendUrl } from '../lib/api';

export interface UploadContext {
  module: 'frequency' | 'hiring' | 'frequency_comissionados';
  category?: 'intern' | 'comissionado';
  monthYear?: string; // YYYY-MM
  lotacao?: string; // sector/department name
  requestNameAndId?: string; // studentName_requestId
  requestId?: string; // stable identifier to unify files in a single folder
  userName?: string; // custom username / manager name
}

// Function to convert file/blob to base64 string
async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      resolve(base64String);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Helper to retry fetch requests on NetworkError or transient errors with exponential backoff
async function fetchWithRetry(url: string, options: RequestInit, retries = 3, delay = 1000): Promise<Response> {
  for (let i = 0; i < retries; i++) {
    try {
      return await fetch(url, options);
    } catch (err) {
      if (i === retries - 1) throw err;
      console.warn(`[Fetch Retry] Failed fetching ${url}, retrying in ${delay}ms... (Attempt ${i + 1}/${retries}). Error:`, err);
      await new Promise(resolve => setTimeout(resolve, delay));
      delay *= 2;
    }
  }
  throw new Error('Fetch failed after retries');
}

/**
 * Service to manage Google Drive file and folder structures.
 * Offloads token acquisition and Direct GDrive API requests to the application's Express backend APIs.
 * This completely satisfies security compliance and avoids client-side CORS issues!
 */
export const googleDriveService = {
  /**
   * Stub checkAuth to maintain backward compatibility, but always resolves true.
   */
  async checkAuth(): Promise<string> {
    return 'authenticated_server_side';
  },

  /**
   * Uploads a file to Google Drive using the backend proxy endpoint `/api/drive/upload`.
   */
  async upload(file: Blob, name: string, context: UploadContext): Promise<string> {
    try {
      const base64Data = await blobToBase64(file);
      const response = await fetchWithRetry(getBackendUrl('/api/drive/upload'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileBase64: base64Data,
          fileName: name,
          fileType: file.type,
          context,
        }),
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(errText || 'Falha ao realizar upload para o Google Drive.');
      }

      const data = await response.json();
      if (!data.webViewLink) {
        throw new Error('Nenhum link retornado do Google Drive.');
      }
      return data.webViewLink;
    } catch (err: any) {
      console.error('googleDriveService.upload error:', err);
      throw err;
    }
  },

  /**
   * Overwrites the content of an existing file on Google Drive using the backend proxy endpoint `/api/drive/update`.
   */
  async updateFileContent(fileIdOrUrl: string, file: Blob): Promise<boolean> {
    try {
      const base64Data = await blobToBase64(file);
      const response = await fetchWithRetry(getBackendUrl('/api/drive/update'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileIdOrUrl,
          fileBase64: base64Data,
          fileType: file.type,
        }),
      });

      if (!response.ok) {
        console.error('googleDriveService.updateFileContent failed:', await response.text());
        return false;
      }

      const data = await response.json();
      return !!data.success;
    } catch (err) {
      console.error('googleDriveService.updateFileContent exception:', err);
      return false;
    }
  },

  /**
   * Deletes a file from Google Drive using the backend proxy endpoint `/api/drive/delete`.
   */
  async deleteFile(fileIdOrUrl: string): Promise<boolean> {
    try {
      const response = await fetchWithRetry(getBackendUrl('/api/drive/delete'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ fileIdOrUrl }),
      });

      if (!response.ok) {
        console.error('googleDriveService.deleteFile failed:', await response.text());
        return false;
      }

      const data = await response.json();
      return !!data.success;
    } catch (err) {
      console.error('googleDriveService.deleteFile exception:', err);
      return false;
    }
  }
};

export function extractDriveFileId(url: string | null | undefined): string | null {
  if (!url) return null;
  const match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (match && match[1]) return match[1];
  
  const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (idMatch && idMatch[1]) return idMatch[1];

  try {
    const cleanUrl = url.split('?')[0].split('#')[0];
    const segments = cleanUrl.split('/');
    for (const seg of segments) {
      if (seg.length >= 25 && seg.length <= 50 && /^[a-zA-Z0-9_-]+$/.test(seg)) {
        if (seg.toLowerCase() !== 'drive' && seg.toLowerCase() !== 'docs' && seg.toLowerCase() !== 'google') {
          return seg;
        }
      }
    }
  } catch (e) {
    // ignore
  }
  
  return null;
}
