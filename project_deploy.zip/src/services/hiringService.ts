import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  Timestamp,
  addDoc,
  deleteDoc
} from 'firebase/firestore';
import { db } from '../firebase';
import { HiringRequest, HiringStatus } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { 
  generateHiringPDF, 
  generateKinshipPDF,
  generateComissionadoForm1,
  generateComissionadoForm2,
  generateComissionadoForm3,
  generateComissionadoForm4,
  generateComissionadoForm5,
  generateComissionadoForm6,
  generateCaixaDeclaration,
  generateComissionadoExoneration
} from '../lib/pdfGenerator';
import { frequencyService } from './frequencyService';

const COLLECTION = 'hiring_requests';

export const hiringService = {
  generateNewId() {
    return doc(collection(db, COLLECTION)).id;
  },

  async createRequest(data: Partial<HiringRequest>, customId?: string) {
    try {
      if (customId) {
        const docRef = doc(db, COLLECTION, customId);
        await setDoc(docRef, {
          ...data,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        return customId;
      }
      const docRef = await addDoc(collection(db, COLLECTION), {
        ...data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, COLLECTION);
      throw error;
    }
  },

  async updateRequest(id: string, data: Partial<HiringRequest>) {
    try {
      const docRef = doc(db, COLLECTION, id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${COLLECTION}/${id}`);
    }
  },

  async getRequest(id: string): Promise<HiringRequest | null> {
    try {
      const docRef = doc(db, COLLECTION, id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as HiringRequest;
      }
      return null;
    } catch (error: any) {
      if (error.code === 'permission-denied' || error.message?.includes('permission-denied')) {
        console.warn('Permissão negada para leitura do requerimento. Verifique as regras do Firestore.', id);
        return null;
      }
      handleFirestoreError(error, OperationType.GET, `${COLLECTION}/${id}`);
      return null;
    }
  },

  async getRequestsBySector(sector: string): Promise<HiringRequest[]> {
    try {
      const q = query(
        collection(db, COLLECTION),
        where('sector', '==', sector),
        orderBy('createdAt', 'desc')
      );
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HiringRequest));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, COLLECTION);
      return [];
    }
  },

  async getAllRequests(): Promise<HiringRequest[]> {
    try {
      const q = query(
        collection(db, COLLECTION),
        orderBy('createdAt', 'desc')
      );
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HiringRequest));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, COLLECTION);
      return [];
    }
  },

  async updateStatus(id: string, status: HiringStatus, additionalData: any = {}) {
    const docRef = doc(db, COLLECTION, id);
    try {
      await updateDoc(docRef, {
        status,
        updatedAt: new Date().toISOString(),
        ...additionalData
      });

      // If status is "approved", regenerate and overwrite PDFs on Drive to include approval footer
      if (status === 'approved') {
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const currentData = docSnap.data() as HiringRequest;
          const mergedData = {
            ...currentData,
            id: docSnap.id,
            status,
            ...additionalData
          };
          await this.regenerateAndOverwritePDFs(id, mergedData);
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${COLLECTION}/${id}`);
      throw error;
    }
  },

  async saveSupervisorSignature(id: string, signature: string) {
    const docRef = doc(db, COLLECTION, id);
    try {
      const docSnap = await getDoc(docRef);
      if (!docSnap.exists()) throw new Error('Request not found');
      
      const currentData = docSnap.data() as HiringRequest;
      const isStudentSigned = currentData.student?.signature || currentData.type === 'opening';
      const signedAtStr = new Date().toISOString();
      
      await updateDoc(docRef, {
        'supervisor.signature': signature,
        'supervisor.signedAt': signedAtStr,
        status: isStudentSigned ? 'submitted' : 'supervisor_signed',
        updatedAt: new Date().toISOString()
      });

      // Regenerate and overwrite the PDFs with the new supervisor signature
      const updatedData: any = {
        ...currentData,
        id: docSnap.id,
        status: isStudentSigned ? 'submitted' : 'supervisor_signed',
        supervisor: {
          ...currentData.supervisor,
          signature,
          signedAt: signedAtStr
        }
      };
      await this.regenerateAndOverwritePDFs(id, updatedData);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${COLLECTION}/${id}`);
      throw error;
    }
  },

  async saveStudentSignature(id: string, signature: string) {
    const docRef = doc(db, COLLECTION, id);
    try {
      const docSnap = await getDoc(docRef);
      if (!docSnap.exists()) throw new Error('Request not found');
      
      const currentData = docSnap.data() as HiringRequest;
      const isSupervisorSigned = !!currentData.supervisor?.signature;
      const signedAtStr = new Date().toISOString();

      await updateDoc(docRef, {
        'student.signature': signature,
        'student.signedAt': signedAtStr,
        status: isSupervisorSigned ? 'submitted' : 'student_signed',
        updatedAt: new Date().toISOString()
      });

      // Regenerate and overwrite the PDFs (especially the parentesco PDF where the student signature goes)
      const updatedData: any = {
        ...currentData,
        id: docSnap.id,
        status: isSupervisorSigned ? 'submitted' : 'student_signed',
        student: {
          ...(currentData.student || { name: 'Estudante', cpf: '', email: '', phone: '' }),
          signature,
          signedAt: signedAtStr
        }
      };
      await this.regenerateAndOverwritePDFs(id, updatedData);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${COLLECTION}/${id}`);
      throw error;
    }
  },

  async saveComissionadoOnboarding(id: string, onboardingDetails: any, signature: string) {
    const docRef = doc(db, COLLECTION, id);
    try {
      const docSnap = await getDoc(docRef);
      if (!docSnap.exists()) throw new Error('Request not found');
      
      const currentData = docSnap.data() as HiringRequest;
      const signedAtStr = new Date().toISOString();
      const nextDetails = {
        ...(currentData.comissionadoDetails || {}),
        ...onboardingDetails
      };

      await updateDoc(docRef, {
        comissionadoDetails: nextDetails,
        'student.signature': signature,
        'student.signedAt': signedAtStr,
        status: 'student_signed' as const,
        updatedAt: new Date().toISOString()
      });

      const updatedData: any = {
        ...currentData,
        id: docSnap.id,
        status: 'student_signed' as const,
        comissionadoDetails: nextDetails,
        student: {
          ...(currentData.student || { name: 'Candidato', cpf: '', email: '', phone: '' }),
          signature,
          signedAt: signedAtStr
        }
      };
      await this.regenerateAndOverwritePDFs(id, updatedData);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${COLLECTION}/${id}`);
      throw error;
    }
  },

  async regenerateAndOverwritePDFs(id: string, updatedData?: Partial<HiringRequest>) {
    try {
      const docRef = doc(db, COLLECTION, id);
      const docSnap = await getDoc(docRef);
      if (!docSnap.exists()) return;
      
      let request = { id: docSnap.id, ...docSnap.data() } as HiringRequest;
      if (updatedData) {
        request = { ...request, ...updatedData };
      }

      let docsUpdated = false;
      const newDocuments = { ...(request.documents || {}) };
      
      if (request.category === 'comissionado') {
        const studentName = request.student?.name || 'Candidato';
        const requestNameAndId = `${studentName}_${request.id}`.replace(/\s+/g, '_');
        const context = {
          module: 'hiring' as const,
          category: 'comissionado' as const,
          lotacao: request.sector || 'Submissoes_Gerais',
          requestNameAndId,
          requestId: request.id,
          userName: request.supervisor?.name
        };

        const cleanServidorName = studentName.trim().replace(/\s+/g, '_');

        const updateOrUpload = async (docKey: string, docGenerator: any, defaultName: string) => {
          const docObj = docGenerator(request, true);
          const blob = docObj.output('blob');
          const existingDoc = (newDocuments as any)?.[docKey];
          if (existingDoc?.fileId) {
            await frequencyService.updateFile(existingDoc.fileId, blob);
          } else {
            const file = new File([blob], defaultName, { type: 'application/pdf' });
            const fileUrl = await frequencyService.uploadFile(file, `hiring_doc_${docKey}`, context);
            (newDocuments as any)[docKey] = { fileId: fileUrl, name: defaultName };
            docsUpdated = true;
          }
        };

        // 1. Form 1 (Indicação)
        if (request.documents?.form1?.fileId) {
          const form1Doc = generateComissionadoForm1(request, true);
          const form1Blob = form1Doc.output('blob');
          await frequencyService.updateFile(request.documents.form1.fileId, form1Blob);
        }

        // 2. Form 2 (Cadastro)
        await updateOrUpload('form2', generateComissionadoForm2, `Formulário_2_Dados_Cadastrais_${cleanServidorName}.pdf`);

        // 3. Form 3 (Parentesco)
        await updateOrUpload('form3', generateComissionadoForm3, `Formulário_3_Declaração_de_Parentesco_${cleanServidorName}.pdf`);

        // 4. Form 4 (Atividade Remunerada)
        await updateOrUpload('form4', generateComissionadoForm4, `Formulário_4_Declaração_Outras_Atividades_${cleanServidorName}.pdf`);

        // 5. Form 5 (Dependentes)
        await updateOrUpload('form5', generateComissionadoForm5, `Formulário_5_Dependentes_${cleanServidorName}.pdf`);

        // 6. Form 6 (Impedimento)
        await updateOrUpload('form6', generateComissionadoForm6, `Formulário_6_Declaração_Idoneidade_${cleanServidorName}.pdf`);

        // 7. Caixa Declaration
        if (request.documents?.declaracaoCaixa?.fileId) {
          const caixaDoc = generateCaixaDeclaration(request, undefined, undefined, true);
          const caixaBlob = caixaDoc.output('blob');
          await frequencyService.updateFile(request.documents.declaracaoCaixa.fileId, caixaBlob);
        }

        // 8. Exoneracao Form
        if (request.documents?.exoneracao?.fileId) {
          const exonDoc = generateComissionadoExoneration(request, undefined, undefined, true);
          const exonBlob = exonDoc.output('blob');
          await frequencyService.updateFile(request.documents.exoneracao.fileId, exonBlob);
        }
      } else {
        const studentName = request.student?.name || 'Candidato';
        const cleanStudentName = studentName.trim().replace(/\s+/g, '_');

        // 1. Requerimento PDF (generateHiringPDF)
        if (request.documents?.requerimento?.fileId) {
          const mgrName = request.createdBy ? request.createdBy.split('@')[0].toUpperCase() : 'GESTOR';
          const mgrEmail = request.createdBy || 'dgep@cmc.pr.gov.br';
          
          const hiringDoc = generateHiringPDF(request, mgrName, mgrEmail, true);
          const hiringBlob = hiringDoc.output('blob');
          const reqFileName = `${cleanStudentName}_Requerimento_Para_Contratação.pdf`;
          
          const updated = await frequencyService.updateFile(request.documents.requerimento.fileId, hiringBlob);
          if (!updated) {
            console.log('Update existing requerimento failed, uploading new file to Drive...');
            const requestNameAndId = `${studentName}_${request.id}`.replace(/\s+/g, '_');
            const context = {
              module: 'hiring' as const,
              category: 'intern' as const,
              lotacao: request.sector || 'Submissoes_Gerais',
              requestNameAndId,
              requestId: request.id
            };
            const hiringFile = new File([hiringBlob], reqFileName, { type: 'application/pdf' });
            const newUrl = await frequencyService.uploadFile(hiringFile, `hiring_doc_requerimento`, context);
            if (newUrl) {
              newDocuments.requerimento = { fileId: newUrl, name: reqFileName };
              docsUpdated = true;
            }
          }
        }
        
        // 2. Declaração do Parentesco PDF (generateKinshipPDF) - only for hiring
        if (request.type === 'hiring' && request.documents?.parentesco?.fileId) {
          const kinshipDoc = generateKinshipPDF(request, true);
          if (kinshipDoc) {
            const kinshipBlob = kinshipDoc.output('blob');
            const kinshipFileName = `${cleanStudentName}_Declaração_de_Parentesco.pdf`;
            
            const updated = await frequencyService.updateFile(request.documents.parentesco.fileId, kinshipBlob);
            if (!updated) {
              console.log('Update existing parentesco failed, uploading new file to Drive...');
              const requestNameAndId = `${studentName}_${request.id}`.replace(/\s+/g, '_');
              const context = {
                module: 'hiring' as const,
                category: 'intern' as const,
                lotacao: request.sector || 'Submissoes_Gerais',
                requestNameAndId,
                requestId: request.id
              };
              const kinshipFile = new File([kinshipBlob], kinshipFileName, { type: 'application/pdf' });
              const newUrl = await frequencyService.uploadFile(kinshipFile, `hiring_doc_parentesco`, context);
              if (newUrl) {
                newDocuments.parentesco = { fileId: newUrl, name: kinshipFileName };
                docsUpdated = true;
              }
            }
          }
        }
      }

      if (docsUpdated) {
        await updateDoc(docRef, {
          documents: newDocuments,
          updatedAt: new Date().toISOString()
        });
      }
    } catch (err) {
      console.error('Error regenerating and overwriting PDFs on Google Drive:', err);
    }
  },

  async deleteRequest(id: string) {
    const docRef = doc(db, COLLECTION, id);
    try {
      // Fetch request first to identify any uploaded files in Drive
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data() as Partial<HiringRequest>;
        if (data.documents) {
          const fileKeys = ['rg', 'cpf', 'photo', 'bank', 'address', 'enrollment', 'parent', 'requerimento', 'parentesco'] as const;
          for (const key of fileKeys) {
            const docObj = data.documents[key];
            if (docObj) {
              const fileIdOrUrl = typeof docObj === 'string' ? docObj : (docObj as any).fileId;
              if (fileIdOrUrl) {
                // Trigger asynchronous delete so we do not block database operation, but clean up Drive
                frequencyService.deleteFile(fileIdOrUrl).catch(err => {
                  console.warn(`Failed to delete Drive file associated with key ${key}:`, err);
                });
              }
            }
          }
        }
      }
    } catch (fetchErr) {
      console.warn("Could not retrieve request files before deletion:", fetchErr);
    }

    try {
      await deleteDoc(docRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${COLLECTION}/${id}`);
      throw error;
    }
  }
};
