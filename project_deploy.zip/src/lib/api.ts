/**
 * Resolves the backend URL dynamically, allowing cross-environment integration
 * (e.g., when the frontend is statically hosted on GitHub Pages but needs the Express API).
 */
export function getBackendUrl(path: string): string {
  // If we are running on any host other than GitHub Pages, we are running the full-stack
  // app on a unified server (localhost, Cloud Run, custom domains). We should ALWAYS use
  // relative paths to avoid any CORS, preflight, or subdomain mismatch issues.
  if (typeof window !== 'undefined' && !window.location.hostname.includes('github.io')) {
    return path.startsWith('/') ? path : `/${path}`;
  }

  const customBackend = import.meta.env.VITE_BACKEND_URL;
  if (customBackend) {
    const base = customBackend.endsWith('/') ? customBackend.slice(0, -1) : customBackend;
    const formattedPath = path.startsWith('/') ? path : `/${path}`;
    return `${base}${formattedPath}`;
  }
  
  // Smart fallback: if the host is github.io, point to the known Cloud Run backend
  if (typeof window !== 'undefined' && window.location.hostname.includes('github.io')) {
    const defaultBackend = "https://ais-pre-k7nx6vyg4qwqvchdv4geyu-468160489021.us-west2.run.app";
    const base = defaultBackend.endsWith('/') ? defaultBackend.slice(0, -1) : defaultBackend;
    const formattedPath = path.startsWith('/') ? path : `/${path}`;
    return `${base}${formattedPath}`;
  }

  return path;
}
