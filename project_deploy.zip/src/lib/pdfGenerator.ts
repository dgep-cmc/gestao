import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { HiringRequest, FrequencyRecord } from '../types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { LOGO_BASE64 } from './logo';
import { SIGN_ICON_BASE64 } from './signature';

export const userNamesCache: { [email: string]: string } = {};
export const userCpfsCache: { [email: string]: string } = {};

const formatCpfMasked = (cpfStr: string): string => {
  if (!cpfStr) return '';
  const digits = cpfStr.replace(/\D/g, '');
  if (digits.length !== 11) return cpfStr;
  return `${digits.substring(0, 3)}.***.${digits.substring(6, 9)}-${digits.substring(9)}`;
};

export const formatFallbackName = (emailOrUsername: string): string => {
  if (!emailOrUsername) return 'USUÁRIO';
  
  // If it already looks like a nice full name with spaces and no dot/at
  if (emailOrUsername.includes(' ') && !emailOrUsername.includes('@') && !emailOrUsername.includes('.')) {
    return emailOrUsername.toUpperCase();
  }
  
  const cleanPart = emailOrUsername.includes('@') 
    ? emailOrUsername.split('@')[0] 
    : emailOrUsername;
    
  // replace common delimiters like . _ - with space
  const nameParts = cleanPart.replace(/[\._\-]/g, ' ').split(/\s+/);
  
  const formattedParts = nameParts
    .filter(part => part.length > 0)
    .map(part => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase());
    
  return formattedParts.join(' ').toUpperCase();
};

const getFullName = (name: string, email: string): string => {
  const cleanEmail = (email || '').trim().toLowerCase();
  if (cleanEmail && userNamesCache[cleanEmail]) {
    return userNamesCache[cleanEmail].toUpperCase();
  }
  
  const cleanName = (name || '').trim();
  if (cleanName) {
    // If name is already formatted without dots/ats and has a space, it's a full name
    if (cleanName.includes(' ') && !cleanName.includes('@') && !cleanName.includes('.')) {
      return cleanName.toUpperCase();
    }
    return formatFallbackName(cleanName);
  }
  
  if (cleanEmail) {
    return formatFallbackName(cleanEmail);
  }
  
  return 'USUÁRIO';
};

const drawHeader = (doc: any, title: string, subtitle?: string) => {
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Logo
  doc.addImage(LOGO_BASE64, 'PNG', 15, 10, 28, 0);
  
  // Vertical Line
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.5);
  doc.line(46, 10, 46, 25);
  
  // Title text
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(title.toUpperCase(), 52, 18);
  
  if (subtitle) {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(subtitle, 52, 24);
  }
};

const drawComissionadosHeader = (doc: any, titleLines: string[], subtitle?: string) => {
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Logo
  doc.addImage(LOGO_BASE64, 'PNG', 15, 10, 28, 0);
  
  // Vertical Line
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.5);
  doc.line(46, 10, 46, 30);
  
  // Title text
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10.5);
  doc.setFont('helvetica', 'bold');
  doc.text(titleLines[0].toUpperCase(), 52, 16);
  doc.text(titleLines[1].toUpperCase(), 52, 21);
  
  if (subtitle) {
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    doc.text(subtitle, 52, 27);
  }
};

const drawStandardSignature = (doc: any, name: string, email: string, dateIso: string, x: number, y: number, isComissionados?: boolean) => {
  doc.addImage(SIGN_ICON_BASE64, 'PNG', x, y, 5, 5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(0, 0, 0); // ensuring black
  let resolvedName = getFullName(name, email);
  if (isComissionados && resolvedName && !resolvedName.toUpperCase().startsWith("VER. ")) {
    resolvedName = "VER. " + resolvedName;
  }
  doc.text(resolvedName, x + 7, y + 3.5);
  
  const cleanEmail = (email || '').trim().toLowerCase();
  const userCpf = userCpfsCache[cleanEmail] ? formatCpfMasked(userCpfsCache[cleanEmail]) : '';
  
  let lineOffset = 0;
  if (userCpf) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.text(`CPF: ${userCpf}`, x + 7, y + 6.5);
    lineOffset = 3;
  }
  
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6);
  doc.text("Documento assinado digitalmente por meio", x, y + 8 + lineOffset);
  doc.text(`do login ${email}`, x, y + 11 + lineOffset);
  const formattedDate = format(new Date(dateIso), "dd/MM/yyyy 'às' HH:mm:ss");
  doc.text(`no dia ${formattedDate}`, x, y + 14 + lineOffset);
};

export const generateInternsListPDF = (
  records: FrequencyRecord[], 
  month: number, 
  year: number,
  userName = 'Administrador',
  userEmail = 'dgep@cmc.pr.gov.br',
  isComissionados = false
) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const nomeMes = format(new Date(year, month - 1, 1), 'MMMM', { locale: ptBR });

  drawHeader(doc, 'Relatório Consolidado de Frequência', 'DGEP - Diretoria de Gestão de Pessoas');
  
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  doc.text(`Referência: ${nomeMes} de ${year}`, 15, 45);
  doc.text(`Data de Emissão: ${format(new Date(), 'dd/MM/yyyy HH:mm:ss')}`, 15, 51);
  doc.text(`Total de Registros: ${records.length} ${isComissionados ? 'servidores' : 'estagiários'} listados`, 15, 57);

  const tableData = records.map(r => [
    (r.matricula || '').toUpperCase(),
    r.internName.toUpperCase(),
    r.lotacao.toUpperCase(),
    r.details?.periodo || r.periodoOriginal || `${String(1).padStart(2, '0')}/${String(month).padStart(2, '0')} a ${String(new Date(year, month, 0).getDate()).padStart(2, '0')}/${String(month).padStart(2, '0')}`,
    r.details?.datasFalta ? `${r.details.falta || '0'}\n(${r.details.datasFalta.toUpperCase()})` : (r.details?.falta || '0'),
    r.details?.datasAtestados ? `${r.details.atestados || '0'}\n(${r.details.datasAtestados.toUpperCase()})` : (r.details?.atestados || '0'),
    r.details?.datasRecesso ? `${r.details.recesso || '0'}\n(${r.details.datasRecesso.toUpperCase()})` : (r.details?.recesso || '0'),
    r.status === 'validada' ? 'V' : 
    r.status === 'submitted' ? 'E' :
    r.status === 'devolvida' ? 'D' : 'P'
  ]);

  autoTable(doc, {
    startY: 65,
    head: [['Matrícula', 'Nome', 'Lotação', 'Período', 'Faltas', 'Atestados', isComissionados ? 'Férias' : 'Recesso', 'Status']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontSize: 7, fontStyle: 'bold', halign: 'center' },
    styles: { fontSize: 6.5, cellPadding: 2, valign: 'middle' },
    columnStyles: {
      0: { cellWidth: 15, halign: 'center' },
      1: { cellWidth: 35, halign: 'left' },
      2: { cellWidth: 35, halign: 'left' },
      3: { cellWidth: 24, halign: 'center' },
      4: { cellWidth: 18, halign: 'center' },
      5: { cellWidth: 23, halign: 'center' },
      6: { cellWidth: 18, halign: 'center' },
      7: { cellWidth: 12, halign: 'center' }
    }
  });

  const finalY = (doc as any).lastAutoTable.finalY + 15;
  
  doc.setFontSize(8);
  doc.text('Legenda Status: (V) Validada | (E) Enviada | (D) Devolvida | (P) Pendente', 15, finalY);

  // Custom simple block for reports as they are signed by the emitting user
  const boxWidth = pageWidth - 30;
  doc.setDrawColor(200, 200, 200);
  doc.setFillColor(248, 248, 248);
  doc.roundedRect(15, finalY + 10, boxWidth, 28, 3, 3, 'FD');
  
  doc.setTextColor(37, 99, 235);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('Relatório emitido pelo usuário:', 20, finalY + 16);
  
  // Electronic signature call
  drawStandardSignature(doc, userName, userEmail, new Date().toISOString(), 20, finalY + 20);

  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - 15, doc.internal.pageSize.getHeight() - 10, { align: 'right' });
  }

  doc.save(`Consolidado_${nomeMes}_${year}.pdf`);
  return doc;
};

export const generateHiringPDF = (request: HiringRequest, userName?: string, userEmail?: string, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxWidth = pageWidth - 30;
  
  if (request.type === 'hiring') {
    drawHeader(doc, 'REQUERIMENTO PARA CONTRATAÇÃO DE ESTAGIÁRIOS', 'DGEP - Diretoria de Gestão de Pessoas');
    
    let y = 35;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text("Solicitamos a contratação do(a) estudante abaixo identificado(a) para exercer atividades como Estagiário(a) na", 15, y);
    doc.text("Câmara Municipal de Curitiba.", 15, y + 5);
    
    y += 10;
    
    const mainData = [
      [{ content: `Setor / Gabinete: ${request.sector.toUpperCase()}`, colSpan: 2 }],
      [{ content: `Nome do estudante: ${request.student?.name.toUpperCase() || 'NÃO INFORMADO'}`, colSpan: 2 }],
      [{ content: `Escolaridade: ${request.level.toUpperCase()}`, colSpan: 2 }],
      [{ content: `Se Técnico ou Superior, curso: ${request.course.toUpperCase()}`, colSpan: 2 }],
      [{ content: `Atividades:\n${request.activities}`, colSpan: 2, styles: { minCellHeight: 15 } }],
      [`Contratar a partir de: ${request.startDate ? format(new Date(request.startDate), 'dd/MM/yyyy') : '___/___'}`, `Estágio obrigatório? ${request.student?.isMandatory ? 'Sim' : 'Não'}`],
      [{ content: `Período: ${request.period.toUpperCase()} (${request.startTime} às ${request.endTime})`, colSpan: 2 }],
      [{ content: `Supervisor: ${request.supervisor.name.toUpperCase()} - Cargo: ${request.supervisor.role.toUpperCase()}`, colSpan: 2 }],
      [`RG: ${request.supervisor.rg}`, `CPF: ${request.supervisor.cpf}`],
      [`E-mail: ${request.supervisor.email}`, `Telefone: ${request.supervisor.phone}`],
      [`Exp.: ${request.supervisor.experience || 'N/I'}`, `Escolaridade: ${request.supervisor.education.toUpperCase()}${request.supervisor.course ? ` - ${request.supervisor.course.toUpperCase()}` : ''}`]
    ];

    autoTable(doc, {
      startY: y,
      body: mainData,
      theme: 'grid',
      styles: { fontSize: 7.5, cellPadding: 1.5, textColor: [0, 0, 0] },
      margin: { left: 15, right: 15 }
    });

    y = (doc as any).lastAutoTable.finalY + 8;
    
    // Add Date
    doc.setFontSize(9);
    doc.text(`Curitiba, ${format(new Date(request.createdAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}`, pageWidth - 15, y, { align: 'right' });
    
    y += 5;

    // Signatures
    // Manager Electronic Signature
    if (userName && userEmail) {
      drawStandardSignature(doc, userName, userEmail, request.createdAt, 30, y);
    }
    
    // Supervisor Collection Signature
    if (request.supervisor.signature) {
      doc.addImage(request.supervisor.signature, 'PNG', pageWidth/2 + 30, y, 40, 12);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      if (request.supervisor.signedAt) {
        doc.text(`Assinado em: ${format(new Date(request.supervisor.signedAt), 'dd/MM/yyyy HH:mm')}`, pageWidth/2 + 30, y + 14);
      }
    } else {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      doc.text("(Aguardando assinatura)", pageWidth/2 + 35, y + 8);
    }

    doc.setDrawColor(0, 0, 0);
    doc.line(15, y + 16, pageWidth/2 - 5, y + 16);
    doc.line(pageWidth/2 + 5, y + 16, pageWidth - 15, y + 16);

    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    doc.text("Vereador (Gabinetes) ou", 15 + ((pageWidth/2 - 20) / 2), y + 20, { align: 'center' });
    doc.text("Chefe de Área (Administrativo)", 15 + ((pageWidth/2 - 20) / 2), y + 23, { align: 'center' });
    
    doc.text("Ciência do Supervisor do Estágio", pageWidth/2 + 5 + ((pageWidth/2 - 20) / 2), y + 20, { align: 'center' });
    
    y += 28;

  } else if (request.type === 'resignation') {
    // Rescisão de Estágio
    drawHeader(doc, 'RESCISÃO DE ESTÁGIO', 'DGEP - Diretoria de Gestão de Pessoas');
    
    let y = 45;

    // Main text body
    const studentName = request.student?.name?.toUpperCase() || 'NÃO INFORMADO';
    const sectorName = request.sector?.toUpperCase() || 'NÃO INFORMADO';
    const resignationDate = request.startDate ? format(new Date(request.startDate), 'dd/MM/yyyy') : '___/___/______';
    
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(0, 0, 0);
    
    const text = `Solicitamos a rescisão do termo de compromisso de estágio do(a) estagiário(a) ${studentName}, lotado(a) no setor ${sectorName}, a partir de ${resignationDate}.`;
    const splitText = doc.splitTextToSize(text, pageWidth - 30);
    doc.text(text, 15, y, { maxWidth: pageWidth - 30, align: 'justify' });
    
    y += (splitText.length * 6) + 20;
    
    // Add Date
    doc.setFontSize(9);
    const cityDateText = `Curitiba, ${format(new Date(request.createdAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}.`;
    doc.text(cityDateText, pageWidth - 15, y, { align: 'right' });
    
    y += 5;
    
    // Centralized digital signature
    const sigX = (pageWidth / 2) - 35;
    if (userName && userEmail) {
      drawStandardSignature(doc, userName, userEmail, request.createdAt, sigX, y);
    } else {
      const backupName = request.supervisor?.name || (request.createdBy ? request.createdBy.split('@')[0].toUpperCase() : 'SUPERVISOR');
      const backupEmail = request.supervisor?.email || request.createdBy || 'dgep@cmc.pr.gov.br';
      drawStandardSignature(doc, backupName, backupEmail, request.createdAt, sigX, y);
    }
    
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.5);
    doc.line(pageWidth / 2 - 45, y + 16, pageWidth / 2 + 45, y + 16);
    
    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    doc.text("SUPERVISOR / GESTOR", pageWidth / 2, y + 20, { align: 'center' });
    
    y += 32;

  } else {
    // Opening Vaga
    drawHeader(doc, 'REQUERIMENTO DE ABERTURA DE VAGA DE ESTÁGIO', 'DGEP - Diretoria de Gestão de Pessoas');
    
    let y = 45;
  
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Data da Solicitação: ${format(new Date(request.createdAt), 'dd/MM/yyyy HH:mm')}`, 15, y);
    y += 10;
  
    const vagaData = [
      ['SETOR SOLICITANTE:', request.sector.toUpperCase()],
      ['CURSO PRETENDIDO:', (request.course || 'QUALQUER ÁREA CORRELATA').toUpperCase()],
      ['PERÍODO DO ESTÁGIO:', `${request.startTime}h às ${request.endTime}h (${request.period.toUpperCase()})`],
      ['E-MAIL RETORNO CURRÍCULOS:', (request.supervisor?.email || 'NÃO INFORMADO').toUpperCase()],
      ['ATIVIDADES DESENVOLVIDAS:', request.activities]
    ];
  
    autoTable(doc, {
      startY: y,
      body: vagaData,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 3, textColor: [0, 0, 0] },
      columnStyles: { 0: { fontStyle: 'bold', cellWidth: 50, fillColor: [250, 250, 250] } },
      margin: { left: 15, right: 15 }
    });

    const tableFinalY = (doc as any).lastAutoTable.finalY;
    let sigY = tableFinalY + 15;
    
    // Check if drawing standard signature runs over current page context
    const pageHeight = doc.internal.pageSize.getHeight();
    if (sigY + 30 > pageHeight - 20) {
      doc.addPage();
      sigY = 20;
    }
    
    const sigX = (pageWidth / 2) - 35;
    const backupName = request.supervisor?.name || (request.createdBy ? request.createdBy.split('@')[0].toUpperCase() : 'SUPERVISOR');
    const backupEmail = request.supervisor?.email || request.createdBy || 'dgep@cmc.pr.gov.br';
    drawStandardSignature(doc, backupName, backupEmail, request.createdAt, sigX, sigY);
    
    // Draw subtitle under signature line
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.5);
    doc.line(pageWidth / 2 - 45, sigY + 18, pageWidth / 2 + 45, sigY + 18);
    
    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text("GESTOR / SOLICITANTE", pageWidth / 2, sigY + 22, { align: 'center' });
  }

  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    const pageHeight = doc.internal.pageSize.getHeight();
    
    if (request.status === 'approved') {
      // Draw subtle horizontal line above footer
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.3);
      doc.line(15, pageHeight - 16, pageWidth - 15, pageHeight - 16);
      
      doc.setFontSize(7.5);
      doc.setTextColor(16, 185, 129);
      doc.setFont('helvetica', 'bold');
      doc.text('VALIDADO PELA DGEP', 15, pageHeight - 11);
      
      const approvedDateStr = request.approvedAt ? format(new Date(request.approvedAt), 'dd/MM/yyyy') : '---';
      const approvedTimeStr = request.approvedAt ? format(new Date(request.approvedAt), 'HH:mm:ss') : '---';
      const approvedByStr = request.approvedBy || '---';
      
      doc.setFontSize(7);
      doc.setTextColor(80, 80, 80);
      doc.setFont('helvetica', 'normal');
      doc.text(`Requerimento validado pela DGEP - Diretoria de Gestão de Pessoas, em ${approvedDateStr} às ${approvedTimeStr} pelo usuário ${approvedByStr}.`, 15, pageHeight - 7);
    }
    
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.setFont('helvetica', 'normal');
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - 20, pageHeight - 10, { align: 'right' });
  }

  const prefix = request.type === 'hiring' ? 'REQUERIMENTO' : request.type === 'resignation' ? 'RESCISAO' : 'VAGA';
  if (!silent) {
    doc.save(`${prefix}_${request.id.substring(0, 8).toUpperCase()}.pdf`);
  }
  return doc;
};

export const generateKinshipPDF = (request: HiringRequest, silent = false) => {
  if (request.type !== 'hiring') return;
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  
  drawHeader(doc, 'INFORMAÇÃO SOBRE VÍNCULO DE PARENTESCO', 'DGEP - Diretoria de Gestão de Pessoas');
  
  let yE3 = 35;
  
  // Header Data
  const studentInfo = [
    [{ content: `Nome do estudante:\n${request.student?.name.toUpperCase() || 'NÃO INFORMADO'}` }],
    [{ content: `CPF:\n${request.student?.cpf || 'NÃO INFORMADO'}` }],
    [{ content: `Lotação:\n${request.sector.toUpperCase()}` }]
  ];

  autoTable(doc, {
    startY: yE3,
    body: studentInfo,
    theme: 'grid',
    styles: { fontSize: 8, cellPadding: 2, textColor: [0, 0, 0] },
    margin: { left: 15, right: 15 }
  });

  yE3 = (doc as any).lastAutoTable.finalY + 15;
  
  // DECLARAÇÃO
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('DECLARAÇÃO', pageWidth / 2, yE3, { align: 'center' });
  
  yE3 += 10;
  
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  
  const declaracao = `Declaro, para fins de contrato de estágio do estudante acima indicado, que NÃO me encontro na condição de cônjuge, companheiro ou parente em linha reta, colateral por consanguinidade ou afinidade, até o terceiro grau, com Agentes Políticos do Município nos cargos de Secretários, Dirigentes e Diretores da Administração Direta e Indireta, inclusive, conforme a Súmula Vinculante nº 13 do STF, da autoridade nomeante ou de servidor da Câmara Municipal de Curitiba, investido em cargo de direção, chefia ou de cargos em comissão de assessoramento.`;
  
  doc.text(declaracao, 15, yE3, { maxWidth: pageWidth - 30, align: 'justify' });
  
  const splitDeclaracao = doc.splitTextToSize(declaracao, pageWidth - 30);
  yE3 += (splitDeclaracao.length * 5) + 15;
  
  // Assinatura do Estudante
  doc.setFontSize(9);
  doc.text(`Data: ${request.student?.signedAt ? format(new Date(request.student.signedAt), 'dd/MM/yyyy') : '___/___/______'}`, 15, yE3 + 25);
  doc.setFont('helvetica', 'bold');
  doc.text('Assinatura do estudante:', 55, yE3 + 25);
  
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.5);
  doc.line(105, yE3 + 25, pageWidth - 15, yE3 + 25);
  
  if (request.student?.signature) {
    doc.addImage(request.student.signature, 'PNG', 105 + (pageWidth - 120 - 50) / 2, yE3 + 5, 50, 15);
  } else {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6);
    doc.text("(Aguardando assinatura via sistema)", 105 + ((pageWidth - 120) / 2), yE3 + 15, { align: 'center' });
  }
  
  // Name and CPF below the signature line
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  const lineCenterX = 105 + (pageWidth - 15 - 105) / 2;
  doc.text(request.student?.name.toUpperCase() || 'NÃO INFORMADO', lineCenterX, yE3 + 30, { align: 'center' });
  doc.text(`CPF: ${request.student?.cpf || 'NÃO INFORMADO'}`, lineCenterX, yE3 + 34, { align: 'center' });
  
  yE3 += 42;

  // Tabela Linha Reta
  autoTable(doc, {
    startY: yE3,
    head: [[{ content: 'PARENTES EM LINHA RETA', colSpan: 3, styles: { halign: 'center' } }]],
    body: [
      [{ content: 'Grau', styles: { fontStyle: 'bold' } }, { content: 'Consanguíneo', styles: { fontStyle: 'bold' } }, { content: 'Afinidade (vínculos atuais)', styles: { fontStyle: 'bold' } }],
      ['1º', 'Pai / Mãe / Filho / Filha', 'Sogro / Sogra, Genro / Nora, Madrasta / Padrasto, Enteado / Enteada'],
      ['2º', 'Avô / Avó / Neto / Neta', 'Avô / Avó, Neta / Neto do cônjuge ou companheiro'],
      ['3º', 'Bisavô / Bisavó', 'Bisavô / Bisavó, Bisneto / Bisneta do cônjuge ou companheiro']
    ],
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0] },
    styles: { fontSize: 6.5, cellPadding: 1.5, halign: 'center', textColor: [0, 0, 0] },
    margin: { left: 15, right: 15 }
  });
  
  yE3 = (doc as any).lastAutoTable.finalY + 5;
  
  // Tabela Linha Colateral
  autoTable(doc, {
    startY: yE3,
    head: [[{ content: 'PARENTES EM LINHA COLATERAL', colSpan: 3, styles: { halign: 'center' } }]],
    body: [
      [{ content: 'Grau', styles: { fontStyle: 'bold' } }, { content: 'Consanguíneo', styles: { fontStyle: 'bold' } }, { content: 'Afinidade (vínculos atuais)', styles: { fontStyle: 'bold' } }],
      ['1º', '-----------', '----------------------'],
      ['2º', 'Irmão / Irmã', 'Cunhado / Cunhada'],
      ['3º', 'Tio / Tia', 'Tio / Tia, Sobrinho / Sobrinha do cônjuge ou companheiro']
    ],
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0] },
    styles: { fontSize: 6.5, cellPadding: 1.5, halign: 'center', textColor: [0, 0, 0] },
    margin: { left: 15, right: 15 }
  });

  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    const pageHeight = doc.internal.pageSize.getHeight();
    
    if (request.status === 'approved') {
      // Draw subtle horizontal line above footer
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.3);
      doc.line(15, pageHeight - 16, pageWidth - 15, pageHeight - 16);
      
      doc.setFontSize(7.5);
      doc.setTextColor(16, 185, 129);
      doc.setFont('helvetica', 'bold');
      doc.text('VALIDADO PELA DGEP', 15, pageHeight - 11);
      
      const approvedDateStr = request.approvedAt ? format(new Date(request.approvedAt), 'dd/MM/yyyy') : '---';
      const approvedTimeStr = request.approvedAt ? format(new Date(request.approvedAt), 'HH:mm:ss') : '---';
      const approvedByStr = request.approvedBy || '---';
      
      doc.setFontSize(7);
      doc.setTextColor(80, 80, 80);
      doc.setFont('helvetica', 'normal');
      doc.text(`Requerimento validado pela DGEP - Diretoria de Gestão de Pessoas, em ${approvedDateStr} às ${approvedTimeStr} pelo usuário ${approvedByStr}.`, 15, pageHeight - 7);
    }
    
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.setFont('helvetica', 'normal');
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - 20, pageHeight - 10, { align: 'right' });
  }

  if (!silent) {
    doc.save(`DECLARACAO_PARENTESCO_${request.id.substring(0, 8).toUpperCase()}.pdf`);
  }
  return doc;
};

export const generateFrequencyPDF = (
  records: any[], 
  month: number, 
  year: number,
  sector: string, 
  userName: string,
  userEmail: string
) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const nomeMes = format(new Date(year, month - 1, 1), 'MMMM', { locale: ptBR });

  drawHeader(doc, 'Formulário de Frequência de Estagiários', 'DGEP - Diretoria de Gestão de Pessoas');
  
  let y = 40;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('À Diretoria de Gestão de Pessoas (DGEP),', 15, y);
  y += 7;

  const infoText = `Informamos o controle de frequência dos estagiários vinculados a este gabinete/lotação, referente ao mês de ${nomeMes.toLowerCase()} de ${year}.`;
  const splitInfo = doc.splitTextToSize(infoText, pageWidth - 30);
  doc.text(splitInfo, 15, y);
  y += (splitInfo.length * 5) + 4;

  doc.setFont('helvetica', 'bold');
  doc.text('Lotação: ', 15, y);
  const startX = 15 + doc.getTextWidth('Lotação: ');
  doc.setFont('helvetica', 'normal');
  doc.text(sector.toUpperCase(), startX, y);
  y += 12;

  const tableData = records.map(r => [
    r.internName.toUpperCase(),
    r.details?.periodo || r.periodoOriginal || 'N/D',
    r.details?.presenca === 'integral' ? 'INTEGRAL' : 'PARCIAL',
    r.details?.datasFalta ? `${r.details.falta || '0'}\n(${r.details.datasFalta.toUpperCase()})` : (r.details?.falta || '0'),
    r.details?.datasAtestados ? `${r.details.atestados || '0'}\n(${r.details.datasAtestados.toUpperCase()})` : (r.details?.atestados || '0'),
    r.details?.datasRecesso ? `${r.details.recesso || '0'}\n(${r.details.datasRecesso.toUpperCase()})` : (r.details?.recesso || '0')
  ]);

  autoTable(doc, {
    startY: y,
    head: [['Estagiário', 'Período', 'Presença', 'Falta', 'Atest./Afast.', 'Recesso']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontSize: 8, fontStyle: 'bold', halign: 'center' },
    styles: { fontSize: 7, cellPadding: 3, halign: 'center' },
    columnStyles: {
      0: { halign: 'left', cellWidth: 55 },
      1: { halign: 'center', cellWidth: 35 },
      2: { halign: 'center', cellWidth: 25 },
      3: { halign: 'center' },
      4: { halign: 'center' },
      5: { halign: 'center' }
    }
  });

  y = (doc as any).lastAutoTable.finalY + 15;
  
  // Find the original submission info from the records to prevent signature recreation or modification
  const submittedRecord = records.find(r => r.submittedAt);
  const signatureDate = submittedRecord?.submittedAt || new Date().toISOString();
  const signatureEmail = submittedRecord?.submittedBy || userEmail;
  const signatureName = submittedRecord?.submittedBy 
    ? getFullName('', submittedRecord.submittedBy)
    : userName;

  if (signatureName && signatureEmail) {
    drawStandardSignature(doc, signatureName, signatureEmail, signatureDate, pageWidth / 2 - 30, y);
  }
  
  doc.setDrawColor(0, 0, 0);
  doc.line(pageWidth / 2 - 45, y + 16, pageWidth / 2 + 45, y + 16);
  
  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.text("Responsável pela Validação", pageWidth / 2, y + 20, { align: 'center' });

  // Detect if validated to draw validation stamp footer
  const isAnyValidated = records.some(r => r.status === 'validada' || r.validatedAt);
  const valRecord = records.find(r => r.validatedAt);
  const validatedAt = valRecord?.validatedAt || null;
  const validatedBy = valRecord?.validatedBy || null;

  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    const pageHeight = doc.internal.pageSize.getHeight();
    
    if (isAnyValidated) {
      // Draw subtle horizontal line above footer
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.3);
      doc.line(15, pageHeight - 16, pageWidth - 15, pageHeight - 16);
      
      doc.setFontSize(7.5);
      doc.setTextColor(16, 185, 129); // emerald green
      doc.setFont('helvetica', 'bold');
      doc.text('VALIDADO PELA DGEP', 15, pageHeight - 11);
      
      const valDate = validatedAt ? new Date(validatedAt) : new Date();
      const approvedDateStr = format(valDate, 'dd/MM/yyyy');
      const approvedTimeStr = format(valDate, 'HH:mm:ss');
      const approvedByStr = validatedBy || 'DGEP';
      
      doc.setFontSize(7);
      doc.setTextColor(80, 80, 80);
      doc.setFont('helvetica', 'normal');
      doc.text(`Frequência validada pela DGEP - Diretoria de Gestão de Pessoas, em ${approvedDateStr} às ${approvedTimeStr} pelo usuário ${approvedByStr}.`, 15, pageHeight - 7);
    }

    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.setFont('helvetica', 'normal');
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - 15, pageHeight - 10, { align: 'right' });
  }

  return doc;
};

export const generateComissionadosFrequencyPDF = (
  records: any[], 
  month: number, 
  year: number,
  sector: string, 
  userName: string,
  userEmail: string
) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const nomeMes = format(new Date(year, month - 1, 1), 'MMMM', { locale: ptBR });

  // Title with line break as requested
  const titleLines = [
    'Formulário de Frequência de Servidores',
    'Ocupantes de Cargos de Provimento em Comissão'
  ];
  drawComissionadosHeader(doc, titleLines, 'DGEP - Diretoria de Gestão de Pessoas');
  
  let y = 42;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  
  // Find submitted signature info for initial text
  const initialSubmittedRecord = records.find(r => r.submittedAt);
  const initialSignatureEmail = initialSubmittedRecord?.submittedBy || userEmail;
  let initialSignatureName = initialSubmittedRecord?.submittedBy 
    ? getFullName('', initialSubmittedRecord.submittedBy)
    : userName;

  let initialSignatureNameUpper = initialSignatureName.trim().toUpperCase();
  if (initialSignatureNameUpper.startsWith("VER. ")) {
    initialSignatureNameUpper = initialSignatureNameUpper.replace("VER. ", "VER ");
  }
  if (initialSignatureNameUpper && !initialSignatureNameUpper.startsWith("VER ")) {
    initialSignatureNameUpper = "VER " + initialSignatureNameUpper;
  }
  
  // Custom initial text as requested
  const infoText = `À Diretoria de Gestão de Pessoas (DGEP),

Em cumprimento à Lei Municipal nº 16.546/2025, que dispõe sobre o controle de frequência de servidores em cargo de provimento em comissão, informamos a frequência relativa ao mês de ${nomeMes.toLowerCase()} de ${year}.

Responsável: ${initialSignatureNameUpper}`;

  const splitInfo = doc.splitTextToSize(infoText, pageWidth - 30);
  doc.text(splitInfo, 15, y);
  y += (splitInfo.length * 4.5) + 6;

  // Render Table Columns: Matrícula; Nome do Servidor; Lotação; Período; Presença; Faltas; Atest./Afast*; Férias
  const tableData = records.map(r => [
    r.matricula || '',
    r.internName.toUpperCase(),
    r.lotacao.toUpperCase(),
    r.details?.periodo || r.periodoOriginal || 'N/D',
    r.details?.presenca === 'integral' ? 'INTEGRAL' : 'PARCIAL',
    r.details?.datasFalta ? `${r.details.falta || '0'}\n(${r.details.datasFalta.toUpperCase()})` : (r.details?.falta || '0'),
    r.details?.datasAtestados ? `${r.details.atestados || '0'}\n(${r.details.datasAtestados.toUpperCase()})` : (r.details?.atestados || '0'),
    r.ferias || '—'
  ]);

  autoTable(doc, {
    startY: y,
    head: [['Matrícula', 'Nome do Servidor', 'Lotação', 'Período', 'Presença', 'Faltas', 'Atest./Afast*', 'Férias']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontSize: 6.5, fontStyle: 'bold', halign: 'center' },
    styles: { fontSize: 6, cellPadding: 1.8, halign: 'center' },
    columnStyles: {
      0: { halign: 'center', cellWidth: 15 },
      1: { halign: 'left', cellWidth: 38 },
      2: { halign: 'left', cellWidth: 30 },
      3: { halign: 'center', cellWidth: 28 },
      4: { halign: 'center', cellWidth: 16 },
      5: { halign: 'center', cellWidth: 16 },
      6: { halign: 'center', cellWidth: 20 },
      7: { halign: 'center', cellWidth: 17 }
    }
  });

  y = (doc as any).lastAutoTable.finalY + 8;

  // Add the italic footer warning as requested
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  const footerNote = "*Em caso de afastamento por motivos de saúde, superior a 3 dias, enviar o atestado à Saúde Ocupacional por meio de Comunicado específico do SPAE.";
  const splitFooter = doc.splitTextToSize(footerNote, pageWidth - 30);
  doc.text(splitFooter, 15, y);
  y += (splitFooter.length * 3.5) + 8;
  
  // Find submitted signature info
  const submittedRecord = records.find(r => r.submittedAt);
  const signatureDate = submittedRecord?.submittedAt || new Date().toISOString();
  const signatureEmail = submittedRecord?.submittedBy || userEmail;
  const signatureName = submittedRecord?.submittedBy 
    ? getFullName('', submittedRecord.submittedBy)
    : userName;

  if (signatureName && signatureEmail) {
    // pass true for isComissionados to prepend VER. to signature
    drawStandardSignature(doc, signatureName, signatureEmail, signatureDate, pageWidth / 2 - 30, y, true);
  }
  
  doc.setDrawColor(0, 0, 0);
  doc.line(pageWidth / 2 - 45, y + 16, pageWidth / 2 + 45, y + 16);
  
  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.text("Responsável pela Validação", pageWidth / 2, y + 20, { align: 'center' });

  // Detect validated status
  const isAnyValidated = records.some(r => r.status === 'validada' || r.validatedAt);
  const valRecord = records.find(r => r.validatedAt);
  const validatedAt = valRecord?.validatedAt || null;
  const validatedBy = valRecord?.validatedBy || null;

  const totalPages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    const pageHeight = doc.internal.pageSize.getHeight();
    
    if (isAnyValidated) {
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.3);
      doc.line(15, pageHeight - 16, pageWidth - 15, pageHeight - 16);
      
      doc.setFontSize(7.5);
      doc.setTextColor(16, 185, 129); // emerald green
      doc.setFont('helvetica', 'bold');
      doc.text('VALIDADO PELA DGEP', 15, pageHeight - 11);
      
      const valDate = validatedAt ? new Date(validatedAt) : new Date();
      const approvedDateStr = format(valDate, 'dd/MM/yyyy');
      const approvedTimeStr = format(valDate, 'HH:mm:ss');
      const approvedByStr = validatedBy || 'DGEP';
      
      doc.setFontSize(7);
      doc.setTextColor(80, 80, 80);
      doc.setFont('helvetica', 'normal');
      doc.text(`Frequência validada pela DGEP - Diretoria de Gestão de Pessoas, em ${approvedDateStr} às ${approvedTimeStr} pelo usuário ${approvedByStr}.`, 15, pageHeight - 7);
    }

    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.setFont('helvetica', 'normal');
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - 15, pageHeight - 10, { align: 'right' });
  }

  return doc;
};

// ==========================================
// COMISSIONADOS PDF GENERATOR FUNCTIONS
// ==========================================

export const generateComissionadoForm1 = (request: HiringRequest, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const details = request.comissionadoDetails || {} as any;
  const isBloco = !!details.isBloco;

  drawComissionadosHeader(doc, [
    isBloco ? 'INDICAÇÃO PARA NOMEAÇÃO EM BLOCO PARLAMENTAR' : 'INDICAÇÃO PARA NOMEAÇÃO EM CARGO EM COMISSÃO',
    'FORMULÁRIO 1'
  ], 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text("EXCELENTÍSSIMO SENHOR PRESIDENTE DA COMISSÃO EXECUTIVA", 15, y);
  y += 10;

  doc.setFont('helvetica', 'normal');
  const nominatorType = isBloco ? 'Líder do Bloco' : 'Vereador(a)';
  const nominatorName = request.supervisor?.name || '___________________________';
  const candidateName = request.student?.name || '___________________________';
  
  const text = `O (A) ${nominatorType} ${nominatorName.toUpperCase()} indica a pessoa abaixo identificada, qualificada conforme dados apontados no Formulário 2 (Dados cadastrais para nomeação em cargo em comissão), para exercer Cargo em Comissão da Estrutura de Apoio à Atividade Político Parlamentar desta Câmara Municipal.`;
  const splitText = doc.splitTextToSize(text, pageWidth - 30);
  doc.text(splitText, 15, y);
  y += (splitText.length * 5) + 10;

  const data = [
    ['NOME:', candidateName.toUpperCase()],
    ['LOTAÇÃO:', (request.sector || 'NÃO DEFINIDO').toUpperCase()],
    ['CARGO:', (details.cargo || 'NÃO DEFINIDO').toUpperCase()],
    ['SÍMBOLO: CC -', (details.simbolo || 'NÃO DEFINIDO').toUpperCase()],
    ['NOMEAR A PARTIR DE:', details.dataNomeacao ? format(new Date(details.dataNomeacao), 'dd/MM/yyyy') : '___/___/______']
  ];

  autoTable(doc, {
    startY: y,
    body: data,
    theme: 'grid',
    styles: { fontSize: 8.5, cellPadding: 3, textColor: [0, 0, 0] },
    columnStyles: { 0: { fontStyle: 'bold', cellWidth: 50, fillColor: [250, 250, 250] } },
    margin: { left: 15, right: 15 }
  });

  y = doc.lastAutoTable.finalY + 15;
  doc.setFontSize(9);
  doc.text(`Curitiba, ${format(new Date(request.createdAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}`, pageWidth - 15, y, { align: 'right' });
  y += 15;

  if (request.supervisor?.signature) {
    doc.addImage(request.supervisor.signature, 'PNG', pageWidth / 2 - 20, y, 40, 12);
  }
  y += 15;

  doc.setDrawColor(0, 0, 0);
  doc.line(pageWidth / 2 - 45, y, pageWidth / 2 + 45, y);
  y += 5;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text(`ASSINATURA DO(A) ${nominatorType.toUpperCase()}`, pageWidth / 2, y, { align: 'center' });

  if (!silent) {
    doc.save(`Formulario_1_Indicacao_${candidateName.replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

export const generateComissionadoForm2 = (request: HiringRequest, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const details = request.comissionadoDetails || {} as any;

  drawComissionadosHeader(doc, [
    'FICHA DE DADOS CADASTRAIS PARA NOMEAÇÃO',
    'FORMULÁRIO 2'
  ], 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  const data = [
    [{ content: 'DADOS PESSOAIS E CONTATO', colSpan: 2, styles: { fontStyle: 'bold', fillColor: [240, 240, 240] } }],
    ['Nome Completo:', (request.student?.name || '').toUpperCase()],
    ['CPF:', request.student?.cpf || ''],
    ['E-mail:', request.student?.email || ''],
    ['Telefone/Celular:', request.student?.phone || ''],
    ['Data de Nascimento:', request.student?.birthDate ? format(new Date(request.student.birthDate), 'dd/MM/yyyy') : ''],
    ['Estado Civil:', details.estadoCivil || ''],
    ['Nacionalidade / Naturalidade:', `${details.nacionalidade || ''} / ${details.naturalidade || ''}`],
    ['Documento de Identidade (RG):', `${details.rg || ''} (${details.rgEmissor || ''} - ${details.rgData || ''})`],
    [{ content: 'ENDEREÇO RESIDENCIAL', colSpan: 2, styles: { fontStyle: 'bold', fillColor: [240, 240, 240] } }],
    ['Logradouro e Número:', `${details.endereco || ''}, nº ${details.numero || ''}`],
    ['Bairro / CEP:', `${details.bairro || ''} - CEP: ${details.cep || ''}`],
    ['Cidade / UF:', `${details.cidade || ''} - ${details.uf || ''}`],
    [{ content: 'ESCOLARIDADE', colSpan: 2, styles: { fontStyle: 'bold', fillColor: [240, 240, 240] } }],
    ['Nível / Formação:', `${details.escolaridade || ''} - ${details.formacao || ''}`]
  ];

  autoTable(doc, {
    startY: y,
    body: data,
    theme: 'grid',
    styles: { fontSize: 8, cellPadding: 2, textColor: [0, 0, 0] },
    columnStyles: { 0: { fontStyle: 'bold', cellWidth: 50, fillColor: [250, 250, 250] } },
    margin: { left: 15, right: 15 }
  });

  y = doc.lastAutoTable.finalY + 10;
  if (request.student?.signature) {
    doc.addImage(request.student.signature, 'PNG', pageWidth / 2 - 20, y, 40, 12);
  }
  y += 15;

  doc.setDrawColor(0, 0, 0);
  doc.line(pageWidth / 2 - 45, y, pageWidth / 2 + 45, y);
  y += 5;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('ASSINATURA DO(A) NOMEADO(A)', pageWidth / 2, y, { align: 'center' });

  if (!silent) {
    doc.save(`Formulario_2_Cadastro_${(request.student?.name || 'Candidato').replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

export const generateComissionadoForm3 = (request: HiringRequest, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const details = request.comissionadoDetails || {} as any;
  const candidateName = (request.student?.name || '').toUpperCase();

  drawComissionadosHeader(doc, [
    'INFORMAÇÃO SOBRE VÍNCULO DE PARENTESCO',
    'FORMULÁRIO 3'
  ], 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('DECLARAÇÃO DE INEXISTÊNCIA / EXISTÊNCIA DE PARENTESCO', 15, y);
  y += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Eu, ${candidateName}, declaro para fins de nomeação em cargo em comissão que:`, 15, y);
  y += 10;

  if (!details.declarouParentesco) {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] NÃO POSSUO parentes que exerçam cargo de direção, chefia ou assessoramento, nem cônjuge, companheiro ou parente em linha reta, colateral ou por afinidade, até o terceiro grau, na Câmara Municipal de Curitiba.', 15, y, { maxWidth: pageWidth - 30 });
    y += 20;
  } else {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] POSSUO parentes com vínculo familiar na Câmara Municipal de Curitiba, conforme listado abaixo:', 15, y);
    y += 10;

    const parentesData = (details.parentesCMC || []).map((p: any) => [
      p.nome.toUpperCase(),
      p.cargo.toUpperCase(),
      p.parentesco.toUpperCase()
    ]);
    if (parentesData.length === 0) {
      parentesData.push(['-', '-', '-']);
    }

    autoTable(doc, {
      startY: y,
      head: [['Nome do Parente', 'Cargo/Função', 'Grau de Parentesco']],
      body: parentesData,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 2 },
      margin: { left: 15, right: 15 }
    });
    y = doc.lastAutoTable.finalY + 15;
  }

  // Draw the kinship legend as requested by user in request 9
  y += 5;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('LEGENDA DE GRAUS DE PARENTESCO:', 15, y);
  y += 5;

  autoTable(doc, {
    startY: y,
    head: [[{ content: 'PARENTES EM LINHA RETA', colSpan: 3, styles: { halign: 'center' } }]],
    body: [
      [{ content: 'Grau', styles: { fontStyle: 'bold' } }, { content: 'Consanguíneo', styles: { fontStyle: 'bold' } }, { content: 'Afinidade (vínculos atuais)', styles: { fontStyle: 'bold' } }],
      ['1º', 'Pai / Mãe / Filho / Filha', 'Sogro / Sogra, Genro / Nora, Madrasta / Padrasto, Enteado / Enteada'],
      ['2º', 'Avô / Avó / Neto / Neta', 'Avô / Avó, Neta / Neto do cônjuge ou companheiro'],
      ['3º', 'Bisavô / Bisavó', 'Bisavô / Bisavó, Bisneto / Bisneta do cônjuge ou companheiro']
    ],
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0] },
    styles: { fontSize: 6.5, cellPadding: 1.5, halign: 'center', textColor: [0, 0, 0] },
    margin: { left: 15, right: 15 }
  });

  y = doc.lastAutoTable.finalY + 5;

  autoTable(doc, {
    startY: y,
    head: [[{ content: 'PARENTES EM LINHA COLATERAL', colSpan: 3, styles: { halign: 'center' } }]],
    body: [
      [{ content: 'Grau', styles: { fontStyle: 'bold' } }, { content: 'Consanguíneo', styles: { fontStyle: 'bold' } }, { content: 'Afinidade (vínculos atuais)', styles: { fontStyle: 'bold' } }],
      ['1º', '-----------', '----------------------'],
      ['2º', 'Irmão / Irmã', 'Cunhado / Cunhada'],
      ['3º', 'Tio / Tia', 'Tio / Tia, Sobrinho / Sobrinha do cônjuge ou companheiro']
    ],
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0] },
    styles: { fontSize: 6.5, cellPadding: 1.5, halign: 'center', textColor: [0, 0, 0] },
    margin: { left: 15, right: 15 }
  });

  y = pageHeight - 55;
  if (request.student?.signature) {
    doc.addImage(request.student.signature, 'PNG', 25, y - 15, 40, 12);
  }
  doc.line(15, y, pageWidth / 2 - 10, y);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ASSINATURA DO DECLARANTE', (15 + (pageWidth / 2 - 10)) / 2, y + 5, { align: 'center' });

  if (request.supervisor?.signature) {
    doc.addImage(request.supervisor.signature, 'PNG', pageWidth / 2 + 25, y - 15, 40, 12);
  }
  doc.line(pageWidth / 2 + 10, y, pageWidth - 15, y);
  doc.text('ASSINATURA DO VEREADOR', (pageWidth / 2 + 10 + (pageWidth - 15)) / 2, y + 5, { align: 'center' });

  if (!silent) {
    doc.save(`Formulario_3_Parentesco_${(request.student?.name || 'Candidato').replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

export const generateComissionadoForm4 = (request: HiringRequest, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const details = request.comissionadoDetails || {} as any;
  const candidateName = (request.student?.name || '').toUpperCase();

  drawComissionadosHeader(doc, [
    'DECLARAÇÃO OUTRAS ATIVIDADES REMUNERADAS',
    'FORMULÁRIO 4'
  ], 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('DECLARAÇÃO DE ACÚMULO DE CARGOS / ATIVIDADES', 15, y);
  y += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Eu, ${candidateName}, declaro under as penas da lei que:`, 15, y);
  y += 10;

  if (details.possuiOutroCargo) {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] EXERÇO outra atividade remunerada conforme informações a seguir:', 15, y);
    y += 10;

    doc.setFont('helvetica', 'normal');
    doc.text(`Nome da entidade pública ou empresa: ${details.detalhesOutroCargo || ''}`, 15, y);
    y += 7;
    doc.text(`Endereço: Telefone: ${details.enderecoOutroCargo || ''}`, 15, y);
    y += 7;
    doc.text(`Cargo/ Função: ${details.cargoOutroCargo || ''}`, 15, y);
    y += 7;
    doc.text(`Horário de Trabalho: ${details.horarioOutroCargo || ''}`, 15, y);
    y += 15;
  } else {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] NÃO EXERÇO qualquer outro cargo, emprego ou função pública, nem atividade remunerada na iniciativa privada que seja incompatível com o horário de expediente desta Câmara Municipal.', 15, y, { maxWidth: pageWidth - 30 });
    y += 20;
  }

  y = pageHeight - 50;
  if (request.student?.signature) {
    doc.addImage(request.student.signature, 'PNG', pageWidth / 2 - 20, y - 15, 40, 12);
  }
  doc.line(pageWidth / 2 - 45, y, pageWidth / 2 + 45, y);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ASSINATURA DO DECLARANTE', pageWidth / 2, y + 5, { align: 'center' });

  if (!silent) {
    doc.save(`Formulario_4_Atividades_${(request.student?.name || 'Candidato').replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

export const generateComissionadoForm5 = (request: HiringRequest, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const details = request.comissionadoDetails || {} as any;
  const candidateName = (request.student?.name || '').toUpperCase();

  drawComissionadosHeader(doc, [
    'INFORMAÇÃO SOBRE DEPENDENTES E FAMÍLIA',
    'FORMULÁRIO 5'
  ], 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('DECLARAÇÃO PARA FINS DE IMPOSTO DE RENDA / CADASTRO', 15, y);
  y += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Eu, ${candidateName}, declaro para fins cadastrais que:`, 15, y);
  y += 10;

  if (!details.possuiDependentes) {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] NÃO POSSUO dependentes para fins tributários ou de cadastro de RH.', 15, y);
    y += 20;
  } else {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] DECLARO como meus dependentes legais as seguintes pessoas:', 15, y);
    y += 10;

    const dependentesData = (details.dependentes || []).map((dep: any) => [
      dep.codigo || '',
      dep.cpf || '',
      dep.nome.toUpperCase(),
      dep.dataNascimento ? format(new Date(dep.dataNascimento), 'dd/MM/yyyy') : ''
    ]);
    if (dependentesData.length === 0) {
      dependentesData.push(['-', '-', '-', '-']);
    }

    autoTable(doc, {
      startY: y,
      head: [['Código', 'CPF', 'Nome do Dependente', 'Data de Nascimento']],
      body: dependentesData,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 2 },
      margin: { left: 15, right: 15 }
    });
    y = doc.lastAutoTable.finalY + 15;
  }

  // Draw the codes table as requested by user in request 9
  y += 5;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('TABELA DE CÓDIGOS DE DEPENDENTES:', 15, y);
  y += 5;

  autoTable(doc, {
    startY: y,
    body: [
      ['01', 'Cônjuge/companheiro(a) com quem o contribuinte tenha filho ou viva há mais de 5 anos'],
      ['02', 'Filho(a) ou enteado(a) até 21 anos, ou de qualquer idade se incapacitado físico/mental para o trabalho'],
      ['03', 'Filho(a) ou enteado(a) universitário ou escola técnica de 2º grau, até 24 anos'],
      ['04', 'Irmão(ã), neto(a) ou bisneto(a) sem arrimo dos pais, de quem o contribuinte detenha a guarda judicial, até 21 anos'],
      ['09', 'Outros dependentes legais conforme regulamentação da Receita Federal']
    ],
    theme: 'grid',
    styles: { fontSize: 6.5, cellPadding: 1.5, textColor: [0, 0, 0] },
    columnStyles: { 0: { fontStyle: 'bold', cellWidth: 15, halign: 'center' } },
    margin: { left: 15, right: 15 }
  });

  y = pageHeight - 50;
  if (request.student?.signature) {
    doc.addImage(request.student.signature, 'PNG', pageWidth / 2 - 20, y - 15, 40, 12);
  }
  doc.line(pageWidth / 2 - 45, y, pageWidth / 2 + 45, y);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ASSINATURA DO DECLARANTE', pageWidth / 2, y + 5, { align: 'center' });

  if (!silent) {
    doc.save(`Formulario_5_Dependentes_${(request.student?.name || 'Candidato').replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

export const generateComissionadoForm6 = (request: HiringRequest, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const details = request.comissionadoDetails || {} as any;
  const candidateName = (request.student?.name || '').toUpperCase();

  drawComissionadosHeader(doc, [
    'DECLARAÇÃO DE INEXISTÊNCIA DE IMPEDIMENTO',
    'FORMULÁRIO 6'
  ], 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('DECLARAÇÃO DE IDONEIDADE E INEXISTÊNCIA DE IMPEDIMENTO LEGAL', 15, y);
  y += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Eu, ${candidateName}, declaro sob as penas da lei, para posse no cargo em comissão, que:`, 15, y);
  y += 10;

  if (details.declarouImpedimento) {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] DECLARO as seguintes ressalvas / processos pendentes:', 15, y);
    y += 10;
    doc.setFont('helvetica', 'normal');
    doc.text(details.detalhesImpedimento || '', 15, y, { maxWidth: pageWidth - 30 });
    y += 15;
  } else {
    doc.setFont('helvetica', 'bold');
    doc.text('[ X ] NÃO respondo a processo administrativo disciplinar, nem fui demitido do serviço público a bem do serviço público ou por justa causa nos últimos 5 anos, não possuindo outros impedimentos legais.', 15, y, { maxWidth: pageWidth - 30 });
    y += 20;
  }

  y = pageHeight - 50;
  if (request.student?.signature) {
    doc.addImage(request.student.signature, 'PNG', pageWidth / 2 - 20, y - 15, 40, 12);
  }
  doc.line(pageWidth / 2 - 45, y, pageWidth / 2 + 45, y);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ASSINATURA DO DECLARANTE', pageWidth / 2, y + 5, { align: 'center' });

  if (!silent) {
    doc.save(`Formulario_6_Impedimento_${(request.student?.name || 'Candidato').replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

export const generateCaixaDeclaration = (request: HiringRequest, dgepManagerName?: string, dgepManagerEmail?: string, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const details = request.comissionadoDetails || {} as any;
  const candidateName = (request.student?.name || '').toUpperCase();

  drawHeader(doc, 'DECLARAÇÃO PARA ABERTURA DE CONTA BANCÁRIA', 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);

  const symbolFormatted = details.simbolo ? (details.simbolo.startsWith('CC') ? details.simbolo : `CC-${details.simbolo}`) : '___';
  const text = `Declaramos para os devidos fins, junto à Caixa Econômica Federal, que o(a) senhor(a) ${candidateName}, portador(a) do CPF nº ${request.student?.cpf || '___________'}, foi nomeado(a) para exercer o Cargo em Comissão de ${details.cargo || '___________'} (símbolo ${symbolFormatted}) no setor ${request.sector.toUpperCase()}, a partir de ${details.dataNomeacao ? format(new Date(details.dataNomeacao), 'dd/MM/yyyy') : '___/___/______'}.\n\nSolicitamos a abertura de conta corrente para fins de crédito de folha de pagamento.`;
  const splitText = doc.splitTextToSize(text, pageWidth - 30);
  doc.text(splitText, 15, y);
  y += (splitText.length * 6) + 15;

  doc.text(`Curitiba, ${format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}`, pageWidth - 15, y, { align: 'right' });
  y += 20;

  if (details.caixaAssinadoDGEP && details.caixaAssinadoPor) {
    const signedAt = details.caixaAssinadoEm || new Date().toISOString();
    drawStandardSignature(doc, details.caixaAssinadoPor.toUpperCase(), details.caixaAssinadoPor, signedAt, pageWidth / 2 - 30, y);
  }
  y += 15;

  doc.line(pageWidth / 2 - 45, y, pageWidth / 2 + 45, y);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('DIRETORIA DE GESTÃO DE PESSOAS - DGEP', pageWidth / 2, y + 5, { align: 'center' });

  if (!silent) {
    doc.save(`Declaracao_Abertura_Conta_Caixa_${candidateName.replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

export const generateComissionadoExoneration = (request: HiringRequest, supervisorName?: string, supervisorEmail?: string, silent = false) => {
  const doc = new jsPDF({ compress: true }) as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const details = request.comissionadoDetails || {} as any;
  const candidateName = (request.student?.name || '').toUpperCase();

  drawComissionadosHeader(doc, [
    'INDICAÇÃO PARA EXONERAÇÃO DE CARGO EM COMISSÃO',
    'FORMULÁRIO DE EXONERAÇÃO'
  ], 'DGEP - Diretoria de Gestão de Pessoas');

  let y = 45;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('EXCELENTÍSSIMO SENHOR PRESIDENTE DA CÂMARA MUNICIPAL DE CURITIBA', 15, y);
  y += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);

  const symbolFormatted = details.simbolo ? (details.simbolo.startsWith('CC') ? details.simbolo : `CC-${details.simbolo}`) : '___';
  const text = `Solicitamos a exoneração do(a) servidor(a) ${candidateName}, portador(a) do CPF nº ${request.student?.cpf || '___________'}, do Cargo em Comissão de ${details.cargo || '___________'} (símbolo ${symbolFormatted}) da lotação do setor ${request.sector.toUpperCase()}, a partir de ${request.startDate ? format(new Date(request.startDate), 'dd/MM/yyyy') : '___/___/______'}.`;
  const splitText = doc.splitTextToSize(text, pageWidth - 30);
  doc.text(splitText, 15, y);
  y += (splitText.length * 6) + 15;

  doc.text(`Curitiba, ${format(new Date(request.createdAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}`, pageWidth - 15, y, { align: 'right' });
  y += 15;

  if (request.supervisor?.signature) {
    doc.addImage(request.supervisor.signature, 'PNG', pageWidth / 2 - 20, y, 40, 12);
  }
  y += 15;

  doc.line(pageWidth / 2 - 45, y, pageWidth / 2 + 45, y);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ASSINATURA DO VEREADOR / GESTOR', pageWidth / 2, y + 5, { align: 'center' });

  if (!silent) {
    doc.save(`Formulario_Exoneracao_${candidateName.replace(/\s+/g, '_')}.pdf`);
  }
  return doc;
};

