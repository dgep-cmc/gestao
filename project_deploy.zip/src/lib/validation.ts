// Deployment trigger - 2026-05-15
export function validateCPF(cpf: string): boolean {
  // Remove non-digits
  const cleanCPF = cpf.replace(/\D/g, '');

  // Must have 11 digits
  if (cleanCPF.length !== 11) return false;

  // Check for repeated digits (e.g. 111.111.111-11)
  if (/^(\d)\1+$/.test(cleanCPF)) return false;

  // Validation logic based on provided algorithm
  let sum1 = 0;
  for (let i = 0; i < 9; i++) {
    sum1 += parseInt(cleanCPF.charAt(i)) * (10 - i);
  }
  let rest1 = (sum1 * 10) % 11;
  if (rest1 === 10) rest1 = 0;

  let sum2 = 0;
  for (let i = 0; i < 10; i++) {
    sum2 += parseInt(cleanCPF.charAt(i)) * (11 - i);
  }
  let rest2 = (sum2 * 10) % 11;
  if (rest2 === 10) rest2 = 0;

  return rest1 === parseInt(cleanCPF.charAt(9)) && rest2 === parseInt(cleanCPF.charAt(10));
}

export function formatCPF(value: string): string {
  const clean = value.replace(/\D/g, '').slice(0, 11);
  return clean
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
}

export function formatPhone(value: string): string {
  const clean = value.replace(/\D/g, '').slice(0, 11);
  
  if (clean.length <= 10) {
    return clean
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{4})(\d{1,4})$/, '$1-$2');
  }
  
  return clean
    .replace(/(\d{2})(\d)/, '($1) $2')
    .replace(/(\d{5})(\d{1,4})$/, '$1-$2');
}
