// Deployment trigger - 2026-05-15
export type UserRole = 'master' | 'manager';

export interface UserProfile {
  uid: string; // The document ID, which will now be the email
  email: string;
  name?: string;
  role: UserRole;
  sectors?: string[]; // Multiple sectors
  active?: boolean;
  allowedModules?: ('frequency' | 'hiring' | 'frequency_comissionados' | 'hiring_comissionados')[];
  cpf?: string;
  phone?: string;
}

export type FrequencyStatus = 'pending' | 'submitted' | 'validada' | 'devolvida';

export interface FrequencyDetails {
  periodo: string;
  startDate?: string;
  endDate?: string;
  presenca: 'integral' | 'parcial';
  falta: string;
  atestados: string;
  recesso: string;
  atestadoFiles?: string[]; // Storage download URLs
  atestadoFilesNames?: string[]; // Original names
  datasJustificadas?: string; // Dates of absences, certificates, or recess
  datasFalta?: string;
  datasAtestados?: string;
  datasRecesso?: string;
}

export interface FrequencyRecord {
  id: string;
  internName: string;
  lotacao: string;
  responsavel: string;
  month: number;
  year: number;
  periodoOriginal: string;
  recessoOriginal: string;
  status: FrequencyStatus;
  matricula?: string;
  cargo?: string;
  details: FrequencyDetails | null;
  submittedAt: string | null;
  submittedBy: string | null;
  returnReason?: string;
  categoria?: 'Ensino Médio' | 'Ensino Superior' | 'Pós Graduação';
  validatedAt?: string | null;
  validatedBy?: string | null;
}

export interface Intern {
  matricula: string;
  internName: string;
  lotacao: string;
  categoria: 'Ensino Médio' | 'Ensino Superior' | 'Pós Graduação';
  dataAdmissao: string; // DD/MM/YYYY
  dataRescisao: string;  // DD/MM/YYYY or empty
  recessoOriginal?: string;
}

export interface GeneratedDocument {
  id?: string;
  fileName: string;
  lotacao: string;
  month: number;
  year: number;
  generatedBy: string;
  timestamp: string;
  pdfUrl: string;
  recordIds?: string[];
}

export type HiringStatus = 'draft' | 'pending' | 'supervisor_signed' | 'student_signed' | 'submitted' | 'approved' | 'rejected' | 'archived';

export interface HiringRequest {
  id: string;
  type: 'hiring' | 'opening' | 'resignation';
  sector: string;
  level: 'Ensino Médio' | 'Técnico' | 'Superior' | 'Pós Graduação';
  course: string;
  activities: string;
  startDate: string;
  startTime: string;
  endTime: string;
  period: 'Manhã' | 'Tarde' | 'Noite';
  
  supervisor: {
    name: string;
    role: string;
    rg: string;
    cpf: string;
    email: string;
    phone: string;
    education: string;
    course?: string;
    experience: string;
    signature?: string; // Base64 image
    signedAt?: string;
  };

  student?: {
    name: string;
    birthDate?: string;
    cpf: string;
    email: string;
    phone: string;
    isMandatory?: boolean;
    signature?: string; // Base64 image
    signedAt?: string;
  };

  category?: 'estagiario' | 'comissionado';
  comissionadoDetails?: any;

  documents?: {
    rg?: { fileId: string; name: string } | null;
    cpf?: { fileId: string; name: string } | null;
    photo?: { fileId: string; name: string } | null;
    bank?: { fileId: string; name: string } | null;
    address?: { fileId: string; name: string } | null;
    enrollment?: { fileId: string; name: string } | null;
    parent?: { fileId: string; name: string } | null;
    requerimento?: { fileId: string; name: string } | null;
    parentesco?: { fileId: string; name: string } | null;
    form1?: { fileId: string; name: string } | null;
    form2?: { fileId: string; name: string } | null;
    form3?: { fileId: string; name: string } | null;
    form4?: { fileId: string; name: string } | null;
    form5?: { fileId: string; name: string } | null;
    form6?: { fileId: string; name: string } | null;
    declaracaoCaixa?: { fileId: string; name: string } | null;
    exoneracao?: { fileId: string; name: string } | null;
  };

  status: HiringStatus;
  previousStatus?: HiringStatus;
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectReason?: string;
  rejectedBy?: string;
  rejectedAt?: string;
}
