// Deployment trigger - 2026-05-15
import React, { Component, ErrorInfo, ReactNode, StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; error: Error | null; errorInfo: ErrorInfo | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
    this.setState({ errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif', color: '#721c24', background: '#f8d7da', minHeight: '100vh', wordBreak: 'break-word' }}>
          <h2>Erro de Inicialização (React Error Boundary)</h2>
          <p>A aplicação não pôde ser iniciada devido a um erro no código.</p>
          <pre style={{ background: 'rgba(0,0,0,0.1)', padding: '10px', borderRadius: '4px', whiteSpace: 'pre-wrap' }}>
            {this.state.error?.toString()}
          </pre>
          <details style={{ whiteSpace: 'pre-wrap', marginTop: '10px' }}>
            {this.state.errorInfo?.componentStack}
          </details>
        </div>
      );
    }
    return this.props.children;
  }
}

const root = document.getElementById('root')!;

createRoot(root).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
