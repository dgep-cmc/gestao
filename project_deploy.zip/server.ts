import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import crypto from "crypto";
import http from "http";
import cors from "cors";

dotenv.config();

// Memory caches to prevent concurrent duplicate folder creations on Google Drive
const serverFolderIdCache: Record<string, string> = {};
const serverPendingFolderPromises: Record<string, Promise<string>> = {};

function cleanFolderId(rawId: string): string {
  if (!rawId) return '1Zy5pLVCQ18JIQGLNeRl35Sx2a0ntbKJx';
  let id = rawId.trim();
  
  if (id.includes('drive.google.com') || id.includes('/folders/')) {
    const match = id.match(/\/folders\/([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
      id = match[1];
    }
  }
  
  const queryIndex = id.indexOf('?');
  if (queryIndex !== -1) {
    id = id.substring(0, queryIndex);
  }
  
  id = id.replace(/[./\s]+$/, '').replace(/^[./\s]+/, '');
  
  if (!id || id === '.' || id.length < 5) {
    return '1Zy5pLVCQ18JIQGLNeRl35Sx2a0ntbKJx';
  }
  
  return id;
}

const WORKSPACE_ROOT_FOLDER_ID = cleanFolderId(process.env.VITE_GOOGLE_DRIVE_FOLDER_ID || '1Zy5pLVCQ18JIQGLNeRl35Sx2a0ntbKJx');

function cleanPrivateKey(key: string): string {
  if (!key) return '';
  let cleaned = key.trim();
  
  // Strip any leading/trailing quotes (single or double) that can be introduced by environment configuration
  cleaned = cleaned.replace(/^["']|["']$/g, '');

  // If the key is a JSON string or JSON-wrapped, let's parse it to get the raw private_key value
  if (cleaned.startsWith('{') || cleaned.startsWith('"')) {
    try {
      let rawJson = cleaned;
      if (rawJson.startsWith('"') && rawJson.endsWith('"')) {
        rawJson = JSON.parse(rawJson);
      }
      const parsed = JSON.parse(rawJson);
      if (parsed && typeof parsed === 'object') {
        if (parsed.private_key) {
          cleaned = parsed.private_key;
        } else if (parsed.VITE_GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY) {
          cleaned = parsed.VITE_GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY;
        }
      }
    } catch (err) {
      // ignore
    }
  }

  // Check if the entire string is base64 encoded (often used to bypass multiline environment variables)
  if (!cleaned.includes('-----BEGIN') && /^[a-zA-Z0-9+/=\s]+$/.test(cleaned) && cleaned.length > 100) {
    try {
      const decoded = Buffer.from(cleaned.replace(/\s/g, ''), 'base64').toString('utf8');
      if (decoded.includes('-----BEGIN')) {
        cleaned = decoded;
      } else {
        // If it's raw base64 data without PEM headers, keep it so we can wrap it below
      }
    } catch (err) {
      // Attempt failed, keep original cleaned key
    }
  }

  // Replace double escaped newlines or literal \n strings (common in .env configuration parsing)
  cleaned = cleaned.replace(/\\n/g, '\n');
  cleaned = cleaned.replace(/\\r/g, '\r');

  // Support any PEM header (e.g. -----BEGIN PRIVATE KEY----- or -----BEGIN RSA PRIVATE KEY-----)
  const startMatch = cleaned.match(/-----BEGIN [A-Z ]*PRIVATE KEY-----/);
  const endMatch = cleaned.match(/-----END [A-Z ]*PRIVATE KEY-----/);
  if (startMatch && endMatch) {
    const startHeader = startMatch[0];
    const endHeader = endMatch[0];
    let body = cleaned
      .replace(startHeader, '')
      .replace(endHeader, '')
      .replace(/\s+/g, ''); // strip all internal whitespace, newlines, or spaces
    
    // Chunk into standard 64-character lines
    const lines: string[] = [];
    lines.push(startHeader);
    for (let i = 0; i < body.length; i += 64) {
      lines.push(body.substring(i, i + 64));
    }
    lines.push(endHeader);
    cleaned = lines.join('\n');
  } else if (!cleaned.includes('-----BEGIN') && /^[a-zA-Z0-9+/=\s]+$/.test(cleaned) && cleaned.length > 50) {
    // If it's pure base64 data without headers, chunk it and wrap it in standard Private Key PEM headers
    let body = cleaned.replace(/\s+/g, '');
    const lines: string[] = [];
    lines.push('-----BEGIN PRIVATE KEY-----');
    for (let i = 0; i < body.length; i += 64) {
      lines.push(body.substring(i, i + 64));
    }
    lines.push('-----END PRIVATE KEY-----');
    cleaned = lines.join('\n');
  }

  return cleaned.trim();
}

function signJwtRS256(payload: object, privateKeyPem: string, clientEmail: string): string {
  const header = { alg: 'RS256', typ: 'JWT' };
  
  const base64UrlEncode = (str: string | Buffer): string => {
    const buf = Buffer.isBuffer(str) ? str : Buffer.from(str);
    return buf.toString('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(payload));
  const signingInput = `${encodedHeader}.${encodedPayload}`;

  const sign = crypto.createSign('SHA256');
  sign.update(signingInput);
  
  const formattedKey = cleanPrivateKey(privateKeyPem);
  
  try {
    const signature = sign.sign(formattedKey);
    return `${signingInput}.${base64UrlEncode(signature)}`;
  } catch (err: any) {
    console.error('--- PRIVATE KEY SIGNING DIAGNOSTICS ---');
    console.error('Error message:', err.message);
    console.error('Raw key input length:', privateKeyPem ? privateKeyPem.length : 0);
    console.error('Raw key input starts with:', privateKeyPem ? privateKeyPem.substring(0, 40) : 'N/A');
    console.error('Raw key input ends with:', privateKeyPem ? privateKeyPem.substring(Math.max(0, privateKeyPem.length - 40)) : 'N/A');
    console.error('Formatted key length:', formattedKey ? formattedKey.length : 0);
    console.error('Formatted key starts with:', formattedKey ? formattedKey.substring(0, 45) : 'N/A');
    console.error('Formatted key ends with:', formattedKey ? formattedKey.substring(Math.max(0, formattedKey.length - 45)) : 'N/A');
    console.error('Does formatted key contain newlines:', formattedKey ? formattedKey.includes('\n') : false);
    console.error('--------------------------------------');
    throw new Error(`Falha ao assinar JWT com a chave privada fornecida: ${err.message}. Verifique os logs para detalhes de diagnóstico.`);
  }
}

async function getServiceAccountAccessToken(): Promise<string> {
  const privateKey = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY || '';
  const email = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_EMAIL || '';

  if (!privateKey || !email) {
    throw new Error('As credenciais da Conta de Serviço Google Drive não estão configuradas nas variáveis do sistema.');
  }

  const now = Math.floor(Date.now() / 1000);
  const payload = {
    iss: email,
    scope: 'https://www.googleapis.com/auth/drive',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };

  const jwt = signJwtRS256(payload, privateKey, email);

  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: jwt,
    }),
  });

  if (!res.ok) {
    throw new Error(`Google Authentication failed: ${await res.text()}`);
  }

  const data = await res.json() as any;
  return data.access_token;
}

async function findFolder(token: string, name: string, parentId?: string): Promise<string | null> {
  try {
    let query = `mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
    if (parentId) {
      query += ` and '${parentId}' in parents`;
    } else {
      query += ` and 'root' in parents`;
    }

    const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name)&pageSize=1000&supportsAllDrives=true&includeItemsFromAllDrives=true`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      console.error('Error finding folder on Drive:', await res.text());
      return null;
    }

    const data = await res.json() as any;
    if (data.files && data.files.length > 0) {
      const targetNormalized = name.normalize('NFC').trim().toUpperCase();
      for (const file of data.files) {
        const fileNormalized = file.name.normalize('NFC').trim().toUpperCase();
        if (fileNormalized === targetNormalized) {
          return file.id;
        }
      }
    }
    return null;
  } catch (err) {
    console.error('findFolder exception:', err);
    return null;
  }
}

async function createFolder(token: string, name: string, parentId?: string): Promise<string> {
  try {
    const body = {
      name: name.normalize('NFC'),
      mimeType: 'application/vnd.google-apps.folder',
      parents: parentId ? [parentId] : undefined,
    };

    const res = await fetch('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      throw new Error(`Erro ao criar pasta no Drive: ${await res.text()}`);
    }

    const data = await res.json() as any;
    return data.id;
  } catch (err) {
    console.error('createFolder exception:', err);
    throw err;
  }
}

async function getOrCreateFolder(token: string, name: string, parentId?: string): Promise<string> {
  const parentKey = parentId || 'root';
  const cleanName = name.normalize('NFC').trim().toUpperCase();
  const cacheKey = `${parentKey}_${cleanName}`;

  if (serverFolderIdCache[cacheKey]) {
    return serverFolderIdCache[cacheKey];
  }

  if (!serverPendingFolderPromises[cacheKey]) {
    serverPendingFolderPromises[cacheKey] = (async () => {
      const existingId = await findFolder(token, name, parentId);
      if (existingId) {
        serverFolderIdCache[cacheKey] = existingId;
        return existingId;
      }
      const createdId = await createFolder(token, name, parentId);
      serverFolderIdCache[cacheKey] = createdId;
      return createdId;
    })();
  }

  try {
    return await serverPendingFolderPromises[cacheKey];
  } finally {
    delete serverPendingFolderPromises[cacheKey];
  }
}

async function findFolderBySubstring(token: string, substring: string, parentId: string): Promise<{ id: string; name: string } | null> {
  try {
    const query = `mimeType = 'application/vnd.google-apps.folder' and trashed = false and '${parentId}' in parents`;
    const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name)&pageSize=1000&supportsAllDrives=true&includeItemsFromAllDrives=true`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      console.error('Error finding folder by substring on Drive:', await res.text());
      return null;
    }

    const data = await res.json() as any;
    if (data.files && data.files.length > 0) {
      const targetSubNormalized = substring.normalize('NFC').trim().toUpperCase();
      for (const file of data.files) {
        const fileNormalized = file.name.normalize('NFC').trim().toUpperCase();
        if (fileNormalized.includes(targetSubNormalized)) {
          return { id: file.id, name: file.name };
        }
      }
    }
    return null;
  } catch (err) {
    console.error('findFolderBySubstring exception:', err);
    return null;
  }
}

async function renameFileOrFolder(token: string, fileId: string, newName: string): Promise<boolean> {
  try {
    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?supportsAllDrives=true`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name: newName }),
    });

    if (!res.ok) {
      console.error('Google Drive rename failed:', await res.text());
      return false;
    }
    return true;
  } catch (err) {
    console.error('renameFileOrFolder exception:', err);
    return false;
  }
}

async function uploadFile(token: string, fileBuffer: Buffer, name: string, fileType: string, parentFolderId: string): Promise<{ id: string; webViewLink: string }> {
  try {
    const boundary = 'custom_boundary_drive_upload';
    const delimiter = `\r\n--${boundary}\r\n`;

    const metadata = {
      name,
      parents: [parentFolderId],
    };

    const metadataPart = `${delimiter}Content-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n`;
    const mediaPartHeader = `${delimiter}Content-Type: ${fileType || 'application/octet-stream'}\r\n\r\n`;
    const mediaPartFooter = `\r\n--${boundary}--`;

    const encoder = new TextEncoder();
    const part1 = encoder.encode(metadataPart);
    const part2 = encoder.encode(mediaPartHeader);
    const part3 = encoder.encode(mediaPartFooter);

    const finalBuffer = Buffer.concat([
      part1,
      part2,
      fileBuffer,
      part3
    ]);

    const url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink&supportsAllDrives=true';
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: finalBuffer,
    });

    if (!res.ok) {
      throw new Error(`Google Drive upload failed: ${await res.text()}`);
    }

    return await res.json() as any;
  } catch (err) {
    console.error('uploadFile to Drive exception:', err);
    throw err;
  }
}

async function resolveTargetFolder(token: string, context: any): Promise<string> {
  const rootId = WORKSPACE_ROOT_FOLDER_ID;
  const sgestaoId = await getOrCreateFolder(token, 'Sistema de Gestão de Pessoas', rootId);

  if (context.module === 'frequency') {
    // Interns frequency
    const estagiariosId = await getOrCreateFolder(token, 'Estagiários', sgestaoId);
    const freqId = await getOrCreateFolder(token, 'Frequências', estagiariosId);
    const monthYear = (context.monthYear || new Date().toISOString().substring(0, 7)).trim();
    const monthYearId = await getOrCreateFolder(token, monthYear, freqId);
    const lotacao = (context.lotacao || 'Não Categorizado').trim();
    return await getOrCreateFolder(token, lotacao, monthYearId);
  } else if (context.module === 'frequency_comissionados') {
    // Comissionados frequency
    const comissionadosId = await getOrCreateFolder(token, 'Comissionados', sgestaoId);
    const freqId = await getOrCreateFolder(token, 'Frequências', comissionadosId);
    const monthYear = (context.monthYear || new Date().toISOString().substring(0, 7)).trim();
    const monthYearId = await getOrCreateFolder(token, monthYear, freqId);
    
    // Subpasta com o nome do gestor / vereador
    const lotacaoUpper = (context.lotacao || '').trim().toUpperCase();
    if (lotacaoUpper === 'GABINETE DA PRESIDÊNCIA') {
      return await getOrCreateFolder(token, 'GABINETE DA PRESIDÊNCIA', monthYearId);
    }

    let gestorName = (context.userName || context.lotacao || 'Não Categorizado').trim().toUpperCase();
    gestorName = gestorName.replace(/^(VER\.|VER|VEREADOR\.|VEREADOR)\s+/, '');
    gestorName = `VER. ${gestorName}`;
    return await getOrCreateFolder(token, gestorName, monthYearId);
  } else {
    // Hiring / Contratações (intern or comissionado)
    const isComissionado = context.category === 'comissionado';
    
    if (isComissionado) {
      // 4. Comissionados Hiring
      const comissionadosId = await getOrCreateFolder(token, 'Comissionados', sgestaoId);
      const hiringId = await getOrCreateFolder(token, 'Contratações', comissionadosId);
      
      // Ver. Nome do Vereador (folder name)
      let vereadorName = (context.userName || context.lotacao || 'Não Categorizado').trim();
      const vereadorNameUpper = vereadorName.toUpperCase();
      if (vereadorNameUpper === 'GABINETE DA PRESIDÊNCIA' || vereadorNameUpper === 'PRESIDÊNCIA') {
        vereadorName = 'Gabinete da Presidência';
      } else {
        vereadorName = vereadorName.replace(/^(VER\.|VER|VEREADOR\.|VEREADOR)\s+/i, '');
        vereadorName = `Ver. ${vereadorName}`;
      }
      const vereadorId = await getOrCreateFolder(token, vereadorName, hiringId);
      
      // Nome do Servidor
      let servidorName = 'Não Categorizado';
      if (context.requestNameAndId) {
        const parts = context.requestNameAndId.split('_');
        if (parts.length > 1) {
          parts.pop(); // remove id
          servidorName = parts.join(' ');
        } else {
          servidorName = context.requestNameAndId;
        }
      }
      return await getOrCreateFolder(token, servidorName, vereadorId);
    } else {
      // 3. Interns Hiring
      const estagiariosId = await getOrCreateFolder(token, 'Estagiários', sgestaoId);
      const hiringId = await getOrCreateFolder(token, 'Contratações', estagiariosId);
      const lotacao = context.lotacao || 'Não Categorizado';
      const lotacaoId = await getOrCreateFolder(token, lotacao, hiringId);
      
      // Nome do Estagiário
      let estagiarioName = 'Não Categorizado';
      if (context.requestNameAndId) {
        const parts = context.requestNameAndId.split('_');
        if (parts.length > 1) {
          parts.pop(); // remove id
          estagiarioName = parts.join(' ');
        } else {
          estagiarioName = context.requestNameAndId;
        }
      }
      return await getOrCreateFolder(token, estagiarioName, lotacaoId);
    }
  }
}

function extractDriveFileId(url: string | null | undefined): string | null {
  if (!url) return null;
  const match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (match && match[1]) return match[1];
  
  const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (idMatch && idMatch[1]) return idMatch[1];

  try {
    const cleanUrl = url.split('?')[0].split('#')[0];
    const segments = cleanUrl.split('/');
    for (const seg of segments) {
      if (seg.length >= 25 && seg.length <= 50 && /^[a-zA-Z0-9_-]+$/.test(seg)) {
        if (seg.toLowerCase() !== 'drive' && seg.toLowerCase() !== 'docs' && seg.toLowerCase() !== 'google') {
          return seg;
        }
      }
    }
  } catch (e) {
    // ignore
  }
  return null;
}

async function updateFileContent(fileIdOrUrl: string, fileBuffer: Buffer, fileType: string): Promise<boolean> {
  try {
    const fileId = fileIdOrUrl.includes('/') ? extractDriveFileId(fileIdOrUrl) : fileIdOrUrl;
    if (!fileId) {
      console.warn('Could not extract file ID for update:', fileIdOrUrl);
      return false;
    }
    const token = await getServiceAccountAccessToken();

    try {
      const untrashUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?supportsAllDrives=true`;
      await fetch(untrashUrl, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ trashed: false }),
      });
    } catch (untrashErr) {
      console.warn('Attempt to untrash file before content update failed, proceeding anyway:', untrashErr);
    }

    const url = `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media&supportsAllDrives=true`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': fileType || 'application/pdf',
      },
      body: fileBuffer,
    });

    if (!res.ok) {
      console.error('Google Drive patch content failed:', await res.text());
      return false;
    }
    return true;
  } catch (err) {
    console.error('updateFileContent exception:', err);
    return false;
  }
}

async function deleteFile(fileIdOrUrl: string): Promise<boolean> {
  try {
    const fileId = fileIdOrUrl.includes('/') ? extractDriveFileId(fileIdOrUrl) : fileIdOrUrl;
    if (!fileId) {
      console.warn('Could not extract file ID for deletion:', fileIdOrUrl);
      return false;
    }
    const token = await getServiceAccountAccessToken();

    try {
      const patchUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?supportsAllDrives=true`;
      const patchRes = await fetch(patchUrl, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ trashed: true }),
      });

      if (patchRes.ok) {
        console.log(`Documento do Google Drive (ID: ${fileId}) movido para a lixeira com sucesso.`);
        return true;
      }

      const errText = await patchRes.text();
      if (patchRes.status === 404) {
        console.warn(`Google Drive move to trash: File not found or already deleted (404) for ID ${fileId}. Consolidating deletion as completed.`);
        return true;
      }
      console.warn(`Tentativa de mover para a lixeira falhou, partindo para exclusão permanente... Erro:`, errText);
    } catch (trashErr) {
      console.warn(`Erro ao mover para a lixeira, partindo para exclusão permanente:`, trashErr);
    }

    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?supportsAllDrives=true`;
    const res = await fetch(url, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!res.ok) {
      const errText = await res.text();
      if (res.status === 404) {
        console.warn(`Google Drive delete file: File not found or already deleted (404) for ID ${fileId}. Consolidating deletion as completed.`);
        return true;
      }
      console.error('Google Drive permanent delete file failed:', errText);
      return false;
    }
    return true;
  } catch (err) {
    console.error('deleteFile exception:', err);
    return false;
  }
}

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const httpServer = http.createServer(app);

  // Use increased limit for JSON requests to handle Base64 file uploads seamlessly
  app.use(express.json({ limit: "50mb" }));

  // CORS Middleware to allow static frontend deployments (e.g. GitHub Pages) to access these APIs
  app.use(cors());

  // Simple Ping/Health route for status checking and self-ping keep-awake
  app.get("/api/ping", (req, res) => {
    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      timezone: "America/Sao_Paulo",
      localTime: new Date().toLocaleTimeString("en-US", { timeZone: "America/Sao_Paulo" })
    });
  });

  // API Route for Google Drive Uploads
  app.post("/api/drive/upload", async (req, res) => {
    try {
      const { fileBase64, fileName, fileType, context } = req.body;
      if (!fileBase64 || !fileName || !context) {
        return res.status(400).send("Faltam parâmetros obrigatórios para o upload (fileBase64, fileName ou context).");
      }

      // Convert Base64 back to Buffer
      const fileBuffer = Buffer.from(fileBase64, "base64");

      // Obtain service account access token securely server-side
      const token = await getServiceAccountAccessToken();

      // Resolve the target directory structure
      const folderId = await resolveTargetFolder(token, context);

      // Upload file directly to resolved directory
      const result = await uploadFile(token, fileBuffer, fileName, fileType, folderId);

      return res.json(result);
    } catch (error: any) {
      console.error("API /api/drive/upload error:", error);
      return res.status(500).send(error.message || "Erro interno ao realizar upload para o Google Drive.");
    }
  });

  // API Route for Downloading Google Drive Files
  app.get("/api/drive/download", async (req, res) => {
    try {
      const fileId = req.query.fileId as string;
      if (!fileId) {
        return res.status(400).send("Falta o parâmetro fileId.");
      }

      // Obtain service account access token securely server-side
      const token = await getServiceAccountAccessToken();

      const url = `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?alt=media`;
      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      if (!response.ok) {
        const text = await response.text();
        return res.status(response.status).send(`Erro ao baixar arquivo do Drive: ${text}`);
      }

      const contentType = response.headers.get("content-type") || "application/octet-stream";
      res.setHeader("Content-Type", contentType);

      const arrayBuffer = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      return res.send(buffer);
    } catch (error: any) {
      console.error("API /api/drive/download error:", error);
      return res.status(500).send(error.message || "Erro interno ao baixar arquivo do Google Drive.");
    }
  });

  // API Route for Google Drive Diagnostics Check
  app.get("/api/drive/diagnostics", async (req, res) => {
    try {
      const privateKey = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY || '';
      const email = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_EMAIL || '';
      const rootId = WORKSPACE_ROOT_FOLDER_ID;

      const results: any = {
        credentials: {
          privateKeyPresent: !!privateKey,
          privateKeyLength: privateKey.length,
          serviceAccountEmail: email,
          rootFolderId: rootId,
        },
        steps: {}
      };

      if (!privateKey || !email) {
        results.steps.auth = {
          success: false,
          error: "Credenciais de conta de serviço Google Drive ausentes (VITE_GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY ou EMAIL no arquivo .env)"
        };
        return res.json(results);
      }

      // Step 1: Authentication / Sign JWT
      let token = '';
      try {
        token = await getServiceAccountAccessToken();
        results.steps.auth = {
          success: true,
          message: "Autenticação realizada com sucesso. Token JWT assinado."
        };
      } catch (authErr: any) {
        results.steps.auth = {
          success: false,
          error: `Falha na assinatura do JWT ou autenticação do token: ${authErr.message}`
        };
        return res.json(results);
      }

      // Step 2: Access Root Folder
      try {
        const metaRes = await fetch(`https://www.googleapis.com/drive/v3/files/${rootId}?fields=id,name,mimeType,capabilities&supportsAllDrives=true`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (!metaRes.ok) {
          const errText = await metaRes.text();
          results.steps.rootFolder = {
            success: false,
            error: `Erro ao obter metadados da pasta raiz (ID: ${rootId}) no Google Drive: ${errText}`
          };
          return res.json(results);
        }

        const meta = await metaRes.json() as any;
        results.steps.rootFolder = {
          success: true,
          folderName: meta.name,
          mimeType: meta.mimeType,
          capabilities: meta.capabilities
        };
      } catch (folderErr: any) {
        results.steps.rootFolder = {
          success: false,
          error: `Falha de rede ou API ao recuperar dados da pasta raiz: ${folderErr.message}`
        };
        return res.json(results);
      }

      // Step 3: Write permission test (create subfolder)
      try {
        const testName = `TEST_DIAGNOSTICS_${Date.now()}`;
        const createRes = await fetch('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: testName,
            mimeType: 'application/vnd.google-apps.folder',
            parents: [rootId]
          }),
        });

        if (!createRes.ok) {
          const errText = await createRes.text();
          results.steps.writeTest = {
            success: false,
            error: `Erro ao criar nova subpasta teste via API: ${errText}`
          };
        } else {
          const created = await createRes.json() as any;
          results.steps.writeTest = {
            success: true,
            message: `Subpasta de teste criada com sucesso (ID: ${created.id}). Permissões de escrita corretas.`
          };

          // Silent cleanup try (Attempts to trash first, then permanently delete for maximum compatibility)
          try {
            // 1. Move to Trash (supports Shared Drives where caller is Writer/Contributor but not Manager)
            await fetch(`https://www.googleapis.com/drive/v3/files/${created.id}?supportsAllDrives=true`, {
              method: 'PATCH',
              headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ trashed: true }),
            });

            // 2. Try permanent deletion (requires Manager status on Shared Drives, runs as best-effort)
            await fetch(`https://www.googleapis.com/drive/v3/files/${created.id}?supportsAllDrives=true`, {
              method: 'DELETE',
              headers: { Authorization: `Bearer ${token}` }
            });
          } catch (delErr) {
            console.warn('Silent cleanup failed for diagnostics folder ID:', created.id, delErr);
            // ignore
          }
        }
      } catch (writeErr: any) {
        results.steps.writeTest = {
          success: false,
          error: `Erro durante teste de permissão de escrita: ${writeErr.message}`
        };
      }

      return res.json(results);
    } catch (error: any) {
      console.error("API /api/drive/diagnostics error:", error);
      return res.status(500).send(error.message || "Erro interno ao rodar diagnósticos.");
    }
  });

  // API Route for Overwriting Google Drive File Content
  app.post("/api/drive/update", async (req, res) => {
    try {
      const { fileIdOrUrl, fileBase64, fileType } = req.body;
      if (!fileIdOrUrl || !fileBase64) {
        return res.status(400).send("Faltam parâmetros obrigatórios para a atualização.");
      }

      const fileBuffer = Buffer.from(fileBase64, "base64");
      const success = await updateFileContent(fileIdOrUrl, fileBuffer, fileType);
      return res.json({ success });
    } catch (error: any) {
      console.error("API /api/drive/update error:", error);
      return res.status(500).send(error.message || "Erro interno ao atualizar arquivo no Google Drive.");
    }
  });

  // API Route for Deleting Google Drive Files cleanly
  app.post("/api/drive/delete", async (req, res) => {
    try {
      const { fileIdOrUrl } = req.body;
      if (!fileIdOrUrl) {
        return res.status(400).send("Falta o parâmetro fileIdOrUrl.");
      }

      const success = await deleteFile(fileIdOrUrl);
      return res.json({ success });
    } catch (error: any) {
      console.error("API /api/drive/delete error:", error);
      return res.status(500).send(error.message || "Erro interno ao excluir arquivo no Google Drive.");
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: { server: httpServer }
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Render Self-Ping scheduler to keep the Render free-tier instance alive with adaptive ranges
  const startSelfPing = () => {
    const RENDER_URL = process.env.RENDER_EXTERNAL_URL || "https://gestao-pessoas.onrender.com";
    if (!RENDER_URL) {
      console.log("[Self-Ping] RENDER_EXTERNAL_URL or fallback is empty. Skipping self-ping setup.");
      return;
    }

    console.log(`[Self-Ping] Inicializado dinamicamente. Alvo: ${RENDER_URL}/api/ping`);

    const triggerNextPing = () => {
      let hour = 12;
      let minute = 0;

      try {
        const options: Intl.DateTimeFormatOptions = {
          timeZone: "America/Sao_Paulo",
          hour12: false,
          hour: "2-digit",
          minute: "2-digit"
        };
        const formatter = new Intl.DateTimeFormat("en-US", options);
        const parts = formatter.format(new Date()).split(":");
        hour = parseInt(parts[0], 10);
        minute = parseInt(parts[1], 10);
      } catch (e) {
        const d = new Date();
        hour = d.getHours();
        minute = d.getMinutes();
      }

      // Calculate minutes since midnight for the America/Sao_Paulo timezone
      const currentMinutes = hour * 60 + minute;
      const startMinutes = 7 * 60;   // 07:00 AM
      const endMinutes = 21 * 60;     // 21:00 PM

      // High frequency window: 07:00 AM to 21:00 PM (inclusive)
      const isHighFrequency = currentMinutes >= startMinutes && currentMinutes <= endMinutes;
      const delayMinutes = isHighFrequency ? 14 : 30;
      const delayMs = delayMinutes * 60 * 1000;

      setTimeout(async () => {
        try {
          const modeLabel = isHighFrequency ? "Alta Frequência (07h às 21h)" : "Baixa Frequência (21h01 às 06h59)";
          console.log(`[Self-Ping] Enviando ping a ${RENDER_URL}/api/ping para manter ativo... [Modo: ${modeLabel}]`);
          const response = await fetch(`${RENDER_URL}/api/ping`);
          console.log(`[Self-Ping] Ping respondido com sucesso! Status: ${response.status}`);
        } catch (err: any) {
          console.error(`[Self-Ping] Erro ao enviar ping para manter ativo:`, err.message || err);
        }
        // Recursively trigger the next dynamic ping
        triggerNextPing();
      }, delayMs);

      const nextTarget = new Date(Date.now() + delayMs);
      const nextTimeStr = nextTarget.toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo" });
      console.log(`[Self-Ping] Próximo ping agendado para as ${nextTimeStr} (Em ${delayMinutes} minutos)`);
    };

    // Trigger the initial scheduler loop immediately
    triggerNextPing();
  };

  // Inicia o self-ping em produção
  if (process.env.NODE_ENV === "production" || process.env.RENDER_EXTERNAL_URL) {
    startSelfPing();
  }
}

// Start the full-stack server
startServer().catch((error) => {
  console.error("Erro fatal ao inicializar o servidor Express:", error);
});
