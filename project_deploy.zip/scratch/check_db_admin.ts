import * as admin from 'firebase-admin';
import * as dotenv from 'dotenv';
import * as path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const serviceAccountEmail = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_EMAIL || '';
let privateKey = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY || '';

// Clean the private key
privateKey = privateKey.trim();
privateKey = privateKey.replace(/^["']|["']$/g, '');
privateKey = privateKey.replace(/\\n/g, '\n');
privateKey = privateKey.replace(/\\r/g, '\r');

const projectId = process.env.VITE_FIREBASE_PROJECT_ID || '';
const databaseId = process.env.VITE_FIREBASE_DATABASE_ID || '';

console.log("Config admin:", { projectId, serviceAccountEmail, databaseId });

admin.initializeApp({
  credential: admin.credential.cert({
    projectId,
    clientEmail: serviceAccountEmail,
    privateKey,
  }),
  databaseURL: `https://${projectId}.firebaseio.com`
});

// Use named database if specified
const db = databaseId && databaseId !== '(default)' 
  ? admin.firestore(admin.app()) 
  : admin.firestore();

if (databaseId && databaseId !== '(default)') {
  // Set databaseId on the client if supported, or try to configure it.
  // In firebase-admin, to select a different database, you can do:
  // db = admin.firestore().database(databaseId) or similar.
  // Actually, we can get firestore for a specific database using admin.firestore(app, databaseId) if supported,
  // or we can just access it. Let's see: in v11+, firestore has a method or constructor.
  // Let's print out what db is.
}

async function check() {
  // Let's get firestore client with databaseId:
  const firestoreClient = (admin.app().firestore as any)(databaseId);
  
  console.log("Fetching interns...");
  const internsSnap = await firestoreClient.collection('interns').get();
  console.log(`Found ${internsSnap.size} interns.`);
  internsSnap.forEach((doc: any) => {
    console.log(`Intern ID: ${doc.id}, data:`, doc.data());
  });

  console.log("Fetching frequencies...");
  const freqSnap = await firestoreClient.collection('frequencies').get();
  console.log(`Found ${freqSnap.size} frequencies.`);
  freqSnap.forEach((doc: any) => {
    console.log(`Freq ID: ${doc.id}, data:`, doc.data());
  });

  console.log("Fetching sectors...");
  const sectorsSnap = await firestoreClient.collection('sectors').get();
  sectorsSnap.forEach((doc: any) => {
    console.log(`Sector ID: ${doc.id}, data:`, doc.data());
  });

  console.log("Fetching mappings...");
  const mappingsSnap = await firestoreClient.collection('sector_mappings').get();
  mappingsSnap.forEach((doc: any) => {
    console.log(`Mapping ID: ${doc.id}, data:`, doc.data());
  });
}

check().catch(console.error);
