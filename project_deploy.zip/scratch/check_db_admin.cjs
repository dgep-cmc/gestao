const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const serviceAccountEmail = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_EMAIL || '';
let privateKey = process.env.VITE_GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY || '';

// Clean the private key
privateKey = privateKey.trim();
privateKey = privateKey.replace(/^["']|["']$/g, '');
privateKey = privateKey.replace(/\\n/g, '\n');
privateKey = privateKey.replace(/\\r/g, '\r');

const projectId = process.env.VITE_FIREBASE_PROJECT_ID || '';
const databaseId = process.env.VITE_FIREBASE_DATABASE_ID || '';

console.log("Config admin:", { projectId, serviceAccountEmail, databaseId });

const app = admin.initializeApp({
  credential: admin.credential.cert({
    projectId,
    clientEmail: serviceAccountEmail,
    privateKey,
  }),
  databaseURL: `https://${projectId}.firebaseio.com`
});

// Use named database
const db = databaseId && databaseId !== '(default)' 
  ? getFirestore(app, databaseId)
  : getFirestore(app);

async function check() {
  console.log("Fetching interns...");
  const internsSnap = await db.collection('interns').get();
  console.log(`Found ${internsSnap.size} interns.`);
  internsSnap.forEach((doc) => {
    console.log(`Intern ID: ${doc.id}, data:`, doc.data());
  });

  console.log("Fetching frequencies...");
  const freqSnap = await db.collection('frequencies').get();
  console.log(`Found ${freqSnap.size} frequencies.`);
  freqSnap.forEach((doc) => {
    console.log(`Freq ID: ${doc.id}, data:`, doc.data());
  });

  console.log("Fetching sectors...");
  const sectorsSnap = await db.collection('sectors').get();
  sectorsSnap.forEach((doc) => {
    console.log(`Sector ID: ${doc.id}, data:`, doc.data());
  });

  console.log("Fetching mappings...");
  const mappingsSnap = await db.collection('sector_mappings').get();
  mappingsSnap.forEach((doc) => {
    console.log(`Mapping ID: ${doc.id}, data:`, doc.data());
  });
}

check().catch(console.error);
