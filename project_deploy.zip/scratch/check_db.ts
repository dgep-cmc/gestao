import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import * as dotenv from 'dotenv';
import * as path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY || '',
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: process.env.VITE_FIREBASE_APP_ID || '',
};

const databaseId = process.env.VITE_FIREBASE_DATABASE_ID || '(default)';

console.log("Config:", { projectId: firebaseConfig.projectId, databaseId });

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, databaseId);

async function check() {
  console.log("Fetching interns...");
  const internsSnap = await getDocs(collection(db, 'interns'));
  console.log(`Found ${internsSnap.size} interns.`);
  internsSnap.docs.forEach(doc => {
    const data = doc.data();
    console.log(`Intern ID: ${doc.id}, Name: ${data.internName}, Lotacao: ${data.lotacao}, Admissao: ${data.dataAdmissao}`);
  });

  console.log("Fetching frequencies...");
  const freqSnap = await getDocs(collection(db, 'frequencies'));
  console.log(`Found ${freqSnap.size} frequencies.`);
  freqSnap.docs.forEach(doc => {
    const data = doc.data();
    console.log(`Freq ID: ${doc.id}, Name: ${data.internName}, Lotacao: ${data.lotacao}, Status: ${data.status}`);
  });
}

check().catch(console.error);
