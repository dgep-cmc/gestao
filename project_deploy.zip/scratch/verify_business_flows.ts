import * as assert from 'assert';

console.log("🧪 Iniciando simulações e validações do fluxo de Fechamento de Frequências e Contratação...");

// ----------------------------------------------------
// 1. Simulação do Fluxo de Fechamento de Frequências
// ----------------------------------------------------
function testFrequencyClosureFlow() {
  console.log("\n1. Testando Fluxo de Fechamento de Frequências...");
  
  // Regra de validação simulada da UI (App.tsx:682 e seguintes)
  const validateFrequencySubmission = (record: any, details: any, todayStr: string) => {
    if (!details) {
      throw new Error("Dados não encontrados para o servidor.");
    }
    
    // Bloqueio se o período final for hoje ou posterior (futuro)
    if (details.endDate && details.endDate >= todayStr) {
      return { success: false, reason: "Bloqueio de Envio: Tentativa de enviar data posterior a hoje." };
    }

    if (!details.periodo || !details.periodo.trim()) {
      return { success: false, reason: "Dados Incompletos: Falta Período de Referência." };
    }

    if (details.presenca === 'parcial') {
      const valFalta = parseFloat(details.falta || '0') || 0;
      const valAtestados = parseFloat(details.atestados || '0') || 0;
      const valRecesso = parseFloat(details.recesso || '0') || 0;

      if (valFalta === 0 && valAtestados === 0 && valRecesso === 0) {
        return { success: false, reason: "Ausência de Ocorrências: Preencha pelo menos uma ocorrência para presença parcial." };
      }

      if (valFalta > 0 && (!details.datasFalta || !details.datasFalta.trim())) {
        return { success: false, reason: "Datas da Falta Não Informadas." };
      }

      if (valAtestados > 0) {
        if (!details.datasAtestados || !details.datasAtestados.trim()) {
          return { success: false, reason: "Datas do Atestado Não Informadas." };
        }
        if (!details.atestadoFiles || details.atestadoFiles.length === 0) {
          return { success: false, reason: "Atestado Médico Obrigatório: Necessário anexar documento." };
        }
      }
    }

    return { success: true };
  };

  const today = "2026-06-05";

  // Cenário A: Sucesso (Fechamento de Maio concluído)
  const okDetails = {
    periodo: "01/05 a 31/05",
    startDate: "2026-05-01",
    endDate: "2026-05-31",
    presenca: "integral"
  };
  const resA = validateFrequencySubmission({ internName: "Joao" }, okDetails, today);
  assert.strictEqual(resA.success, true);
  console.log("  ✅ Cenário A (Presença Integral Passado): Sucesso esperado!");

  // Cenário B: Erro por data futura (Tentando fechar Junho antes do fim do mês)
  const futureDetails = {
    periodo: "01/06 a 30/06",
    startDate: "2026-06-01",
    endDate: "2026-06-30",
    presenca: "integral"
  };
  const resB = validateFrequencySubmission({ internName: "Joao" }, futureDetails, today);
  assert.strictEqual(resB.success, false);
  assert.ok(resB.reason?.includes("Bloqueio de Envio"));
  console.log("  ✅ Cenário B (Período Futuro Bloqueado): Sucesso esperado!");

  // Cenário C: Erro por presença parcial sem justificativas preenchidas
  const invalidParcialDetails = {
    periodo: "01/05 a 31/05",
    startDate: "2026-05-01",
    endDate: "2026-05-31",
    presenca: "parcial",
    falta: "2",
    datasFalta: "" // sem datas indicadas
  };
  const resC = validateFrequencySubmission({ internName: "Joao" }, invalidParcialDetails, today);
  assert.strictEqual(resC.success, false);
  assert.ok(resC.reason?.includes("Datas da Falta"));
  console.log("  ✅ Cenário C (Falta parcial sem datas): Sucesso esperado!");

  // Cenário D: Erro por falta de atestado anexado
  const missingAtestadoDetails = {
    periodo: "01/05 a 31/05",
    startDate: "2026-05-01",
    endDate: "2026-05-31",
    presenca: "parcial",
    atestados: "1",
    datasAtestados: "12/05",
    atestadoFiles: [] // vazio
  };
  const resD = validateFrequencySubmission({ internName: "Joao" }, missingAtestadoDetails, today);
  assert.strictEqual(resD.success, false);
  assert.ok(resD.reason?.includes("Atestado Médico Obrigatório"));
  console.log("  ✅ Cenário D (Atestado sem arquivo anexo): Sucesso esperado!");
}

// ----------------------------------------------------
// 2. Simulação do Fluxo de Contratação (Hiring)
// ----------------------------------------------------
function testHiringFlow() {
  console.log("\n2. Testando Fluxo de Contratação...");

  // Máquina de estados simulada das regras de negócio do Hiring (hiringService.ts)
  const getNextHiringStatus = (currentStatus: string, action: 'save_draft' | 'submit_request' | 'supervisor_sign' | 'student_sign' | 'dgep_approve' | 'dgep_reject') => {
    switch (currentStatus) {
      case 'draft':
        if (action === 'save_draft') return 'draft';
        if (action === 'submit_request') return 'pending';
        break;
      case 'pending':
        if (action === 'supervisor_sign') return 'supervisor_signed';
        break;
      case 'supervisor_signed':
        if (action === 'student_sign') return 'submitted'; // Ambas as assinaturas prontas
        break;
      case 'submitted':
        if (action === 'dgep_approve') return 'approved';
        if (action === 'dgep_reject') return 'rejected';
        break;
      case 'rejected':
        if (action === 'save_draft') return 'draft'; // Volta a rascunho para correção
        break;
    }
    return currentStatus; // Sem transição válida
  };

  // Simular transição completa
  let status = 'draft';
  console.log(`  - Estado inicial: ${status}`);

  status = getNextHiringStatus(status, 'submit_request');
  assert.strictEqual(status, 'pending');
  console.log(`  - Submetido pelo Gestor: ${status}`);

  status = getNextHiringStatus(status, 'supervisor_sign');
  assert.strictEqual(status, 'supervisor_signed');
  console.log(`  - Supervisor assinou: ${status}`);

  status = getNextHiringStatus(status, 'student_sign');
  assert.strictEqual(status, 'submitted');
  console.log(`  - Estudante assinou: ${status} (Aguardando DGEP)`);

  status = getNextHiringStatus(status, 'dgep_approve');
  assert.strictEqual(status, 'approved');
  console.log(`  - DGEP Aprovou: ${status} (Termo assinado e ativo!)`);

  console.log("  ✅ Fluxo de Estados da Contratação OK!");
}

try {
  testFrequencyClosureFlow();
  testHiringFlow();
  console.log("\n🎉 Fase 4: Validação lógica dos fluxos concluída com sucesso!");
} catch (e) {
  console.error("❌ Falha nos testes de validação dos fluxos:", e);
  process.exit(1);
}
