import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, writeBatch } from 'firebase/firestore';
import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';

// Carrega variáveis do .env
dotenv.config();

const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY || '',
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: process.env.VITE_FIREBASE_APP_ID || '',
};

console.log("Inicializando Firebase com o Projeto:", firebaseConfig.projectId);
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

function parseCSV(filePath: string): any[] {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');
  const headers = lines[0].split(';').map(h => h.trim().replace(/^\uFEFF/, '')); // Remove BOM se houver
  
  const results: any[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const values = line.split(';').map(v => v.trim());
    const row: any = {};
    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });
    results.push(row);
  }
  return results;
}

async function importEstagiarios() {
  const filePath = path.join(process.cwd(), 'estagiarios_maio.csv');
  if (!fs.existsSync(filePath)) {
    console.error("Arquivo estagiarios_maio.csv não encontrado.");
    return;
  }

  console.log("Lendo estagiarios_maio.csv...");
  const rows = parseCSV(filePath);
  console.log(`Encontrados ${rows.length} estagiários.`);

  const batch = writeBatch(db);
  rows.forEach(row => {
    const matricula = row['Matrícula'];
    const nome = row['Nome do servidor'];
    const lotacao = row['Lotação'];
    const nivel = row['Nível'] || 'Superior';
    const admissao = row['Data de admissão'];
    const rescisao = row['Data de rescisão'] || '';

    if (!nome) return;

    let mappedNivel: 'Ensino Médio' | 'Ensino Superior' | 'Pós Graduação' = 'Ensino Superior';
    const valNivel = nivel.toLowerCase();
    if (valNivel.includes('medio') || valNivel.includes('médio') || valNivel.includes('tecnico') || valNivel.includes('técnico')) {
      mappedNivel = 'Ensino Médio';
    } else if (valNivel.includes('pos') || valNivel.includes('pós') || valNivel.includes('gradua') || valNivel.includes('especializa')) {
      mappedNivel = 'Pós Graduação';
    }

    const docId = matricula || nome.toLowerCase().replace(/[^a-z0-9]/g, '');
    const docRef = doc(db, 'interns', docId);
    
    batch.set(docRef, {
      matricula: docId,
      internName: nome,
      lotacao,
      categoria: mappedNivel,
      dataAdmissao: admissao,
      dataRescisao: rescisao,
      recessoOriginal: '',
      importMonth: 5,
      importYear: 2026
    }, { merge: true });
  });

  await batch.commit();
  console.log("Estagiários importados com sucesso!");
}

async function importComissionados() {
  const filePath = path.join(process.cwd(), 'comissionados_maio.csv');
  if (!fs.existsSync(filePath)) {
    console.error("Arquivo comissionados_maio.csv não encontrado.");
    return;
  }

  console.log("Lendo comissionados_maio.csv...");
  const rows = parseCSV(filePath);
  console.log(`Encontrados ${rows.length} comissionados.`);

  // O limite de batch no firestore é de 500 operações. Como comissionados são ~350, cabe em um único batch.
  const batch = writeBatch(db);
  rows.forEach(row => {
    const matricula = row['Matrícula'];
    const nome = row['Nome do servidor'];
    const lotacao = row['Lotação'];
    const cargo = row['Cargo'] || '';
    const admissao = row['Data de admissão'];
    const rescisao = row['Data de rescisão'] || '';
    const feriasInicio = row['Férias Início'] || '';
    const feriasFim = row['Férias Fim'] || '';
    
    let feriasStr = '';
    if (feriasInicio && feriasFim) {
      feriasStr = `${feriasInicio} a ${feriasFim}`;
    }

    if (!nome) return;

    const docId = matricula || nome.toLowerCase().replace(/[^a-z0-9]/g, '');
    const docRef = doc(db, 'comissionados', docId);

    batch.set(docRef, {
      matricula: docId,
      internName: nome,
      lotacao,
      cargo,
      dataAdmissao: admissao,
      dataRescisao: rescisao,
      ferias: feriasStr,
      importMonth: 5,
      importYear: 2026
    }, { merge: true });
  });

  await batch.commit();
  console.log("Comissionados importados com sucesso!");
}

async function main() {
  try {
    await importEstagiarios();
    await importComissionados();
    console.log("Tudo pronto! Banco de testes populado para Maio/2026.");
  } catch (err) {
    console.error("Erro na importação:", err);
  }
}

main();
