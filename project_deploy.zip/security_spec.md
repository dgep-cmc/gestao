# Security Spec - Frequência Estagiários CMC

## Data Invariants
- A user must have a role (master or manager).
- A FrequencyRecord must belong to a specific month and year.
- Managers can only see and confirm frequency for interns in their assigned sector.
- Master users (DGEP) have full control over sectors, users, and frequency data.

## Identity, Integrity, and State Payloads (The Dirty Dozen)
1. **Identity Spoofing**: A manager trying to update a frequency record for a different sector.
2. **Identity Spoofing**: A user trying to set their own role to 'master' during registration.
3. **Integrity Violation**: An admin uploading a CSV with invalid data types (e.g., month = "March" instead of 3).
4. **Integrity Violation**: A manager changing the `internName` or `lotacao` of an existing record.
5. **State Shortcut**: A manager trying to "un-submit" a record once it's finalized (if we implement a final state logic).
6. **Access Violation**: An unauthenticated user reading any frequency data.
7. **Access Violation**: A manager reading the list of all users.
8. **Privilege Escalation**: A manager setting their own `sectorName` to bypass restrictions.
9. **Resource Poisoning**: Uploading a record with a massive string for `internName`.
10. **Resource Poisoning**: Using a document ID that is a 2KB string.
11. **Relational Sync**: Submitting a frequency for a non-existent intern/record.
12. **PII Leak**: A manager reading private details of other managers.

## Test Runner Plan
I will implement `firestore.rules` and verify them via code review and implementation logic.
