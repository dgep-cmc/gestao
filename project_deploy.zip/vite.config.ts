// Deployment trigger - 2026-05-15
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  return {
    base: './',
    plugins: [react(), tailwindcss()],
    optimizeDeps: {
      include: ['react-signature-canvas', 'trim-canvas', 'prop-types']
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true,
      target: 'es2022',
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
